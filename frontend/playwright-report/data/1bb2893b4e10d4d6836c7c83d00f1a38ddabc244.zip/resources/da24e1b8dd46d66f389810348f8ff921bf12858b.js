import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Profile/index.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=41a64c35";
import api from "/src/services/api.js";
import { useAuth } from "/src/context/AuthContext.jsx";
var _jsxFileName = "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Profile/index.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=41a64c35";
var _s = $RefreshSig$();
export default function Profile() {
	_s();
	const { authConfig, showError, showMessage, session, updateSession } = useAuth();
	const [profile, setProfile] = useState(null);
	const [toggling2FA, setToggling2FA] = useState(false);
	useEffect(() => {
		const fetchProfile = async () => {
			try {
				const response = await api.get("/auth/profile", authConfig());
				setProfile(response.data);
			} catch (err) {
				showError("No se pudo cargar la información del perfil");
			}
		};
		fetchProfile();
	}, []);
	const toggle2FA = async () => {
		if (!profile) return;
		setToggling2FA(true);
		try {
			const newState = !profile.doble_factor_activo;
			const response = await api.put("/auth/profile/2fa", { activo: newState }, authConfig());
			setProfile({
				...profile,
				doble_factor_activo: response.data.doble_factor_activo
			});
			showMessage(response.data.mensaje || "Ajustes de seguridad actualizados");
			// Update session if it holds this data
			if (session?.usuario) {
				updateSession({
					...session,
					usuario: {
						...session.usuario,
						doble_factor_activo: response.data.doble_factor_activo
					}
				});
			}
		} catch (err) {
			showError("No se pudo actualizar el estado de 2FA");
		} finally {
			setToggling2FA(false);
		}
	};
	if (!profile) return /* @__PURE__ */ _jsxDEV("div", {
		className: "p-8 text-center text-sm font-medium text-slate-500 dark:text-slate-400",
		children: "Cargando perfil..."
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 43,
		columnNumber: 24
	}, this);
	const fullName = [
		profile.nombre,
		profile.primer_apellido,
		profile.segundo_apellido
	].filter(Boolean).join(" ");
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
		className: "mb-6",
		children: [/* @__PURE__ */ _jsxDEV("h2", {
			className: "text-2xl font-bold text-slate-800 dark:text-white",
			children: "Perfil de Usuario"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 50,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("p", {
			className: "text-sm font-medium text-slate-500 dark:text-slate-400",
			children: "Gestiona tus datos personales y ajustes de seguridad."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 51,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 49,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV("div", {
		className: "grid grid-cols-1 gap-6 md:grid-cols-2",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "rounded-2xl border border-slate-200 dark:border-[#313D4A] bg-white dark:bg-[#24303F] shadow-sm overflow-hidden",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "border-b border-slate-200 dark:border-[#313D4A] px-7 py-5",
				children: /* @__PURE__ */ _jsxDEV("h3", {
					className: "text-lg font-bold text-slate-800 dark:text-white",
					children: "Información Personal"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 59,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 58,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col gap-5 p-7",
				children: [
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "mb-2 block text-sm font-medium text-slate-700 dark:text-slate-300",
						children: "Nombre Completo"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "w-full rounded-lg border border-slate-200 dark:border-[#313D4A] bg-slate-50 dark:bg-[#1A222C] px-4 py-2.5 text-slate-800 dark:text-white font-medium",
						children: fullName
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 64,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "mb-2 block text-sm font-medium text-slate-700 dark:text-slate-300",
						children: "Correo Electrónico"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "w-full rounded-lg border border-slate-200 dark:border-[#313D4A] bg-slate-50 dark:bg-[#1A222C] px-4 py-2.5 text-slate-800 dark:text-white font-medium",
						children: profile.correo
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "mb-2 block text-sm font-medium text-slate-700 dark:text-slate-300",
						children: "Rol de Acceso"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 77,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "w-full rounded-lg border border-slate-200 dark:border-[#313D4A] bg-slate-50 dark:bg-[#1A222C] px-4 py-2.5 text-slate-800 dark:text-white font-medium",
						children: profile.sigla_rol === "ADM" ? "Administrador" : "Operador"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 76,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 57,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "rounded-2xl border border-slate-200 dark:border-[#313D4A] bg-white dark:bg-[#24303F] shadow-sm overflow-hidden",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "border-b border-slate-200 dark:border-[#313D4A] px-7 py-5",
				children: /* @__PURE__ */ _jsxDEV("h3", {
					className: "text-lg font-bold text-slate-800 dark:text-white",
					children: "Seguridad"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 88,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 87,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col gap-6 p-7",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
					className: "mb-1 text-sm font-bold text-slate-800 dark:text-white",
					children: "Autenticación de Dos Factores (2FA)"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 92,
					columnNumber: 15
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-sm font-medium text-slate-500 dark:text-slate-400",
					children: "Protege tu cuenta con un código temporal enviado a tu correo en cada inicio de sesión."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 93,
					columnNumber: 15
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 91,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between rounded-lg border border-slate-200 dark:border-[#313D4A] bg-slate-50 dark:bg-[#1A222C] p-4",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
						className: "font-semibold text-slate-800 dark:text-white",
						children: "Estado del 2FA"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 98,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: `text-sm font-medium ${profile.doble_factor_activo ? "text-emerald-600 dark:text-emerald-400" : "text-slate-500 dark:text-slate-400"}`,
						children: profile.doble_factor_activo ? "Activado" : "Desactivado"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 17
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 97,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("label", {
						className: "relative inline-flex cursor-pointer items-center",
						children: [/* @__PURE__ */ _jsxDEV("input", {
							type: "checkbox",
							className: "peer sr-only",
							checked: profile.doble_factor_activo || false,
							onChange: toggle2FA,
							disabled: toggling2FA
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 104,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("div", { className: "peer h-6 w-11 rounded-full bg-slate-200 dark:bg-[#313D4A] after:absolute after:left-[2px] after:top-[2px] after:h-5 after:w-5 after:rounded-full after:border after:border-slate-300 dark:after:border-[#24303F] after:bg-white after:transition-all after:content-[''] peer-checked:bg-blue-600 peer-checked:after:translate-x-full peer-checked:after:border-white peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800/50 disabled:opacity-50" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 111,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 103,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 96,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 90,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 86,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 54,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 48,
		columnNumber: 5
	}, this);
}
_s(Profile, "DM8h/mfyBvtpR03Ts/F7/YUkyMo=", false, function() {
	return [useAuth];
});
_c = Profile;
var _c;
$RefreshReg$(_c, "Profile");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Profile/index.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Profile/index.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Profile/index.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Profile/index.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLGlCQUFpQjtBQUNwQyxPQUFPLFNBQVM7QUFDaEIsU0FBUyxlQUFlOzs7O0FBRXhCLGVBQWUsU0FBUyxVQUFVOztDQUNoQyxNQUFNLEVBQUUsWUFBWSxXQUFXLGFBQWEsU0FBUyxrQkFBa0IsUUFBUTtDQUMvRSxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsSUFBSTtDQUMzQyxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxLQUFLO0NBRXBELGdCQUFnQjtFQUNkLE1BQU0sZUFBZSxZQUFZO0dBQy9CLElBQUk7SUFDRixNQUFNLFdBQVcsTUFBTSxJQUFJLElBQUksaUJBQWlCLFdBQVcsQ0FBQztJQUM1RCxXQUFXLFNBQVMsSUFBSTtHQUMxQixTQUFTLEtBQUs7SUFDWixVQUFVLDZDQUE2QztHQUN6RDtFQUNGO0VBQ0EsYUFBYTtDQUNmLEdBQUcsQ0FBQyxDQUFDO0NBRUwsTUFBTSxZQUFZLFlBQVk7RUFDNUIsSUFBSSxDQUFDLFNBQVM7RUFDZCxlQUFlLElBQUk7RUFDbkIsSUFBSTtHQUNGLE1BQU0sV0FBVyxDQUFDLFFBQVE7R0FDMUIsTUFBTSxXQUFXLE1BQU0sSUFBSSxJQUFJLHFCQUFxQixFQUFFLFFBQVEsU0FBUyxHQUFHLFdBQVcsQ0FBQztHQUV0RixXQUFXO0lBQUUsR0FBRztJQUFTLHFCQUFxQixTQUFTLEtBQUs7R0FBb0IsQ0FBQztHQUNqRixZQUFZLFNBQVMsS0FBSyxXQUFXLG1DQUFtQzs7R0FHeEUsSUFBSSxTQUFTLFNBQVM7SUFDcEIsY0FBYztLQUFFLEdBQUc7S0FBUyxTQUFTO01BQUUsR0FBRyxRQUFRO01BQVMscUJBQXFCLFNBQVMsS0FBSztLQUFvQjtJQUFFLENBQUM7R0FDdkg7RUFDRixTQUFTLEtBQUs7R0FDWixVQUFVLHdDQUF3QztFQUNwRCxVQUFVO0dBQ1IsZUFBZSxLQUFLO0VBQ3RCO0NBQ0Y7Q0FFQSxJQUFJLENBQUMsU0FBUyxPQUFPLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQXlFO0NBQXVCOzs7OztDQUVwSSxNQUFNLFdBQVc7RUFBQyxRQUFRO0VBQVEsUUFBUTtFQUFpQixRQUFRO0NBQWdCLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztDQUU3RyxPQUNFLGdEQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FDRSx3QkFBQyxNQUFEO0dBQUksV0FBVTthQUFvRDtFQUFxQjs7OztZQUN2Rix3QkFBQyxLQUFEO0dBQUcsV0FBVTthQUF5RDtFQUF3RDs7OztVQUMzSDs7Ozs7V0FFTCx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBR0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBbUQ7SUFBd0I7Ozs7O0dBQ3RGOzs7O2FBQ0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBb0U7S0FBc0I7Ozs7ZUFDM0csd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1o7S0FDRTs7OzthQUNGOzs7OztLQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBb0U7S0FBeUI7Ozs7ZUFDOUcsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1osUUFBUTtLQUNOOzs7O2FBQ0Y7Ozs7O0tBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUFvRTtLQUFvQjs7OztlQUN6Ryx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDWixRQUFRLGNBQWMsUUFBUSxrQkFBa0I7S0FDOUM7Ozs7YUFDRjs7Ozs7SUFDRjs7Ozs7V0FDRjs7Ozs7WUFHTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFtRDtJQUFhOzs7OztHQUMzRTs7OzthQUNMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBd0Q7SUFBdUM7Ozs7Y0FDN0csd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBeUQ7SUFBeUY7Ozs7WUFDNUo7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUErQztLQUFpQjs7OztlQUM3RSx3QkFBQyxLQUFEO01BQUcsV0FBVyx1QkFBdUIsUUFBUSxzQkFBc0IsMkNBQTJDO2dCQUMzRyxRQUFRLHNCQUFzQixhQUFhO0tBQzNDOzs7O2FBQ0E7Ozs7ZUFDTCx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBakIsQ0FDRSx3QkFBQyxTQUFEO09BQ0UsTUFBSztPQUNMLFdBQVU7T0FDVixTQUFTLFFBQVEsdUJBQXVCO09BQ3hDLFVBQVU7T0FDVixVQUFVO01BQ1g7Ozs7Z0JBQ0Qsd0JBQUMsT0FBRCxFQUFLLFdBQVUsK2RBQW9lOzs7O2NBQzllOzs7OzthQUNKOzs7OztZQUNGOzs7OztXQUNGOzs7OztVQUVGOzs7OztTQUNMOzs7OztBQUVOIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgYXBpIGZyb20gJy4uLy4uL3NlcnZpY2VzL2FwaSdcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi8uLi9jb250ZXh0L0F1dGhDb250ZXh0J1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQcm9maWxlKCkge1xuICBjb25zdCB7IGF1dGhDb25maWcsIHNob3dFcnJvciwgc2hvd01lc3NhZ2UsIHNlc3Npb24sIHVwZGF0ZVNlc3Npb24gfSA9IHVzZUF1dGgoKVxuICBjb25zdCBbcHJvZmlsZSwgc2V0UHJvZmlsZV0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbdG9nZ2xpbmcyRkEsIHNldFRvZ2dsaW5nMkZBXSA9IHVzZVN0YXRlKGZhbHNlKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgZmV0Y2hQcm9maWxlID0gYXN5bmMgKCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KCcvYXV0aC9wcm9maWxlJywgYXV0aENvbmZpZygpKVxuICAgICAgICBzZXRQcm9maWxlKHJlc3BvbnNlLmRhdGEpXG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgc2hvd0Vycm9yKCdObyBzZSBwdWRvIGNhcmdhciBsYSBpbmZvcm1hY2nDs24gZGVsIHBlcmZpbCcpXG4gICAgICB9XG4gICAgfVxuICAgIGZldGNoUHJvZmlsZSgpXG4gIH0sIFtdKVxuXG4gIGNvbnN0IHRvZ2dsZTJGQSA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAoIXByb2ZpbGUpIHJldHVyblxuICAgIHNldFRvZ2dsaW5nMkZBKHRydWUpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IG5ld1N0YXRlID0gIXByb2ZpbGUuZG9ibGVfZmFjdG9yX2FjdGl2b1xuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucHV0KCcvYXV0aC9wcm9maWxlLzJmYScsIHsgYWN0aXZvOiBuZXdTdGF0ZSB9LCBhdXRoQ29uZmlnKCkpXG4gICAgICBcbiAgICAgIHNldFByb2ZpbGUoeyAuLi5wcm9maWxlLCBkb2JsZV9mYWN0b3JfYWN0aXZvOiByZXNwb25zZS5kYXRhLmRvYmxlX2ZhY3Rvcl9hY3Rpdm8gfSlcbiAgICAgIHNob3dNZXNzYWdlKHJlc3BvbnNlLmRhdGEubWVuc2FqZSB8fCAnQWp1c3RlcyBkZSBzZWd1cmlkYWQgYWN0dWFsaXphZG9zJylcbiAgICAgIFxuICAgICAgLy8gVXBkYXRlIHNlc3Npb24gaWYgaXQgaG9sZHMgdGhpcyBkYXRhXG4gICAgICBpZiAoc2Vzc2lvbj8udXN1YXJpbykge1xuICAgICAgICB1cGRhdGVTZXNzaW9uKHsgLi4uc2Vzc2lvbiwgdXN1YXJpbzogeyAuLi5zZXNzaW9uLnVzdWFyaW8sIGRvYmxlX2ZhY3Rvcl9hY3Rpdm86IHJlc3BvbnNlLmRhdGEuZG9ibGVfZmFjdG9yX2FjdGl2byB9IH0pXG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzaG93RXJyb3IoJ05vIHNlIHB1ZG8gYWN0dWFsaXphciBlbCBlc3RhZG8gZGUgMkZBJylcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0VG9nZ2xpbmcyRkEoZmFsc2UpXG4gICAgfVxuICB9XG5cbiAgaWYgKCFwcm9maWxlKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJwLTggdGV4dC1jZW50ZXIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+Q2FyZ2FuZG8gcGVyZmlsLi4uPC9kaXY+XG4gIFxuICBjb25zdCBmdWxsTmFtZSA9IFtwcm9maWxlLm5vbWJyZSwgcHJvZmlsZS5wcmltZXJfYXBlbGxpZG8sIHByb2ZpbGUuc2VndW5kb19hcGVsbGlkb10uZmlsdGVyKEJvb2xlYW4pLmpvaW4oJyAnKVxuICBcbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlXCI+UGVyZmlsIGRlIFVzdWFyaW88L2gyPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5HZXN0aW9uYSB0dXMgZGF0b3MgcGVyc29uYWxlcyB5IGFqdXN0ZXMgZGUgc2VndXJpZGFkLjwvcD5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgZ2FwLTYgbWQ6Z3JpZC1jb2xzLTJcIj5cbiAgICAgICAgXG4gICAgICAgIHsvKiBJbmZvcm1hY2nDs24gUGVyc29uYWwgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIGJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIHNoYWRvdy1zbSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIHB4LTcgcHktNVwiPlxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZVwiPkluZm9ybWFjacOzbiBQZXJzb25hbDwvaDM+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC01IHAtN1wiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1iLTIgYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+Tm9tYnJlIENvbXBsZXRvPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gYmctc2xhdGUtNTAgZGFyazpiZy1bIzFBMjIyQ10gcHgtNCBweS0yLjUgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAge2Z1bGxOYW1lfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibWItMiBibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5Db3JyZW8gRWxlY3Ryw7NuaWNvPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gYmctc2xhdGUtNTAgZGFyazpiZy1bIzFBMjIyQ10gcHgtNCBweS0yLjUgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAge3Byb2ZpbGUuY29ycmVvfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibWItMiBibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5Sb2wgZGUgQWNjZXNvPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gYmctc2xhdGUtNTAgZGFyazpiZy1bIzFBMjIyQ10gcHgtNCBweS0yLjUgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAge3Byb2ZpbGUuc2lnbGFfcm9sID09PSAnQURNJyA/ICdBZG1pbmlzdHJhZG9yJyA6ICdPcGVyYWRvcid9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBTZWd1cmlkYWQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIGJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIHNoYWRvdy1zbSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIHB4LTcgcHktNVwiPlxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZVwiPlNlZ3VyaWRhZDwvaDM+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC02IHAtN1wiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cIm1iLTEgdGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlXCI+QXV0ZW50aWNhY2nDs24gZGUgRG9zIEZhY3RvcmVzICgyRkEpPC9oND5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+UHJvdGVnZSB0dSBjdWVudGEgY29uIHVuIGPDs2RpZ28gdGVtcG9yYWwgZW52aWFkbyBhIHR1IGNvcnJlbyBlbiBjYWRhIGluaWNpbyBkZSBzZXNpw7NuLjwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBiZy1zbGF0ZS01MCBkYXJrOmJnLVsjMUEyMjJDXSBwLTRcIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZVwiPkVzdGFkbyBkZWwgMkZBPC9wPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT17YHRleHQtc20gZm9udC1tZWRpdW0gJHtwcm9maWxlLmRvYmxlX2ZhY3Rvcl9hY3Rpdm8gPyAndGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAnIDogJ3RleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAnfWB9PlxuICAgICAgICAgICAgICAgICAge3Byb2ZpbGUuZG9ibGVfZmFjdG9yX2FjdGl2byA/ICdBY3RpdmFkbycgOiAnRGVzYWN0aXZhZG8nfVxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJyZWxhdGl2ZSBpbmxpbmUtZmxleCBjdXJzb3ItcG9pbnRlciBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8aW5wdXQgXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIiBcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInBlZXIgc3Itb25seVwiIFxuICAgICAgICAgICAgICAgICAgY2hlY2tlZD17cHJvZmlsZS5kb2JsZV9mYWN0b3JfYWN0aXZvIHx8IGZhbHNlfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RvZ2dsZTJGQX1cbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXt0b2dnbGluZzJGQX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGVlciBoLTYgdy0xMSByb3VuZGVkLWZ1bGwgYmctc2xhdGUtMjAwIGRhcms6YmctWyMzMTNENEFdIGFmdGVyOmFic29sdXRlIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmJvcmRlciBhZnRlcjpib3JkZXItc2xhdGUtMzAwIGRhcms6YWZ0ZXI6Ym9yZGVyLVsjMjQzMDNGXSBhZnRlcjpiZy13aGl0ZSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBhZnRlcjpjb250ZW50LVsnJ10gcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgcGVlci1mb2N1czpvdXRsaW5lLW5vbmUgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLWJsdWUtODAwLzUwIGRpc2FibGVkOm9wYWNpdHktNTBcIj48L2Rpdj5cbiAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgPC9kaXY+XG4gICAgPC8+XG4gIClcbn1cbiJdfQ==