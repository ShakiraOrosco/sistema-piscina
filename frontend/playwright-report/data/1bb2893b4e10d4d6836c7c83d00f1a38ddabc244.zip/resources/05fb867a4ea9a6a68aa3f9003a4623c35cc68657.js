import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/PrediccionPanel/index.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=41a64c35";
var _jsxFileName = "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/components/PrediccionPanel/index.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=41a64c35";
var _s = $RefreshSig$();
// Rangos máximos que usa el servicio LSTM (np.clip) para escalar las barras
const QUIMICOS = [
	{
		key: "aluminio_pred",
		nombre: "Sulfato de Aluminio",
		simbolo: "Al",
		max: 1e3,
		gradient: "from-sky-400 to-blue-600",
		soft: "bg-sky-50 dark:bg-sky-900/20 text-sky-600 dark:text-sky-300",
		desc: "Floculante · clarifica el agua"
	},
	{
		key: "cobre_pred",
		nombre: "Sulfato de Cobre",
		simbolo: "Cu",
		max: 1e3,
		gradient: "from-teal-400 to-emerald-600",
		soft: "bg-teal-50 dark:bg-teal-900/20 text-teal-600 dark:text-teal-300",
		desc: "Alguicida · controla algas"
	},
	{
		key: "cloro_pred",
		nombre: "Cloro",
		simbolo: "Cl",
		max: 200,
		gradient: "from-violet-400 to-fuchsia-600",
		soft: "bg-violet-50 dark:bg-violet-900/20 text-violet-600 dark:text-violet-300",
		desc: "Desinfectante · elimina bacterias"
	}
];
const FRANJAS_BASE = [
	"08:00",
	"12:00",
	"16:00"
];
export default function PrediccionPanel({ prediccion, detalle, dosisAplicadas, onPredecir }) {
	_s();
	const [prediciendo, setPrediciendo] = useState(false);
	const [destello, setDestello] = useState(false);
	const ultimaFecha = useRef(prediccion?.fecha_prediccion);
	// Micro-animación cuando llega una predicción nueva
	useEffect(() => {
		const fecha = prediccion?.fecha_prediccion;
		if (fecha && ultimaFecha.current && fecha !== ultimaFecha.current) {
			setDestello(true);
			const t = window.setTimeout(() => setDestello(false), 1400);
			ultimaFecha.current = fecha;
			return () => window.clearTimeout(t);
		}
		ultimaFecha.current = fecha;
	}, [prediccion?.fecha_prediccion]);
	const handlePredecir = async () => {
		if (!onPredecir) return;
		setPrediciendo(true);
		try {
			await onPredecir();
		} finally {
			setPrediciendo(false);
		}
	};
	const franjas = detalle?.franjas?.length ? detalle.franjas : FRANJAS_BASE.map((hora) => ({
		hora,
		capturada: false
	}));
	const capturadas = detalle?.franjas_capturadas ?? 0;
	const esFinal = detalle?.tipo === "final";
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "panel-prediccion-lstm",
		className: `relative mt-6 overflow-hidden rounded-2xl border bg-white dark:bg-[#24303F] p-7 shadow-sm transition-all duration-700 ${destello ? "border-violet-400 ring-4 ring-violet-400/25" : "border-slate-200 dark:border-[#313D4A]"}`,
		children: [
			/* @__PURE__ */ _jsxDEV("div", { className: "pointer-events-none absolute -right-24 -top-24 h-64 w-64 rounded-full bg-gradient-to-br from-violet-500/15 via-sky-400/10 to-transparent blur-2xl" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 79,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "relative mb-6 flex flex-wrap items-start justify-between gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-sky-500 text-white shadow-md shadow-violet-500/30",
						children: /* @__PURE__ */ _jsxDEV("svg", {
							width: "22",
							height: "22",
							viewBox: "0 0 24 24",
							fill: "none",
							xmlns: "http://www.w3.org/2000/svg",
							children: [/* @__PURE__ */ _jsxDEV("path", {
								d: "M9.5 2A2.5 2.5 0 0 0 7 4.5v.6A3 3 0 0 0 4.5 8a3 3 0 0 0 .4 1.5A3 3 0 0 0 3 12.3a3 3 0 0 0 2 2.8V16a3 3 0 0 0 3 3h.5a2.5 2.5 0 0 0 5 0V4.5A2.5 2.5 0 0 0 9.5 2Z",
								stroke: "currentColor",
								strokeWidth: "1.8",
								strokeLinejoin: "round"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 86,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("path", {
								d: "M14.5 2A2.5 2.5 0 0 1 17 4.5v.6A3 3 0 0 1 19.5 8a3 3 0 0 1-.4 1.5 3 3 0 0 1 1.9 2.8 3 3 0 0 1-2 2.8V16a3 3 0 0 1-3 3h-.5",
								stroke: "currentColor",
								strokeWidth: "1.8",
								strokeLinejoin: "round"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 87,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 85,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
						className: "text-xl font-bold text-slate-800 dark:text-white",
						children: "Predicción de dosificación"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 91,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-sm font-medium text-slate-500 dark:text-slate-400",
						children: "Modelo LSTM · Presupuesto de químicos del día"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 94,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 83,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-wrap items-center gap-3",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						id: "badge-tipo-prediccion",
						className: `flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold ${esFinal ? "bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400" : "bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400"}`,
						children: [
							/* @__PURE__ */ _jsxDEV("span", { className: `h-2 w-2 rounded-full ${esFinal ? "bg-emerald-500" : "bg-amber-500 animate-pulse"}` }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 109,
								columnNumber: 13
							}, this),
							esFinal ? "Final" : "Parcial",
							" · ",
							capturadas,
							"/3 franjas"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 101,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						id: "btn-predecir-ahora",
						onClick: handlePredecir,
						disabled: prediciendo,
						className: "group flex items-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-sky-600 px-4 py-2 text-sm font-semibold text-white shadow-md shadow-violet-500/25 transition-all hover:-translate-y-0.5 hover:shadow-lg hover:shadow-violet-500/30 disabled:cursor-wait disabled:opacity-70",
						children: [/* @__PURE__ */ _jsxDEV("svg", {
							className: `h-4 w-4 ${prediciendo ? "animate-spin" : "transition-transform group-hover:rotate-180"}`,
							viewBox: "0 0 24 24",
							fill: "none",
							xmlns: "http://www.w3.org/2000/svg",
							children: /* @__PURE__ */ _jsxDEV("path", {
								d: "M4 4v5h5M20 20v-5h-5M5.6 15a7 7 0 0 0 12.3 2.4M18.4 9A7 7 0 0 0 6.1 6.6",
								stroke: "currentColor",
								strokeWidth: "2",
								strokeLinecap: "round",
								strokeLinejoin: "round"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 123,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 119,
							columnNumber: 13
						}, this), prediciendo ? "Calculando…" : "Predecir ahora"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 113,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 100,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 82,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "relative grid grid-cols-1 gap-6",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 gap-4 md:grid-cols-3",
					children: QUIMICOS.map((q) => {
						const valorTotal = prediccion?.[q.key];
						const tiene = valorTotal !== null && valorTotal !== undefined;
						const nombreQuimicoKey = q.nombre.toLowerCase();
						const aplicado = dosisAplicadas?.[nombreQuimicoKey] || 0;
						const restante = tiene ? Math.max(0, Number(valorTotal) - aplicado) : 0;
						const pctAplicado = tiene && Number(valorTotal) > 0 ? Math.min(100, aplicado / Number(valorTotal) * 100) : 0;
						return /* @__PURE__ */ _jsxDEV("div", {
							id: `card-pred-${q.simbolo.toLowerCase()}`,
							className: "group flex flex-col justify-between rounded-2xl border border-slate-200 dark:border-[#313D4A] bg-slate-50/60 dark:bg-[#1A222C] p-5 transition-all hover:-translate-y-0.5 hover:shadow-md",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "mb-4 flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: `flex h-9 w-9 items-center justify-center rounded-lg text-sm font-bold ${q.soft}`,
										children: q.simbolo
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 151,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] font-semibold uppercase tracking-wider text-slate-400",
										children: [
											"máx ",
											q.max,
											" g"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 154,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 150,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-medium text-slate-500 dark:text-slate-400",
									children: q.nombre
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 158,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "mt-1 flex items-end gap-2",
									children: [/* @__PURE__ */ _jsxDEV("h5", {
										className: "text-3xl font-bold text-slate-800 dark:text-white",
										children: [tiene ? restante.toFixed(0) : "—", /* @__PURE__ */ _jsxDEV("span", {
											className: "ml-1 text-sm font-medium text-slate-500 dark:text-slate-400",
											children: "g"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 162,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 160,
										columnNumber: 21
									}, this), aplicado > 0 && /* @__PURE__ */ _jsxDEV("span", {
										className: "mb-1 text-xs font-medium text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-900/20 px-2 py-0.5 rounded-full",
										children: [
											"Restante (de ",
											Number(valorTotal).toFixed(0),
											"g)"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 165,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 159,
									columnNumber: 19
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "mb-1.5 flex justify-between text-[10px] font-medium text-slate-500",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: [
											"Aplicado: ",
											aplicado.toFixed(1),
											"g"
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 174,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
											"Total: ",
											tiene ? Number(valorTotal).toFixed(1) : "0",
											"g"
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 175,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 173,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "h-2 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-700",
										children: /* @__PURE__ */ _jsxDEV("div", {
											className: `h-full rounded-full bg-gradient-to-r ${q.gradient} transition-[width] duration-1000 ease-out`,
											style: { width: `${pctAplicado}%` }
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 178,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 177,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "mt-3 text-[11px] text-slate-400 dark:text-slate-500",
										children: q.desc
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 183,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 172,
								columnNumber: 17
							}, this)]
						}, q.key, true, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 15
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 132,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 130,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 70,
		columnNumber: 5
	}, this);
}
_s(PrediccionPanel, "R6pTh8jHUuNIrZ1IgHVReR5IW4s=");
_c = PrediccionPanel;
function Dato({ etiqueta, valor }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "rounded-lg bg-slate-50 dark:bg-[#1A222C] px-2 py-1.5",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "text-slate-400",
			children: etiqueta
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 198,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "font-semibold text-slate-700 dark:text-slate-200",
			children: valor
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 199,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 197,
		columnNumber: 5
	}, this);
}
_c2 = Dato;
function fmt(v, d = 2) {
	return v === null || v === undefined ? "—" : Number(v).toFixed(d);
}
function formatHora(value) {
	if (!value) return "—";
	if (typeof value === "string" && value.includes("T")) {
		const t = value.split("T")[1];
		if (t) return t.substring(0, 5);
	}
	return new Date(value).toLocaleTimeString([], {
		hour: "2-digit",
		minute: "2-digit",
		hour12: false
	});
}
var _c, _c2;
$RefreshReg$(_c, "PrediccionPanel");
$RefreshReg$(_c2, "Dato");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/PrediccionPanel/index.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/components/PrediccionPanel/index.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/components/PrediccionPanel/index.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/components/PrediccionPanel/index.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFFBQVEsZ0JBQWdCOzs7OztBQUc1QyxNQUFNLFdBQVc7Q0FDZjtFQUNFLEtBQUs7RUFDTCxRQUFRO0VBQ1IsU0FBUztFQUNULEtBQUs7RUFDTCxVQUFVO0VBQ1YsTUFBTTtFQUNOLE1BQU07Q0FDUjtDQUNBO0VBQ0UsS0FBSztFQUNMLFFBQVE7RUFDUixTQUFTO0VBQ1QsS0FBSztFQUNMLFVBQVU7RUFDVixNQUFNO0VBQ04sTUFBTTtDQUNSO0NBQ0E7RUFDRSxLQUFLO0VBQ0wsUUFBUTtFQUNSLFNBQVM7RUFDVCxLQUFLO0VBQ0wsVUFBVTtFQUNWLE1BQU07RUFDTixNQUFNO0NBQ1I7QUFDRjtBQUVBLE1BQU0sZUFBZTtDQUFDO0NBQVM7Q0FBUztBQUFPO0FBRS9DLGVBQWUsU0FBUyxnQkFBZ0IsRUFBRSxZQUFZLFNBQVMsZ0JBQWdCLGNBQWM7O0NBQzNGLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEtBQUs7Q0FDcEQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEtBQUs7Q0FDOUMsTUFBTSxjQUFjLE9BQU8sWUFBWSxnQkFBZ0I7O0NBR3ZELGdCQUFnQjtFQUNkLE1BQU0sUUFBUSxZQUFZO0VBQzFCLElBQUksU0FBUyxZQUFZLFdBQVcsVUFBVSxZQUFZLFNBQVM7R0FDakUsWUFBWSxJQUFJO0dBQ2hCLE1BQU0sSUFBSSxPQUFPLGlCQUFpQixZQUFZLEtBQUssR0FBRyxJQUFJO0dBQzFELFlBQVksVUFBVTtHQUN0QixhQUFhLE9BQU8sYUFBYSxDQUFDO0VBQ3BDO0VBQ0EsWUFBWSxVQUFVO0NBQ3hCLEdBQUcsQ0FBQyxZQUFZLGdCQUFnQixDQUFDO0NBRWpDLE1BQU0saUJBQWlCLFlBQVk7RUFDakMsSUFBSSxDQUFDLFlBQVk7RUFDakIsZUFBZSxJQUFJO0VBQ25CLElBQUk7R0FDRixNQUFNLFdBQVc7RUFDbkIsVUFBVTtHQUNSLGVBQWUsS0FBSztFQUN0QjtDQUNGO0NBRUEsTUFBTSxVQUFVLFNBQVMsU0FBUyxTQUM5QixRQUFRLFVBQ1IsYUFBYSxLQUFLLFVBQVU7RUFBRTtFQUFNLFdBQVc7Q0FBTSxFQUFFO0NBQzNELE1BQU0sYUFBYSxTQUFTLHNCQUFzQjtDQUNsRCxNQUFNLFVBQVUsU0FBUyxTQUFTO0NBRWxDLE9BQ0Usd0JBQUMsV0FBRDtFQUNFLElBQUc7RUFDSCxXQUFXLHlIQUNULFdBQ0ksZ0RBQ0E7WUFMUjtHQVNFLHdCQUFDLE9BQUQsRUFBSyxXQUFVLG9KQUFxSjs7Ozs7R0FHcEssd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxPQUFEO09BQUssT0FBTTtPQUFLLFFBQU87T0FBSyxTQUFRO09BQVksTUFBSztPQUFPLE9BQU07aUJBQWxFLENBQ0Usd0JBQUMsUUFBRDtRQUFNLEdBQUU7UUFBaUssUUFBTztRQUFlLGFBQVk7UUFBTSxnQkFBZTtPQUFTOzs7O2lCQUN6Tyx3QkFBQyxRQUFEO1FBQU0sR0FBRTtRQUEySCxRQUFPO1FBQWUsYUFBWTtRQUFNLGdCQUFlO09BQVM7Ozs7ZUFDaE07Ozs7OztLQUNGOzs7O2VBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFtRDtLQUU3RDs7OztlQUNKLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUF5RDtLQUVuRTs7OzthQUNBOzs7O2FBQ0Y7Ozs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQ7TUFDRSxJQUFHO01BQ0gsV0FBVywwRUFDVCxVQUNJLGdGQUNBO2dCQUxSO09BUUUsd0JBQUMsUUFBRCxFQUFNLFdBQVcsd0JBQXdCLFVBQVUsbUJBQW1CLCtCQUFpQzs7Ozs7T0FDdEcsVUFBVSxVQUFVO09BQVU7T0FBSTtPQUFXO01BQzFDOzs7OztlQUVOLHdCQUFDLFVBQUQ7TUFDRSxJQUFHO01BQ0gsU0FBUztNQUNULFVBQVU7TUFDVixXQUFVO2dCQUpaLENBTUUsd0JBQUMsT0FBRDtPQUNFLFdBQVcsV0FBVyxjQUFjLGlCQUFpQjtPQUNyRCxTQUFRO09BQVksTUFBSztPQUFPLE9BQU07aUJBRXRDLHdCQUFDLFFBQUQ7UUFBTSxHQUFFO1FBQTBFLFFBQU87UUFBZSxhQUFZO1FBQUksZUFBYztRQUFRLGdCQUFlO09BQVM7Ozs7O01BQ25LOzs7O2dCQUNKLGNBQWMsZ0JBQWdCLGdCQUN6Qjs7Ozs7YUFDTDs7Ozs7WUFDRjs7Ozs7O0dBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FFYix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaLFNBQVMsS0FBSyxNQUFNO01BQ25CLE1BQU0sYUFBYSxhQUFhLEVBQUU7TUFDbEMsTUFBTSxRQUFRLGVBQWUsUUFBUSxlQUFlO01BRXBELE1BQU0sbUJBQW1CLEVBQUUsT0FBTyxZQUFZO01BQzlDLE1BQU0sV0FBVyxpQkFBaUIscUJBQXFCO01BQ3ZELE1BQU0sV0FBVyxRQUFRLEtBQUssSUFBSSxHQUFHLE9BQU8sVUFBVSxJQUFJLFFBQVEsSUFBSTtNQUV0RSxNQUFNLGNBQWMsU0FBUyxPQUFPLFVBQVUsSUFBSSxJQUFJLEtBQUssSUFBSSxLQUFNLFdBQVcsT0FBTyxVQUFVLElBQUssR0FBRyxJQUFJO01BRTdHLE9BQ0Usd0JBQUMsT0FBRDtPQUVFLElBQUksYUFBYSxFQUFFLFFBQVEsWUFBWTtPQUN2QyxXQUFVO2lCQUhaLENBS0Usd0JBQUMsT0FBRDtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVcseUVBQXlFLEVBQUU7b0JBQ3pGLEVBQUU7U0FDQzs7OzttQkFDTix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEI7V0FBb0Y7V0FDN0UsRUFBRTtXQUFJO1VBQ1A7Ozs7O2lCQUNIOzs7Ozs7UUFDTCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBMEQsRUFBRTtRQUFhOzs7OztRQUN6Rix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFkLENBQ0csUUFBUSxTQUFTLFFBQVEsQ0FBQyxJQUFJLEtBQy9CLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUE4RDtVQUFPOzs7O2tCQUNuRjs7Ozs7bUJBQ0gsV0FBVyxLQUNWLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQjtXQUFnSjtXQUNoSSxPQUFPLFVBQVUsQ0FBQyxDQUFDLFFBQVEsQ0FBQztXQUFFO1VBQ3hDOzs7OztpQkFFTDs7Ozs7O09BQ0Y7Ozs7aUJBRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTTtXQUFXLFNBQVMsUUFBUSxDQUFDO1dBQUU7VUFBTzs7OztvQkFDNUMsd0JBQUMsUUFBRDtXQUFNO1dBQVEsUUFBUSxPQUFPLFVBQVUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJO1dBQUk7VUFBTzs7OztrQkFDOUQ7Ozs7OztTQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNiLHdCQUFDLE9BQUQ7V0FDRSxXQUFXLHdDQUF3QyxFQUFFLFNBQVM7V0FDOUQsT0FBTyxFQUFFLE9BQU8sR0FBRyxZQUFZLEdBQUc7VUFDbkM7Ozs7O1NBQ0U7Ozs7O1NBQ0wsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQXVELEVBQUU7U0FBUTs7Ozs7UUFDM0U7Ozs7O2VBQ0Y7U0F4Q0UsRUFBRTs7OzthQXdDSjtLQUVULENBQUM7SUFDRTs7Ozs7R0FFRjs7Ozs7RUFDRTs7Ozs7O0FBRWI7OztBQUVBLFNBQVMsS0FBSyxFQUFFLFVBQVUsU0FBUztDQUNqQyxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFrQjtFQUFjOzs7O1lBQy9DLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQW9EO0VBQVc7Ozs7VUFDM0U7Ozs7OztBQUVUOztBQUVBLFNBQVMsSUFBSSxHQUFHLElBQUksR0FBRztDQUNyQixPQUFPLE1BQU0sUUFBUSxNQUFNLFlBQVksTUFBTSxPQUFPLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNsRTtBQUVBLFNBQVMsV0FBVyxPQUFPO0NBQ3pCLElBQUksQ0FBQyxPQUFPLE9BQU87Q0FDbkIsSUFBSSxPQUFPLFVBQVUsWUFBWSxNQUFNLFNBQVMsR0FBRyxHQUFHO0VBQ3BELE1BQU0sSUFBSSxNQUFNLE1BQU0sR0FBRyxDQUFDLENBQUM7RUFDM0IsSUFBSSxHQUFHLE9BQU8sRUFBRSxVQUFVLEdBQUcsQ0FBQztDQUNoQztDQUNBLE9BQU8sSUFBSSxLQUFLLEtBQUssQ0FBQyxDQUFDLG1CQUFtQixDQUFDLEdBQUc7RUFBRSxNQUFNO0VBQVcsUUFBUTtFQUFXLFFBQVE7Q0FBTSxDQUFDO0FBQ3JHIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcblxuLy8gUmFuZ29zIG3DoXhpbW9zIHF1ZSB1c2EgZWwgc2VydmljaW8gTFNUTSAobnAuY2xpcCkgcGFyYSBlc2NhbGFyIGxhcyBiYXJyYXNcbmNvbnN0IFFVSU1JQ09TID0gW1xuICB7XG4gICAga2V5OiAnYWx1bWluaW9fcHJlZCcsXG4gICAgbm9tYnJlOiAnU3VsZmF0byBkZSBBbHVtaW5pbycsXG4gICAgc2ltYm9sbzogJ0FsJyxcbiAgICBtYXg6IDEwMDAsXG4gICAgZ3JhZGllbnQ6ICdmcm9tLXNreS00MDAgdG8tYmx1ZS02MDAnLFxuICAgIHNvZnQ6ICdiZy1za3ktNTAgZGFyazpiZy1za3ktOTAwLzIwIHRleHQtc2t5LTYwMCBkYXJrOnRleHQtc2t5LTMwMCcsXG4gICAgZGVzYzogJ0Zsb2N1bGFudGUgwrcgY2xhcmlmaWNhIGVsIGFndWEnLFxuICB9LFxuICB7XG4gICAga2V5OiAnY29icmVfcHJlZCcsXG4gICAgbm9tYnJlOiAnU3VsZmF0byBkZSBDb2JyZScsXG4gICAgc2ltYm9sbzogJ0N1JyxcbiAgICBtYXg6IDEwMDAsXG4gICAgZ3JhZGllbnQ6ICdmcm9tLXRlYWwtNDAwIHRvLWVtZXJhbGQtNjAwJyxcbiAgICBzb2Z0OiAnYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTAwLzIwIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtMzAwJyxcbiAgICBkZXNjOiAnQWxndWljaWRhIMK3IGNvbnRyb2xhIGFsZ2FzJyxcbiAgfSxcbiAge1xuICAgIGtleTogJ2Nsb3JvX3ByZWQnLFxuICAgIG5vbWJyZTogJ0Nsb3JvJyxcbiAgICBzaW1ib2xvOiAnQ2wnLFxuICAgIG1heDogMjAwLFxuICAgIGdyYWRpZW50OiAnZnJvbS12aW9sZXQtNDAwIHRvLWZ1Y2hzaWEtNjAwJyxcbiAgICBzb2Z0OiAnYmctdmlvbGV0LTUwIGRhcms6YmctdmlvbGV0LTkwMC8yMCB0ZXh0LXZpb2xldC02MDAgZGFyazp0ZXh0LXZpb2xldC0zMDAnLFxuICAgIGRlc2M6ICdEZXNpbmZlY3RhbnRlIMK3IGVsaW1pbmEgYmFjdGVyaWFzJyxcbiAgfSxcbl1cblxuY29uc3QgRlJBTkpBU19CQVNFID0gWycwODowMCcsICcxMjowMCcsICcxNjowMCddXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFByZWRpY2Npb25QYW5lbCh7IHByZWRpY2Npb24sIGRldGFsbGUsIGRvc2lzQXBsaWNhZGFzLCBvblByZWRlY2lyIH0pIHtcbiAgY29uc3QgW3ByZWRpY2llbmRvLCBzZXRQcmVkaWNpZW5kb10gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW2Rlc3RlbGxvLCBzZXREZXN0ZWxsb10gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgdWx0aW1hRmVjaGEgPSB1c2VSZWYocHJlZGljY2lvbj8uZmVjaGFfcHJlZGljY2lvbilcblxuICAvLyBNaWNyby1hbmltYWNpw7NuIGN1YW5kbyBsbGVnYSB1bmEgcHJlZGljY2nDs24gbnVldmFcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBmZWNoYSA9IHByZWRpY2Npb24/LmZlY2hhX3ByZWRpY2Npb25cbiAgICBpZiAoZmVjaGEgJiYgdWx0aW1hRmVjaGEuY3VycmVudCAmJiBmZWNoYSAhPT0gdWx0aW1hRmVjaGEuY3VycmVudCkge1xuICAgICAgc2V0RGVzdGVsbG8odHJ1ZSlcbiAgICAgIGNvbnN0IHQgPSB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiBzZXREZXN0ZWxsbyhmYWxzZSksIDE0MDApXG4gICAgICB1bHRpbWFGZWNoYS5jdXJyZW50ID0gZmVjaGFcbiAgICAgIHJldHVybiAoKSA9PiB3aW5kb3cuY2xlYXJUaW1lb3V0KHQpXG4gICAgfVxuICAgIHVsdGltYUZlY2hhLmN1cnJlbnQgPSBmZWNoYVxuICB9LCBbcHJlZGljY2lvbj8uZmVjaGFfcHJlZGljY2lvbl0pXG5cbiAgY29uc3QgaGFuZGxlUHJlZGVjaXIgPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFvblByZWRlY2lyKSByZXR1cm5cbiAgICBzZXRQcmVkaWNpZW5kbyh0cnVlKVxuICAgIHRyeSB7XG4gICAgICBhd2FpdCBvblByZWRlY2lyKClcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0UHJlZGljaWVuZG8oZmFsc2UpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgZnJhbmphcyA9IGRldGFsbGU/LmZyYW5qYXM/Lmxlbmd0aFxuICAgID8gZGV0YWxsZS5mcmFuamFzXG4gICAgOiBGUkFOSkFTX0JBU0UubWFwKChob3JhKSA9PiAoeyBob3JhLCBjYXB0dXJhZGE6IGZhbHNlIH0pKVxuICBjb25zdCBjYXB0dXJhZGFzID0gZGV0YWxsZT8uZnJhbmphc19jYXB0dXJhZGFzID8/IDBcbiAgY29uc3QgZXNGaW5hbCA9IGRldGFsbGU/LnRpcG8gPT09ICdmaW5hbCdcblxuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uXG4gICAgICBpZD1cInBhbmVsLXByZWRpY2Npb24tbHN0bVwiXG4gICAgICBjbGFzc05hbWU9e2ByZWxhdGl2ZSBtdC02IG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLTJ4bCBib3JkZXIgYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gcC03IHNoYWRvdy1zbSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi03MDAgJHtcbiAgICAgICAgZGVzdGVsbG9cbiAgICAgICAgICA/ICdib3JkZXItdmlvbGV0LTQwMCByaW5nLTQgcmluZy12aW9sZXQtNDAwLzI1J1xuICAgICAgICAgIDogJ2JvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdJ1xuICAgICAgfWB9XG4gICAgPlxuICAgICAgey8qIEhhbG8gZGVjb3JhdGl2byAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtbm9uZSBhYnNvbHV0ZSAtcmlnaHQtMjQgLXRvcC0yNCBoLTY0IHctNjQgcm91bmRlZC1mdWxsIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tdmlvbGV0LTUwMC8xNSB2aWEtc2t5LTQwMC8xMCB0by10cmFuc3BhcmVudCBibHVyLTJ4bFwiIC8+XG5cbiAgICAgIHsvKiBFbmNhYmV6YWRvICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBtYi02IGZsZXggZmxleC13cmFwIGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtMTEgdy0xMSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC14bCBiZy1ncmFkaWVudC10by1iciBmcm9tLXZpb2xldC01MDAgdG8tc2t5LTUwMCB0ZXh0LXdoaXRlIHNoYWRvdy1tZCBzaGFkb3ctdmlvbGV0LTUwMC8zMFwiPlxuICAgICAgICAgICAgPHN2ZyB3aWR0aD1cIjIyXCIgaGVpZ2h0PVwiMjJcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cIm5vbmVcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+XG4gICAgICAgICAgICAgIDxwYXRoIGQ9XCJNOS41IDJBMi41IDIuNSAwIDAgMCA3IDQuNXYuNkEzIDMgMCAwIDAgNC41IDhhMyAzIDAgMCAwIC40IDEuNUEzIDMgMCAwIDAgMyAxMi4zYTMgMyAwIDAgMCAyIDIuOFYxNmEzIDMgMCAwIDAgMyAzaC41YTIuNSAyLjUgMCAwIDAgNSAwVjQuNUEyLjUgMi41IDAgMCAwIDkuNSAyWlwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMS44XCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIC8+XG4gICAgICAgICAgICAgIDxwYXRoIGQ9XCJNMTQuNSAyQTIuNSAyLjUgMCAwIDEgMTcgNC41di42QTMgMyAwIDAgMSAxOS41IDhhMyAzIDAgMCAxLS40IDEuNSAzIDMgMCAwIDEgMS45IDIuOCAzIDMgMCAwIDEtMiAyLjhWMTZhMyAzIDAgMCAxLTMgM2gtLjVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjEuOFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiAvPlxuICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgUHJlZGljY2nDs24gZGUgZG9zaWZpY2FjacOzblxuICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICBNb2RlbG8gTFNUTSDCtyBQcmVzdXB1ZXN0byBkZSBxdcOtbWljb3MgZGVsIGTDrWFcbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgaWQ9XCJiYWRnZS10aXBvLXByZWRpY2Npb25cIlxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLWZ1bGwgcHgtMyBweS0xIHRleHQteHMgZm9udC1zZW1pYm9sZCAke1xuICAgICAgICAgICAgICBlc0ZpbmFsXG4gICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtOTAwLzIwIHRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwJ1xuICAgICAgICAgICAgICAgIDogJ2JnLWFtYmVyLTUwIGRhcms6YmctYW1iZXItOTAwLzIwIHRleHQtYW1iZXItNjAwIGRhcms6dGV4dC1hbWJlci00MDAnXG4gICAgICAgICAgICB9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BoLTIgdy0yIHJvdW5kZWQtZnVsbCAke2VzRmluYWwgPyAnYmctZW1lcmFsZC01MDAnIDogJ2JnLWFtYmVyLTUwMCBhbmltYXRlLXB1bHNlJ31gfSAvPlxuICAgICAgICAgICAge2VzRmluYWwgPyAnRmluYWwnIDogJ1BhcmNpYWwnfSDCtyB7Y2FwdHVyYWRhc30vMyBmcmFuamFzXG4gICAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgaWQ9XCJidG4tcHJlZGVjaXItYWhvcmFcIlxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUHJlZGVjaXJ9XG4gICAgICAgICAgICBkaXNhYmxlZD17cHJlZGljaWVuZG99XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLXhsIGJnLWdyYWRpZW50LXRvLXIgZnJvbS12aW9sZXQtNjAwIHRvLXNreS02MDAgcHgtNCBweS0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlIHNoYWRvdy1tZCBzaGFkb3ctdmlvbGV0LTUwMC8yNSB0cmFuc2l0aW9uLWFsbCBob3ZlcjotdHJhbnNsYXRlLXktMC41IGhvdmVyOnNoYWRvdy1sZyBob3ZlcjpzaGFkb3ctdmlvbGV0LTUwMC8zMCBkaXNhYmxlZDpjdXJzb3Itd2FpdCBkaXNhYmxlZDpvcGFjaXR5LTcwXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8c3ZnXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YGgtNCB3LTQgJHtwcmVkaWNpZW5kbyA/ICdhbmltYXRlLXNwaW4nIDogJ3RyYW5zaXRpb24tdHJhbnNmb3JtIGdyb3VwLWhvdmVyOnJvdGF0ZS0xODAnfWB9XG4gICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBmaWxsPVwibm9uZVwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8cGF0aCBkPVwiTTQgNHY1aDVNMjAgMjB2LTVoLTVNNS42IDE1YTcgNyAwIDAgMCAxMi4zIDIuNE0xOC40IDlBNyA3IDAgMCAwIDYuMSA2LjZcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjJcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgLz5cbiAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAge3ByZWRpY2llbmRvID8gJ0NhbGN1bGFuZG/igKYnIDogJ1ByZWRlY2lyIGFob3JhJ31cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBncmlkIGdyaWQtY29scy0xIGdhcC02XCI+XG4gICAgICAgIHsvKiBUYXJqZXRhcyBkZSBxdcOtbWljb3MgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBnYXAtNCBtZDpncmlkLWNvbHMtM1wiPlxuICAgICAgICAgIHtRVUlNSUNPUy5tYXAoKHEpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHZhbG9yVG90YWwgPSBwcmVkaWNjaW9uPy5bcS5rZXldXG4gICAgICAgICAgICBjb25zdCB0aWVuZSA9IHZhbG9yVG90YWwgIT09IG51bGwgJiYgdmFsb3JUb3RhbCAhPT0gdW5kZWZpbmVkXG4gICAgICAgICAgICBcbiAgICAgICAgICAgIGNvbnN0IG5vbWJyZVF1aW1pY29LZXkgPSBxLm5vbWJyZS50b0xvd2VyQ2FzZSgpXG4gICAgICAgICAgICBjb25zdCBhcGxpY2FkbyA9IGRvc2lzQXBsaWNhZGFzPy5bbm9tYnJlUXVpbWljb0tleV0gfHwgMFxuICAgICAgICAgICAgY29uc3QgcmVzdGFudGUgPSB0aWVuZSA/IE1hdGgubWF4KDAsIE51bWJlcih2YWxvclRvdGFsKSAtIGFwbGljYWRvKSA6IDBcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgY29uc3QgcGN0QXBsaWNhZG8gPSB0aWVuZSAmJiBOdW1iZXIodmFsb3JUb3RhbCkgPiAwID8gTWF0aC5taW4oMTAwLCAoYXBsaWNhZG8gLyBOdW1iZXIodmFsb3JUb3RhbCkpICogMTAwKSA6IDBcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGtleT17cS5rZXl9XG4gICAgICAgICAgICAgICAgaWQ9e2BjYXJkLXByZWQtJHtxLnNpbWJvbG8udG9Mb3dlckNhc2UoKX1gfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdyb3VwIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBiZy1zbGF0ZS01MC82MCBkYXJrOmJnLVsjMUEyMjJDXSBwLTUgdHJhbnNpdGlvbi1hbGwgaG92ZXI6LXRyYW5zbGF0ZS15LTAuNSBob3ZlcjpzaGFkb3ctbWRcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgZmxleCBoLTkgdy05IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWxnIHRleHQtc20gZm9udC1ib2xkICR7cS5zb2Z0fWB9PlxuICAgICAgICAgICAgICAgICAgICAgIHtxLnNpbWJvbG99XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICBtw6F4IHtxLm1heH0gZ1xuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPntxLm5vbWJyZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgZmxleCBpdGVtcy1lbmQgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGg1IGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7dGllbmUgPyByZXN0YW50ZS50b0ZpeGVkKDApIDogJ+KAlCd9XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5nPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2g1PlxuICAgICAgICAgICAgICAgICAgICB7YXBsaWNhZG8gPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYi0xIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtOTAwLzIwIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgUmVzdGFudGUgKGRlIHtOdW1iZXIodmFsb3JUb3RhbCkudG9GaXhlZCgwKX1nKVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0xLjUgZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1bMTBweF0gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+QXBsaWNhZG86IHthcGxpY2Fkby50b0ZpeGVkKDEpfWc8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlRvdGFsOiB7dGllbmUgPyBOdW1iZXIodmFsb3JUb3RhbCkudG9GaXhlZCgxKSA6ICcwJ31nPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMiB3LWZ1bGwgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS0yMDAgZGFyazpiZy1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGgtZnVsbCByb3VuZGVkLWZ1bGwgYmctZ3JhZGllbnQtdG8tciAke3EuZ3JhZGllbnR9IHRyYW5zaXRpb24tW3dpZHRoXSBkdXJhdGlvbi0xMDAwIGVhc2Utb3V0YH1cbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7cGN0QXBsaWNhZG99JWAgfX1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwXCI+e3EuZGVzY308L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKVxuICAgICAgICAgIH0pfVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgPC9kaXY+XG4gICAgPC9zZWN0aW9uPlxuICApXG59XG5cbmZ1bmN0aW9uIERhdG8oeyBldGlxdWV0YSwgdmFsb3IgfSkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBiZy1zbGF0ZS01MCBkYXJrOmJnLVsjMUEyMjJDXSBweC0yIHB5LTEuNVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPntldGlxdWV0YX08L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+e3ZhbG9yfTwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59XG5cbmZ1bmN0aW9uIGZtdCh2LCBkID0gMikge1xuICByZXR1cm4gdiA9PT0gbnVsbCB8fCB2ID09PSB1bmRlZmluZWQgPyAn4oCUJyA6IE51bWJlcih2KS50b0ZpeGVkKGQpXG59XG5cbmZ1bmN0aW9uIGZvcm1hdEhvcmEodmFsdWUpIHtcbiAgaWYgKCF2YWx1ZSkgcmV0dXJuICfigJQnXG4gIGlmICh0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnICYmIHZhbHVlLmluY2x1ZGVzKCdUJykpIHtcbiAgICBjb25zdCB0ID0gdmFsdWUuc3BsaXQoJ1QnKVsxXVxuICAgIGlmICh0KSByZXR1cm4gdC5zdWJzdHJpbmcoMCwgNSlcbiAgfVxuICByZXR1cm4gbmV3IERhdGUodmFsdWUpLnRvTG9jYWxlVGltZVN0cmluZyhbXSwgeyBob3VyOiAnMi1kaWdpdCcsIG1pbnV0ZTogJzItZGlnaXQnLCBob3VyMTI6IGZhbHNlIH0pXG59XG4iXX0=