import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/layout/DefaultLayout.jsx");const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import { Outlet, Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=41a64c35";
import { useAuth } from "/src/context/AuthContext.jsx";
import Sidebar from "/src/components/Sidebar/index.jsx";
import Header from "/src/components/Header/index.jsx";
var _jsxFileName = "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/layout/DefaultLayout.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=41a64c35";
var _s = $RefreshSig$();
export default function DefaultLayout() {
	_s();
	const { session, error, message } = useAuth();
	if (!session) {
		return /* @__PURE__ */ _jsxDEV(Navigate, {
			to: "/auth/login",
			replace: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 10,
			columnNumber: 12
		}, this);
	}
	if (session.must_change_password) {
		return /* @__PURE__ */ _jsxDEV(Navigate, {
			to: "/auth/change-password",
			replace: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 12
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "tailadmin-layout flex h-screen overflow-hidden font-sans text-slate-800",
		children: [/* @__PURE__ */ _jsxDEV(Sidebar, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 19,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "relative flex flex-1 flex-col overflow-y-auto overflow-x-hidden",
			children: [/* @__PURE__ */ _jsxDEV(Header, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("main", {
				className: "mx-auto w-full max-w-screen-2xl p-4 md:p-6 2xl:p-10",
				children: [
					error && /* @__PURE__ */ _jsxDEV("div", {
						className: "mb-6 flex w-full border-l-6 border-red-500 bg-red-50 px-7 py-4 shadow-sm rounded-md",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "w-full",
							children: [/* @__PURE__ */ _jsxDEV("h5", {
								className: "mb-1 text-lg font-semibold text-red-800",
								children: "Ocurrió un error"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 27,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "leading-relaxed text-red-600",
								children: error
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 28,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 26,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 13
					}, this),
					message && /* @__PURE__ */ _jsxDEV("div", {
						className: "mb-6 flex w-full border-l-6 border-green-500 bg-green-50 px-7 py-4 shadow-sm rounded-md",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "w-full",
							children: /* @__PURE__ */ _jsxDEV("p", {
								className: "leading-relaxed text-green-700 font-medium",
								children: message
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 36,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 35,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 34,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Outlet, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 18,
		columnNumber: 5
	}, this);
}
_s(DefaultLayout, "s5U12hmXca5dmeLH7ytmzjL0SnI=", false, function() {
	return [useAuth];
});
_c = DefaultLayout;
var _c;
$RefreshReg$(_c, "DefaultLayout");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/layout/DefaultLayout.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/layout/DefaultLayout.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/layout/DefaultLayout.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/layout/DefaultLayout.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxRQUFRLGdCQUFnQjtBQUNqQyxTQUFTLGVBQWU7QUFDeEIsT0FBTyxhQUFhO0FBQ3BCLE9BQU8sWUFBWTs7OztBQUVuQixlQUFlLFNBQVMsZ0JBQWdCOztDQUN0QyxNQUFNLEVBQUUsU0FBUyxPQUFPLFlBQVksUUFBUTtDQUU1QyxJQUFJLENBQUMsU0FBUztFQUNaLE9BQU8sd0JBQUMsVUFBRDtHQUFVLElBQUc7R0FBYztFQUFTOzs7OztDQUM3QztDQUVBLElBQUksUUFBUSxzQkFBc0I7RUFDaEMsT0FBTyx3QkFBQyxVQUFEO0dBQVUsSUFBRztHQUF3QjtFQUFTOzs7OztDQUN2RDtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLFNBQUQsQ0FBVTs7OztZQUNWLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxRQUFELENBQVM7Ozs7YUFFVCx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFoQjtLQUNHLFNBQ0Msd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBMEM7T0FBb0I7Ozs7aUJBQzVFLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFnQztPQUFTOzs7O2VBQ25EOzs7Ozs7S0FDRjs7Ozs7S0FHTixXQUNDLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUE4QztPQUFXOzs7OztNQUNuRTs7Ozs7S0FDRjs7Ozs7S0FHUCx3QkFBQyxRQUFELENBQVM7Ozs7O0lBQ0w7Ozs7O1dBQ0g7Ozs7O1VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkRlZmF1bHRMYXlvdXQuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE91dGxldCwgTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uL2NvbnRleHQvQXV0aENvbnRleHQnXG5pbXBvcnQgU2lkZWJhciBmcm9tICcuLi9jb21wb25lbnRzL1NpZGViYXInXG5pbXBvcnQgSGVhZGVyIGZyb20gJy4uL2NvbXBvbmVudHMvSGVhZGVyJ1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEZWZhdWx0TGF5b3V0KCkge1xuICBjb25zdCB7IHNlc3Npb24sIGVycm9yLCBtZXNzYWdlIH0gPSB1c2VBdXRoKClcblxuICBpZiAoIXNlc3Npb24pIHtcbiAgICByZXR1cm4gPE5hdmlnYXRlIHRvPVwiL2F1dGgvbG9naW5cIiByZXBsYWNlIC8+XG4gIH1cblxuICBpZiAoc2Vzc2lvbi5tdXN0X2NoYW5nZV9wYXNzd29yZCkge1xuICAgIHJldHVybiA8TmF2aWdhdGUgdG89XCIvYXV0aC9jaGFuZ2UtcGFzc3dvcmRcIiByZXBsYWNlIC8+XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwidGFpbGFkbWluLWxheW91dCBmbGV4IGgtc2NyZWVuIG92ZXJmbG93LWhpZGRlbiBmb250LXNhbnMgdGV4dC1zbGF0ZS04MDBcIj5cbiAgICAgIDxTaWRlYmFyIC8+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXggZmxleC0xIGZsZXgtY29sIG92ZXJmbG93LXktYXV0byBvdmVyZmxvdy14LWhpZGRlblwiPlxuICAgICAgICA8SGVhZGVyIC8+XG4gICAgICAgIFxuICAgICAgICA8bWFpbiBjbGFzc05hbWU9XCJteC1hdXRvIHctZnVsbCBtYXgtdy1zY3JlZW4tMnhsIHAtNCBtZDpwLTYgMnhsOnAtMTBcIj5cbiAgICAgICAgICB7ZXJyb3IgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02IGZsZXggdy1mdWxsIGJvcmRlci1sLTYgYm9yZGVyLXJlZC01MDAgYmctcmVkLTUwIHB4LTcgcHktNCBzaGFkb3ctc20gcm91bmRlZC1tZFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxuICAgICAgICAgICAgICAgIDxoNSBjbGFzc05hbWU9XCJtYi0xIHRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXJlZC04MDBcIj5PY3VycmnDsyB1biBlcnJvcjwvaDU+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibGVhZGluZy1yZWxheGVkIHRleHQtcmVkLTYwMFwiPntlcnJvcn08L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgICBcbiAgICAgICAgICB7bWVzc2FnZSAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTYgZmxleCB3LWZ1bGwgYm9yZGVyLWwtNiBib3JkZXItZ3JlZW4tNTAwIGJnLWdyZWVuLTUwIHB4LTcgcHktNCBzaGFkb3ctc20gcm91bmRlZC1tZFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImxlYWRpbmctcmVsYXhlZCB0ZXh0LWdyZWVuLTcwMCBmb250LW1lZGl1bVwiPnttZXNzYWdlfTwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgPE91dGxldCAvPlxuICAgICAgICA8L21haW4+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl19