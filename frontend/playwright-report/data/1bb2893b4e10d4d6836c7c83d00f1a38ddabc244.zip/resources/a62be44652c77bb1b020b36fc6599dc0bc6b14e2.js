import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Authentication/ChangePassword.jsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { useNavigate, Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=41a64c35";
import api from "/src/services/api.js";
import { useAuth } from "/src/context/AuthContext.jsx";
var _jsxFileName = "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Authentication/ChangePassword.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=41a64c35";
var _s = $RefreshSig$();
export default function ChangePassword() {
	_s();
	const { session, updateSession, authConfig, showError, showMessage } = useAuth();
	const navigate = useNavigate();
	if (!session) {
		return /* @__PURE__ */ _jsxDEV(Navigate, {
			to: "/auth/login",
			replace: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 10,
			columnNumber: 12
		}, this);
	}
	const submitChangePassword = async (event) => {
		event.preventDefault();
		try {
			const form = new FormData(event.currentTarget);
			const { data } = await api.post("/auth/change-password", Object.fromEntries(form), authConfig());
			const updatedSession = {
				...session,
				must_change_password: false
			};
			updateSession(updatedSession);
			showMessage(data.mensaje);
			navigate("/dashboard");
		} catch (requestError) {
			showError(requestError);
		}
	};
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "login-shell single",
		children: /* @__PURE__ */ _jsxDEV("section", {
			className: "login-card",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "brand login-brand",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "brand-mark",
					children: "PA"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 33,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Playa Azul" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("small", { children: "Control center" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 36,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 34,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("form", {
				className: "form",
				onSubmit: submitChangePassword,
				children: [
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "eyebrow",
							children: "PRIMER ACCESO"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 41,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", { children: "Define tu contraseña" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 42,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "muted",
							children: "Cambia la contraseña temporal antes de continuar."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 43,
							columnNumber: 13
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 40,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("label", { children: ["Contraseña temporal", /* @__PURE__ */ _jsxDEV("input", {
						name: "password_actual",
						type: "password",
						autoComplete: "current-password",
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 47,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 45,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("label", { children: ["Nueva contraseña", /* @__PURE__ */ _jsxDEV("input", {
						name: "password_nueva",
						type: "password",
						minLength: "8",
						autoComplete: "new-password",
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("label", { children: ["Confirmar nueva contraseña", /* @__PURE__ */ _jsxDEV("input", {
						name: "confirmar_password_nueva",
						type: "password",
						minLength: "8",
						autoComplete: "new-password",
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 53,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						className: "primary",
						type: "submit",
						children: ["Guardar contraseña ", /* @__PURE__ */ _jsxDEV("span", { children: "→" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 57,
							columnNumber: 72
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 39,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 31,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 30,
		columnNumber: 5
	}, this);
}
_s(ChangePassword, "Dn/kriyKcKbEP4b20pjS9pbWTQ0=", false, function() {
	return [useAuth, useNavigate];
});
_c = ChangePassword;
var _c;
$RefreshReg$(_c, "ChangePassword");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Authentication/ChangePassword.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Authentication/ChangePassword.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Authentication/ChangePassword.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Authentication/ChangePassword.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhLGdCQUFnQjtBQUN0QyxPQUFPLFNBQVM7QUFDaEIsU0FBUyxlQUFlOzs7O0FBRXhCLGVBQWUsU0FBUyxpQkFBaUI7O0NBQ3ZDLE1BQU0sRUFBRSxTQUFTLGVBQWUsWUFBWSxXQUFXLGdCQUFnQixRQUFRO0NBQy9FLE1BQU0sV0FBVyxZQUFZO0NBRTdCLElBQUksQ0FBQyxTQUFTO0VBQ1osT0FBTyx3QkFBQyxVQUFEO0dBQVUsSUFBRztHQUFjO0VBQVM7Ozs7O0NBQzdDO0NBRUEsTUFBTSx1QkFBdUIsT0FBTyxVQUFVO0VBQzVDLE1BQU0sZUFBZTtFQUNyQixJQUFJO0dBQ0YsTUFBTSxPQUFPLElBQUksU0FBUyxNQUFNLGFBQWE7R0FDN0MsTUFBTSxFQUFFLFNBQVMsTUFBTSxJQUFJLEtBQUsseUJBQXlCLE9BQU8sWUFBWSxJQUFJLEdBQUcsV0FBVyxDQUFDO0dBRS9GLE1BQU0saUJBQWlCO0lBQUUsR0FBRztJQUFTLHNCQUFzQjtHQUFNO0dBQ2pFLGNBQWMsY0FBYztHQUU1QixZQUFZLEtBQUssT0FBTztHQUN4QixTQUFTLFlBQVk7RUFDdkIsU0FBUyxjQUFjO0dBQ3JCLFVBQVUsWUFBWTtFQUN4QjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxRQUFEO0VBQU0sV0FBVTtZQUNkLHdCQUFDLFdBQUQ7R0FBUyxXQUFVO2FBQW5CLENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWE7SUFBUTs7OztjQUNyQyx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsVUFBRCxZQUFRLGFBQWtCOzs7O2NBQzFCLHdCQUFDLFNBQUQsWUFBTyxpQkFBcUI7Ozs7WUFDekI7Ozs7WUFDRjs7Ozs7YUFDTCx3QkFBQyxRQUFEO0lBQU0sV0FBVTtJQUFPLFVBQVU7Y0FBakM7S0FDRSx3QkFBQyxPQUFEO01BQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQVU7TUFBbUI7Ozs7O01BQzdDLHdCQUFDLE1BQUQsWUFBSSx1QkFBd0I7Ozs7O01BQzVCLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFRO01BQW9EOzs7OztLQUN0RTs7Ozs7S0FDTCx3QkFBQyxTQUFELGFBQU8sdUJBRUwsd0JBQUMsU0FBRDtNQUFPLE1BQUs7TUFBa0IsTUFBSztNQUFXLGNBQWE7TUFBbUI7S0FBVTs7OzthQUNuRjs7Ozs7S0FDUCx3QkFBQyxTQUFELGFBQU8sb0JBRUwsd0JBQUMsU0FBRDtNQUFPLE1BQUs7TUFBaUIsTUFBSztNQUFXLFdBQVU7TUFBSSxjQUFhO01BQWU7S0FBVTs7OzthQUM1Rjs7Ozs7S0FDUCx3QkFBQyxTQUFELGFBQU8sOEJBRUwsd0JBQUMsU0FBRDtNQUFPLE1BQUs7TUFBMkIsTUFBSztNQUFXLFdBQVU7TUFBSSxjQUFhO01BQWU7S0FBVTs7OzthQUN0Rzs7Ozs7S0FDUCx3QkFBQyxVQUFEO01BQVEsV0FBVTtNQUFVLE1BQUs7Z0JBQWpDLENBQTBDLHVCQUFtQix3QkFBQyxRQUFELFlBQU0sSUFBTzs7OztjQUFTOzs7Ozs7SUFDL0U7Ozs7O1dBQ0M7Ozs7OztDQUNMOzs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNoYW5nZVBhc3N3b3JkLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VOYXZpZ2F0ZSwgTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IGFwaSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9hcGknXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vY29udGV4dC9BdXRoQ29udGV4dCdcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQ2hhbmdlUGFzc3dvcmQoKSB7XG4gIGNvbnN0IHsgc2Vzc2lvbiwgdXBkYXRlU2Vzc2lvbiwgYXV0aENvbmZpZywgc2hvd0Vycm9yLCBzaG93TWVzc2FnZSB9ID0gdXNlQXV0aCgpXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxuXG4gIGlmICghc2Vzc2lvbikge1xuICAgIHJldHVybiA8TmF2aWdhdGUgdG89XCIvYXV0aC9sb2dpblwiIHJlcGxhY2UgLz5cbiAgfVxuXG4gIGNvbnN0IHN1Ym1pdENoYW5nZVBhc3N3b3JkID0gYXN5bmMgKGV2ZW50KSA9PiB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCBmb3JtID0gbmV3IEZvcm1EYXRhKGV2ZW50LmN1cnJlbnRUYXJnZXQpXG4gICAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IGFwaS5wb3N0KCcvYXV0aC9jaGFuZ2UtcGFzc3dvcmQnLCBPYmplY3QuZnJvbUVudHJpZXMoZm9ybSksIGF1dGhDb25maWcoKSlcbiAgICAgIFxuICAgICAgY29uc3QgdXBkYXRlZFNlc3Npb24gPSB7IC4uLnNlc3Npb24sIG11c3RfY2hhbmdlX3Bhc3N3b3JkOiBmYWxzZSB9XG4gICAgICB1cGRhdGVTZXNzaW9uKHVwZGF0ZWRTZXNzaW9uKVxuICAgICAgXG4gICAgICBzaG93TWVzc2FnZShkYXRhLm1lbnNhamUpXG4gICAgICBuYXZpZ2F0ZSgnL2Rhc2hib2FyZCcpXG4gICAgfSBjYXRjaCAocmVxdWVzdEVycm9yKSB7XG4gICAgICBzaG93RXJyb3IocmVxdWVzdEVycm9yKVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPG1haW4gY2xhc3NOYW1lPVwibG9naW4tc2hlbGwgc2luZ2xlXCI+XG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJsb2dpbi1jYXJkXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYnJhbmQgbG9naW4tYnJhbmRcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJicmFuZC1tYXJrXCI+UEE8L3NwYW4+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxzdHJvbmc+UGxheWEgQXp1bDwvc3Ryb25nPlxuICAgICAgICAgICAgPHNtYWxsPkNvbnRyb2wgY2VudGVyPC9zbWFsbD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cImZvcm1cIiBvblN1Ym1pdD17c3VibWl0Q2hhbmdlUGFzc3dvcmR9PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJleWVicm93XCI+UFJJTUVSIEFDQ0VTTzwvc3Bhbj5cbiAgICAgICAgICAgIDxoMj5EZWZpbmUgdHUgY29udHJhc2XDsWE8L2gyPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXV0ZWRcIj5DYW1iaWEgbGEgY29udHJhc2XDsWEgdGVtcG9yYWwgYW50ZXMgZGUgY29udGludWFyLjwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8bGFiZWw+XG4gICAgICAgICAgICBDb250cmFzZcOxYSB0ZW1wb3JhbFxuICAgICAgICAgICAgPGlucHV0IG5hbWU9XCJwYXNzd29yZF9hY3R1YWxcIiB0eXBlPVwicGFzc3dvcmRcIiBhdXRvQ29tcGxldGU9XCJjdXJyZW50LXBhc3N3b3JkXCIgcmVxdWlyZWQgLz5cbiAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgIDxsYWJlbD5cbiAgICAgICAgICAgIE51ZXZhIGNvbnRyYXNlw7FhXG4gICAgICAgICAgICA8aW5wdXQgbmFtZT1cInBhc3N3b3JkX251ZXZhXCIgdHlwZT1cInBhc3N3b3JkXCIgbWluTGVuZ3RoPVwiOFwiIGF1dG9Db21wbGV0ZT1cIm5ldy1wYXNzd29yZFwiIHJlcXVpcmVkIC8+XG4gICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICA8bGFiZWw+XG4gICAgICAgICAgICBDb25maXJtYXIgbnVldmEgY29udHJhc2XDsWFcbiAgICAgICAgICAgIDxpbnB1dCBuYW1lPVwiY29uZmlybWFyX3Bhc3N3b3JkX251ZXZhXCIgdHlwZT1cInBhc3N3b3JkXCIgbWluTGVuZ3RoPVwiOFwiIGF1dG9Db21wbGV0ZT1cIm5ldy1wYXNzd29yZFwiIHJlcXVpcmVkIC8+XG4gICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInByaW1hcnlcIiB0eXBlPVwic3VibWl0XCI+R3VhcmRhciBjb250cmFzZcOxYSA8c3Bhbj7ihpI8L3NwYW4+PC9idXR0b24+XG4gICAgICAgIDwvZm9ybT5cbiAgICAgIDwvc2VjdGlvbj5cbiAgICA8L21haW4+XG4gIClcbn1cbiJdfQ==