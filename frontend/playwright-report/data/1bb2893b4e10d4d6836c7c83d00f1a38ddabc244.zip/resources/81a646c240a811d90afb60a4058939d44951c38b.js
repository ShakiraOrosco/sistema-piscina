import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Dashboard/index.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=41a64c35";
import { monitoringApi } from "/src/services/api.js";
import { useAuth } from "/src/context/AuthContext.jsx";
import PrediccionPanel from "/src/components/PrediccionPanel/index.jsx";
import ReportesModal from "/src/components/ReportesModal/index.jsx";
import { ResponsiveContainer, ComposedChart, Area, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ReferenceLine } from "/node_modules/.vite/deps/recharts.js?v=41a64c35";
var _jsxFileName = "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Dashboard/index.jsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=41a64c35";
var _s = $RefreshSig$();
export default function Dashboard() {
	_s();
	const { session, showError } = useAuth();
	const [sensorData, setSensorData] = useState(null);
	const [loadingSensors, setLoadingSensors] = useState(false);
	const [jornadaDisponible, setJornadaDisponible] = useState(true);
	const [selectedSensor, setSelectedSensor] = useState("ph");
	const [showReportModal, setShowReportModal] = useState(false);
	const loadSensorData = async () => {
		setLoadingSensors(true);
		try {
			const [{ data: state }, { data: alerts }] = await Promise.all([monitoringApi.get("/api/estado_actual"), monitoringApi.get("/api/alertas")]);
			setSensorData({
				...state,
				alertas: alerts
			});
			setJornadaDisponible(true);
		} catch (requestError) {
			setSensorData(null);
			if (requestError.response?.status === 404) {
				setJornadaDisponible(false);
			} else if (showError) {
				showError(requestError.response?.data?.detail || "No se pudieron cargar las lecturas de los sensores");
			}
		} finally {
			setLoadingSensors(false);
		}
	};
	useEffect(() => {
		loadSensorData();
		const intervalId = window.setInterval(loadSensorData, 1e4);
		return () => window.clearInterval(intervalId);
	}, []);
	const predecirAhora = async () => {
		try {
			await monitoringApi.post("/api/predecir");
			await loadSensorData();
		} catch (requestError) {
			if (showError) {
				showError(requestError.response?.data?.detail || "No se pudo generar la predicción");
			}
		}
	};
	const measurement = sensorData?.ultima_medicion;
	const summary = sensorData?.resumen;
	const rawReadings = sensorData?.historial || [];
	const pronostico = sensorData?.pronostico || {};
	const estadoSensores = sensorData?.estado_sensores || {};
	const estimados = sensorData?.valores_estimados || {};
	// Un sensor "falló" si no envió dato, envió algo fuera de rango o se desconectó
	const sensorFallo = (v) => [
		"sin_dato",
		"fuera_rango",
		"sin_conexion"
	].includes(estadoSensores?.[v]?.estado);
	const ultimoValido = (v) => {
		for (let i = rawReadings.length - 1; i >= 0; i--) {
			if (rawReadings[i][v] !== null && rawReadings[i][v] !== undefined) return rawReadings[i][v];
		}
		return null;
	};
	// Valor a mostrar en la tarjeta: estimado si el sensor falló, si no la última lectura válida
	const valorSensor = (v) => {
		if (sensorFallo(v) && estimados?.[v]) return estimados[v].valor;
		return measurement?.[v] ?? ultimoValido(v);
	};
	// Ordenar rawReadings de más reciente a más antigua para la tabla
	const sortedReadings = [...rawReadings].sort((a, b) => new Date(b.fecha_hora) - new Date(a.fecha_hora));
	// Formatear lecturas para los gráficos (cronológico ascendente de izquierda a derecha)
	const chartData = [...sortedReadings].reverse().map((r) => ({
		ts: new Date(r.fecha_hora).getTime(),
		hora: formatTime(r.fecha_hora),
		pH: r.ph !== null && r.ph !== undefined ? Number(Number(r.ph).toFixed(2)) : null,
		Turbidez: r.turbidez !== null && r.turbidez !== undefined ? Number(Number(r.turbidez).toFixed(2)) : null,
		Temperatura: r.temperatura !== null && r.temperatura !== undefined ? Number(Number(r.temperatura).toFixed(2)) : null
	}));
	const [currentPage, setCurrentPage] = useState(1);
	const [modalAforo, setModalAforo] = useState(null);
	const [modalPage, setModalPage] = useState(1);
	const [tableTab, setTableTab] = useState("sensores");
	const itemsPerPage = 10;
	const rawManualReadings = sensorData?.aforo_manual_registros || [];
	const manualSummary = sensorData?.aforo_manual_resumen || {};
	const rawCameraReadings = sensorData?.aforo_camara_registros || [];
	const cameraSummary = sensorData?.aforo_camara_resumen || {};
	// Ordenar de más reciente a más antigua
	const sortedManualReadings = [...rawManualReadings].sort((a, b) => new Date(b.hora_entrada || b.creado_en) - new Date(a.hora_entrada || a.creado_en));
	const sortedCameraReadings = [...rawCameraReadings].sort((a, b) => new Date(b.fecha_hora || b.creado_en) - new Date(a.fecha_hora || a.creado_en));
	// Datos para la tabla del dashboard según tab activo
	const currentTableList = tableTab === "manual" ? sortedManualReadings : tableTab === "camara" ? sortedCameraReadings : sortedReadings;
	const totalPages = Math.ceil(currentTableList.length / itemsPerPage) || 1;
	const paginatedList = currentTableList.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);
	// Datos para el modal según aforo seleccionado
	const modalList = modalAforo === "manual" ? sortedManualReadings : sortedCameraReadings;
	const modalTotalPages = Math.ceil(modalList.length / itemsPerPage) || 1;
	const paginatedModalList = modalList.slice((modalPage - 1) * itemsPerPage, modalPage * itemsPerPage);
	if (!jornadaDisponible) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "flex h-[60vh] flex-col items-center justify-center rounded-2xl border border-slate-200 dark:border-[#313D4A] bg-white dark:bg-[#24303F] p-8 text-center shadow-sm",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-blue-50 dark:bg-blue-900/20 text-blue-500",
					children: /* @__PURE__ */ _jsxDEV("svg", {
						width: "32",
						height: "32",
						viewBox: "0 0 24 24",
						fill: "none",
						xmlns: "http://www.w3.org/2000/svg",
						children: /* @__PURE__ */ _jsxDEV("path", {
							d: "M12 8V12L15 15M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z",
							stroke: "currentColor",
							strokeWidth: "2",
							strokeLinecap: "round",
							strokeLinejoin: "round"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 136,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 135,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 134,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h3", {
					className: "mb-2 text-2xl font-bold text-slate-800 dark:text-white",
					children: "No hay una jornada disponible"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 139,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "max-w-md text-slate-500 dark:text-slate-400",
					children: "Actualmente no hay ninguna jornada iniciada para el día de hoy. Los sensores comenzarán a registrar datos una vez que se inicie una nueva jornada."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 140,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 133,
			columnNumber: 7
		}, this);
	}
	const sensorConfig = {
		ph: {
			title: "Monitoreo de pH",
			color: "#2563eb",
			unit: "",
			dataKey: "pH",
			minOpt: 7,
			maxOpt: 7.6
		},
		turbidez: {
			title: "Monitoreo de Turbidez",
			color: "#ea580c",
			unit: "NTU",
			dataKey: "Turbidez",
			maxOpt: 5
		},
		temperatura: {
			title: "Monitoreo de Temperatura",
			color: "#10b981",
			unit: "°C",
			dataKey: "Temperatura",
			minOpt: 24,
			maxOpt: 30
		}
	};
	// Combinar lecturas reales + pronóstico del sensor seleccionado
	const cfgSel = sensorConfig[selectedSensor];
	const seriePron = pronostico?.[selectedSensor] || [];
	const puntosReales = chartData.map((p) => ({ ...p }));
	const ultimoReal = [...puntosReales].reverse().find((p) => p[cfgSel.dataKey] !== null);
	if (ultimoReal && seriePron.length) {
		// Ancla: el pronóstico arranca en la última lectura real para que la línea sea continua
		ultimoReal.Pronostico = ultimoReal[cfgSel.dataKey];
		ultimoReal.Rango = [ultimoReal[cfgSel.dataKey], ultimoReal[cfgSel.dataKey]];
	}
	const puntosPron = seriePron.map((p) => ({
		ts: new Date(p.fecha_hora).getTime(),
		hora: formatTime(p.fecha_hora),
		Pronostico: Number(Number(p.valor).toFixed(2)),
		Rango: [Number(Number(p.inferior).toFixed(2)), Number(Number(p.superior).toFixed(2))]
	}));
	const chartCombinado = [...puntosReales, ...puntosPron].sort((a, b) => a.ts - b.ts);
	const hayPronostico = puntosPron.length > 0;
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV("div", {
			className: "grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					onClick: () => setSelectedSensor("ph"),
					className: `cursor-pointer rounded-2xl border p-5 shadow-sm transition-all ${selectedSensor === "ph" ? "border-blue-500 ring-2 ring-blue-500/20 bg-blue-50/20 dark:bg-blue-900/10" : "border-slate-200 dark:border-[#313D4A] bg-white dark:bg-[#24303F] hover:border-blue-300"}`,
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "mb-3 flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 text-lg font-bold",
						children: "pH"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 202,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-end justify-between",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-medium text-slate-500 dark:text-slate-400",
							children: "Sensor de pH"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 207,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("h4", {
							className: "mt-1 text-2xl font-bold text-slate-800 dark:text-white flex items-baseline gap-1.5",
							children: [formatValue(valorSensor("ph")), sensorFallo("ph") && /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold text-amber-500",
								title: "Valor estimado por falla de sensor",
								children: "~est."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 211,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 208,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 206,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: `rounded-full px-2 py-0.5 text-[10px] font-semibold ${sensorFallo("ph") ? "bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400" : phState(valorSensor("ph")) === "normal" ? "bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400" : "bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400"}`,
							children: sensorFallo("ph") ? "Estimado" : phState(valorSensor("ph")) === "normal" ? "Óptimo" : "Alerta"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 215,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 205,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 198,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					onClick: () => setSelectedSensor("turbidez"),
					className: `cursor-pointer rounded-2xl border p-5 shadow-sm transition-all ${selectedSensor === "turbidez" ? "border-orange-500 ring-2 ring-orange-500/20 bg-orange-50/20 dark:bg-orange-900/10" : "border-slate-200 dark:border-[#313D4A] bg-white dark:bg-[#24303F] hover:border-orange-300"}`,
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "mb-3 flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 dark:bg-orange-900/20 text-orange-600 dark:text-orange-400",
						children: /* @__PURE__ */ _jsxDEV("svg", {
							width: "20",
							height: "20",
							viewBox: "0 0 24 24",
							fill: "none",
							xmlns: "http://www.w3.org/2000/svg",
							children: [/* @__PURE__ */ _jsxDEV("path", {
								d: "M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z",
								stroke: "currentColor",
								strokeWidth: "2",
								strokeLinecap: "round",
								strokeLinejoin: "round"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 234,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("path", {
								d: "M8 14C8 14 9.5 16 12 16C14.5 16 16 14 16 14",
								stroke: "currentColor",
								strokeWidth: "2",
								strokeLinecap: "round",
								strokeLinejoin: "round"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 235,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 233,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 232,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-end justify-between",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-medium text-slate-500 dark:text-slate-400",
							children: "Sensor Turbidez"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 240,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("h4", {
							className: "mt-1 text-2xl font-bold text-slate-800 dark:text-white flex items-baseline gap-1.5",
							children: [
								formatValue(valorSensor("turbidez")),
								" ",
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-medium text-slate-500 dark:text-slate-400",
									children: "NTU"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 242,
									columnNumber: 56
								}, this),
								sensorFallo("turbidez") && /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-semibold text-amber-500",
									title: "Valor estimado por falla de sensor",
									children: "~est."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 244,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 241,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 239,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: `rounded-full px-2 py-0.5 text-[10px] font-semibold ${sensorFallo("turbidez") ? "bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400" : turbidityState(valorSensor("turbidez")) === "normal" ? "bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400" : "bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400"}`,
							children: sensorFallo("turbidez") ? "Estimado" : turbidityState(valorSensor("turbidez")) === "normal" ? "Limpio" : "Alerta"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 248,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 238,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 228,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					onClick: () => setSelectedSensor("temperatura"),
					className: `cursor-pointer rounded-2xl border p-5 shadow-sm transition-all ${selectedSensor === "temperatura" ? "border-emerald-500 ring-2 ring-emerald-500/20 bg-emerald-50/20 dark:bg-emerald-900/10" : "border-slate-200 dark:border-[#313D4A] bg-white dark:bg-[#24303F] hover:border-emerald-300"}`,
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "mb-3 flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400",
						children: /* @__PURE__ */ _jsxDEV("svg", {
							width: "20",
							height: "20",
							viewBox: "0 0 24 24",
							fill: "none",
							xmlns: "http://www.w3.org/2000/svg",
							children: /* @__PURE__ */ _jsxDEV("path", {
								d: "M14 14.76V3.5C14 2.67157 13.3284 2 12.5 2C11.6716 2 11 2.67157 11 3.5V14.76C9.20914 15.6318 8 17.5255 8 19.5C8 22.5376 10.0147 24 12.5 24C14.9853 24 17 22.5376 17 19.5C17 17.5255 15.7909 15.6318 14 14.76Z",
								stroke: "currentColor",
								strokeWidth: "2",
								strokeLinecap: "round",
								strokeLinejoin: "round"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 267,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 266,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 265,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-end justify-between",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-medium text-slate-500 dark:text-slate-400",
							children: "Sensor Temperatura"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 272,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("h4", {
							className: "mt-1 text-2xl font-bold text-slate-800 dark:text-white flex items-baseline gap-1.5",
							children: [
								formatValue(valorSensor("temperatura")),
								" ",
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-medium text-slate-500 dark:text-slate-400",
									children: "°C"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 274,
									columnNumber: 59
								}, this),
								sensorFallo("temperatura") && /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-semibold text-amber-500",
									title: "Valor estimado por falla de sensor",
									children: "~est."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 276,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 273,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 271,
							columnNumber: 13
						}, this), sensorFallo("temperatura") && /* @__PURE__ */ _jsxDEV("span", {
							className: "rounded-full bg-amber-50 dark:bg-amber-900/20 px-2 py-0.5 text-[10px] font-semibold text-amber-600 dark:text-amber-400",
							children: "Estimado"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 281,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 270,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 261,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					onClick: () => {
						setModalAforo("manual");
						setModalPage(1);
					},
					className: "group cursor-pointer rounded-2xl border border-slate-200 dark:border-[#313D4A] bg-white dark:bg-[#24303F] p-5 shadow-sm transition-all hover:border-indigo-400 dark:hover:border-indigo-500 hover:shadow-md",
					title: "Haz clic para ver todos los registros de taquilla del día",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mb-3 flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 group-hover:scale-105 transition-transform",
							children: /* @__PURE__ */ _jsxDEV("svg", {
								width: "20",
								height: "20",
								viewBox: "0 0 24 24",
								fill: "none",
								xmlns: "http://www.w3.org/2000/svg",
								children: [/* @__PURE__ */ _jsxDEV("path", {
									d: "M17 21V19C17 17.9391 16.5786 16.9217 15.8284 16.1716C15.0783 15.4214 14.0609 15 13 15H5C3.93913 15 2.92172 15.4214 2.17157 16.1716C1.42143 16.9217 1 17.9391 1 19V21",
									stroke: "currentColor",
									strokeWidth: "2",
									strokeLinecap: "round",
									strokeLinejoin: "round"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 296,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("path", {
									d: "M9 11C11.2091 11 13 9.20914 13 7C13 4.79086 11.2091 3 9 3C6.79086 3 5 4.79086 5 7C5 9.20914 6.79086 11 9 11Z",
									stroke: "currentColor",
									strokeWidth: "2",
									strokeLinecap: "round",
									strokeLinejoin: "round"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 297,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 295,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 294,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-end justify-between",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-medium text-slate-500 dark:text-slate-400",
								children: "Aforo Manual"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 302,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("h4", {
								className: "mt-1 text-2xl font-bold text-slate-800 dark:text-white",
								children: sensorData?.aforo_manual ?? sensorData?.personas_hoy ?? summary?.total_personas ?? "0"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 303,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 301,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "rounded-full bg-blue-50 dark:bg-blue-900/20 px-2 py-0.5 text-[10px] font-semibold text-blue-600 dark:text-blue-400",
								children: "Taquilla"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 307,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 300,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mt-3 flex items-center justify-between border-t border-slate-100 dark:border-[#313D4A] pt-2.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400 group-hover:text-indigo-700 dark:group-hover:text-indigo-300",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: [
								"Ver registros (",
								rawManualReadings.length,
								")"
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 312,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("svg", {
								className: "w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5",
								fill: "none",
								stroke: "currentColor",
								viewBox: "0 0 24 24",
								children: /* @__PURE__ */ _jsxDEV("path", {
									strokeLinecap: "round",
									strokeLinejoin: "round",
									strokeWidth: "2.5",
									d: "M9 5l7 7-7 7"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 314,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 313,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 311,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 289,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					onClick: () => {
						setModalAforo("camara");
						setModalPage(1);
					},
					className: "group cursor-pointer rounded-2xl border border-slate-200 dark:border-[#313D4A] bg-white dark:bg-[#24303F] p-5 shadow-sm transition-all hover:border-purple-400 dark:hover:border-purple-500 hover:shadow-md",
					title: "Haz clic para ver todos los registros de la cámara del día",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mb-3 flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400 group-hover:scale-105 transition-transform",
							children: /* @__PURE__ */ _jsxDEV("svg", {
								width: "20",
								height: "20",
								viewBox: "0 0 24 24",
								fill: "none",
								xmlns: "http://www.w3.org/2000/svg",
								children: /* @__PURE__ */ _jsxDEV("path", {
									d: "M15 10L21 6V18L15 14M4 18H13C14.1046 18 15 17.1046 15 16V8C15 6.89543 14.1046 6 13 6H4C2.89543 6 2 6.89543 2 8V16C2 17.1046 2.89543 18 4 18Z",
									stroke: "currentColor",
									strokeWidth: "2",
									strokeLinecap: "round",
									strokeLinejoin: "round"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 327,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 326,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 325,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-end justify-between",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-medium text-slate-500 dark:text-slate-400",
								children: "Aforo Cámara"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 332,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("h4", {
								className: "mt-1 text-2xl font-bold text-slate-800 dark:text-white",
								children: sensorData?.aforo_camara ?? "0"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 333,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 331,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "rounded-full bg-purple-50 dark:bg-purple-900/20 px-2 py-0.5 text-[10px] font-semibold text-purple-600 dark:text-purple-400",
								children: "Cámara IA"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 337,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 330,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mt-3 flex items-center justify-between border-t border-slate-100 dark:border-[#313D4A] pt-2.5 text-xs font-semibold text-purple-600 dark:text-purple-400 group-hover:text-purple-700 dark:group-hover:text-purple-300",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: [
								"Ver registros (",
								rawCameraReadings.length,
								")"
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 342,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("svg", {
								className: "w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5",
								fill: "none",
								stroke: "currentColor",
								viewBox: "0 0 24 24",
								children: /* @__PURE__ */ _jsxDEV("path", {
									strokeLinecap: "round",
									strokeLinejoin: "round",
									strokeWidth: "2.5",
									d: "M9 5l7 7-7 7"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 344,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 343,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 341,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 320,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 195,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(PrediccionPanel, {
			prediccion: sensorData?.prediccion,
			detalle: sensorData?.prediccion_detalle,
			dosisAplicadas: sensorData?.dosis_aplicadas,
			onPredecir: predecirAhora
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 352,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "mt-6 flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-slate-200 dark:border-[#313D4A] bg-white dark:bg-[#24303F] p-4 shadow-sm",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "text-sm font-bold text-slate-700 dark:text-slate-200 mr-2",
						children: "Ver Gráfico de:"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 362,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setSelectedSensor("ph"),
						className: `rounded-xl px-4 py-2 text-sm font-semibold transition-all ${selectedSensor === "ph" ? "bg-blue-600 text-white shadow-md" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200"}`,
						children: "💧 pH"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 364,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setSelectedSensor("turbidez"),
						className: `rounded-xl px-4 py-2 text-sm font-semibold transition-all ${selectedSensor === "turbidez" ? "bg-orange-600 text-white shadow-md" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200"}`,
						children: "🌊 Turbidez"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 371,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setSelectedSensor("temperatura"),
						className: `rounded-xl px-4 py-2 text-sm font-semibold transition-all ${selectedSensor === "temperatura" ? "bg-emerald-600 text-white shadow-md" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200"}`,
						children: "🌡️ Temperatura"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 378,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 361,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					onClick: () => setShowReportModal(true),
					className: "flex items-center gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shadow-sm hover:shadow cursor-pointer",
					children: [/* @__PURE__ */ _jsxDEV("svg", {
						className: "w-3.5 h-3.5",
						fill: "none",
						stroke: "currentColor",
						viewBox: "0 0 24 24",
						children: /* @__PURE__ */ _jsxDEV("path", {
							strokeLinecap: "round",
							strokeLinejoin: "round",
							strokeWidth: "2",
							d: "M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 392,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 391,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Generar Reporte (PDF)" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 394,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 387,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "flex items-center gap-1.5 rounded-full bg-emerald-50 dark:bg-emerald-900/20 px-3 py-1 text-xs font-semibold text-emerald-600 dark:text-emerald-400",
					children: [/* @__PURE__ */ _jsxDEV("span", { className: "h-2 w-2 rounded-full bg-emerald-500 animate-pulse" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 398,
						columnNumber: 13
					}, this), " Lecturas en tiempo real"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 397,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 386,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 360,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "mt-6 grid grid-cols-1 gap-6 xl:grid-cols-3",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "rounded-2xl border border-slate-200 dark:border-[#313D4A] bg-white dark:bg-[#24303F] p-7 shadow-sm xl:col-span-2",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "mb-6 flex flex-wrap items-center justify-between gap-2",
					children: /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
						className: "text-xl font-bold text-slate-800 dark:text-white flex items-center gap-3",
						children: [sensorConfig[selectedSensor]?.title, hayPronostico && /* @__PURE__ */ _jsxDEV("span", {
							className: "rounded-full bg-violet-50 dark:bg-violet-900/20 px-3 py-1 text-xs font-semibold text-violet-600 dark:text-violet-300",
							children: "-- Pronóstico a 20:00"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 412,
							columnNumber: 19
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 409,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-sm font-medium text-slate-500 dark:text-slate-400",
						children: `Historial real (línea continua) y tendencia estimada hasta el cierre (línea punteada)`
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 417,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 408,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 407,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "h-80 w-full",
					children: chartCombinado.length > 0 ? /* @__PURE__ */ _jsxDEV(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ _jsxDEV(ComposedChart, {
							data: chartCombinado,
							margin: {
								top: 15,
								right: 30,
								left: 0,
								bottom: 5
							},
							children: [
								/* @__PURE__ */ _jsxDEV(CartesianGrid, {
									strokeDasharray: "3 3",
									stroke: "#e2e8f0",
									opacity: .6
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 427,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV(XAxis, {
									dataKey: "hora",
									stroke: "#64748b",
									fontSize: 11
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 428,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV(YAxis, {
									domain: [(dataMin) => Math.floor((dataMin - .2) * 10) / 10, (dataMax) => Math.ceil((dataMax + .2) * 10) / 10],
									stroke: sensorConfig[selectedSensor].color,
									fontSize: 11
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 429,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV(Tooltip, { contentStyle: {
									backgroundColor: "#0f172a",
									borderRadius: "8px",
									border: "none",
									color: "#fff"
								} }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 434,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV(Legend, {}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 435,
									columnNumber: 19
								}, this),
								sensorConfig[selectedSensor].minOpt && /* @__PURE__ */ _jsxDEV(ReferenceLine, {
									y: sensorConfig[selectedSensor].minOpt,
									label: {
										value: "Min Óptimo (7.0)",
										fill: "#10b981",
										fontSize: 10
									},
									stroke: "#10b981",
									strokeDasharray: "4 4"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 438,
									columnNumber: 21
								}, this),
								sensorConfig[selectedSensor].maxOpt && /* @__PURE__ */ _jsxDEV(ReferenceLine, {
									y: sensorConfig[selectedSensor].maxOpt,
									label: {
										value: "Max Óptimo (7.6)",
										fill: "#10b981",
										fontSize: 10
									},
									stroke: "#10b981",
									strokeDasharray: "4 4"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 441,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV(Area, {
									type: "linear",
									dataKey: "Rango",
									stroke: "none",
									fill: sensorConfig[selectedSensor].color,
									fillOpacity: .12,
									name: "Rango de confianza (95%)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 445,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV(Line, {
									type: "linear",
									name: `${sensorConfig[selectedSensor].dataKey} Real`,
									dataKey: sensorConfig[selectedSensor].dataKey,
									stroke: sensorConfig[selectedSensor].color,
									strokeWidth: 3,
									dot: {
										r: 4,
										fill: sensorConfig[selectedSensor].color,
										strokeWidth: 1.5,
										stroke: "#fff"
									},
									activeDot: { r: 6 },
									connectNulls: false
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 455,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV(Line, {
									type: "linear",
									name: `${sensorConfig[selectedSensor].dataKey} Pronosticado`,
									dataKey: "Pronostico",
									stroke: sensorConfig[selectedSensor].color,
									strokeWidth: 2.5,
									strokeDasharray: "5 5",
									dot: {
										r: 3,
										fill: "#fff",
										strokeWidth: 2,
										stroke: sensorConfig[selectedSensor].color
									},
									activeDot: { r: 5 },
									connectNulls: true
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 467,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 426,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 425,
						columnNumber: 15
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "flex h-full items-center justify-center text-sm text-slate-400",
						children: "Esperando primeras lecturas del sensor..."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 481,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 423,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 406,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "rounded-2xl border border-slate-200 dark:border-[#313D4A] bg-white dark:bg-[#24303F] p-7 shadow-sm xl:col-span-1",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "mb-6 flex items-center justify-between",
					children: /* @__PURE__ */ _jsxDEV("h4", {
						className: "text-xl font-bold text-slate-800 dark:text-white flex items-center gap-2",
						children: ["Alertas en Vivo", sensorData?.alertas?.some((a) => a.tipo === "action") && /* @__PURE__ */ _jsxDEV("span", { className: "flex h-2.5 w-2.5 rounded-full bg-blue-500 animate-ping" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 494,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 491,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 490,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col gap-4",
					children: sensorData?.alertas?.length ? sensorData.alertas.map((alert, index) => {
						const esAccion = alert.tipo === "action";
						const esOk = alert.tipo === "ok";
						return /* @__PURE__ */ _jsxDEV("div", {
							className: `flex flex-col gap-3 rounded-lg border p-4 ${esOk ? "border-emerald-100 dark:border-emerald-900/30 bg-emerald-50/50 dark:bg-emerald-900/10" : esAccion ? "border-blue-200 dark:border-blue-900/50 bg-blue-50 dark:bg-blue-900/20 shadow-sm" : "border-red-100 dark:border-red-900/30 bg-red-50/50 dark:bg-red-900/10"}`,
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-start gap-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: `flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full ${esOk ? "bg-emerald-100 dark:bg-emerald-900/50 text-emerald-600 dark:text-emerald-400" : esAccion ? "bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400" : "bg-red-100 dark:bg-red-900/50 text-red-600 dark:text-red-400"}`,
									children: esOk ? /* @__PURE__ */ _jsxDEV("svg", {
										className: "w-5 h-5",
										fill: "none",
										stroke: "currentColor",
										viewBox: "0 0 24 24",
										xmlns: "http://www.w3.org/2000/svg",
										children: /* @__PURE__ */ _jsxDEV("path", {
											strokeLinecap: "round",
											strokeLinejoin: "round",
											strokeWidth: "2",
											d: "M5 13l4 4L19 7"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 520,
											columnNumber: 139
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 520,
										columnNumber: 25
									}, this) : esAccion ? /* @__PURE__ */ _jsxDEV("svg", {
										className: "w-5 h-5",
										fill: "none",
										stroke: "currentColor",
										viewBox: "0 0 24 24",
										xmlns: "http://www.w3.org/2000/svg",
										children: /* @__PURE__ */ _jsxDEV("path", {
											strokeLinecap: "round",
											strokeLinejoin: "round",
											strokeWidth: "2",
											d: "M13 10V3L4 14h7v7l9-11h-7z"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 522,
											columnNumber: 139
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 522,
										columnNumber: 25
									}, this) : /* @__PURE__ */ _jsxDEV("svg", {
										className: "w-5 h-5",
										fill: "none",
										stroke: "currentColor",
										viewBox: "0 0 24 24",
										xmlns: "http://www.w3.org/2000/svg",
										children: /* @__PURE__ */ _jsxDEV("path", {
											strokeLinecap: "round",
											strokeLinejoin: "round",
											strokeWidth: "2",
											d: "M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 524,
											columnNumber: 139
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 524,
										columnNumber: 25
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 514,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: `text-sm font-medium leading-relaxed ${esOk ? "text-emerald-800 dark:text-emerald-400" : esAccion ? "text-blue-900 dark:text-blue-300" : "text-red-800 dark:text-red-400"}`,
									children: alert.msg
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 527,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 513,
								columnNumber: 19
							}, this), esAccion && /* @__PURE__ */ _jsxDEV("button", {
								onClick: async () => {
									try {
										await monitoringApi.post("/api/dosificacion_parcial", {
											quimico: alert.quimico,
											cantidad_g: alert.cantidad
										});
										await loadSensorData();
									} catch (e) {
										if (showError) showError("Error al registrar la micro-dosis");
									}
								},
								className: "mt-2 flex w-full items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 py-2 text-sm font-semibold text-white shadow-md transition-all hover:-translate-y-0.5 hover:bg-blue-700 hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: [
									"Aplicar Dosis (",
									alert.cantidad,
									"g)"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 551,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("svg", {
									width: "16",
									height: "16",
									viewBox: "0 0 24 24",
									fill: "none",
									xmlns: "http://www.w3.org/2000/svg",
									children: /* @__PURE__ */ _jsxDEV("path", {
										d: "M5 12h14M12 5l7 7-7 7",
										stroke: "currentColor",
										strokeWidth: "2",
										strokeLinecap: "round",
										strokeLinejoin: "round"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 553,
										columnNumber: 25
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 552,
									columnNumber: 23
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 537,
								columnNumber: 21
							}, this)]
						}, index, true, {
							fileName: _jsxFileName,
							lineNumber: 505,
							columnNumber: 17
						}, this);
					}) : /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3 rounded-lg border border-slate-100 dark:border-[#313D4A] bg-slate-50 dark:bg-[#1A222C] p-4",
						children: /* @__PURE__ */ _jsxDEV("p", {
							className: "text-sm font-medium text-slate-500 dark:text-slate-400",
							children: "Sin alertas hoy."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 561,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 560,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 499,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 489,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 404,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "mt-6",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "rounded-2xl border border-slate-200 dark:border-[#313D4A] bg-white dark:bg-[#24303F] p-7 shadow-sm",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mb-6 flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 dark:border-[#313D4A] pb-5",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => {
										setTableTab("sensores");
										setCurrentPage(1);
									},
									className: `flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold transition-all ${tableTab === "sensores" ? "bg-blue-600 text-white shadow-md shadow-blue-500/20" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"}`,
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "💧 Sensores Físicos" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 584,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: `rounded-full px-2 py-0.5 text-xs font-semibold ${tableTab === "sensores" ? "bg-white/20 text-white" : "bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300"}`,
										children: sortedReadings.length
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 585,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 576,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => {
										setTableTab("manual");
										setCurrentPage(1);
									},
									className: `flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold transition-all ${tableTab === "manual" ? "bg-indigo-600 text-white shadow-md shadow-indigo-500/20" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"}`,
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "👥 Aforo Manual (Taquilla)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 598,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: `rounded-full px-2 py-0.5 text-xs font-semibold ${tableTab === "manual" ? "bg-white/20 text-white" : "bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300"}`,
										children: sortedManualReadings.length
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 599,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 590,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => {
										setTableTab("camara");
										setCurrentPage(1);
									},
									className: `flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold transition-all ${tableTab === "camara" ? "bg-purple-600 text-white shadow-md shadow-purple-500/20" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"}`,
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "📷 Aforo Cámara (IA)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 612,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: `rounded-full px-2 py-0.5 text-xs font-semibold ${tableTab === "camara" ? "bg-white/20 text-white" : "bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300"}`,
										children: sortedCameraReadings.length
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 613,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 604,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setShowReportModal(true),
									className: "flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-md shadow-blue-500/20 transition-all cursor-pointer",
									children: /* @__PURE__ */ _jsxDEV("span", { children: "📊 Generar Reporte / Exportar PDF" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 622,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 618,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 575,
							columnNumber: 13
						}, this), (tableTab === "manual" || tableTab === "camara") && /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => {
								setModalAforo(tableTab);
								setModalPage(1);
							},
							className: "inline-flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3.5 py-2 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-all shadow-sm",
							children: [/* @__PURE__ */ _jsxDEV("svg", {
								className: "w-4 h-4 text-blue-500",
								fill: "none",
								stroke: "currentColor",
								viewBox: "0 0 24 24",
								children: /* @__PURE__ */ _jsxDEV("path", {
									strokeLinecap: "round",
									strokeLinejoin: "round",
									strokeWidth: "2",
									d: "M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 633,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 632,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Abrir en Vista Completa" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 635,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 628,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 574,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mb-6 flex flex-wrap items-center justify-between gap-4",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
							className: "text-xl font-bold text-slate-800 dark:text-white",
							children: [
								tableTab === "sensores" && "Historial de Lecturas Registradas de Sensores",
								tableTab === "manual" && "Historial de Ingresos Registrados en Taquilla",
								tableTab === "camara" && "Historial de Conteo Registrado por Cámara Inteligente"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 642,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-sm font-medium text-slate-500 dark:text-slate-400",
							children: [
								"Mostrando ",
								currentTableList.length > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0,
								" - ",
								Math.min(currentPage * itemsPerPage, currentTableList.length),
								" de ",
								currentTableList.length,
								" registros del día"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 647,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 641,
							columnNumber: 13
						}, this), currentTableList.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setCurrentPage((prev) => Math.max(prev - 1, 1)),
									disabled: currentPage === 1,
									className: "flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 transition-all hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed",
									title: "Página anterior",
									children: /* @__PURE__ */ _jsxDEV("svg", {
										width: "18",
										height: "18",
										viewBox: "0 0 24 24",
										fill: "none",
										xmlns: "http://www.w3.org/2000/svg",
										children: /* @__PURE__ */ _jsxDEV("path", {
											d: "M15 19L8 12L15 5",
											stroke: "currentColor",
											strokeWidth: "2",
											strokeLinecap: "round",
											strokeLinejoin: "round"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 662,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 661,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 655,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-sm font-semibold text-slate-700 dark:text-slate-300",
									children: [
										"Página ",
										currentPage,
										" de ",
										totalPages
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 666,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setCurrentPage((prev) => Math.min(prev + 1, totalPages)),
									disabled: currentPage === totalPages,
									className: "flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 transition-all hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed",
									title: "Página siguiente",
									children: /* @__PURE__ */ _jsxDEV("svg", {
										width: "18",
										height: "18",
										viewBox: "0 0 24 24",
										fill: "none",
										xmlns: "http://www.w3.org/2000/svg",
										children: /* @__PURE__ */ _jsxDEV("path", {
											d: "M9 5L16 12L9 19",
											stroke: "currentColor",
											strokeWidth: "2",
											strokeLinecap: "round",
											strokeLinejoin: "round"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 677,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 676,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 670,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 654,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 640,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "max-w-full overflow-x-auto",
						children: [
							tableTab === "sensores" && /* @__PURE__ */ _jsxDEV("table", {
								className: "w-full table-auto",
								children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
									className: "border-b border-slate-200 dark:border-[#313D4A] text-left",
									children: [
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 pr-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide",
											children: "HORA"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 690,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide",
											children: "pH"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 691,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide",
											children: "TURBIDEZ (NTU)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 692,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 pl-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide",
											children: "TEMPERATURA (°C)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 693,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 689,
									columnNumber: 19
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 688,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: [paginatedList.map((reading, index) => /* @__PURE__ */ _jsxDEV("tr", {
									className: "border-b border-slate-100 dark:border-[#313D4A] last:border-0 hover:bg-slate-50 dark:hover:bg-[#313D4A] transition-colors",
									children: [
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 pr-4 text-sm font-medium text-slate-700 dark:text-slate-300",
											children: formatTime(reading.fecha_hora)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 699,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 px-4 text-sm font-medium text-slate-800 dark:text-slate-200",
											children: formatValue(reading.ph)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 702,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 px-4 text-sm font-medium text-slate-800 dark:text-slate-200",
											children: [formatValue(reading.turbidez), " NTU"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 705,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 pl-4 text-sm font-bold text-slate-800 dark:text-slate-200",
											children: [formatValue(reading.temperatura), " °C"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 708,
											columnNumber: 23
										}, this)
									]
								}, index, true, {
									fileName: _jsxFileName,
									lineNumber: 698,
									columnNumber: 21
								}, this)), paginatedList.length === 0 && /* @__PURE__ */ _jsxDEV("tr", { children: /* @__PURE__ */ _jsxDEV("td", {
									colSpan: "4",
									className: "py-8 text-center text-sm text-slate-500 dark:text-slate-400",
									children: "No hay lecturas de sensores registradas en la jornada de hoy."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 715,
									columnNumber: 23
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 714,
									columnNumber: 21
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 696,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 687,
								columnNumber: 15
							}, this),
							tableTab === "manual" && /* @__PURE__ */ _jsxDEV("table", {
								className: "w-full table-auto",
								children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
									className: "border-b border-slate-200 dark:border-[#313D4A] text-left",
									children: [
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 pr-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide",
											children: "HORA ENTRADA"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 729,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide text-center",
											children: "TOTAL PERSONAS"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 730,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide text-center",
											children: "TARIFA 15 BS"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 731,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide text-center",
											children: "TARIFA 20 BS"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 732,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide text-right",
											children: "TOTAL RECAUDADO"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 733,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 pl-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide",
											children: "OBSERVACIONES"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 734,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 728,
									columnNumber: 19
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 727,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: [paginatedList.map((reg, index) => /* @__PURE__ */ _jsxDEV("tr", {
									className: "border-b border-slate-100 dark:border-[#313D4A] last:border-0 hover:bg-slate-50 dark:hover:bg-[#313D4A] transition-colors",
									children: [
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 pr-4 text-sm font-semibold text-slate-700 dark:text-slate-300",
											children: formatTime(reg.hora_entrada || reg.creado_en)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 740,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 px-4 text-sm text-center",
											children: /* @__PURE__ */ _jsxDEV("span", {
												className: "inline-flex items-center justify-center rounded-full bg-indigo-50 dark:bg-indigo-900/30 px-3 py-0.5 text-xs font-bold text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800",
												children: [reg.total_personas, " pers."]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 744,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 743,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 px-4 text-sm font-medium text-slate-700 dark:text-slate-300 text-center",
											children: reg.cantidad_tarifa_15 ?? 0
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 748,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 px-4 text-sm font-medium text-slate-700 dark:text-slate-300 text-center",
											children: reg.cantidad_tarifa_20 ?? 0
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 751,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 px-4 text-sm font-bold text-emerald-600 dark:text-emerald-400 text-right",
											children: ["Bs. ", Number(reg.total_recaudado ?? 0).toFixed(2)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 754,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 pl-4 text-sm text-slate-500 dark:text-slate-400 italic",
											children: reg.observaciones || "—"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 757,
											columnNumber: 23
										}, this)
									]
								}, reg.id_registro || index, true, {
									fileName: _jsxFileName,
									lineNumber: 739,
									columnNumber: 21
								}, this)), paginatedList.length === 0 && /* @__PURE__ */ _jsxDEV("tr", { children: /* @__PURE__ */ _jsxDEV("td", {
									colSpan: "6",
									className: "py-8 text-center text-sm text-slate-500 dark:text-slate-400",
									children: "No se han registrado ingresos manuales de taquilla en la jornada de hoy."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 764,
									columnNumber: 23
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 763,
									columnNumber: 21
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 737,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 726,
								columnNumber: 15
							}, this),
							tableTab === "camara" && /* @__PURE__ */ _jsxDEV("table", {
								className: "w-full table-auto",
								children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
									className: "border-b border-slate-200 dark:border-[#313D4A] text-left",
									children: [
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 pr-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide",
											children: "HORA DE CAPTURA"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 778,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide text-center",
											children: "PERSONAS DETECTADAS"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 779,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide text-center",
											children: "NIVEL DE AFLUENCIA"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 780,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 pl-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide",
											children: "DISPOSITIVO"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 781,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 777,
									columnNumber: 19
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 776,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: [paginatedList.map((reg, index) => /* @__PURE__ */ _jsxDEV("tr", {
									className: "border-b border-slate-100 dark:border-[#313D4A] last:border-0 hover:bg-slate-50 dark:hover:bg-[#313D4A] transition-colors",
									children: [
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 pr-4 text-sm font-semibold text-slate-700 dark:text-slate-300",
											children: formatTime(reg.fecha_hora || reg.creado_en)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 787,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 px-4 text-sm text-center",
											children: /* @__PURE__ */ _jsxDEV("span", {
												className: "inline-flex items-center justify-center rounded-full bg-purple-50 dark:bg-purple-900/30 px-3.5 py-1 text-sm font-black text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800",
												children: [reg.cantidad_personas, " bañistas"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 791,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 790,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 px-4 text-sm text-center",
											children: badgeAfluencia(reg.cantidad_personas)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 795,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 pl-4 text-sm font-medium text-slate-600 dark:text-slate-400",
											children: /* @__PURE__ */ _jsxDEV("span", {
												className: "inline-flex items-center gap-1.5 font-mono text-xs bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-lg border border-slate-200 dark:border-slate-700",
												children: ["📷 ", reg.id_dispositivo || "ESP32-CAM"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 799,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 798,
											columnNumber: 23
										}, this)
									]
								}, reg.id_registro || index, true, {
									fileName: _jsxFileName,
									lineNumber: 786,
									columnNumber: 21
								}, this)), paginatedList.length === 0 && /* @__PURE__ */ _jsxDEV("tr", { children: /* @__PURE__ */ _jsxDEV("td", {
									colSpan: "4",
									className: "py-8 text-center text-sm text-slate-500 dark:text-slate-400",
									children: "No hay lecturas registradas por la cámara inteligente en la jornada de hoy."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 807,
									columnNumber: 23
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 806,
									columnNumber: 21
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 784,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 775,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 684,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 571,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 570,
			columnNumber: 7
		}, this),
		modalAforo && /* @__PURE__ */ _jsxDEV("div", {
			className: "fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto",
			onClick: () => setModalAforo(null),
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "relative w-full max-w-4xl rounded-3xl bg-white dark:bg-[#24303F] border border-slate-200 dark:border-[#313D4A] shadow-2xl overflow-hidden my-6 animate-in fade-in zoom-in-95 duration-200",
				onClick: (e) => e.stopPropagation(),
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between border-b border-slate-100 dark:border-[#313D4A] px-7 py-5",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: `flex h-11 w-11 items-center justify-center rounded-xl ${modalAforo === "manual" ? "bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400" : "bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400"}`,
								children: modalAforo === "manual" ? /* @__PURE__ */ _jsxDEV("svg", {
									width: "24",
									height: "24",
									viewBox: "0 0 24 24",
									fill: "none",
									stroke: "currentColor",
									strokeWidth: "2",
									strokeLinecap: "round",
									strokeLinejoin: "round",
									children: [/* @__PURE__ */ _jsxDEV("path", { d: "M17 21V19C17 17.9391 16.5786 16.9217 15.8284 16.1716C15.0783 15.4214 14.0609 15 13 15H5C3.93913 15 2.92172 15.4214 2.17157 16.1716C1.42143 16.9217 1 17.9391 1 19V21" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 839,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("path", { d: "M9 11C11.2091 11 13 9.20914 13 7C13 4.79086 11.2091 3 9 3C6.79086 3 5 4.79086 5 7C5 9.20914 6.79086 11 9 11Z" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 840,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 838,
									columnNumber: 21
								}, this) : /* @__PURE__ */ _jsxDEV("svg", {
									width: "24",
									height: "24",
									viewBox: "0 0 24 24",
									fill: "none",
									stroke: "currentColor",
									strokeWidth: "2",
									strokeLinecap: "round",
									strokeLinejoin: "round",
									children: /* @__PURE__ */ _jsxDEV("path", { d: "M15 10L21 6V18L15 14M4 18H13C14.1046 18 15 17.1046 15 16V8C15 6.89543 14.1046 6 13 6H4C2.89543 6 2 6.89543 2 8V16C2 17.1046 2.89543 18 4 18Z" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 844,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 843,
									columnNumber: 21
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 832,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-xl font-bold text-slate-800 dark:text-white",
								children: ["Registros del Día — ", modalAforo === "manual" ? "Aforo Manual (Taquilla)" : "Aforo Cámara Inteligente"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 849,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs font-medium text-slate-500 dark:text-slate-400",
								children: "Historial cronológico completo de las lecturas registradas durante la jornada de hoy"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 852,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 848,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 831,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setModalAforo(null),
							className: "rounded-xl p-2 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-600 dark:hover:text-slate-200 transition-colors",
							title: "Cerrar ventana",
							children: /* @__PURE__ */ _jsxDEV("svg", {
								className: "w-6 h-6",
								fill: "none",
								stroke: "currentColor",
								viewBox: "0 0 24 24",
								children: /* @__PURE__ */ _jsxDEV("path", {
									strokeLinecap: "round",
									strokeLinejoin: "round",
									strokeWidth: "2",
									d: "M6 18L18 6M6 6l12 12"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 864,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 863,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 858,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 830,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex border-b border-slate-100 dark:border-[#313D4A] px-7 pt-3 bg-slate-50/50 dark:bg-slate-900/20 gap-3",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => {
								setModalAforo("manual");
								setModalPage(1);
							},
							className: `flex items-center gap-2 border-b-2 px-4 py-3 text-sm font-bold transition-all ${modalAforo === "manual" ? "border-indigo-600 text-indigo-600 dark:text-indigo-400" : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"}`,
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "👥 Aforo Manual (Taquilla)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 879,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "rounded-full bg-indigo-50 dark:bg-indigo-900/30 px-2 py-0.5 text-xs text-indigo-600 dark:text-indigo-400 font-semibold",
								children: sortedManualReadings.length
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 880,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 871,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => {
								setModalAforo("camara");
								setModalPage(1);
							},
							className: `flex items-center gap-2 border-b-2 px-4 py-3 text-sm font-bold transition-all ${modalAforo === "camara" ? "border-purple-600 text-purple-600 dark:text-purple-400" : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"}`,
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "📷 Aforo Cámara IA" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 893,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "rounded-full bg-purple-50 dark:bg-purple-900/30 px-2 py-0.5 text-xs text-purple-600 dark:text-purple-400 font-semibold",
								children: sortedCameraReadings.length
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 894,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 885,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 870,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-7 max-h-[70vh] overflow-y-auto",
						children: [
							modalAforo === "manual" ? /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 md:grid-cols-4 gap-4 mb-6",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "rounded-xl border border-slate-200 dark:border-[#313D4A] bg-slate-50 dark:bg-slate-800/50 p-4",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs font-semibold uppercase tracking-wider text-slate-400",
											children: "Total Personas Hoy"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 906,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-2xl font-black text-slate-800 dark:text-white mt-1",
											children: manualSummary.total_personas ?? sensorData?.aforo_manual ?? 0
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 907,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 905,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "rounded-xl border border-slate-200 dark:border-[#313D4A] bg-slate-50 dark:bg-slate-800/50 p-4",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs font-semibold uppercase tracking-wider text-emerald-500",
											children: "Recaudado Hoy"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 912,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1",
											children: ["Bs. ", Number(manualSummary.total_recaudado ?? 0).toFixed(2)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 913,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 911,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "rounded-xl border border-slate-200 dark:border-[#313D4A] bg-slate-50 dark:bg-slate-800/50 p-4",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs font-semibold uppercase tracking-wider text-blue-500",
											children: "Tarifa 15 Bs"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 918,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-2xl font-black text-blue-600 dark:text-blue-400 mt-1",
											children: [
												manualSummary.total_tarifa_15 ?? 0,
												" ",
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs font-normal text-slate-400",
													children: "pers."
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 920,
													columnNumber: 60
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 919,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 917,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "rounded-xl border border-slate-200 dark:border-[#313D4A] bg-slate-50 dark:bg-slate-800/50 p-4",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs font-semibold uppercase tracking-wider text-indigo-500",
											children: "Tarifa 20 Bs"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 924,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-2xl font-black text-indigo-600 dark:text-indigo-400 mt-1",
											children: [
												manualSummary.total_tarifa_20 ?? 0,
												" ",
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs font-normal text-slate-400",
													children: "pers."
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 926,
													columnNumber: 60
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 925,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 923,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 904,
								columnNumber: 17
							}, this) : /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 md:grid-cols-4 gap-4 mb-6",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "rounded-xl border border-slate-200 dark:border-[#313D4A] bg-slate-50 dark:bg-slate-800/50 p-4",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs font-semibold uppercase tracking-wider text-slate-400",
											children: "Último Conteo en Vivo"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 933,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-2xl font-black text-slate-800 dark:text-white mt-1",
											children: [
												cameraSummary.ultimo_conteo ?? sensorData?.aforo_camara ?? 0,
												" ",
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs font-normal text-slate-400",
													children: "pers."
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 935,
													columnNumber: 86
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 934,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 932,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "rounded-xl border border-slate-200 dark:border-[#313D4A] bg-slate-50 dark:bg-slate-800/50 p-4",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs font-semibold uppercase tracking-wider text-red-500",
											children: "Pico Máximo del Día"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 939,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-2xl font-black text-red-600 dark:text-red-400 mt-1",
											children: [
												cameraSummary.pico_personas ?? 0,
												" ",
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs font-normal text-slate-400",
													children: "bañistas"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 941,
													columnNumber: 58
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 940,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 938,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "rounded-xl border border-slate-200 dark:border-[#313D4A] bg-slate-50 dark:bg-slate-800/50 p-4",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs font-semibold uppercase tracking-wider text-purple-500",
											children: "Promedio del Día"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 945,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-2xl font-black text-purple-600 dark:text-purple-400 mt-1",
											children: [
												cameraSummary.promedio_personas ?? 0,
												" ",
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs font-normal text-slate-400",
													children: "bañistas"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 947,
													columnNumber: 62
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 946,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 944,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "rounded-xl border border-slate-200 dark:border-[#313D4A] bg-slate-50 dark:bg-slate-800/50 p-4",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs font-semibold uppercase tracking-wider text-blue-500",
											children: "Total de Capturas"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 951,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-2xl font-black text-blue-600 dark:text-blue-400 mt-1",
											children: [
												sortedCameraReadings.length,
												" ",
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs font-normal text-slate-400",
													children: "registros"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 953,
													columnNumber: 53
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 952,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 950,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 931,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "overflow-x-auto rounded-2xl border border-slate-200 dark:border-[#313D4A]",
								children: modalAforo === "manual" ? /* @__PURE__ */ _jsxDEV("table", {
									className: "w-full table-auto",
									children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
										className: "border-b border-slate-200 dark:border-[#313D4A] bg-slate-50/70 dark:bg-slate-800/50 text-left",
										children: [
											/* @__PURE__ */ _jsxDEV("th", {
												className: "py-3 px-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide",
												children: "HORA"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 965,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "py-3 px-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide text-center",
												children: "TOTAL PERSONAS"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 966,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "py-3 px-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide text-center",
												children: "TARIFA 15 BS"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 967,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "py-3 px-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide text-center",
												children: "TARIFA 20 BS"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 968,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "py-3 px-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide text-right",
												children: "RECAUDADO"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 969,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "py-3 px-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide",
												children: "OBSERVACIONES"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 970,
												columnNumber: 25
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 964,
										columnNumber: 23
									}, this) }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 963,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: [paginatedModalList.map((reg, index) => /* @__PURE__ */ _jsxDEV("tr", {
										className: "border-b border-slate-100 dark:border-[#313D4A] last:border-0 hover:bg-slate-50 dark:hover:bg-[#313D4A] transition-colors",
										children: [
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-4 text-sm font-semibold text-slate-700 dark:text-slate-300",
												children: formatTime(reg.hora_entrada || reg.creado_en)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 976,
												columnNumber: 27
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-4 text-sm text-center",
												children: /* @__PURE__ */ _jsxDEV("span", {
													className: "inline-flex items-center justify-center rounded-full bg-indigo-50 dark:bg-indigo-900/30 px-3 py-0.5 text-xs font-bold text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800",
													children: [reg.total_personas, " pers."]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 980,
													columnNumber: 29
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 979,
												columnNumber: 27
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-4 text-sm font-medium text-slate-700 dark:text-slate-300 text-center",
												children: reg.cantidad_tarifa_15 ?? 0
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 984,
												columnNumber: 27
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-4 text-sm font-medium text-slate-700 dark:text-slate-300 text-center",
												children: reg.cantidad_tarifa_20 ?? 0
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 987,
												columnNumber: 27
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-4 text-sm font-bold text-emerald-600 dark:text-emerald-400 text-right",
												children: ["Bs. ", Number(reg.total_recaudado ?? 0).toFixed(2)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 990,
												columnNumber: 27
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-4 text-sm text-slate-500 dark:text-slate-400 italic",
												children: reg.observaciones || "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 993,
												columnNumber: 27
											}, this)
										]
									}, reg.id_registro || index, true, {
										fileName: _jsxFileName,
										lineNumber: 975,
										columnNumber: 25
									}, this)), paginatedModalList.length === 0 && /* @__PURE__ */ _jsxDEV("tr", { children: /* @__PURE__ */ _jsxDEV("td", {
										colSpan: "6",
										className: "py-8 text-center text-sm text-slate-500 dark:text-slate-400",
										children: "No se han registrado entradas de taquilla en la jornada de hoy."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1e3,
										columnNumber: 27
									}, this) }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 999,
										columnNumber: 25
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 973,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 962,
									columnNumber: 19
								}, this) : /* @__PURE__ */ _jsxDEV("table", {
									className: "w-full table-auto",
									children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
										className: "border-b border-slate-200 dark:border-[#313D4A] bg-slate-50/70 dark:bg-slate-800/50 text-left",
										children: [
											/* @__PURE__ */ _jsxDEV("th", {
												className: "py-3 px-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide",
												children: "HORA DE CAPTURA"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1011,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "py-3 px-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide text-center",
												children: "PERSONAS DETECTADAS"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1012,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "py-3 px-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide text-center",
												children: "NIVEL DE AFLUENCIA"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1013,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "py-3 px-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide",
												children: "DISPOSITIVO"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1014,
												columnNumber: 25
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1010,
										columnNumber: 23
									}, this) }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1009,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: [paginatedModalList.map((reg, index) => /* @__PURE__ */ _jsxDEV("tr", {
										className: "border-b border-slate-100 dark:border-[#313D4A] last:border-0 hover:bg-slate-50 dark:hover:bg-[#313D4A] transition-colors",
										children: [
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-4 text-sm font-semibold text-slate-700 dark:text-slate-300",
												children: formatTime(reg.fecha_hora || reg.creado_en)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1020,
												columnNumber: 27
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-4 text-sm text-center",
												children: /* @__PURE__ */ _jsxDEV("span", {
													className: "inline-flex items-center justify-center rounded-full bg-purple-50 dark:bg-purple-900/30 px-3.5 py-1 text-sm font-black text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800",
													children: [reg.cantidad_personas, " bañistas"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1024,
													columnNumber: 29
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1023,
												columnNumber: 27
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-4 text-sm text-center",
												children: badgeAfluencia(reg.cantidad_personas)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1028,
												columnNumber: 27
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-4 text-sm font-medium text-slate-600 dark:text-slate-400",
												children: /* @__PURE__ */ _jsxDEV("span", {
													className: "inline-flex items-center gap-1.5 font-mono text-xs bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700",
													children: ["📷 ", reg.id_dispositivo || "ESP32-CAM"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1032,
													columnNumber: 29
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1031,
												columnNumber: 27
											}, this)
										]
									}, reg.id_registro || index, true, {
										fileName: _jsxFileName,
										lineNumber: 1019,
										columnNumber: 25
									}, this)), paginatedModalList.length === 0 && /* @__PURE__ */ _jsxDEV("tr", { children: /* @__PURE__ */ _jsxDEV("td", {
										colSpan: "4",
										className: "py-8 text-center text-sm text-slate-500 dark:text-slate-400",
										children: "No hay lecturas registradas por la cámara inteligente en la jornada de hoy."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1040,
										columnNumber: 27
									}, this) }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1039,
										columnNumber: 25
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1017,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1008,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 960,
								columnNumber: 15
							}, this),
							modalList.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-5 flex items-center justify-between",
								children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs font-medium text-slate-500 dark:text-slate-400",
									children: [
										"Mostrando ",
										(modalPage - 1) * itemsPerPage + 1,
										" - ",
										Math.min(modalPage * itemsPerPage, modalList.length),
										" de ",
										modalList.length,
										" registros"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1053,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setModalPage((prev) => Math.max(prev - 1, 1)),
											disabled: modalPage === 1,
											className: "flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 transition-all hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-bold",
											children: "←"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1058,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs font-semibold text-slate-700 dark:text-slate-300",
											children: [
												"Página ",
												modalPage,
												" de ",
												modalTotalPages
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1065,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setModalPage((prev) => Math.min(prev + 1, modalTotalPages)),
											disabled: modalPage === modalTotalPages,
											className: "flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 transition-all hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-bold",
											children: "→"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1068,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1057,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1052,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 901,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-end border-t border-slate-100 dark:border-[#313D4A] px-7 py-4 bg-slate-50/50 dark:bg-slate-900/20",
						children: /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setModalAforo(null),
							className: "rounded-xl bg-slate-800 dark:bg-slate-700 hover:bg-slate-900 dark:hover:bg-slate-600 text-white font-bold text-sm px-5 py-2.5 transition-all shadow-sm",
							children: "Cerrar"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1082,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1081,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 825,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 821,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV(ReportesModal, {
			isOpen: showReportModal,
			onClose: () => setShowReportModal(false)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 1094,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 193,
		columnNumber: 5
	}, this);
}
_s(Dashboard, "elP9k6FnwTaEYazhD9UK0n6KiXQ=", false, function() {
	return [useAuth];
});
_c = Dashboard;
function badgeAfluencia(cantidad) {
	if (cantidad > 30) {
		return /* @__PURE__ */ _jsxDEV("span", {
			className: "inline-flex items-center gap-1.5 rounded-full bg-red-50 dark:bg-red-900/20 px-2.5 py-0.5 text-xs font-semibold text-red-600 dark:text-red-400 border border-red-200 dark:border-red-800",
			children: [/* @__PURE__ */ _jsxDEV("span", { className: "h-1.5 w-1.5 rounded-full bg-red-500" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1106,
				columnNumber: 9
			}, this), "Alta afluencia"]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 1105,
			columnNumber: 7
		}, this);
	}
	if (cantidad > 15) {
		return /* @__PURE__ */ _jsxDEV("span", {
			className: "inline-flex items-center gap-1.5 rounded-full bg-amber-50 dark:bg-amber-900/20 px-2.5 py-0.5 text-xs font-semibold text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-800",
			children: [/* @__PURE__ */ _jsxDEV("span", { className: "h-1.5 w-1.5 rounded-full bg-amber-500" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1114,
				columnNumber: 9
			}, this), "Moderada"]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 1113,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("span", {
		className: "inline-flex items-center gap-1.5 rounded-full bg-emerald-50 dark:bg-emerald-900/20 px-2.5 py-0.5 text-xs font-semibold text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800",
		children: [/* @__PURE__ */ _jsxDEV("span", { className: "h-1.5 w-1.5 rounded-full bg-emerald-500" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 1121,
			columnNumber: 7
		}, this), "Baja / Normal"]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 1120,
		columnNumber: 5
	}, this);
}
function formatValue(value) {
	return value === null || value === undefined ? "—" : Number(value).toFixed(2);
}
function formatTime(value) {
	if (!value) return "—";
	// Extrae directamente la hora de la cadena (ej: '2026-09-13T20:30:15...' -> '20:30:15')
	if (typeof value === "string" && value.includes("T")) {
		const timePart = value.split("T")[1];
		if (timePart) {
			return timePart.substring(0, 8);
		}
	}
	const dateObj = new Date(value);
	return dateObj.toLocaleTimeString([], {
		hour: "2-digit",
		minute: "2-digit",
		second: "2-digit",
		hour12: false
	});
}
function phState(value) {
	if (value === undefined || value === null) return "empty";
	return value < 7 || value > 7.6 ? "warning" : "normal";
}
function turbidityState(value) {
	if (value === undefined || value === null) return "empty";
	return value > 10 ? "danger" : value > 5 ? "warning" : "normal";
}
var _c;
$RefreshReg$(_c, "Dashboard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Dashboard/index.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Dashboard/index.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Dashboard/index.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Dashboard/index.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLHFCQUFxQjtBQUM5QixTQUFTLGVBQWU7QUFDeEIsT0FBTyxxQkFBcUI7QUFDNUIsT0FBTyxtQkFBbUI7QUFDMUIsU0FDRSxxQkFDQSxlQUNBLE1BQ0EsTUFDQSxPQUNBLE9BQ0EsZUFDQSxTQUNBLFFBQ0EscUJBQ0s7Ozs7QUFFUCxlQUFlLFNBQVMsWUFBWTs7Q0FDbEMsTUFBTSxFQUFFLFNBQVMsY0FBYyxRQUFRO0NBQ3ZDLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLElBQUk7Q0FDakQsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxLQUFLO0NBQzFELE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQVMsSUFBSTtDQUMvRCxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLElBQUk7Q0FDekQsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxLQUFLO0NBRTVELE1BQU0saUJBQWlCLFlBQVk7RUFDakMsa0JBQWtCLElBQUk7RUFDdEIsSUFBSTtHQUNGLE1BQU0sQ0FBQyxFQUFFLE1BQU0sU0FBUyxFQUFFLE1BQU0sWUFBWSxNQUFNLFFBQVEsSUFBSSxDQUM1RCxjQUFjLElBQUksb0JBQW9CLEdBQ3RDLGNBQWMsSUFBSSxjQUFjLENBQ2xDLENBQUM7R0FDRCxjQUFjO0lBQUUsR0FBRztJQUFPLFNBQVM7R0FBTyxDQUFDO0dBQzNDLHFCQUFxQixJQUFJO0VBQzNCLFNBQVMsY0FBYztHQUNyQixjQUFjLElBQUk7R0FDbEIsSUFBSSxhQUFhLFVBQVUsV0FBVyxLQUFLO0lBQ3pDLHFCQUFxQixLQUFLO0dBQzVCLE9BQU8sSUFBSSxXQUFXO0lBQ3BCLFVBQVUsYUFBYSxVQUFVLE1BQU0sVUFBVSxvREFBb0Q7R0FDdkc7RUFDRixVQUFVO0dBQ1Isa0JBQWtCLEtBQUs7RUFDekI7Q0FDRjtDQUVBLGdCQUFnQjtFQUNkLGVBQWU7RUFDZixNQUFNLGFBQWEsT0FBTyxZQUFZLGdCQUFnQixHQUFLO0VBQzNELGFBQWEsT0FBTyxjQUFjLFVBQVU7Q0FDOUMsR0FBRyxDQUFDLENBQUM7Q0FFTCxNQUFNLGdCQUFnQixZQUFZO0VBQ2hDLElBQUk7R0FDRixNQUFNLGNBQWMsS0FBSyxlQUFlO0dBQ3hDLE1BQU0sZUFBZTtFQUN2QixTQUFTLGNBQWM7R0FDckIsSUFBSSxXQUFXO0lBQ2IsVUFBVSxhQUFhLFVBQVUsTUFBTSxVQUFVLGtDQUFrQztHQUNyRjtFQUNGO0NBQ0Y7Q0FFQSxNQUFNLGNBQWMsWUFBWTtDQUNoQyxNQUFNLFVBQVUsWUFBWTtDQUM1QixNQUFNLGNBQWMsWUFBWSxhQUFhLENBQUM7Q0FDOUMsTUFBTSxhQUFhLFlBQVksY0FBYyxDQUFDO0NBQzlDLE1BQU0saUJBQWlCLFlBQVksbUJBQW1CLENBQUM7Q0FDdkQsTUFBTSxZQUFZLFlBQVkscUJBQXFCLENBQUM7O0NBR3BELE1BQU0sZUFBZSxNQUFNO0VBQUM7RUFBWTtFQUFlO0NBQWMsQ0FBQyxDQUFDLFNBQVMsaUJBQWlCLEVBQUUsRUFBRSxNQUFNO0NBQzNHLE1BQU0sZ0JBQWdCLE1BQU07RUFDMUIsS0FBSyxJQUFJLElBQUksWUFBWSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7R0FDaEQsSUFBSSxZQUFZLEVBQUUsQ0FBQyxPQUFPLFFBQVEsWUFBWSxFQUFFLENBQUMsT0FBTyxXQUFXLE9BQU8sWUFBWSxFQUFFLENBQUM7RUFDM0Y7RUFDQSxPQUFPO0NBQ1Q7O0NBRUEsTUFBTSxlQUFlLE1BQU07RUFDekIsSUFBSSxZQUFZLENBQUMsS0FBSyxZQUFZLElBQUksT0FBTyxVQUFVLEVBQUUsQ0FBQztFQUMxRCxPQUFPLGNBQWMsTUFBTSxhQUFhLENBQUM7Q0FDM0M7O0NBR0EsTUFBTSxpQkFBaUIsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxDQUFDLE1BQU0sR0FBRyxNQUFNLElBQUksS0FBSyxFQUFFLFVBQVUsSUFBSSxJQUFJLEtBQUssRUFBRSxVQUFVLENBQUM7O0NBR3RHLE1BQU0sWUFBWSxDQUFDLEdBQUcsY0FBYyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxPQUFPO0VBQzFELElBQUksSUFBSSxLQUFLLEVBQUUsVUFBVSxDQUFDLENBQUMsUUFBUTtFQUNuQyxNQUFNLFdBQVcsRUFBRSxVQUFVO0VBQzdCLElBQUksRUFBRSxPQUFPLFFBQVEsRUFBRSxPQUFPLFlBQVksT0FBTyxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSTtFQUM1RSxVQUFVLEVBQUUsYUFBYSxRQUFRLEVBQUUsYUFBYSxZQUFZLE9BQU8sT0FBTyxFQUFFLFFBQVEsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUk7RUFDcEcsYUFBYSxFQUFFLGdCQUFnQixRQUFRLEVBQUUsZ0JBQWdCLFlBQVksT0FBTyxPQUFPLEVBQUUsV0FBVyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSTtDQUNsSCxFQUFFO0NBRUYsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsQ0FBQztDQUNoRCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxJQUFJO0NBQ2pELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLENBQUM7Q0FDNUMsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLFVBQVU7Q0FDbkQsTUFBTSxlQUFlO0NBRXJCLE1BQU0sb0JBQW9CLFlBQVksMEJBQTBCLENBQUM7Q0FDakUsTUFBTSxnQkFBZ0IsWUFBWSx3QkFBd0IsQ0FBQztDQUMzRCxNQUFNLG9CQUFvQixZQUFZLDBCQUEwQixDQUFDO0NBQ2pFLE1BQU0sZ0JBQWdCLFlBQVksd0JBQXdCLENBQUM7O0NBRzNELE1BQU0sdUJBQXVCLENBQUMsR0FBRyxpQkFBaUIsQ0FBQyxDQUFDLE1BQ2pELEdBQUcsTUFBTSxJQUFJLEtBQUssRUFBRSxnQkFBZ0IsRUFBRSxTQUFTLElBQUksSUFBSSxLQUFLLEVBQUUsZ0JBQWdCLEVBQUUsU0FBUyxDQUM1RjtDQUNBLE1BQU0sdUJBQXVCLENBQUMsR0FBRyxpQkFBaUIsQ0FBQyxDQUFDLE1BQ2pELEdBQUcsTUFBTSxJQUFJLEtBQUssRUFBRSxjQUFjLEVBQUUsU0FBUyxJQUFJLElBQUksS0FBSyxFQUFFLGNBQWMsRUFBRSxTQUFTLENBQ3hGOztDQUdBLE1BQU0sbUJBQ0osYUFBYSxXQUFXLHVCQUN4QixhQUFhLFdBQVcsdUJBQ3hCO0NBRUYsTUFBTSxhQUFhLEtBQUssS0FBSyxpQkFBaUIsU0FBUyxZQUFZLEtBQUs7Q0FDeEUsTUFBTSxnQkFBZ0IsaUJBQWlCLE9BQU8sY0FBYyxLQUFLLGNBQWMsY0FBYyxZQUFZOztDQUd6RyxNQUFNLFlBQVksZUFBZSxXQUFXLHVCQUF1QjtDQUNuRSxNQUFNLGtCQUFrQixLQUFLLEtBQUssVUFBVSxTQUFTLFlBQVksS0FBSztDQUN0RSxNQUFNLHFCQUFxQixVQUFVLE9BQU8sWUFBWSxLQUFLLGNBQWMsWUFBWSxZQUFZO0NBRW5HLElBQUksQ0FBQyxtQkFBbUI7RUFDdEIsT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxPQUFEO01BQUssT0FBTTtNQUFLLFFBQU87TUFBSyxTQUFRO01BQVksTUFBSztNQUFPLE9BQU07Z0JBQ2hFLHdCQUFDLFFBQUQ7T0FBTSxHQUFFO09BQWtJLFFBQU87T0FBZSxhQUFZO09BQUksZUFBYztPQUFRLGdCQUFlO01BQVE7Ozs7O0tBQzFOOzs7OztJQUNGOzs7OztJQUNMLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQXlEO0lBQWlDOzs7OztJQUN4Ryx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUE4QztJQUV4RDs7Ozs7R0FDQTs7Ozs7O0NBRVQ7Q0FFQSxNQUFNLGVBQWU7RUFDbkIsSUFBSTtHQUNGLE9BQU87R0FDUCxPQUFPO0dBQ1AsTUFBTTtHQUNOLFNBQVM7R0FDVCxRQUFRO0dBQ1IsUUFBUTtFQUNWO0VBQ0EsVUFBVTtHQUNSLE9BQU87R0FDUCxPQUFPO0dBQ1AsTUFBTTtHQUNOLFNBQVM7R0FDVCxRQUFRO0VBQ1Y7RUFDQSxhQUFhO0dBQ1gsT0FBTztHQUNQLE9BQU87R0FDUCxNQUFNO0dBQ04sU0FBUztHQUNULFFBQVE7R0FDUixRQUFRO0VBQ1Y7Q0FDRjs7Q0FHQSxNQUFNLFNBQVMsYUFBYTtDQUM1QixNQUFNLFlBQVksYUFBYSxtQkFBbUIsQ0FBQztDQUNuRCxNQUFNLGVBQWUsVUFBVSxLQUFLLE9BQU8sRUFBRSxHQUFHLEVBQUUsRUFBRTtDQUNwRCxNQUFNLGFBQWEsQ0FBQyxHQUFHLFlBQVksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sTUFBTSxFQUFFLE9BQU8sYUFBYSxJQUFJO0NBQ3JGLElBQUksY0FBYyxVQUFVLFFBQVE7O0VBRWxDLFdBQVcsYUFBYSxXQUFXLE9BQU87RUFDMUMsV0FBVyxRQUFRLENBQUMsV0FBVyxPQUFPLFVBQVUsV0FBVyxPQUFPLFFBQVE7Q0FDNUU7Q0FDQSxNQUFNLGFBQWEsVUFBVSxLQUFLLE9BQU87RUFDdkMsSUFBSSxJQUFJLEtBQUssRUFBRSxVQUFVLENBQUMsQ0FBQyxRQUFRO0VBQ25DLE1BQU0sV0FBVyxFQUFFLFVBQVU7RUFDN0IsWUFBWSxPQUFPLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztFQUM3QyxPQUFPLENBQUMsT0FBTyxPQUFPLEVBQUUsUUFBUSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxPQUFPLE9BQU8sRUFBRSxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0NBQ3RGLEVBQUU7Q0FDRixNQUFNLGlCQUFpQixDQUFDLEdBQUcsY0FBYyxHQUFHLFVBQVUsQ0FBQyxDQUFDLE1BQU0sR0FBRyxNQUFNLEVBQUUsS0FBSyxFQUFFLEVBQUU7Q0FDbEYsTUFBTSxnQkFBZ0IsV0FBVyxTQUFTO0NBRTFDLE9BQ0U7RUFFRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBR0Usd0JBQUMsT0FBRDtLQUNFLGVBQWUsa0JBQWtCLElBQUk7S0FDckMsV0FBVyxrRUFBa0UsbUJBQW1CLE9BQU8sOEVBQThFO2VBRnZMLENBSUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQStJO0tBRXpKOzs7O2VBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQXlEO01BQWtCOzs7O2dCQUMzRix3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZCxDQUNHLFlBQVksWUFBWSxJQUFJLENBQUMsR0FDN0IsWUFBWSxJQUFJLEtBQ2Ysd0JBQUMsUUFBRDtRQUFNLFdBQVU7UUFBdUMsT0FBTTtrQkFBcUM7T0FBVzs7OztlQUU3Rzs7Ozs7Y0FDRDs7OztnQkFDTCx3QkFBQyxRQUFEO09BQU0sV0FBVyxzREFDZixZQUFZLElBQUksSUFDWix3RUFDQSxRQUFRLFlBQVksSUFBSSxDQUFDLE1BQU0sV0FDL0IsZ0ZBQ0E7aUJBRUgsWUFBWSxJQUFJLElBQUksYUFBYSxRQUFRLFlBQVksSUFBSSxDQUFDLE1BQU0sV0FBVyxXQUFXO01BQ25GOzs7O2NBQ0g7Ozs7O2FBQ0Y7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FDRSxlQUFlLGtCQUFrQixVQUFVO0tBQzNDLFdBQVcsa0VBQWtFLG1CQUFtQixhQUFhLHNGQUFzRjtlQUZyTSxDQUlFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLE9BQUQ7T0FBSyxPQUFNO09BQUssUUFBTztPQUFLLFNBQVE7T0FBWSxNQUFLO09BQU8sT0FBTTtpQkFBbEUsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sR0FBRTtRQUFvSCxRQUFPO1FBQWUsYUFBWTtRQUFJLGVBQWM7UUFBUSxnQkFBZTtPQUFROzs7O2lCQUMvTSx3QkFBQyxRQUFEO1FBQU0sR0FBRTtRQUE4QyxRQUFPO1FBQWUsYUFBWTtRQUFJLGVBQWM7UUFBUSxnQkFBZTtPQUFROzs7O2VBQ3RJOzs7Ozs7S0FDRjs7OztlQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUF5RDtNQUFxQjs7OztnQkFDOUYsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQ7UUFDRyxZQUFZLFlBQVksVUFBVSxDQUFDO1FBQUU7UUFBQyx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBeUQ7UUFBUzs7Ozs7UUFDeEgsWUFBWSxVQUFVLEtBQ3JCLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO1NBQXVDLE9BQU07bUJBQXFDO1FBQVc7Ozs7O09BRTdHOzs7OztjQUNEOzs7O2dCQUNMLHdCQUFDLFFBQUQ7T0FBTSxXQUFXLHNEQUNmLFlBQVksVUFBVSxJQUNsQix3RUFDQSxlQUFlLFlBQVksVUFBVSxDQUFDLE1BQU0sV0FDNUMsZ0ZBQ0E7aUJBRUgsWUFBWSxVQUFVLElBQUksYUFBYSxlQUFlLFlBQVksVUFBVSxDQUFDLE1BQU0sV0FBVyxXQUFXO01BQ3RHOzs7O2NBQ0g7Ozs7O2FBQ0Y7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FDRSxlQUFlLGtCQUFrQixhQUFhO0tBQzlDLFdBQVcsa0VBQWtFLG1CQUFtQixnQkFBZ0IsMEZBQTBGO2VBRjVNLENBSUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsT0FBRDtPQUFLLE9BQU07T0FBSyxRQUFPO09BQUssU0FBUTtPQUFZLE1BQUs7T0FBTyxPQUFNO2lCQUNoRSx3QkFBQyxRQUFEO1FBQU0sR0FBRTtRQUErTSxRQUFPO1FBQWUsYUFBWTtRQUFJLGVBQWM7UUFBUSxnQkFBZTtPQUFROzs7OztNQUN2Uzs7Ozs7S0FDRjs7OztlQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUF5RDtNQUF3Qjs7OztnQkFDakcsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQ7UUFDRyxZQUFZLFlBQVksYUFBYSxDQUFDO1FBQUU7UUFBQyx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBeUQ7UUFBUTs7Ozs7UUFDMUgsWUFBWSxhQUFhLEtBQ3hCLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO1NBQXVDLE9BQU07bUJBQXFDO1FBQVc7Ozs7O09BRTdHOzs7OztjQUNEOzs7O2dCQUNKLFlBQVksYUFBYSxLQUN4Qix3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBeUg7TUFFbkk7Ozs7Y0FFTDs7Ozs7YUFDRjs7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUNFLGVBQWU7TUFBRSxjQUFjLFFBQVE7TUFBRyxhQUFhLENBQUM7S0FBRztLQUMzRCxXQUFVO0tBQ1YsT0FBTTtlQUhSO01BS0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsT0FBRDtRQUFLLE9BQU07UUFBSyxRQUFPO1FBQUssU0FBUTtRQUFZLE1BQUs7UUFBTyxPQUFNO2tCQUFsRSxDQUNFLHdCQUFDLFFBQUQ7U0FBTSxHQUFFO1NBQXVLLFFBQU87U0FBZSxhQUFZO1NBQUksZUFBYztTQUFRLGdCQUFlO1FBQVE7Ozs7a0JBQ2xRLHdCQUFDLFFBQUQ7U0FBTSxHQUFFO1NBQStHLFFBQU87U0FBZSxhQUFZO1NBQUksZUFBYztTQUFRLGdCQUFlO1FBQVE7Ozs7Z0JBQ3ZNOzs7Ozs7TUFDRjs7Ozs7TUFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBeUQ7T0FBa0I7Ozs7aUJBQzNGLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUNYLFlBQVksZ0JBQWdCLFlBQVksZ0JBQWdCLFNBQVMsa0JBQWtCO09BQ2xGOzs7O2VBQ0Q7Ozs7aUJBQ0wsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQXFIO09BRS9IOzs7O2VBQ0g7Ozs7OztNQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNO1FBQWdCLGtCQUFrQjtRQUFPO09BQU87Ozs7aUJBQ3RELHdCQUFDLE9BQUQ7UUFBSyxXQUFVO1FBQStELE1BQUs7UUFBTyxRQUFPO1FBQWUsU0FBUTtrQkFDdEgsd0JBQUMsUUFBRDtTQUFNLGVBQWM7U0FBUSxnQkFBZTtTQUFRLGFBQVk7U0FBTSxHQUFFO1FBQWdCOzs7OztPQUNwRjs7OztlQUNGOzs7Ozs7S0FDRjs7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUNFLGVBQWU7TUFBRSxjQUFjLFFBQVE7TUFBRyxhQUFhLENBQUM7S0FBRztLQUMzRCxXQUFVO0tBQ1YsT0FBTTtlQUhSO01BS0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsT0FBRDtRQUFLLE9BQU07UUFBSyxRQUFPO1FBQUssU0FBUTtRQUFZLE1BQUs7UUFBTyxPQUFNO2tCQUNoRSx3QkFBQyxRQUFEO1NBQU0sR0FBRTtTQUErSSxRQUFPO1NBQWUsYUFBWTtTQUFJLGVBQWM7U0FBUSxnQkFBZTtRQUFROzs7OztPQUN2Tzs7Ozs7TUFDRjs7Ozs7TUFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBeUQ7T0FBa0I7Ozs7aUJBQzNGLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUNYLFlBQVksZ0JBQWdCO09BQzNCOzs7O2VBQ0Q7Ozs7aUJBQ0wsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQTZIO09BRXZJOzs7O2VBQ0g7Ozs7OztNQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNO1FBQWdCLGtCQUFrQjtRQUFPO09BQU87Ozs7aUJBQ3RELHdCQUFDLE9BQUQ7UUFBSyxXQUFVO1FBQStELE1BQUs7UUFBTyxRQUFPO1FBQWUsU0FBUTtrQkFDdEgsd0JBQUMsUUFBRDtTQUFNLGVBQWM7U0FBUSxnQkFBZTtTQUFRLGFBQVk7U0FBTSxHQUFFO1FBQWdCOzs7OztPQUNwRjs7OztlQUNGOzs7Ozs7S0FDRjs7Ozs7O0dBRUY7Ozs7OztFQUdMLHdCQUFDLGlCQUFEO0dBQ0UsWUFBWSxZQUFZO0dBQ3hCLFNBQVMsWUFBWTtHQUNyQixnQkFBZ0IsWUFBWTtHQUM1QixZQUFZO0VBQ2I7Ozs7O0VBR0Qsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBNEQ7S0FBcUI7Ozs7O0tBRWpHLHdCQUFDLFVBQUQ7TUFDRSxlQUFlLGtCQUFrQixJQUFJO01BQ3JDLFdBQVcsNkRBQTZELG1CQUFtQixPQUFPLHFDQUFxQztnQkFDeEk7S0FFTzs7Ozs7S0FFUix3QkFBQyxVQUFEO01BQ0UsZUFBZSxrQkFBa0IsVUFBVTtNQUMzQyxXQUFXLDZEQUE2RCxtQkFBbUIsYUFBYSx1Q0FBdUM7Z0JBQ2hKO0tBRU87Ozs7O0tBRVIsd0JBQUMsVUFBRDtNQUNFLGVBQWUsa0JBQWtCLGFBQWE7TUFDOUMsV0FBVyw2REFBNkQsbUJBQW1CLGdCQUFnQix3Q0FBd0M7Z0JBQ3BKO0tBRU87Ozs7O0lBQ0w7Ozs7O2FBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFVBQUQ7S0FDRSxlQUFlLG1CQUFtQixJQUFJO0tBQ3RDLFdBQVU7ZUFGWixDQUlFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO01BQWMsTUFBSztNQUFPLFFBQU87TUFBZSxTQUFRO2dCQUNyRSx3QkFBQyxRQUFEO09BQU0sZUFBYztPQUFRLGdCQUFlO09BQVEsYUFBWTtPQUFJLEdBQUU7TUFBbUk7Ozs7O0tBQ3JNOzs7O2VBQ0wsd0JBQUMsUUFBRCxZQUFNLHdCQUEyQjs7OzthQUMzQjs7Ozs7Y0FFUix3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFoQixDQUNFLHdCQUFDLFFBQUQsRUFBTSxXQUFVLG9EQUEwRDs7OztlQUFDLDBCQUN2RTs7Ozs7WUFDSDs7Ozs7V0FDRjs7Ozs7O0VBR0wsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUVFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZCxDQUNHLGFBQWEsZUFBZSxFQUFFLE9BQzlCLGlCQUNDLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUF1SDtNQUVqSTs7OztjQUVOOzs7OztlQUNKLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUNWO0tBQ0E7Ozs7YUFDQTs7Ozs7SUFDRjs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osZUFBZSxTQUFTLElBQ3ZCLHdCQUFDLHFCQUFEO01BQXFCLE9BQU07TUFBTyxRQUFPO2dCQUN2Qyx3QkFBQyxlQUFEO09BQWUsTUFBTTtPQUFnQixRQUFRO1FBQUUsS0FBSztRQUFJLE9BQU87UUFBSSxNQUFNO1FBQUcsUUFBUTtPQUFFO2lCQUF0RjtRQUNFLHdCQUFDLGVBQUQ7U0FBZSxpQkFBZ0I7U0FBTSxRQUFPO1NBQVUsU0FBUztRQUFNOzs7OztRQUNyRSx3QkFBQyxPQUFEO1NBQU8sU0FBUTtTQUFPLFFBQU87U0FBVSxVQUFVO1FBQUs7Ozs7O1FBQ3RELHdCQUFDLE9BQUQ7U0FDRSxRQUFRLEVBQUUsWUFBWSxLQUFLLE9BQU8sVUFBVSxNQUFPLEVBQUUsSUFBSSxLQUFLLFlBQVksS0FBSyxNQUFNLFVBQVUsTUFBTyxFQUFFLElBQUksRUFBRTtTQUM5RyxRQUFRLGFBQWEsZUFBZSxDQUFDO1NBQ3JDLFVBQVU7UUFDWDs7Ozs7UUFDRCx3QkFBQyxTQUFELEVBQVMsY0FBYztTQUFFLGlCQUFpQjtTQUFXLGNBQWM7U0FBTyxRQUFRO1NBQVEsT0FBTztRQUFPLEVBQUk7Ozs7O1FBQzVHLHdCQUFDLFFBQUQsQ0FBUzs7Ozs7UUFFUixhQUFhLGVBQWUsQ0FBQyxVQUM1Qix3QkFBQyxlQUFEO1NBQWUsR0FBRyxhQUFhLGVBQWUsQ0FBQztTQUFRLE9BQU87VUFBRSxPQUFPO1VBQW9CLE1BQU07VUFBVyxVQUFVO1NBQUc7U0FBRyxRQUFPO1NBQVUsaUJBQWdCO1FBQU87Ozs7O1FBRXJLLGFBQWEsZUFBZSxDQUFDLFVBQzVCLHdCQUFDLGVBQUQ7U0FBZSxHQUFHLGFBQWEsZUFBZSxDQUFDO1NBQVEsT0FBTztVQUFFLE9BQU87VUFBb0IsTUFBTTtVQUFXLFVBQVU7U0FBRztTQUFHLFFBQU87U0FBVSxpQkFBZ0I7UUFBTzs7Ozs7UUFJdEssd0JBQUMsTUFBRDtTQUNFLE1BQUs7U0FDTCxTQUFRO1NBQ1IsUUFBTztTQUNQLE1BQU0sYUFBYSxlQUFlLENBQUM7U0FDbkMsYUFBYTtTQUNiLE1BQUs7UUFDTjs7Ozs7UUFHRCx3QkFBQyxNQUFEO1NBQ0UsTUFBSztTQUNMLE1BQU0sR0FBRyxhQUFhLGVBQWUsQ0FBQyxRQUFRO1NBQzlDLFNBQVMsYUFBYSxlQUFlLENBQUM7U0FDdEMsUUFBUSxhQUFhLGVBQWUsQ0FBQztTQUNyQyxhQUFhO1NBQ2IsS0FBSztVQUFFLEdBQUc7VUFBRyxNQUFNLGFBQWEsZUFBZSxDQUFDO1VBQU8sYUFBYTtVQUFLLFFBQVE7U0FBTztTQUN4RixXQUFXLEVBQUUsR0FBRyxFQUFFO1NBQ2xCLGNBQWM7UUFDZjs7Ozs7UUFHRCx3QkFBQyxNQUFEO1NBQ0UsTUFBSztTQUNMLE1BQU0sR0FBRyxhQUFhLGVBQWUsQ0FBQyxRQUFRO1NBQzlDLFNBQVE7U0FDUixRQUFRLGFBQWEsZUFBZSxDQUFDO1NBQ3JDLGFBQWE7U0FDYixpQkFBZ0I7U0FDaEIsS0FBSztVQUFFLEdBQUc7VUFBRyxNQUFNO1VBQVEsYUFBYTtVQUFHLFFBQVEsYUFBYSxlQUFlLENBQUM7U0FBTTtTQUN0RixXQUFXLEVBQUUsR0FBRyxFQUFFO1NBQ2xCLGNBQWM7UUFDZjs7Ozs7T0FDWTs7Ozs7O0tBQ0k7Ozs7Z0JBRXJCLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFpRTtLQUUzRTs7Ozs7SUFFSjs7OztZQUNGOzs7OzthQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFkLENBQXlGLG1CQUV0RixZQUFZLFNBQVMsTUFBSyxNQUFLLEVBQUUsU0FBUyxRQUFRLEtBQ2pELHdCQUFDLFFBQUQsRUFBTSxXQUFVLHlEQUErRDs7OztjQUUvRTs7Ozs7O0lBQ0Q7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaLFlBQVksU0FBUyxTQUFTLFdBQVcsUUFBUSxLQUFLLE9BQU8sVUFBVTtNQUN0RSxNQUFNLFdBQVcsTUFBTSxTQUFTO01BQ2hDLE1BQU0sT0FBTyxNQUFNLFNBQVM7TUFFNUIsT0FDRSx3QkFBQyxPQUFEO09BQ0UsV0FBVyw2Q0FDVCxPQUFPLDBGQUNQLFdBQVcscUZBQ1g7aUJBSkosQ0FRRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFXLHVFQUNkLE9BQU8saUZBQ1AsV0FBVyxxRUFDWDttQkFFQyxPQUNDLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO1VBQVUsTUFBSztVQUFPLFFBQU87VUFBZSxTQUFRO1VBQVksT0FBTTtvQkFBNkIsd0JBQUMsUUFBRDtXQUFNLGVBQWM7V0FBUSxnQkFBZTtXQUFRLGFBQVk7V0FBSSxHQUFFO1VBQXVCOzs7OztTQUFNOzs7O29CQUNsTixXQUNGLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO1VBQVUsTUFBSztVQUFPLFFBQU87VUFBZSxTQUFRO1VBQVksT0FBTTtvQkFBNkIsd0JBQUMsUUFBRDtXQUFNLGVBQWM7V0FBUSxnQkFBZTtXQUFRLGFBQVk7V0FBSSxHQUFFO1VBQW1DOzs7OztTQUFNOzs7O29CQUVoTyx3QkFBQyxPQUFEO1VBQUssV0FBVTtVQUFVLE1BQUs7VUFBTyxRQUFPO1VBQWUsU0FBUTtVQUFZLE9BQU07b0JBQTZCLHdCQUFDLFFBQUQ7V0FBTSxlQUFjO1dBQVEsZ0JBQWU7V0FBUSxhQUFZO1dBQUksR0FBRTtVQUE2STs7Ozs7U0FBTTs7Ozs7UUFFelU7Ozs7a0JBQ0wsd0JBQUMsS0FBRDtTQUFHLFdBQVcsdUNBQ1osT0FBTywyQ0FDUCxXQUFXLHFDQUNYO21CQUVDLE1BQU07UUFDTjs7OztnQkFDQTs7Ozs7aUJBRUosWUFDQyx3QkFBQyxVQUFEO1FBQ0UsU0FBUyxZQUFZO1NBQ25CLElBQUk7VUFDRixNQUFNLGNBQWMsS0FBSyw2QkFBNkI7V0FDcEQsU0FBUyxNQUFNO1dBQ2YsWUFBWSxNQUFNO1VBQ3BCLENBQUM7VUFDRCxNQUFNLGVBQWU7U0FDdkIsU0FBUyxHQUFHO1VBQ1YsSUFBSSxXQUFXLFVBQVUsbUNBQW1DO1NBQzlEO1FBQ0Y7UUFDQSxXQUFVO2tCQVpaLENBY0Usd0JBQUMsUUFBRDtTQUFNO1NBQWdCLE1BQU07U0FBUztRQUFROzs7O2tCQUM3Qyx3QkFBQyxPQUFEO1NBQUssT0FBTTtTQUFLLFFBQU87U0FBSyxTQUFRO1NBQVksTUFBSztTQUFPLE9BQU07bUJBQ2hFLHdCQUFDLFFBQUQ7VUFBTSxHQUFFO1VBQXdCLFFBQU87VUFBZSxhQUFZO1VBQUksZUFBYztVQUFRLGdCQUFlO1NBQVE7Ozs7O1FBQ2hIOzs7O2dCQUNDOzs7OztlQUVQO1NBOUNFOzs7O2FBOENGO0tBRVQsQ0FBQyxJQUNDLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUF5RDtNQUFtQjs7Ozs7S0FDdEY7Ozs7O0lBRUo7Ozs7WUFDRjs7Ozs7V0FFRjs7Ozs7O0VBR0wsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDYix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBR0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLFVBQUQ7U0FDRSxlQUFlO1VBQUUsWUFBWSxVQUFVO1VBQUcsZUFBZSxDQUFDO1NBQUc7U0FDN0QsV0FBVyxtRkFDVCxhQUFhLGFBQ1Qsd0RBQ0E7bUJBTFIsQ0FRRSx3QkFBQyxRQUFELFlBQU0sc0JBQXlCOzs7O21CQUMvQix3QkFBQyxRQUFEO1VBQU0sV0FBVyxrREFBa0QsYUFBYSxhQUFhLDJCQUEyQjtvQkFDckgsZUFBZTtTQUNaOzs7O2lCQUNBOzs7Ozs7UUFFUix3QkFBQyxVQUFEO1NBQ0UsZUFBZTtVQUFFLFlBQVksUUFBUTtVQUFHLGVBQWUsQ0FBQztTQUFHO1NBQzNELFdBQVcsbUZBQ1QsYUFBYSxXQUNULDREQUNBO21CQUxSLENBUUUsd0JBQUMsUUFBRCxZQUFNLDZCQUFnQzs7OzttQkFDdEMsd0JBQUMsUUFBRDtVQUFNLFdBQVcsa0RBQWtELGFBQWEsV0FBVywyQkFBMkI7b0JBQ25ILHFCQUFxQjtTQUNsQjs7OztpQkFDQTs7Ozs7O1FBRVIsd0JBQUMsVUFBRDtTQUNFLGVBQWU7VUFBRSxZQUFZLFFBQVE7VUFBRyxlQUFlLENBQUM7U0FBRztTQUMzRCxXQUFXLG1GQUNULGFBQWEsV0FDVCw0REFDQTttQkFMUixDQVFFLHdCQUFDLFFBQUQsWUFBTSx1QkFBMEI7Ozs7bUJBQ2hDLHdCQUFDLFFBQUQ7VUFBTSxXQUFXLGtEQUFrRCxhQUFhLFdBQVcsMkJBQTJCO29CQUNuSCxxQkFBcUI7U0FDbEI7Ozs7aUJBQ0E7Ozs7OztRQUVSLHdCQUFDLFVBQUQ7U0FDRSxlQUFlLG1CQUFtQixJQUFJO1NBQ3RDLFdBQVU7bUJBRVYsd0JBQUMsUUFBRCxZQUFNLG9DQUF1Qzs7Ozs7UUFDdkM7Ozs7O09BQ0w7Ozs7O2lCQUdILGFBQWEsWUFBWSxhQUFhLGFBQ3RDLHdCQUFDLFVBQUQ7T0FDRSxlQUFlO1FBQUUsY0FBYyxRQUFRO1FBQUcsYUFBYSxDQUFDO09BQUc7T0FDM0QsV0FBVTtpQkFGWixDQUlFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO1FBQXdCLE1BQUs7UUFBTyxRQUFPO1FBQWUsU0FBUTtrQkFDL0Usd0JBQUMsUUFBRDtTQUFNLGVBQWM7U0FBUSxnQkFBZTtTQUFRLGFBQVk7U0FBSSxHQUFFO1FBQTZGOzs7OztPQUMvSjs7OztpQkFDTCx3QkFBQyxRQUFELFlBQU0sMEJBQTZCOzs7O2VBQzdCOzs7OztjQUVQOzs7Ozs7S0FFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZDtRQUNHLGFBQWEsY0FBYztRQUMzQixhQUFhLFlBQVk7UUFDekIsYUFBYSxZQUFZO09BQ3hCOzs7OztnQkFDSix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBYjtRQUFzRTtRQUN6RCxpQkFBaUIsU0FBUyxLQUFLLGNBQWMsS0FBSyxlQUFlLElBQUk7UUFBRTtRQUFJLEtBQUssSUFBSSxjQUFjLGNBQWMsaUJBQWlCLE1BQU07UUFBRTtRQUFLLGlCQUFpQjtRQUFPO09BQ2hMOzs7OztjQUNBOzs7O2dCQUdKLGlCQUFpQixTQUFTLEtBQ3pCLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsVUFBRDtTQUNFLGVBQWUsZ0JBQWdCLFNBQVMsS0FBSyxJQUFJLE9BQU8sR0FBRyxDQUFDLENBQUM7U0FDN0QsVUFBVSxnQkFBZ0I7U0FDMUIsV0FBVTtTQUNWLE9BQU07bUJBRU4sd0JBQUMsT0FBRDtVQUFLLE9BQU07VUFBSyxRQUFPO1VBQUssU0FBUTtVQUFZLE1BQUs7VUFBTyxPQUFNO29CQUNoRSx3QkFBQyxRQUFEO1dBQU0sR0FBRTtXQUFtQixRQUFPO1dBQWUsYUFBWTtXQUFJLGVBQWM7V0FBUSxnQkFBZTtVQUFROzs7OztTQUMzRzs7Ozs7UUFDQzs7Ozs7UUFFUix3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEI7VUFBMkU7VUFDakU7VUFBWTtVQUFLO1NBQ3JCOzs7Ozs7UUFFTix3QkFBQyxVQUFEO1NBQ0UsZUFBZSxnQkFBZ0IsU0FBUyxLQUFLLElBQUksT0FBTyxHQUFHLFVBQVUsQ0FBQztTQUN0RSxVQUFVLGdCQUFnQjtTQUMxQixXQUFVO1NBQ1YsT0FBTTttQkFFTix3QkFBQyxPQUFEO1VBQUssT0FBTTtVQUFLLFFBQU87VUFBSyxTQUFRO1VBQVksTUFBSztVQUFPLE9BQU07b0JBQ2hFLHdCQUFDLFFBQUQ7V0FBTSxHQUFFO1dBQWtCLFFBQU87V0FBZSxhQUFZO1dBQUksZUFBYztXQUFRLGdCQUFlO1VBQVE7Ozs7O1NBQzFHOzs7OztRQUNDOzs7OztPQUNMOzs7OztjQUVKOzs7Ozs7S0FFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUVHLGFBQWEsY0FDWix3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBakIsQ0FDRSx3QkFBQyxTQUFELFlBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWQ7VUFDRSx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBNkY7VUFBUTs7Ozs7VUFDbkgsd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQTZGO1VBQU07Ozs7O1VBQ2pILHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUE2RjtVQUFrQjs7Ozs7VUFDN0gsd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQTZGO1VBQW9COzs7OztTQUM3SDs7Ozs7aUJBQ0M7Ozs7a0JBQ1Asd0JBQUMsU0FBRCxhQUNHLGNBQWMsS0FBSyxTQUFTLFVBQzNCLHdCQUFDLE1BQUQ7U0FBZ0IsV0FBVTttQkFBMUI7VUFDRSx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFDWCxXQUFXLFFBQVEsVUFBVTtVQUM1Qjs7Ozs7VUFDSix3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFDWCxZQUFZLFFBQVEsRUFBRTtVQUNyQjs7Ozs7VUFDSix3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBZCxDQUNHLFlBQVksUUFBUSxRQUFRLEdBQUUsTUFDN0I7Ozs7OztVQUNKLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFkLENBQ0csWUFBWSxRQUFRLFdBQVcsR0FBRSxLQUNoQzs7Ozs7O1NBQ0Y7V0FiSzs7OztlQWFMLENBQ0wsR0FDQSxjQUFjLFdBQVcsS0FDeEIsd0JBQUMsTUFBRCxZQUNFLHdCQUFDLE1BQUQ7U0FBSSxTQUFRO1NBQUksV0FBVTttQkFBOEQ7UUFFcEY7Ozs7aUJBQ0Y7Ozs7Z0JBRUQ7Ozs7Z0JBQ0Y7Ozs7OztPQUlSLGFBQWEsWUFDWix3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBakIsQ0FDRSx3QkFBQyxTQUFELFlBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWQ7VUFDRSx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBNkY7VUFBZ0I7Ozs7O1VBQzNILHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUF5RztVQUFrQjs7Ozs7VUFDekksd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQXlHO1VBQWdCOzs7OztVQUN2SSx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBeUc7VUFBZ0I7Ozs7O1VBQ3ZJLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUF3RztVQUFtQjs7Ozs7VUFDekksd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQTZGO1VBQWlCOzs7OztTQUMxSDs7Ozs7aUJBQ0M7Ozs7a0JBQ1Asd0JBQUMsU0FBRCxhQUNHLGNBQWMsS0FBSyxLQUFLLFVBQ3ZCLHdCQUFDLE1BQUQ7U0FBbUMsV0FBVTttQkFBN0M7VUFDRSx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFDWCxXQUFXLElBQUksZ0JBQWdCLElBQUksU0FBUztVQUMzQzs7Ozs7VUFDSix3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFDWix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaEIsQ0FDRyxJQUFJLGdCQUFlLFFBQ2hCOzs7Ozs7VUFDSjs7Ozs7VUFDSix3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFDWCxJQUFJLHNCQUFzQjtVQUN6Qjs7Ozs7VUFDSix3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFDWCxJQUFJLHNCQUFzQjtVQUN6Qjs7Ozs7VUFDSix3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBZCxDQUE4RixRQUN2RixPQUFPLElBQUksbUJBQW1CLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUM3Qzs7Ozs7O1VBQ0osd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQ1gsSUFBSSxpQkFBaUI7VUFDcEI7Ozs7O1NBQ0Y7V0FyQkssSUFBSSxlQUFlOzs7O2VBcUJ4QixDQUNMLEdBQ0EsY0FBYyxXQUFXLEtBQ3hCLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO1NBQUksU0FBUTtTQUFJLFdBQVU7bUJBQThEO1FBRXBGOzs7O2lCQUNGOzs7O2dCQUVEOzs7O2dCQUNGOzs7Ozs7T0FJUixhQUFhLFlBQ1osd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQWpCLENBQ0Usd0JBQUMsU0FBRCxZQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFkO1VBQ0Usd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQTZGO1VBQW1COzs7OztVQUM5SCx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBeUc7VUFBdUI7Ozs7O1VBQzlJLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUF5RztVQUFzQjs7Ozs7VUFDN0ksd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQTZGO1VBQWU7Ozs7O1NBQ3hIOzs7OztpQkFDQzs7OztrQkFDUCx3QkFBQyxTQUFELGFBQ0csY0FBYyxLQUFLLEtBQUssVUFDdkIsd0JBQUMsTUFBRDtTQUFtQyxXQUFVO21CQUE3QztVQUNFLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUNYLFdBQVcsSUFBSSxjQUFjLElBQUksU0FBUztVQUN6Qzs7Ozs7VUFDSix3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFDWix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaEIsQ0FDRyxJQUFJLG1CQUFrQixXQUNuQjs7Ozs7O1VBQ0o7Ozs7O1VBQ0osd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQ1gsZUFBZSxJQUFJLGlCQUFpQjtVQUNuQzs7Ozs7VUFDSix3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFDWix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaEIsQ0FBeUssT0FDbkssSUFBSSxrQkFBa0IsV0FDdEI7Ozs7OztVQUNKOzs7OztTQUNGO1dBakJLLElBQUksZUFBZTs7OztlQWlCeEIsQ0FDTCxHQUNBLGNBQWMsV0FBVyxLQUN4Qix3QkFBQyxNQUFELFlBQ0Usd0JBQUMsTUFBRDtTQUFJLFNBQVE7U0FBSSxXQUFVO21CQUE4RDtRQUVwRjs7OztpQkFDRjs7OztnQkFFRDs7OztnQkFDRjs7Ozs7O01BRU47Ozs7OztJQUNGOzs7Ozs7RUFDRjs7Ozs7RUFHSixjQUNDLHdCQUFDLE9BQUQ7R0FDRSxXQUFVO0dBQ1YsZUFBZSxjQUFjLElBQUk7YUFFakMsd0JBQUMsT0FBRDtJQUNFLFdBQVU7SUFDVixVQUFVLE1BQU0sRUFBRSxnQkFBZ0I7Y0FGcEM7S0FLRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVcseURBQ2QsZUFBZSxXQUNYLDRFQUNBO2tCQUVILGVBQWUsV0FDZCx3QkFBQyxPQUFEO1NBQUssT0FBTTtTQUFLLFFBQU87U0FBSyxTQUFRO1NBQVksTUFBSztTQUFPLFFBQU87U0FBZSxhQUFZO1NBQUksZUFBYztTQUFRLGdCQUFlO21CQUF2SSxDQUNFLHdCQUFDLFFBQUQsRUFBTSxHQUFFLHVLQUF1Szs7OzttQkFDL0ssd0JBQUMsUUFBRCxFQUFNLEdBQUUsK0dBQStHOzs7O2lCQUNwSDs7Ozs7bUJBRUwsd0JBQUMsT0FBRDtTQUFLLE9BQU07U0FBSyxRQUFPO1NBQUssU0FBUTtTQUFZLE1BQUs7U0FBTyxRQUFPO1NBQWUsYUFBWTtTQUFJLGVBQWM7U0FBUSxnQkFBZTttQkFDckksd0JBQUMsUUFBRCxFQUFNLEdBQUUsK0lBQStJOzs7OztRQUNwSjs7Ozs7T0FFSjs7OztpQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQsQ0FBaUUsd0JBQzFDLGVBQWUsV0FBVyw0QkFBNEIsMEJBQ3pFOzs7OztpQkFDSix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBeUQ7T0FFbkU7Ozs7ZUFDQTs7OztlQUNGOzs7OztnQkFFTCx3QkFBQyxVQUFEO09BQ0UsZUFBZSxjQUFjLElBQUk7T0FDakMsV0FBVTtPQUNWLE9BQU07aUJBRU4sd0JBQUMsT0FBRDtRQUFLLFdBQVU7UUFBVSxNQUFLO1FBQU8sUUFBTztRQUFlLFNBQVE7a0JBQ2pFLHdCQUFDLFFBQUQ7U0FBTSxlQUFjO1NBQVEsZ0JBQWU7U0FBUSxhQUFZO1NBQUksR0FBRTtRQUF3Qjs7Ozs7T0FDMUY7Ozs7O01BQ0M7Ozs7Y0FDTDs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxVQUFEO09BQ0UsZUFBZTtRQUFFLGNBQWMsUUFBUTtRQUFHLGFBQWEsQ0FBQztPQUFHO09BQzNELFdBQVcsaUZBQ1QsZUFBZSxXQUNYLDJEQUNBO2lCQUxSLENBUUUsd0JBQUMsUUFBRCxZQUFNLDZCQUFnQzs7OztpQkFDdEMsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IscUJBQXFCO09BQ2xCOzs7O2VBQ0E7Ozs7O2dCQUVSLHdCQUFDLFVBQUQ7T0FDRSxlQUFlO1FBQUUsY0FBYyxRQUFRO1FBQUcsYUFBYSxDQUFDO09BQUc7T0FDM0QsV0FBVyxpRkFDVCxlQUFlLFdBQ1gsMkRBQ0E7aUJBTFIsQ0FRRSx3QkFBQyxRQUFELFlBQU0scUJBQXdCOzs7O2lCQUM5Qix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYixxQkFBcUI7T0FDbEI7Ozs7ZUFDQTs7Ozs7Y0FDTDs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FFRyxlQUFlLFdBQ2Qsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFnRTtVQUFxQjs7OztvQkFDbEcsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQ1YsY0FBYyxrQkFBa0IsWUFBWSxnQkFBZ0I7VUFDNUQ7Ozs7a0JBQ0E7Ozs7OztTQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQWtFO1VBQWdCOzs7O29CQUMvRix3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBYixDQUErRSxRQUN4RSxPQUFPLGNBQWMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUN4RDs7Ozs7a0JBQ0E7Ozs7OztTQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQStEO1VBQWU7Ozs7b0JBQzNGLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFiO1lBQ0csY0FBYyxtQkFBbUI7WUFBRTtZQUFDLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFxQztZQUFXOzs7OztXQUNwRzs7Ozs7a0JBQ0E7Ozs7OztTQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQWlFO1VBQWU7Ozs7b0JBQzdGLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFiO1lBQ0csY0FBYyxtQkFBbUI7WUFBRTtZQUFDLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFxQztZQUFXOzs7OztXQUNwRzs7Ozs7a0JBQ0E7Ozs7OztRQUNGOzs7OztrQkFFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQWdFO1VBQXdCOzs7O29CQUNyRyx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBYjtZQUNHLGNBQWMsaUJBQWlCLFlBQVksZ0JBQWdCO1lBQUU7WUFBQyx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBcUM7WUFBVzs7Ozs7V0FDOUg7Ozs7O2tCQUNBOzs7Ozs7U0FDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUE4RDtVQUFzQjs7OztvQkFDakcsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQWI7WUFDRyxjQUFjLGlCQUFpQjtZQUFFO1lBQUMsd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQXFDO1lBQWM7Ozs7O1dBQ3JHOzs7OztrQkFDQTs7Ozs7O1NBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBaUU7VUFBbUI7Ozs7b0JBQ2pHLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFiO1lBQ0csY0FBYyxxQkFBcUI7WUFBRTtZQUFDLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFxQztZQUFjOzs7OztXQUN6Rzs7Ozs7a0JBQ0E7Ozs7OztTQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQStEO1VBQW9COzs7O29CQUNoRyx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBYjtZQUNHLHFCQUFxQjtZQUFPO1lBQUMsd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQXFDO1lBQWU7Ozs7O1dBQ2pHOzs7OztrQkFDQTs7Ozs7O1FBQ0Y7Ozs7OztPQUlQLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNaLGVBQWUsV0FDZCx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBakIsQ0FDRSx3QkFBQyxTQUFELFlBQ0Usd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWQ7V0FDRSx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBNkY7V0FBUTs7Ozs7V0FDbkgsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQXlHO1dBQWtCOzs7OztXQUN6SSx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBeUc7V0FBZ0I7Ozs7O1dBQ3ZJLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUF5RztXQUFnQjs7Ozs7V0FDdkksd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQXdHO1dBQWE7Ozs7O1dBQ25JLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUE2RjtXQUFpQjs7Ozs7VUFDMUg7Ozs7O2tCQUNDOzs7O21CQUNQLHdCQUFDLFNBQUQsYUFDRyxtQkFBbUIsS0FBSyxLQUFLLFVBQzVCLHdCQUFDLE1BQUQ7VUFBbUMsV0FBVTtvQkFBN0M7V0FDRSx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDWCxXQUFXLElBQUksZ0JBQWdCLElBQUksU0FBUztXQUMzQzs7Ozs7V0FDSix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDWix3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBaEIsQ0FDRyxJQUFJLGdCQUFlLFFBQ2hCOzs7Ozs7V0FDSjs7Ozs7V0FDSix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDWCxJQUFJLHNCQUFzQjtXQUN6Qjs7Ozs7V0FDSix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDWCxJQUFJLHNCQUFzQjtXQUN6Qjs7Ozs7V0FDSix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBZCxDQUE4RixRQUN2RixPQUFPLElBQUksbUJBQW1CLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUM3Qzs7Ozs7O1dBQ0osd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQ1gsSUFBSSxpQkFBaUI7V0FDcEI7Ozs7O1VBQ0Y7WUFyQkssSUFBSSxlQUFlOzs7O2dCQXFCeEIsQ0FDTCxHQUNBLG1CQUFtQixXQUFXLEtBQzdCLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO1VBQUksU0FBUTtVQUFJLFdBQVU7b0JBQThEO1NBRXBGOzs7O2tCQUNGOzs7O2lCQUVEOzs7O2lCQUNGOzs7OzttQkFFUCx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBakIsQ0FDRSx3QkFBQyxTQUFELFlBQ0Usd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWQ7V0FDRSx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBNkY7V0FBbUI7Ozs7O1dBQzlILHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUF5RztXQUF1Qjs7Ozs7V0FDOUksd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQXlHO1dBQXNCOzs7OztXQUM3SSx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBNkY7V0FBZTs7Ozs7VUFDeEg7Ozs7O2tCQUNDOzs7O21CQUNQLHdCQUFDLFNBQUQsYUFDRyxtQkFBbUIsS0FBSyxLQUFLLFVBQzVCLHdCQUFDLE1BQUQ7VUFBbUMsV0FBVTtvQkFBN0M7V0FDRSx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDWCxXQUFXLElBQUksY0FBYyxJQUFJLFNBQVM7V0FDekM7Ozs7O1dBQ0osd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQ1osd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWhCLENBQ0csSUFBSSxtQkFBa0IsV0FDbkI7Ozs7OztXQUNKOzs7OztXQUNKLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUNYLGVBQWUsSUFBSSxpQkFBaUI7V0FDbkM7Ozs7O1dBQ0osd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQ1osd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWhCLENBQXlLLE9BQ25LLElBQUksa0JBQWtCLFdBQ3RCOzs7Ozs7V0FDSjs7Ozs7VUFDRjtZQWpCSyxJQUFJLGVBQWU7Ozs7Z0JBaUJ4QixDQUNMLEdBQ0EsbUJBQW1CLFdBQVcsS0FDN0Isd0JBQUMsTUFBRCxZQUNFLHdCQUFDLE1BQUQ7VUFBSSxTQUFRO1VBQUksV0FBVTtvQkFBOEQ7U0FFcEY7Ozs7a0JBQ0Y7Ozs7aUJBRUQ7Ozs7aUJBQ0Y7Ozs7OztPQUVOOzs7OztPQUdKLFVBQVUsU0FBUyxLQUNsQix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFiO1VBQXNFO1dBQ3hELFlBQVksS0FBSyxlQUFlO1VBQUU7VUFBSSxLQUFLLElBQUksWUFBWSxjQUFjLFVBQVUsTUFBTTtVQUFFO1VBQUssVUFBVTtVQUFPO1NBQzVIOzs7OztrQkFFSCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLFVBQUQ7V0FDRSxlQUFlLGNBQWMsU0FBUyxLQUFLLElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQztXQUMzRCxVQUFVLGNBQWM7V0FDeEIsV0FBVTtxQkFDWDtVQUVPOzs7OztVQUNSLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQjtZQUEyRTtZQUNqRTtZQUFVO1lBQUs7V0FDbkI7Ozs7OztVQUNOLHdCQUFDLFVBQUQ7V0FDRSxlQUFlLGNBQWMsU0FBUyxLQUFLLElBQUksT0FBTyxHQUFHLGVBQWUsQ0FBQztXQUN6RSxVQUFVLGNBQWM7V0FDeEIsV0FBVTtxQkFDWDtVQUVPOzs7OztTQUNMOzs7OztnQkFDRjs7Ozs7O01BRUo7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGNBQWMsSUFBSTtPQUNqQyxXQUFVO2lCQUNYO01BRU87Ozs7O0tBQ0w7Ozs7O0lBQ0Y7Ozs7OztFQUNGOzs7OztFQUlQLHdCQUFDLGVBQUQ7R0FDRSxRQUFRO0dBQ1IsZUFBZSxtQkFBbUIsS0FBSztFQUN4Qzs7Ozs7Q0FDRDs7Ozs7QUFFTjs7Ozs7QUFFQSxTQUFTLGVBQWUsVUFBVTtDQUNoQyxJQUFJLFdBQVcsSUFBSTtFQUNqQixPQUNFLHdCQUFDLFFBQUQ7R0FBTSxXQUFVO2FBQWhCLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsc0NBQTRDOzs7O2FBQUMsZ0JBRXpEOzs7Ozs7Q0FFVjtDQUNBLElBQUksV0FBVyxJQUFJO0VBQ2pCLE9BQ0Usd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFBaEIsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSx3Q0FBOEM7Ozs7YUFBQyxVQUUzRDs7Ozs7O0NBRVY7Q0FDQSxPQUNFLHdCQUFDLFFBQUQ7RUFBTSxXQUFVO1lBQWhCLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsMENBQWdEOzs7O1lBQUMsZUFFN0Q7Ozs7OztBQUVWO0FBRUEsU0FBUyxZQUFZLE9BQU87Q0FBRSxPQUFPLFVBQVUsUUFBUSxVQUFVLFlBQVksTUFBTSxPQUFPLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUFFO0FBRTVHLFNBQVMsV0FBVyxPQUFPO0NBQ3pCLElBQUksQ0FBQyxPQUFPLE9BQU87O0NBRW5CLElBQUksT0FBTyxVQUFVLFlBQVksTUFBTSxTQUFTLEdBQUcsR0FBRztFQUNwRCxNQUFNLFdBQVcsTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDO0VBQ2xDLElBQUksVUFBVTtHQUNaLE9BQU8sU0FBUyxVQUFVLEdBQUcsQ0FBQztFQUNoQztDQUNGO0NBQ0EsTUFBTSxVQUFVLElBQUksS0FBSyxLQUFLO0NBQzlCLE9BQU8sUUFBUSxtQkFBbUIsQ0FBQyxHQUFHO0VBQUUsTUFBTTtFQUFXLFFBQVE7RUFBVyxRQUFRO0VBQVcsUUFBUTtDQUFNLENBQUM7QUFDaEg7QUFFQSxTQUFTLFFBQVEsT0FBTztDQUFFLElBQUksVUFBVSxhQUFhLFVBQVUsTUFBTSxPQUFPO0NBQVMsT0FBTyxRQUFRLEtBQUssUUFBUSxNQUFNLFlBQVk7QUFBUztBQUM1SSxTQUFTLGVBQWUsT0FBTztDQUFFLElBQUksVUFBVSxhQUFhLFVBQVUsTUFBTSxPQUFPO0NBQVMsT0FBTyxRQUFRLEtBQUssV0FBVyxRQUFRLElBQUksWUFBWTtBQUFTIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBtb25pdG9yaW5nQXBpIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvYXBpJ1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uL2NvbnRleHQvQXV0aENvbnRleHQnXG5pbXBvcnQgUHJlZGljY2lvblBhbmVsIGZyb20gJy4uLy4uL2NvbXBvbmVudHMvUHJlZGljY2lvblBhbmVsJ1xuaW1wb3J0IFJlcG9ydGVzTW9kYWwgZnJvbSAnLi4vLi4vY29tcG9uZW50cy9SZXBvcnRlc01vZGFsJ1xuaW1wb3J0IHtcbiAgUmVzcG9uc2l2ZUNvbnRhaW5lcixcbiAgQ29tcG9zZWRDaGFydCxcbiAgQXJlYSxcbiAgTGluZSxcbiAgWEF4aXMsXG4gIFlBeGlzLFxuICBDYXJ0ZXNpYW5HcmlkLFxuICBUb29sdGlwLFxuICBMZWdlbmQsXG4gIFJlZmVyZW5jZUxpbmVcbn0gZnJvbSAncmVjaGFydHMnXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIERhc2hib2FyZCgpIHtcbiAgY29uc3QgeyBzZXNzaW9uLCBzaG93RXJyb3IgfSA9IHVzZUF1dGgoKVxuICBjb25zdCBbc2Vuc29yRGF0YSwgc2V0U2Vuc29yRGF0YV0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbbG9hZGluZ1NlbnNvcnMsIHNldExvYWRpbmdTZW5zb3JzXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbam9ybmFkYURpc3BvbmlibGUsIHNldEpvcm5hZGFEaXNwb25pYmxlXSA9IHVzZVN0YXRlKHRydWUpXG4gIGNvbnN0IFtzZWxlY3RlZFNlbnNvciwgc2V0U2VsZWN0ZWRTZW5zb3JdID0gdXNlU3RhdGUoJ3BoJykgLy8gJ3BoJyB8ICd0dXJiaWRleicgfCAndGVtcGVyYXR1cmEnIHwgJ3RvZG9zJ1xuICBjb25zdCBbc2hvd1JlcG9ydE1vZGFsLCBzZXRTaG93UmVwb3J0TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgY29uc3QgbG9hZFNlbnNvckRhdGEgPSBhc3luYyAoKSA9PiB7XG4gICAgc2V0TG9hZGluZ1NlbnNvcnModHJ1ZSlcbiAgICB0cnkge1xuICAgICAgY29uc3QgW3sgZGF0YTogc3RhdGUgfSwgeyBkYXRhOiBhbGVydHMgfV0gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgICAgIG1vbml0b3JpbmdBcGkuZ2V0KCcvYXBpL2VzdGFkb19hY3R1YWwnKSxcbiAgICAgICAgbW9uaXRvcmluZ0FwaS5nZXQoJy9hcGkvYWxlcnRhcycpLFxuICAgICAgXSlcbiAgICAgIHNldFNlbnNvckRhdGEoeyAuLi5zdGF0ZSwgYWxlcnRhczogYWxlcnRzIH0pXG4gICAgICBzZXRKb3JuYWRhRGlzcG9uaWJsZSh0cnVlKVxuICAgIH0gY2F0Y2ggKHJlcXVlc3RFcnJvcikge1xuICAgICAgc2V0U2Vuc29yRGF0YShudWxsKVxuICAgICAgaWYgKHJlcXVlc3RFcnJvci5yZXNwb25zZT8uc3RhdHVzID09PSA0MDQpIHtcbiAgICAgICAgc2V0Sm9ybmFkYURpc3BvbmlibGUoZmFsc2UpXG4gICAgICB9IGVsc2UgaWYgKHNob3dFcnJvcikge1xuICAgICAgICBzaG93RXJyb3IocmVxdWVzdEVycm9yLnJlc3BvbnNlPy5kYXRhPy5kZXRhaWwgfHwgJ05vIHNlIHB1ZGllcm9uIGNhcmdhciBsYXMgbGVjdHVyYXMgZGUgbG9zIHNlbnNvcmVzJylcbiAgICAgIH1cbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0TG9hZGluZ1NlbnNvcnMoZmFsc2UpXG4gICAgfVxuICB9XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsb2FkU2Vuc29yRGF0YSgpXG4gICAgY29uc3QgaW50ZXJ2YWxJZCA9IHdpbmRvdy5zZXRJbnRlcnZhbChsb2FkU2Vuc29yRGF0YSwgMTAwMDApXG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5jbGVhckludGVydmFsKGludGVydmFsSWQpXG4gIH0sIFtdKVxuXG4gIGNvbnN0IHByZWRlY2lyQWhvcmEgPSBhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IG1vbml0b3JpbmdBcGkucG9zdCgnL2FwaS9wcmVkZWNpcicpXG4gICAgICBhd2FpdCBsb2FkU2Vuc29yRGF0YSgpXG4gICAgfSBjYXRjaCAocmVxdWVzdEVycm9yKSB7XG4gICAgICBpZiAoc2hvd0Vycm9yKSB7XG4gICAgICAgIHNob3dFcnJvcihyZXF1ZXN0RXJyb3IucmVzcG9uc2U/LmRhdGE/LmRldGFpbCB8fCAnTm8gc2UgcHVkbyBnZW5lcmFyIGxhIHByZWRpY2Npw7NuJylcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBjb25zdCBtZWFzdXJlbWVudCA9IHNlbnNvckRhdGE/LnVsdGltYV9tZWRpY2lvblxuICBjb25zdCBzdW1tYXJ5ID0gc2Vuc29yRGF0YT8ucmVzdW1lblxuICBjb25zdCByYXdSZWFkaW5ncyA9IHNlbnNvckRhdGE/Lmhpc3RvcmlhbCB8fCBbXVxuICBjb25zdCBwcm9ub3N0aWNvID0gc2Vuc29yRGF0YT8ucHJvbm9zdGljbyB8fCB7fVxuICBjb25zdCBlc3RhZG9TZW5zb3JlcyA9IHNlbnNvckRhdGE/LmVzdGFkb19zZW5zb3JlcyB8fCB7fVxuICBjb25zdCBlc3RpbWFkb3MgPSBzZW5zb3JEYXRhPy52YWxvcmVzX2VzdGltYWRvcyB8fCB7fVxuXG4gIC8vIFVuIHNlbnNvciBcImZhbGzDs1wiIHNpIG5vIGVudmnDsyBkYXRvLCBlbnZpw7MgYWxnbyBmdWVyYSBkZSByYW5nbyBvIHNlIGRlc2NvbmVjdMOzXG4gIGNvbnN0IHNlbnNvckZhbGxvID0gKHYpID0+IFsnc2luX2RhdG8nLCAnZnVlcmFfcmFuZ28nLCAnc2luX2NvbmV4aW9uJ10uaW5jbHVkZXMoZXN0YWRvU2Vuc29yZXM/Llt2XT8uZXN0YWRvKVxuICBjb25zdCB1bHRpbW9WYWxpZG8gPSAodikgPT4ge1xuICAgIGZvciAobGV0IGkgPSByYXdSZWFkaW5ncy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgICAgaWYgKHJhd1JlYWRpbmdzW2ldW3ZdICE9PSBudWxsICYmIHJhd1JlYWRpbmdzW2ldW3ZdICE9PSB1bmRlZmluZWQpIHJldHVybiByYXdSZWFkaW5nc1tpXVt2XVxuICAgIH1cbiAgICByZXR1cm4gbnVsbFxuICB9XG4gIC8vIFZhbG9yIGEgbW9zdHJhciBlbiBsYSB0YXJqZXRhOiBlc3RpbWFkbyBzaSBlbCBzZW5zb3IgZmFsbMOzLCBzaSBubyBsYSDDumx0aW1hIGxlY3R1cmEgdsOhbGlkYVxuICBjb25zdCB2YWxvclNlbnNvciA9ICh2KSA9PiB7XG4gICAgaWYgKHNlbnNvckZhbGxvKHYpICYmIGVzdGltYWRvcz8uW3ZdKSByZXR1cm4gZXN0aW1hZG9zW3ZdLnZhbG9yXG4gICAgcmV0dXJuIG1lYXN1cmVtZW50Py5bdl0gPz8gdWx0aW1vVmFsaWRvKHYpXG4gIH1cblxuICAvLyBPcmRlbmFyIHJhd1JlYWRpbmdzIGRlIG3DoXMgcmVjaWVudGUgYSBtw6FzIGFudGlndWEgcGFyYSBsYSB0YWJsYVxuICBjb25zdCBzb3J0ZWRSZWFkaW5ncyA9IFsuLi5yYXdSZWFkaW5nc10uc29ydCgoYSwgYikgPT4gbmV3IERhdGUoYi5mZWNoYV9ob3JhKSAtIG5ldyBEYXRlKGEuZmVjaGFfaG9yYSkpXG5cbiAgLy8gRm9ybWF0ZWFyIGxlY3R1cmFzIHBhcmEgbG9zIGdyw6FmaWNvcyAoY3Jvbm9sw7NnaWNvIGFzY2VuZGVudGUgZGUgaXpxdWllcmRhIGEgZGVyZWNoYSlcbiAgY29uc3QgY2hhcnREYXRhID0gWy4uLnNvcnRlZFJlYWRpbmdzXS5yZXZlcnNlKCkubWFwKChyKSA9PiAoe1xuICAgIHRzOiBuZXcgRGF0ZShyLmZlY2hhX2hvcmEpLmdldFRpbWUoKSxcbiAgICBob3JhOiBmb3JtYXRUaW1lKHIuZmVjaGFfaG9yYSksXG4gICAgcEg6IHIucGggIT09IG51bGwgJiYgci5waCAhPT0gdW5kZWZpbmVkID8gTnVtYmVyKE51bWJlcihyLnBoKS50b0ZpeGVkKDIpKSA6IG51bGwsXG4gICAgVHVyYmlkZXo6IHIudHVyYmlkZXogIT09IG51bGwgJiYgci50dXJiaWRleiAhPT0gdW5kZWZpbmVkID8gTnVtYmVyKE51bWJlcihyLnR1cmJpZGV6KS50b0ZpeGVkKDIpKSA6IG51bGwsXG4gICAgVGVtcGVyYXR1cmE6IHIudGVtcGVyYXR1cmEgIT09IG51bGwgJiYgci50ZW1wZXJhdHVyYSAhPT0gdW5kZWZpbmVkID8gTnVtYmVyKE51bWJlcihyLnRlbXBlcmF0dXJhKS50b0ZpeGVkKDIpKSA6IG51bGwsXG4gIH0pKVxuXG4gIGNvbnN0IFtjdXJyZW50UGFnZSwgc2V0Q3VycmVudFBhZ2VdID0gdXNlU3RhdGUoMSlcbiAgY29uc3QgW21vZGFsQWZvcm8sIHNldE1vZGFsQWZvcm9dID0gdXNlU3RhdGUobnVsbCkgLy8gJ21hbnVhbCcgfCAnY2FtYXJhJyB8IG51bGxcbiAgY29uc3QgW21vZGFsUGFnZSwgc2V0TW9kYWxQYWdlXSA9IHVzZVN0YXRlKDEpXG4gIGNvbnN0IFt0YWJsZVRhYiwgc2V0VGFibGVUYWJdID0gdXNlU3RhdGUoJ3NlbnNvcmVzJykgLy8gJ3NlbnNvcmVzJyB8ICdtYW51YWwnIHwgJ2NhbWFyYSdcbiAgY29uc3QgaXRlbXNQZXJQYWdlID0gMTBcblxuICBjb25zdCByYXdNYW51YWxSZWFkaW5ncyA9IHNlbnNvckRhdGE/LmFmb3JvX21hbnVhbF9yZWdpc3Ryb3MgfHwgW11cbiAgY29uc3QgbWFudWFsU3VtbWFyeSA9IHNlbnNvckRhdGE/LmFmb3JvX21hbnVhbF9yZXN1bWVuIHx8IHt9XG4gIGNvbnN0IHJhd0NhbWVyYVJlYWRpbmdzID0gc2Vuc29yRGF0YT8uYWZvcm9fY2FtYXJhX3JlZ2lzdHJvcyB8fCBbXVxuICBjb25zdCBjYW1lcmFTdW1tYXJ5ID0gc2Vuc29yRGF0YT8uYWZvcm9fY2FtYXJhX3Jlc3VtZW4gfHwge31cblxuICAvLyBPcmRlbmFyIGRlIG3DoXMgcmVjaWVudGUgYSBtw6FzIGFudGlndWFcbiAgY29uc3Qgc29ydGVkTWFudWFsUmVhZGluZ3MgPSBbLi4ucmF3TWFudWFsUmVhZGluZ3NdLnNvcnQoXG4gICAgKGEsIGIpID0+IG5ldyBEYXRlKGIuaG9yYV9lbnRyYWRhIHx8IGIuY3JlYWRvX2VuKSAtIG5ldyBEYXRlKGEuaG9yYV9lbnRyYWRhIHx8IGEuY3JlYWRvX2VuKVxuICApXG4gIGNvbnN0IHNvcnRlZENhbWVyYVJlYWRpbmdzID0gWy4uLnJhd0NhbWVyYVJlYWRpbmdzXS5zb3J0KFxuICAgIChhLCBiKSA9PiBuZXcgRGF0ZShiLmZlY2hhX2hvcmEgfHwgYi5jcmVhZG9fZW4pIC0gbmV3IERhdGUoYS5mZWNoYV9ob3JhIHx8IGEuY3JlYWRvX2VuKVxuICApXG5cbiAgLy8gRGF0b3MgcGFyYSBsYSB0YWJsYSBkZWwgZGFzaGJvYXJkIHNlZ8O6biB0YWIgYWN0aXZvXG4gIGNvbnN0IGN1cnJlbnRUYWJsZUxpc3QgPVxuICAgIHRhYmxlVGFiID09PSAnbWFudWFsJyA/IHNvcnRlZE1hbnVhbFJlYWRpbmdzIDpcbiAgICB0YWJsZVRhYiA9PT0gJ2NhbWFyYScgPyBzb3J0ZWRDYW1lcmFSZWFkaW5ncyA6XG4gICAgc29ydGVkUmVhZGluZ3NcblxuICBjb25zdCB0b3RhbFBhZ2VzID0gTWF0aC5jZWlsKGN1cnJlbnRUYWJsZUxpc3QubGVuZ3RoIC8gaXRlbXNQZXJQYWdlKSB8fCAxXG4gIGNvbnN0IHBhZ2luYXRlZExpc3QgPSBjdXJyZW50VGFibGVMaXN0LnNsaWNlKChjdXJyZW50UGFnZSAtIDEpICogaXRlbXNQZXJQYWdlLCBjdXJyZW50UGFnZSAqIGl0ZW1zUGVyUGFnZSlcblxuICAvLyBEYXRvcyBwYXJhIGVsIG1vZGFsIHNlZ8O6biBhZm9ybyBzZWxlY2Npb25hZG9cbiAgY29uc3QgbW9kYWxMaXN0ID0gbW9kYWxBZm9ybyA9PT0gJ21hbnVhbCcgPyBzb3J0ZWRNYW51YWxSZWFkaW5ncyA6IHNvcnRlZENhbWVyYVJlYWRpbmdzXG4gIGNvbnN0IG1vZGFsVG90YWxQYWdlcyA9IE1hdGguY2VpbChtb2RhbExpc3QubGVuZ3RoIC8gaXRlbXNQZXJQYWdlKSB8fCAxXG4gIGNvbnN0IHBhZ2luYXRlZE1vZGFsTGlzdCA9IG1vZGFsTGlzdC5zbGljZSgobW9kYWxQYWdlIC0gMSkgKiBpdGVtc1BlclBhZ2UsIG1vZGFsUGFnZSAqIGl0ZW1zUGVyUGFnZSlcblxuICBpZiAoIWpvcm5hZGFEaXNwb25pYmxlKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLVs2MHZoXSBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIGJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIHAtOCB0ZXh0LWNlbnRlciBzaGFkb3ctc21cIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00IGZsZXggaC0xNiB3LTE2IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGwgYmctYmx1ZS01MCBkYXJrOmJnLWJsdWUtOTAwLzIwIHRleHQtYmx1ZS01MDBcIj5cbiAgICAgICAgICA8c3ZnIHdpZHRoPVwiMzJcIiBoZWlnaHQ9XCIzMlwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBmaWxsPVwibm9uZVwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIj5cbiAgICAgICAgICAgIDxwYXRoIGQ9XCJNMTIgOFYxMkwxNSAxNU0yMSAxMkMyMSAxNi45NzA2IDE2Ljk3MDYgMjEgMTIgMjFDNy4wMjk0NCAyMSAzIDE2Ljk3MDYgMyAxMkMzIDcuMDI5NDQgNy4wMjk0NCAzIDEyIDNDMTYuOTcwNiAzIDIxIDcuMDI5NDQgMjEgMTJaXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIyXCIgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiLz5cbiAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi0yIHRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGVcIj5ObyBoYXkgdW5hIGpvcm5hZGEgZGlzcG9uaWJsZTwvaDM+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cIm1heC13LW1kIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICBBY3R1YWxtZW50ZSBubyBoYXkgbmluZ3VuYSBqb3JuYWRhIGluaWNpYWRhIHBhcmEgZWwgZMOtYSBkZSBob3kuIExvcyBzZW5zb3JlcyBjb21lbnphcsOhbiBhIHJlZ2lzdHJhciBkYXRvcyB1bmEgdmV6IHF1ZSBzZSBpbmljaWUgdW5hIG51ZXZhIGpvcm5hZGEuXG4gICAgICAgIDwvcD5cbiAgICAgIDwvZGl2PlxuICAgIClcbiAgfVxuXG4gIGNvbnN0IHNlbnNvckNvbmZpZyA9IHtcbiAgICBwaDogeyBcbiAgICAgIHRpdGxlOiAnTW9uaXRvcmVvIGRlIHBIJywgXG4gICAgICBjb2xvcjogJyMyNTYzZWInLCBcbiAgICAgIHVuaXQ6ICcnLCBcbiAgICAgIGRhdGFLZXk6ICdwSCcsXG4gICAgICBtaW5PcHQ6IDcuMCwgXG4gICAgICBtYXhPcHQ6IDcuNiBcbiAgICB9LFxuICAgIHR1cmJpZGV6OiB7IFxuICAgICAgdGl0bGU6ICdNb25pdG9yZW8gZGUgVHVyYmlkZXonLCBcbiAgICAgIGNvbG9yOiAnI2VhNTgwYycsIFxuICAgICAgdW5pdDogJ05UVScsIFxuICAgICAgZGF0YUtleTogJ1R1cmJpZGV6JyxcbiAgICAgIG1heE9wdDogNS4wIFxuICAgIH0sXG4gICAgdGVtcGVyYXR1cmE6IHsgXG4gICAgICB0aXRsZTogJ01vbml0b3JlbyBkZSBUZW1wZXJhdHVyYScsIFxuICAgICAgY29sb3I6ICcjMTBiOTgxJywgXG4gICAgICB1bml0OiAnwrBDJywgXG4gICAgICBkYXRhS2V5OiAnVGVtcGVyYXR1cmEnLFxuICAgICAgbWluT3B0OiAyNCwgXG4gICAgICBtYXhPcHQ6IDMwIFxuICAgIH0sXG4gIH1cblxuICAvLyBDb21iaW5hciBsZWN0dXJhcyByZWFsZXMgKyBwcm9uw7NzdGljbyBkZWwgc2Vuc29yIHNlbGVjY2lvbmFkb1xuICBjb25zdCBjZmdTZWwgPSBzZW5zb3JDb25maWdbc2VsZWN0ZWRTZW5zb3JdXG4gIGNvbnN0IHNlcmllUHJvbiA9IHByb25vc3RpY28/LltzZWxlY3RlZFNlbnNvcl0gfHwgW11cbiAgY29uc3QgcHVudG9zUmVhbGVzID0gY2hhcnREYXRhLm1hcCgocCkgPT4gKHsgLi4ucCB9KSlcbiAgY29uc3QgdWx0aW1vUmVhbCA9IFsuLi5wdW50b3NSZWFsZXNdLnJldmVyc2UoKS5maW5kKChwKSA9PiBwW2NmZ1NlbC5kYXRhS2V5XSAhPT0gbnVsbClcbiAgaWYgKHVsdGltb1JlYWwgJiYgc2VyaWVQcm9uLmxlbmd0aCkge1xuICAgIC8vIEFuY2xhOiBlbCBwcm9uw7NzdGljbyBhcnJhbmNhIGVuIGxhIMO6bHRpbWEgbGVjdHVyYSByZWFsIHBhcmEgcXVlIGxhIGzDrW5lYSBzZWEgY29udGludWFcbiAgICB1bHRpbW9SZWFsLlByb25vc3RpY28gPSB1bHRpbW9SZWFsW2NmZ1NlbC5kYXRhS2V5XVxuICAgIHVsdGltb1JlYWwuUmFuZ28gPSBbdWx0aW1vUmVhbFtjZmdTZWwuZGF0YUtleV0sIHVsdGltb1JlYWxbY2ZnU2VsLmRhdGFLZXldXVxuICB9XG4gIGNvbnN0IHB1bnRvc1Byb24gPSBzZXJpZVByb24ubWFwKChwKSA9PiAoe1xuICAgIHRzOiBuZXcgRGF0ZShwLmZlY2hhX2hvcmEpLmdldFRpbWUoKSxcbiAgICBob3JhOiBmb3JtYXRUaW1lKHAuZmVjaGFfaG9yYSksXG4gICAgUHJvbm9zdGljbzogTnVtYmVyKE51bWJlcihwLnZhbG9yKS50b0ZpeGVkKDIpKSxcbiAgICBSYW5nbzogW051bWJlcihOdW1iZXIocC5pbmZlcmlvcikudG9GaXhlZCgyKSksIE51bWJlcihOdW1iZXIocC5zdXBlcmlvcikudG9GaXhlZCgyKSldLFxuICB9KSlcbiAgY29uc3QgY2hhcnRDb21iaW5hZG8gPSBbLi4ucHVudG9zUmVhbGVzLCAuLi5wdW50b3NQcm9uXS5zb3J0KChhLCBiKSA9PiBhLnRzIC0gYi50cylcbiAgY29uc3QgaGF5UHJvbm9zdGljbyA9IHB1bnRvc1Byb24ubGVuZ3RoID4gMFxuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIHsvKiBUQVJKRVRBUyBJTlRFUkFDVElWQVMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgZ2FwLTUgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgeGw6Z3JpZC1jb2xzLTVcIj5cbiAgICAgICAgXG4gICAgICAgIHsvKiBwSCBDYXJkICovfVxuICAgICAgICA8ZGl2IFxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkU2Vuc29yKCdwaCcpfVxuICAgICAgICAgIGNsYXNzTmFtZT17YGN1cnNvci1wb2ludGVyIHJvdW5kZWQtMnhsIGJvcmRlciBwLTUgc2hhZG93LXNtIHRyYW5zaXRpb24tYWxsICR7c2VsZWN0ZWRTZW5zb3IgPT09ICdwaCcgPyAnYm9yZGVyLWJsdWUtNTAwIHJpbmctMiByaW5nLWJsdWUtNTAwLzIwIGJnLWJsdWUtNTAvMjAgZGFyazpiZy1ibHVlLTkwMC8xMCcgOiAnYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gaG92ZXI6Ym9yZGVyLWJsdWUtMzAwJ31gfVxuICAgICAgICA+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIGZsZXggaC0xMCB3LTEwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWxnIGJnLWJsdWUtNTAgZGFyazpiZy1ibHVlLTkwMC8yMCB0ZXh0LWJsdWUtNjAwIGRhcms6dGV4dC1ibHVlLTQwMCB0ZXh0LWxnIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgcEhcbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtZW5kIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+U2Vuc29yIGRlIHBIPC9zcGFuPlxuICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlIGZsZXggaXRlbXMtYmFzZWxpbmUgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgIHtmb3JtYXRWYWx1ZSh2YWxvclNlbnNvcigncGgnKSl9XG4gICAgICAgICAgICAgICAge3NlbnNvckZhbGxvKCdwaCcpICYmIChcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWFtYmVyLTUwMFwiIHRpdGxlPVwiVmFsb3IgZXN0aW1hZG8gcG9yIGZhbGxhIGRlIHNlbnNvclwiPn5lc3QuPC9zcGFuPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHJvdW5kZWQtZnVsbCBweC0yIHB5LTAuNSB0ZXh0LVsxMHB4XSBmb250LXNlbWlib2xkICR7XG4gICAgICAgICAgICAgIHNlbnNvckZhbGxvKCdwaCcpXG4gICAgICAgICAgICAgICAgPyAnYmctYW1iZXItNTAgZGFyazpiZy1hbWJlci05MDAvMjAgdGV4dC1hbWJlci02MDAgZGFyazp0ZXh0LWFtYmVyLTQwMCdcbiAgICAgICAgICAgICAgICA6IHBoU3RhdGUodmFsb3JTZW5zb3IoJ3BoJykpID09PSAnbm9ybWFsJ1xuICAgICAgICAgICAgICAgID8gJ2JnLWVtZXJhbGQtNTAgZGFyazpiZy1lbWVyYWxkLTkwMC8yMCB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCdcbiAgICAgICAgICAgICAgICA6ICdiZy1yZWQtNTAgZGFyazpiZy1yZWQtOTAwLzIwIHRleHQtcmVkLTYwMCBkYXJrOnRleHQtcmVkLTQwMCdcbiAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAge3NlbnNvckZhbGxvKCdwaCcpID8gJ0VzdGltYWRvJyA6IHBoU3RhdGUodmFsb3JTZW5zb3IoJ3BoJykpID09PSAnbm9ybWFsJyA/ICfDk3B0aW1vJyA6ICdBbGVydGEnfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogVHVyYmlkZXogQ2FyZCAqL31cbiAgICAgICAgPGRpdiBcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZFNlbnNvcigndHVyYmlkZXonKX1cbiAgICAgICAgICBjbGFzc05hbWU9e2BjdXJzb3ItcG9pbnRlciByb3VuZGVkLTJ4bCBib3JkZXIgcC01IHNoYWRvdy1zbSB0cmFuc2l0aW9uLWFsbCAke3NlbGVjdGVkU2Vuc29yID09PSAndHVyYmlkZXonID8gJ2JvcmRlci1vcmFuZ2UtNTAwIHJpbmctMiByaW5nLW9yYW5nZS01MDAvMjAgYmctb3JhbmdlLTUwLzIwIGRhcms6Ymctb3JhbmdlLTkwMC8xMCcgOiAnYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gaG92ZXI6Ym9yZGVyLW9yYW5nZS0zMDAnfWB9XG4gICAgICAgID5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBoLTEwIHctMTAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtbGcgYmctb3JhbmdlLTUwIGRhcms6Ymctb3JhbmdlLTkwMC8yMCB0ZXh0LW9yYW5nZS02MDAgZGFyazp0ZXh0LW9yYW5nZS00MDBcIj5cbiAgICAgICAgICAgIDxzdmcgd2lkdGg9XCIyMFwiIGhlaWdodD1cIjIwXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiPlxuICAgICAgICAgICAgICA8cGF0aCBkPVwiTTEyIDIyQzE3LjUyMjggMjIgMjIgMTcuNTIyOCAyMiAxMkMyMiA2LjQ3NzE1IDE3LjUyMjggMiAxMiAyQzYuNDc3MTUgMiAyIDYuNDc3MTUgMiAxMkMyIDE3LjUyMjggNi40NzcxNSAyMiAxMiAyMlpcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjJcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIvPlxuICAgICAgICAgICAgICA8cGF0aCBkPVwiTTggMTRDOCAxNCA5LjUgMTYgMTIgMTZDMTQuNSAxNiAxNiAxNCAxNiAxNFwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMlwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIi8+XG4gICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtZW5kIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+U2Vuc29yIFR1cmJpZGV6PC9zcGFuPlxuICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlIGZsZXggaXRlbXMtYmFzZWxpbmUgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgIHtmb3JtYXRWYWx1ZSh2YWxvclNlbnNvcigndHVyYmlkZXonKSl9IDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPk5UVTwvc3Bhbj5cbiAgICAgICAgICAgICAgICB7c2Vuc29yRmFsbG8oJ3R1cmJpZGV6JykgJiYgKFxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtYW1iZXItNTAwXCIgdGl0bGU9XCJWYWxvciBlc3RpbWFkbyBwb3IgZmFsbGEgZGUgc2Vuc29yXCI+fmVzdC48L3NwYW4+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcm91bmRlZC1mdWxsIHB4LTIgcHktMC41IHRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgJHtcbiAgICAgICAgICAgICAgc2Vuc29yRmFsbG8oJ3R1cmJpZGV6JylcbiAgICAgICAgICAgICAgICA/ICdiZy1hbWJlci01MCBkYXJrOmJnLWFtYmVyLTkwMC8yMCB0ZXh0LWFtYmVyLTYwMCBkYXJrOnRleHQtYW1iZXItNDAwJ1xuICAgICAgICAgICAgICAgIDogdHVyYmlkaXR5U3RhdGUodmFsb3JTZW5zb3IoJ3R1cmJpZGV6JykpID09PSAnbm9ybWFsJ1xuICAgICAgICAgICAgICAgID8gJ2JnLWVtZXJhbGQtNTAgZGFyazpiZy1lbWVyYWxkLTkwMC8yMCB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCdcbiAgICAgICAgICAgICAgICA6ICdiZy1yZWQtNTAgZGFyazpiZy1yZWQtOTAwLzIwIHRleHQtcmVkLTYwMCBkYXJrOnRleHQtcmVkLTQwMCdcbiAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAge3NlbnNvckZhbGxvKCd0dXJiaWRleicpID8gJ0VzdGltYWRvJyA6IHR1cmJpZGl0eVN0YXRlKHZhbG9yU2Vuc29yKCd0dXJiaWRleicpKSA9PT0gJ25vcm1hbCcgPyAnTGltcGlvJyA6ICdBbGVydGEnfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogVGVtcGVyYXR1cmEgQ2FyZCAqL31cbiAgICAgICAgPGRpdiBcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZFNlbnNvcigndGVtcGVyYXR1cmEnKX1cbiAgICAgICAgICBjbGFzc05hbWU9e2BjdXJzb3ItcG9pbnRlciByb3VuZGVkLTJ4bCBib3JkZXIgcC01IHNoYWRvdy1zbSB0cmFuc2l0aW9uLWFsbCAke3NlbGVjdGVkU2Vuc29yID09PSAndGVtcGVyYXR1cmEnID8gJ2JvcmRlci1lbWVyYWxkLTUwMCByaW5nLTIgcmluZy1lbWVyYWxkLTUwMC8yMCBiZy1lbWVyYWxkLTUwLzIwIGRhcms6YmctZW1lcmFsZC05MDAvMTAnIDogJ2JvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIGJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIGhvdmVyOmJvcmRlci1lbWVyYWxkLTMwMCd9YH1cbiAgICAgICAgPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyBmbGV4IGgtMTAgdy0xMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1sZyBiZy1lbWVyYWxkLTUwIGRhcms6YmctZW1lcmFsZC05MDAvMjAgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDBcIj5cbiAgICAgICAgICAgIDxzdmcgd2lkdGg9XCIyMFwiIGhlaWdodD1cIjIwXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiPlxuICAgICAgICAgICAgICA8cGF0aCBkPVwiTTE0IDE0Ljc2VjMuNUMxNCAyLjY3MTU3IDEzLjMyODQgMiAxMi41IDJDMTEuNjcxNiAyIDExIDIuNjcxNTcgMTEgMy41VjE0Ljc2QzkuMjA5MTQgMTUuNjMxOCA4IDE3LjUyNTUgOCAxOS41QzggMjIuNTM3NiAxMC4wMTQ3IDI0IDEyLjUgMjRDMTQuOTg1MyAyNCAxNyAyMi41Mzc2IDE3IDE5LjVDMTcgMTcuNTI1NSAxNS43OTA5IDE1LjYzMTggMTQgMTQuNzZaXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIyXCIgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiLz5cbiAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1lbmQganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5TZW5zb3IgVGVtcGVyYXR1cmE8L3NwYW4+XG4gICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJtdC0xIHRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGUgZmxleCBpdGVtcy1iYXNlbGluZSBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAge2Zvcm1hdFZhbHVlKHZhbG9yU2Vuc29yKCd0ZW1wZXJhdHVyYScpKX0gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+wrBDPC9zcGFuPlxuICAgICAgICAgICAgICAgIHtzZW5zb3JGYWxsbygndGVtcGVyYXR1cmEnKSAmJiAoXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1hbWJlci01MDBcIiB0aXRsZT1cIlZhbG9yIGVzdGltYWRvIHBvciBmYWxsYSBkZSBzZW5zb3JcIj5+ZXN0Ljwvc3Bhbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB7c2Vuc29yRmFsbG8oJ3RlbXBlcmF0dXJhJykgJiYgKFxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyb3VuZGVkLWZ1bGwgYmctYW1iZXItNTAgZGFyazpiZy1hbWJlci05MDAvMjAgcHgtMiBweS0wLjUgdGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWFtYmVyLTYwMCBkYXJrOnRleHQtYW1iZXItNDAwXCI+XG4gICAgICAgICAgICAgICAgRXN0aW1hZG9cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIEFmb3JvIE1hbnVhbCBDYXJkICovfVxuICAgICAgICA8ZGl2IFxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0TW9kYWxBZm9ybygnbWFudWFsJyk7IHNldE1vZGFsUGFnZSgxKTsgfX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCBjdXJzb3ItcG9pbnRlciByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gcC01IHNoYWRvdy1zbSB0cmFuc2l0aW9uLWFsbCBob3Zlcjpib3JkZXItaW5kaWdvLTQwMCBkYXJrOmhvdmVyOmJvcmRlci1pbmRpZ28tNTAwIGhvdmVyOnNoYWRvdy1tZFwiXG4gICAgICAgICAgdGl0bGU9XCJIYXogY2xpYyBwYXJhIHZlciB0b2RvcyBsb3MgcmVnaXN0cm9zIGRlIHRhcXVpbGxhIGRlbCBkw61hXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyBmbGV4IGgtMTAgdy0xMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1sZyBiZy1pbmRpZ28tNTAgZGFyazpiZy1pbmRpZ28tOTAwLzIwIHRleHQtaW5kaWdvLTYwMCBkYXJrOnRleHQtaW5kaWdvLTQwMCBncm91cC1ob3ZlcjpzY2FsZS0xMDUgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIj5cbiAgICAgICAgICAgIDxzdmcgd2lkdGg9XCIyMFwiIGhlaWdodD1cIjIwXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiPlxuICAgICAgICAgICAgICA8cGF0aCBkPVwiTTE3IDIxVjE5QzE3IDE3LjkzOTEgMTYuNTc4NiAxNi45MjE3IDE1LjgyODQgMTYuMTcxNkMxNS4wNzgzIDE1LjQyMTQgMTQuMDYwOSAxNSAxMyAxNUg1QzMuOTM5MTMgMTUgMi45MjE3MiAxNS40MjE0IDIuMTcxNTcgMTYuMTcxNkMxLjQyMTQzIDE2LjkyMTcgMSAxNy45MzkxIDEgMTlWMjFcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjJcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIvPlxuICAgICAgICAgICAgICA8cGF0aCBkPVwiTTkgMTFDMTEuMjA5MSAxMSAxMyA5LjIwOTE0IDEzIDdDMTMgNC43OTA4NiAxMS4yMDkxIDMgOSAzQzYuNzkwODYgMyA1IDQuNzkwODYgNSA3QzUgOS4yMDkxNCA2Ljc5MDg2IDExIDkgMTFaXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIyXCIgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiLz5cbiAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1lbmQganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5BZm9ybyBNYW51YWw8L3NwYW4+XG4gICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJtdC0xIHRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICB7c2Vuc29yRGF0YT8uYWZvcm9fbWFudWFsID8/IHNlbnNvckRhdGE/LnBlcnNvbmFzX2hveSA/PyBzdW1tYXJ5Py50b3RhbF9wZXJzb25hcyA/PyAnMCd9XG4gICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJvdW5kZWQtZnVsbCBiZy1ibHVlLTUwIGRhcms6YmctYmx1ZS05MDAvMjAgcHgtMiBweS0wLjUgdGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsdWUtNjAwIGRhcms6dGV4dC1ibHVlLTQwMFwiPlxuICAgICAgICAgICAgICBUYXF1aWxsYVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gcHQtMi41IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWluZGlnby02MDAgZGFyazp0ZXh0LWluZGlnby00MDAgZ3JvdXAtaG92ZXI6dGV4dC1pbmRpZ28tNzAwIGRhcms6Z3JvdXAtaG92ZXI6dGV4dC1pbmRpZ28tMzAwXCI+XG4gICAgICAgICAgICA8c3Bhbj5WZXIgcmVnaXN0cm9zICh7cmF3TWFudWFsUmVhZGluZ3MubGVuZ3RofSk8L3NwYW4+XG4gICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRyYW5zaXRpb24tdHJhbnNmb3JtIGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTAuNVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyLjVcIiBkPVwiTTkgNWw3IDctNyA3XCIgLz5cbiAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQWZvcm8gQ8OhbWFyYSBDYXJkICovfVxuICAgICAgICA8ZGl2IFxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0TW9kYWxBZm9ybygnY2FtYXJhJyk7IHNldE1vZGFsUGFnZSgxKTsgfX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCBjdXJzb3ItcG9pbnRlciByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gcC01IHNoYWRvdy1zbSB0cmFuc2l0aW9uLWFsbCBob3Zlcjpib3JkZXItcHVycGxlLTQwMCBkYXJrOmhvdmVyOmJvcmRlci1wdXJwbGUtNTAwIGhvdmVyOnNoYWRvdy1tZFwiXG4gICAgICAgICAgdGl0bGU9XCJIYXogY2xpYyBwYXJhIHZlciB0b2RvcyBsb3MgcmVnaXN0cm9zIGRlIGxhIGPDoW1hcmEgZGVsIGTDrWFcIlxuICAgICAgICA+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIGZsZXggaC0xMCB3LTEwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWxnIGJnLXB1cnBsZS01MCBkYXJrOmJnLXB1cnBsZS05MDAvMjAgdGV4dC1wdXJwbGUtNjAwIGRhcms6dGV4dC1wdXJwbGUtNDAwIGdyb3VwLWhvdmVyOnNjYWxlLTEwNSB0cmFuc2l0aW9uLXRyYW5zZm9ybVwiPlxuICAgICAgICAgICAgPHN2ZyB3aWR0aD1cIjIwXCIgaGVpZ2h0PVwiMjBcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cIm5vbmVcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+XG4gICAgICAgICAgICAgIDxwYXRoIGQ9XCJNMTUgMTBMMjEgNlYxOEwxNSAxNE00IDE4SDEzQzE0LjEwNDYgMTggMTUgMTcuMTA0NiAxNSAxNlY4QzE1IDYuODk1NDMgMTQuMTA0NiA2IDEzIDZINEMyLjg5NTQzIDYgMiA2Ljg5NTQzIDIgOFYxNkMyIDE3LjEwNDYgMi44OTU0MyAxOCA0IDE4WlwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMlwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIi8+XG4gICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtZW5kIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+QWZvcm8gQ8OhbWFyYTwvc3Bhbj5cbiAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cIm10LTEgdGV4dC0yeGwgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgIHtzZW5zb3JEYXRhPy5hZm9yb19jYW1hcmEgPz8gJzAnfVxuICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyb3VuZGVkLWZ1bGwgYmctcHVycGxlLTUwIGRhcms6YmctcHVycGxlLTkwMC8yMCBweC0yIHB5LTAuNSB0ZXh0LVsxMHB4XSBmb250LXNlbWlib2xkIHRleHQtcHVycGxlLTYwMCBkYXJrOnRleHQtcHVycGxlLTQwMFwiPlxuICAgICAgICAgICAgICBDw6FtYXJhIElBXG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBwdC0yLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtcHVycGxlLTYwMCBkYXJrOnRleHQtcHVycGxlLTQwMCBncm91cC1ob3Zlcjp0ZXh0LXB1cnBsZS03MDAgZGFyazpncm91cC1ob3Zlcjp0ZXh0LXB1cnBsZS0zMDBcIj5cbiAgICAgICAgICAgIDxzcGFuPlZlciByZWdpc3Ryb3MgKHtyYXdDYW1lcmFSZWFkaW5ncy5sZW5ndGh9KTwvc3Bhbj5cbiAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZ3JvdXAtaG92ZXI6dHJhbnNsYXRlLXgtMC41XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjIuNVwiIGQ9XCJNOSA1bDcgNy03IDdcIiAvPlxuICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFBSRURJQ0NJw5NOIExTVE0gREUgRE9TSUZJQ0FDScOTTiAqL31cbiAgICAgIDxQcmVkaWNjaW9uUGFuZWxcbiAgICAgICAgcHJlZGljY2lvbj17c2Vuc29yRGF0YT8ucHJlZGljY2lvbn1cbiAgICAgICAgZGV0YWxsZT17c2Vuc29yRGF0YT8ucHJlZGljY2lvbl9kZXRhbGxlfVxuICAgICAgICBkb3Npc0FwbGljYWRhcz17c2Vuc29yRGF0YT8uZG9zaXNfYXBsaWNhZGFzfVxuICAgICAgICBvblByZWRlY2lyPXtwcmVkZWNpckFob3JhfVxuICAgICAgLz5cblxuICAgICAgey8qIEJPVE9ORVMgREUgU0VMRUNDScOTTiBERSBTRU5TT1IgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gcC00IHNoYWRvdy1zbVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgbXItMlwiPlZlciBHcsOhZmljbyBkZTo8L3NwYW4+XG4gICAgICAgICAgXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRTZW5zb3IoJ3BoJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2Byb3VuZGVkLXhsIHB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgJHtzZWxlY3RlZFNlbnNvciA9PT0gJ3BoJyA/ICdiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdy1tZCcgOiAnYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgaG92ZXI6Ymctc2xhdGUtMjAwJ31gfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIPCfkqcgcEhcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICBcbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZFNlbnNvcigndHVyYmlkZXonKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHJvdW5kZWQteGwgcHgtNCBweS0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCAke3NlbGVjdGVkU2Vuc29yID09PSAndHVyYmlkZXonID8gJ2JnLW9yYW5nZS02MDAgdGV4dC13aGl0ZSBzaGFkb3ctbWQnIDogJ2JnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGhvdmVyOmJnLXNsYXRlLTIwMCd9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICDwn4yKIFR1cmJpZGV6XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRTZW5zb3IoJ3RlbXBlcmF0dXJhJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2Byb3VuZGVkLXhsIHB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgJHtzZWxlY3RlZFNlbnNvciA9PT0gJ3RlbXBlcmF0dXJhJyA/ICdiZy1lbWVyYWxkLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdy1tZCcgOiAnYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgaG92ZXI6Ymctc2xhdGUtMjAwJ31gfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIPCfjKHvuI8gVGVtcGVyYXR1cmFcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dSZXBvcnRNb2RhbCh0cnVlKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTYwMCB0by1pbmRpZ28tNjAwIGhvdmVyOmZyb20tYmx1ZS03MDAgaG92ZXI6dG8taW5kaWdvLTcwMCB0ZXh0LXdoaXRlIHB4LTMuNSBweS0xLjUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCBzaGFkb3ctc20gaG92ZXI6c2hhZG93IGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTEyIDEwdjZtMCAwbC0zLTNtMyAzbDMtM20yIDhIN2EyIDIgMCAwMS0yLTJWNWEyIDIgMCAwMTItMmg1LjU4NmExIDEgMCAwMS43MDcuMjkzbDUuNDE0IDUuNDE0YTEgMSAwIDAxLjI5My43MDdWMTlhMiAyIDAgMDEtMiAyelwiIC8+XG4gICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgIDxzcGFuPkdlbmVyYXIgUmVwb3J0ZSAoUERGKTwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcm91bmRlZC1mdWxsIGJnLWVtZXJhbGQtNTAgZGFyazpiZy1lbWVyYWxkLTkwMC8yMCBweC0zIHB5LTEgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoLTIgdy0yIHJvdW5kZWQtZnVsbCBiZy1lbWVyYWxkLTUwMCBhbmltYXRlLXB1bHNlXCI+PC9zcGFuPiBMZWN0dXJhcyBlbiB0aWVtcG8gcmVhbFxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFNFQ0NJw5NOIERFIEdSw4FGSUNPIElORElWSURVQUwgUE9SIFNFTlNPUiAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBncmlkIGdyaWQtY29scy0xIGdhcC02IHhsOmdyaWQtY29scy0zXCI+XG4gICAgICAgIFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBiZy13aGl0ZSBkYXJrOmJnLVsjMjQzMDNGXSBwLTcgc2hhZG93LXNtIHhsOmNvbC1zcGFuLTJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTYgZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMlwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIHtzZW5zb3JDb25maWdbc2VsZWN0ZWRTZW5zb3JdPy50aXRsZX1cbiAgICAgICAgICAgICAgICB7aGF5UHJvbm9zdGljbyAmJiAoXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyb3VuZGVkLWZ1bGwgYmctdmlvbGV0LTUwIGRhcms6YmctdmlvbGV0LTkwMC8yMCBweC0zIHB5LTEgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtdmlvbGV0LTYwMCBkYXJrOnRleHQtdmlvbGV0LTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAtLSBQcm9uw7NzdGljbyBhIDIwOjAwXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAge2BIaXN0b3JpYWwgcmVhbCAobMOtbmVhIGNvbnRpbnVhKSB5IHRlbmRlbmNpYSBlc3RpbWFkYSBoYXN0YSBlbCBjaWVycmUgKGzDrW5lYSBwdW50ZWFkYSlgfVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC04MCB3LWZ1bGxcIj5cbiAgICAgICAgICAgIHtjaGFydENvbWJpbmFkby5sZW5ndGggPiAwID8gKFxuICAgICAgICAgICAgICA8UmVzcG9uc2l2ZUNvbnRhaW5lciB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9XCIxMDAlXCI+XG4gICAgICAgICAgICAgICAgPENvbXBvc2VkQ2hhcnQgZGF0YT17Y2hhcnRDb21iaW5hZG99IG1hcmdpbj17eyB0b3A6IDE1LCByaWdodDogMzAsIGxlZnQ6IDAsIGJvdHRvbTogNSB9fT5cbiAgICAgICAgICAgICAgICAgIDxDYXJ0ZXNpYW5HcmlkIHN0cm9rZURhc2hhcnJheT1cIjMgM1wiIHN0cm9rZT1cIiNlMmU4ZjBcIiBvcGFjaXR5PXswLjZ9IC8+XG4gICAgICAgICAgICAgICAgICA8WEF4aXMgZGF0YUtleT1cImhvcmFcIiBzdHJva2U9XCIjNjQ3NDhiXCIgZm9udFNpemU9ezExfSAvPlxuICAgICAgICAgICAgICAgICAgPFlBeGlzIFxuICAgICAgICAgICAgICAgICAgICBkb21haW49e1soZGF0YU1pbikgPT4gTWF0aC5mbG9vcigoZGF0YU1pbiAtIDAuMikgKiAxMCkgLyAxMCwgKGRhdGFNYXgpID0+IE1hdGguY2VpbCgoZGF0YU1heCArIDAuMikgKiAxMCkgLyAxMF19IFxuICAgICAgICAgICAgICAgICAgICBzdHJva2U9e3NlbnNvckNvbmZpZ1tzZWxlY3RlZFNlbnNvcl0uY29sb3J9IFxuICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT17MTF9IFxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDxUb29sdGlwIGNvbnRlbnRTdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6ICcjMGYxNzJhJywgYm9yZGVyUmFkaXVzOiAnOHB4JywgYm9yZGVyOiAnbm9uZScsIGNvbG9yOiAnI2ZmZicgfX0gLz5cbiAgICAgICAgICAgICAgICAgIDxMZWdlbmQgLz5cbiAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAge3NlbnNvckNvbmZpZ1tzZWxlY3RlZFNlbnNvcl0ubWluT3B0ICYmIChcbiAgICAgICAgICAgICAgICAgICAgPFJlZmVyZW5jZUxpbmUgeT17c2Vuc29yQ29uZmlnW3NlbGVjdGVkU2Vuc29yXS5taW5PcHR9IGxhYmVsPXt7IHZhbHVlOiAnTWluIMOTcHRpbW8gKDcuMCknLCBmaWxsOiAnIzEwYjk4MScsIGZvbnRTaXplOiAxMCB9fSBzdHJva2U9XCIjMTBiOTgxXCIgc3Ryb2tlRGFzaGFycmF5PVwiNCA0XCIgLz5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICB7c2Vuc29yQ29uZmlnW3NlbGVjdGVkU2Vuc29yXS5tYXhPcHQgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8UmVmZXJlbmNlTGluZSB5PXtzZW5zb3JDb25maWdbc2VsZWN0ZWRTZW5zb3JdLm1heE9wdH0gbGFiZWw9e3sgdmFsdWU6ICdNYXggw5NwdGltbyAoNy42KScsIGZpbGw6ICcjMTBiOTgxJywgZm9udFNpemU6IDEwIH19IHN0cm9rZT1cIiMxMGI5ODFcIiBzdHJva2VEYXNoYXJyYXk9XCI0IDRcIiAvPlxuICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgey8qIEJhbmRhIGRlIGNvbmZpYW56YSBwYXJhIGVsIHByb27Ds3N0aWNvICovfVxuICAgICAgICAgICAgICAgICAgPEFyZWFcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImxpbmVhclwiXG4gICAgICAgICAgICAgICAgICAgIGRhdGFLZXk9XCJSYW5nb1wiXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cIm5vbmVcIlxuICAgICAgICAgICAgICAgICAgICBmaWxsPXtzZW5zb3JDb25maWdbc2VsZWN0ZWRTZW5zb3JdLmNvbG9yfVxuICAgICAgICAgICAgICAgICAgICBmaWxsT3BhY2l0eT17MC4xMn1cbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cIlJhbmdvIGRlIGNvbmZpYW56YSAoOTUlKVwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICB7LyogTMOtbmVhIHJlYWwgKi99XG4gICAgICAgICAgICAgICAgICA8TGluZSBcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImxpbmVhclwiIFxuICAgICAgICAgICAgICAgICAgICBuYW1lPXtgJHtzZW5zb3JDb25maWdbc2VsZWN0ZWRTZW5zb3JdLmRhdGFLZXl9IFJlYWxgfVxuICAgICAgICAgICAgICAgICAgICBkYXRhS2V5PXtzZW5zb3JDb25maWdbc2VsZWN0ZWRTZW5zb3JdLmRhdGFLZXl9IFxuICAgICAgICAgICAgICAgICAgICBzdHJva2U9e3NlbnNvckNvbmZpZ1tzZWxlY3RlZFNlbnNvcl0uY29sb3J9IFxuICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD17M30gXG4gICAgICAgICAgICAgICAgICAgIGRvdD17eyByOiA0LCBmaWxsOiBzZW5zb3JDb25maWdbc2VsZWN0ZWRTZW5zb3JdLmNvbG9yLCBzdHJva2VXaWR0aDogMS41LCBzdHJva2U6ICcjZmZmJyB9fVxuICAgICAgICAgICAgICAgICAgICBhY3RpdmVEb3Q9e3sgcjogNiB9fVxuICAgICAgICAgICAgICAgICAgICBjb25uZWN0TnVsbHM9e2ZhbHNlfVxuICAgICAgICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgICAgICAgey8qIEzDrW5lYSBwdW50ZWFkYSBkZSBwcm9uw7NzdGljbyAqL31cbiAgICAgICAgICAgICAgICAgIDxMaW5lIFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibGluZWFyXCIgXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9e2Ake3NlbnNvckNvbmZpZ1tzZWxlY3RlZFNlbnNvcl0uZGF0YUtleX0gUHJvbm9zdGljYWRvYH1cbiAgICAgICAgICAgICAgICAgICAgZGF0YUtleT1cIlByb25vc3RpY29cIiBcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPXtzZW5zb3JDb25maWdbc2VsZWN0ZWRTZW5zb3JdLmNvbG9yfSBcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezIuNX0gXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZURhc2hhcnJheT1cIjUgNVwiXG4gICAgICAgICAgICAgICAgICAgIGRvdD17eyByOiAzLCBmaWxsOiAnI2ZmZicsIHN0cm9rZVdpZHRoOiAyLCBzdHJva2U6IHNlbnNvckNvbmZpZ1tzZWxlY3RlZFNlbnNvcl0uY29sb3IgfX1cbiAgICAgICAgICAgICAgICAgICAgYWN0aXZlRG90PXt7IHI6IDUgfX1cbiAgICAgICAgICAgICAgICAgICAgY29ubmVjdE51bGxzPXt0cnVlfVxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L0NvbXBvc2VkQ2hhcnQ+XG4gICAgICAgICAgICAgIDwvUmVzcG9uc2l2ZUNvbnRhaW5lcj5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLWZ1bGwgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtc20gdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICBFc3BlcmFuZG8gcHJpbWVyYXMgbGVjdHVyYXMgZGVsIHNlbnNvci4uLlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBBbGVydGFzIHkgQWNjaW9uZXMgZW4gVml2byAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gcC03IHNoYWRvdy1zbSB4bDpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICBBbGVydGFzIGVuIFZpdm9cbiAgICAgICAgICAgICAge3NlbnNvckRhdGE/LmFsZXJ0YXM/LnNvbWUoYSA9PiBhLnRpcG8gPT09ICdhY3Rpb24nKSAmJiAoXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBoLTIuNSB3LTIuNSByb3VuZGVkLWZ1bGwgYmctYmx1ZS01MDAgYW5pbWF0ZS1waW5nXCI+PC9zcGFuPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtNFwiPlxuICAgICAgICAgICAge3NlbnNvckRhdGE/LmFsZXJ0YXM/Lmxlbmd0aCA/IHNlbnNvckRhdGEuYWxlcnRhcy5tYXAoKGFsZXJ0LCBpbmRleCkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBlc0FjY2lvbiA9IGFsZXJ0LnRpcG8gPT09ICdhY3Rpb24nO1xuICAgICAgICAgICAgICBjb25zdCBlc09rID0gYWxlcnQudGlwbyA9PT0gJ29rJztcbiAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPGRpdiBcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggZmxleC1jb2wgZ2FwLTMgcm91bmRlZC1sZyBib3JkZXIgcC00ICR7XG4gICAgICAgICAgICAgICAgICAgIGVzT2sgPyAnYm9yZGVyLWVtZXJhbGQtMTAwIGRhcms6Ym9yZGVyLWVtZXJhbGQtOTAwLzMwIGJnLWVtZXJhbGQtNTAvNTAgZGFyazpiZy1lbWVyYWxkLTkwMC8xMCcgOiBcbiAgICAgICAgICAgICAgICAgICAgZXNBY2Npb24gPyAnYm9yZGVyLWJsdWUtMjAwIGRhcms6Ym9yZGVyLWJsdWUtOTAwLzUwIGJnLWJsdWUtNTAgZGFyazpiZy1ibHVlLTkwMC8yMCBzaGFkb3ctc20nIDogXG4gICAgICAgICAgICAgICAgICAgICdib3JkZXItcmVkLTEwMCBkYXJrOmJvcmRlci1yZWQtOTAwLzMwIGJnLXJlZC01MC81MCBkYXJrOmJnLXJlZC05MDAvMTAnXG4gICAgICAgICAgICAgICAgICB9YH0gXG4gICAgICAgICAgICAgICAgICBrZXk9e2luZGV4fVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGZsZXggaC04IHctOCBmbGV4LXNocmluay0wIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGwgJHtcbiAgICAgICAgICAgICAgICAgICAgICBlc09rID8gJ2JnLWVtZXJhbGQtMTAwIGRhcms6YmctZW1lcmFsZC05MDAvNTAgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAnIDogXG4gICAgICAgICAgICAgICAgICAgICAgZXNBY2Npb24gPyAnYmctYmx1ZS0xMDAgZGFyazpiZy1ibHVlLTkwMC81MCB0ZXh0LWJsdWUtNjAwIGRhcms6dGV4dC1ibHVlLTQwMCcgOiBcbiAgICAgICAgICAgICAgICAgICAgICAnYmctcmVkLTEwMCBkYXJrOmJnLXJlZC05MDAvNTAgdGV4dC1yZWQtNjAwIGRhcms6dGV4dC1yZWQtNDAwJ1xuICAgICAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgICAge2VzT2sgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNSBoLTVcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+PHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNNSAxM2w0IDRMMTkgN1wiPjwvcGF0aD48L3N2Zz5cbiAgICAgICAgICAgICAgICAgICAgICApIDogZXNBY2Npb24gPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNSBoLTVcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+PHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMTMgMTBWM0w0IDE0aDd2N2w5LTExaC03elwiPjwvcGF0aD48L3N2Zz5cbiAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTUgaC01XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiPjxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTEyIDl2Mm0wIDRoLjAxbS02LjkzOCA0aDEzLjg1NmMxLjU0IDAgMi41MDItMS42NjcgMS43MzItM0wxMy43MzIgNGMtLjc3LTEuMzMzLTIuNjk0LTEuMzMzLTMuNDY0IDBMMy4zNCAxNmMtLjc3IDEuMzMzLjE5MiAzIDEuNzMyIDN6XCI+PC9wYXRoPjwvc3ZnPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9e2B0ZXh0LXNtIGZvbnQtbWVkaXVtIGxlYWRpbmctcmVsYXhlZCAke1xuICAgICAgICAgICAgICAgICAgICAgIGVzT2sgPyAndGV4dC1lbWVyYWxkLTgwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAnIDogXG4gICAgICAgICAgICAgICAgICAgICAgZXNBY2Npb24gPyAndGV4dC1ibHVlLTkwMCBkYXJrOnRleHQtYmx1ZS0zMDAnIDogXG4gICAgICAgICAgICAgICAgICAgICAgJ3RleHQtcmVkLTgwMCBkYXJrOnRleHQtcmVkLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICAgICAgICAgIHthbGVydC5tc2d9XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICB7ZXNBY2Npb24gJiYgKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17YXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYXdhaXQgbW9uaXRvcmluZ0FwaS5wb3N0KCcvYXBpL2Rvc2lmaWNhY2lvbl9wYXJjaWFsJywgeyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWltaWNvOiBhbGVydC5xdWltaWNvLCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYW50aWRhZF9nOiBhbGVydC5jYW50aWRhZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGF3YWl0IGxvYWRTZW5zb3JEYXRhKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzaG93RXJyb3IpIHNob3dFcnJvcignRXJyb3IgYWwgcmVnaXN0cmFyIGxhIG1pY3JvLWRvc2lzJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0yIGZsZXggdy1mdWxsIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiByb3VuZGVkLXhsIGJnLWJsdWUtNjAwIHB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBzaGFkb3ctbWQgdHJhbnNpdGlvbi1hbGwgaG92ZXI6LXRyYW5zbGF0ZS15LTAuNSBob3ZlcjpiZy1ibHVlLTcwMCBob3ZlcjpzaGFkb3ctbGcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOnJpbmctb2Zmc2V0LTJcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+QXBsaWNhciBEb3NpcyAoe2FsZXJ0LmNhbnRpZGFkfWcpPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzdmcgd2lkdGg9XCIxNlwiIGhlaWdodD1cIjE2XCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD1cIk01IDEyaDE0TTEyIDVsNyA3LTcgN1wiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMlwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIi8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pIDogKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItWyMzMTNENEFdIGJnLXNsYXRlLTUwIGRhcms6YmctWyMxQTIyMkNdIHAtNFwiPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlNpbiBhbGVydGFzIGhveS48L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogVEFCTEEgQ09OIFBBR0lOQUNJw5NOIERFIDEwIFJFR0lTVFJPUyBZIFNFTEVDVE9SIERFIFZJU1RBICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIGJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIHAtNyBzaGFkb3ctc21cIj5cbiAgICAgICAgICBcbiAgICAgICAgICB7LyogU0VMRUNUT1IgREUgUEVTVEHDkUFTIERFIEhJU1RPUklBTCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTYgZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNCBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBwYi01XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRUYWJsZVRhYignc2Vuc29yZXMnKTsgc2V0Q3VycmVudFBhZ2UoMSk7IH19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcm91bmRlZC14bCBweC00IHB5LTIuNSB0ZXh0LXNtIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgdGFibGVUYWIgPT09ICdzZW5zb3JlcydcbiAgICAgICAgICAgICAgICAgICAgPyAnYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBzaGFkb3ctbWQgc2hhZG93LWJsdWUtNTAwLzIwJ1xuICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBob3ZlcjpiZy1zbGF0ZS0yMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS03MDAnXG4gICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8c3Bhbj7wn5KnIFNlbnNvcmVzIEbDrXNpY29zPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHJvdW5kZWQtZnVsbCBweC0yIHB5LTAuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgJHt0YWJsZVRhYiA9PT0gJ3NlbnNvcmVzJyA/ICdiZy13aGl0ZS8yMCB0ZXh0LXdoaXRlJyA6ICdiZy1zbGF0ZS0yMDAgZGFyazpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCd9YH0+XG4gICAgICAgICAgICAgICAgICB7c29ydGVkUmVhZGluZ3MubGVuZ3RofVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0VGFibGVUYWIoJ21hbnVhbCcpOyBzZXRDdXJyZW50UGFnZSgxKTsgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLXhsIHB4LTQgcHktMi41IHRleHQtc20gZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgICB0YWJsZVRhYiA9PT0gJ21hbnVhbCdcbiAgICAgICAgICAgICAgICAgICAgPyAnYmctaW5kaWdvLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdy1tZCBzaGFkb3ctaW5kaWdvLTUwMC8yMCdcbiAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgaG92ZXI6Ymctc2xhdGUtMjAwIGRhcms6aG92ZXI6Ymctc2xhdGUtNzAwJ1xuICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPHNwYW4+8J+RpSBBZm9ybyBNYW51YWwgKFRhcXVpbGxhKTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2Byb3VuZGVkLWZ1bGwgcHgtMiBweS0wLjUgdGV4dC14cyBmb250LXNlbWlib2xkICR7dGFibGVUYWIgPT09ICdtYW51YWwnID8gJ2JnLXdoaXRlLzIwIHRleHQtd2hpdGUnIDogJ2JnLXNsYXRlLTIwMCBkYXJrOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwJ31gfT5cbiAgICAgICAgICAgICAgICAgIHtzb3J0ZWRNYW51YWxSZWFkaW5ncy5sZW5ndGh9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRUYWJsZVRhYignY2FtYXJhJyk7IHNldEN1cnJlbnRQYWdlKDEpOyB9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHJvdW5kZWQteGwgcHgtNCBweS0yLjUgdGV4dC1zbSBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgIHRhYmxlVGFiID09PSAnY2FtYXJhJ1xuICAgICAgICAgICAgICAgICAgICA/ICdiZy1wdXJwbGUtNjAwIHRleHQtd2hpdGUgc2hhZG93LW1kIHNoYWRvdy1wdXJwbGUtNTAwLzIwJ1xuICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBob3ZlcjpiZy1zbGF0ZS0yMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS03MDAnXG4gICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8c3Bhbj7wn5O3IEFmb3JvIEPDoW1hcmEgKElBKTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2Byb3VuZGVkLWZ1bGwgcHgtMiBweS0wLjUgdGV4dC14cyBmb250LXNlbWlib2xkICR7dGFibGVUYWIgPT09ICdjYW1hcmEnID8gJ2JnLXdoaXRlLzIwIHRleHQtd2hpdGUnIDogJ2JnLXNsYXRlLTIwMCBkYXJrOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwJ31gfT5cbiAgICAgICAgICAgICAgICAgIHtzb3J0ZWRDYW1lcmFSZWFkaW5ncy5sZW5ndGh9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1JlcG9ydE1vZGFsKHRydWUpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHJvdW5kZWQteGwgcHgtNCBweS0yLjUgdGV4dC1zbSBmb250LWJvbGQgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNjAwIHRvLWluZGlnby02MDAgaG92ZXI6ZnJvbS1ibHVlLTcwMCBob3Zlcjp0by1pbmRpZ28tNzAwIHRleHQtd2hpdGUgc2hhZG93LW1kIHNoYWRvdy1ibHVlLTUwMC8yMCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8c3Bhbj7wn5OKIEdlbmVyYXIgUmVwb3J0ZSAvIEV4cG9ydGFyIFBERjwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEJPVMOTTiBSw4FQSURPIFBBUkEgQUJSSVIgRUwgTU9EQUwgQ09NUExFVE8gKi99XG4gICAgICAgICAgICB7KHRhYmxlVGFiID09PSAnbWFudWFsJyB8fCB0YWJsZVRhYiA9PT0gJ2NhbWFyYScpICYmIChcbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0TW9kYWxBZm9ybyh0YWJsZVRhYik7IHNldE1vZGFsUGFnZSgxKTsgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBweC0zLjUgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCB0cmFuc2l0aW9uLWFsbCBzaGFkb3ctc21cIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYmx1ZS01MDBcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTQgOFY0bTAgMGg0TTQgNGw1IDVtMTEtMVY0bTAgMGgtNG00IDBsLTUgNU00IDE2djRtMCAwaDRtLTQgMGw1LTVtMTEgNWwtNS01bTUgNXYtNG0wIDRoLTRcIiAvPlxuICAgICAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgICAgIDxzcGFuPkFicmlyIGVuIFZpc3RhIENvbXBsZXRhPC9zcGFuPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTYgZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgIHt0YWJsZVRhYiA9PT0gJ3NlbnNvcmVzJyAmJiAnSGlzdG9yaWFsIGRlIExlY3R1cmFzIFJlZ2lzdHJhZGFzIGRlIFNlbnNvcmVzJ31cbiAgICAgICAgICAgICAgICB7dGFibGVUYWIgPT09ICdtYW51YWwnICYmICdIaXN0b3JpYWwgZGUgSW5ncmVzb3MgUmVnaXN0cmFkb3MgZW4gVGFxdWlsbGEnfVxuICAgICAgICAgICAgICAgIHt0YWJsZVRhYiA9PT0gJ2NhbWFyYScgJiYgJ0hpc3RvcmlhbCBkZSBDb250ZW8gUmVnaXN0cmFkbyBwb3IgQ8OhbWFyYSBJbnRlbGlnZW50ZSd9XG4gICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgIE1vc3RyYW5kbyB7Y3VycmVudFRhYmxlTGlzdC5sZW5ndGggPiAwID8gKGN1cnJlbnRQYWdlIC0gMSkgKiBpdGVtc1BlclBhZ2UgKyAxIDogMH0gLSB7TWF0aC5taW4oY3VycmVudFBhZ2UgKiBpdGVtc1BlclBhZ2UsIGN1cnJlbnRUYWJsZUxpc3QubGVuZ3RoKX0gZGUge2N1cnJlbnRUYWJsZUxpc3QubGVuZ3RofSByZWdpc3Ryb3MgZGVsIGTDrWFcbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBDT05UUk9MRVMgREUgUEFHSU5BQ0nDk04gQ09OIEZMRUNIQVMgKi99XG4gICAgICAgICAgICB7Y3VycmVudFRhYmxlTGlzdC5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEN1cnJlbnRQYWdlKChwcmV2KSA9PiBNYXRoLm1heChwcmV2IC0gMSwgMSkpfVxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2N1cnJlbnRQYWdlID09PSAxfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBoLTkgdy05IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIHRyYW5zaXRpb24tYWxsIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCBkaXNhYmxlZDpvcGFjaXR5LTQwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZFwiXG4gICAgICAgICAgICAgICAgICB0aXRsZT1cIlDDoWdpbmEgYW50ZXJpb3JcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxzdmcgd2lkdGg9XCIxOFwiIGhlaWdodD1cIjE4XCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiPlxuICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPVwiTTE1IDE5TDggMTJMMTUgNVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMlwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIi8+XG4gICAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICBQw6FnaW5hIHtjdXJyZW50UGFnZX0gZGUge3RvdGFsUGFnZXN9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Q3VycmVudFBhZ2UoKHByZXYpID0+IE1hdGgubWluKHByZXYgKyAxLCB0b3RhbFBhZ2VzKSl9XG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17Y3VycmVudFBhZ2UgPT09IHRvdGFsUGFnZXN9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGgtOSB3LTkgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgdHJhbnNpdGlvbi1hbGwgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtNzAwIGRpc2FibGVkOm9wYWNpdHktNDAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkXCJcbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUMOhZ2luYSBzaWd1aWVudGVcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxzdmcgd2lkdGg9XCIxOFwiIGhlaWdodD1cIjE4XCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiPlxuICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPVwiTTkgNUwxNiAxMkw5IDE5XCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIyXCIgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiLz5cbiAgICAgICAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LWZ1bGwgb3ZlcmZsb3cteC1hdXRvXCI+XG4gICAgICAgICAgICB7LyogVEFCTEEgMTogU0VOU09SRVMgRsONU0lDT1MgKi99XG4gICAgICAgICAgICB7dGFibGVUYWIgPT09ICdzZW5zb3JlcycgJiYgKFxuICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRhYmxlLWF1dG9cIj5cbiAgICAgICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gdGV4dC1sZWZ0XCI+XG4gICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHByLTQgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5IT1JBPC90aD5cbiAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPnBIPC90aD5cbiAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlRVUkJJREVaIChOVFUpPC90aD5cbiAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcGwtNCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlRFTVBFUkFUVVJBICjCsEMpPC90aD5cbiAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICA8dGJvZHk+XG4gICAgICAgICAgICAgICAgICB7cGFnaW5hdGVkTGlzdC5tYXAoKHJlYWRpbmcsIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2luZGV4fSBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBsYXN0OmJvcmRlci0wIGhvdmVyOmJnLXNsYXRlLTUwIGRhcms6aG92ZXI6YmctWyMzMTNENEFdIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHItNCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRUaW1lKHJlYWRpbmcuZmVjaGFfaG9yYSl9XG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC00IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdFZhbHVlKHJlYWRpbmcucGgpfVxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRWYWx1ZShyZWFkaW5nLnR1cmJpZGV6KX0gTlRVXG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBwbC00IHRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRWYWx1ZShyZWFkaW5nLnRlbXBlcmF0dXJhKX0gwrBDXG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAge3BhZ2luYXRlZExpc3QubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjb2xTcGFuPVwiNFwiIGNsYXNzTmFtZT1cInB5LTggdGV4dC1jZW50ZXIgdGV4dC1zbSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBObyBoYXkgbGVjdHVyYXMgZGUgc2Vuc29yZXMgcmVnaXN0cmFkYXMgZW4gbGEgam9ybmFkYSBkZSBob3kuXG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiBUQUJMQSAyOiBBRk9STyBNQU5VQUwgKFRBUVVJTExBKSAqL31cbiAgICAgICAgICAgIHt0YWJsZVRhYiA9PT0gJ21hbnVhbCcgJiYgKFxuICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRhYmxlLWF1dG9cIj5cbiAgICAgICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gdGV4dC1sZWZ0XCI+XG4gICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHByLTQgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5IT1JBIEVOVFJBREE8L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHRleHQtY2VudGVyXCI+VE9UQUwgUEVSU09OQVM8L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHRleHQtY2VudGVyXCI+VEFSSUZBIDE1IEJTPC90aD5cbiAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSB0ZXh0LWNlbnRlclwiPlRBUklGQSAyMCBCUzwvdGg+XG4gICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTQgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgdGV4dC1yaWdodFwiPlRPVEFMIFJFQ0FVREFETzwvdGg+XG4gICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHBsLTQgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5PQlNFUlZBQ0lPTkVTPC90aD5cbiAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICA8dGJvZHk+XG4gICAgICAgICAgICAgICAgICB7cGFnaW5hdGVkTGlzdC5tYXAoKHJlZywgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17cmVnLmlkX3JlZ2lzdHJvIHx8IGluZGV4fSBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBsYXN0OmJvcmRlci0wIGhvdmVyOmJnLXNsYXRlLTUwIGRhcms6aG92ZXI6YmctWyMzMTNENEFdIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHItNCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdFRpbWUocmVnLmhvcmFfZW50cmFkYSB8fCByZWcuY3JlYWRvX2VuKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTQgdGV4dC1zbSB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBiZy1pbmRpZ28tNTAgZGFyazpiZy1pbmRpZ28tOTAwLzMwIHB4LTMgcHktMC41IHRleHQteHMgZm9udC1ib2xkIHRleHQtaW5kaWdvLTcwMCBkYXJrOnRleHQtaW5kaWdvLTMwMCBib3JkZXIgYm9yZGVyLWluZGlnby0yMDAgZGFyazpib3JkZXItaW5kaWdvLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVnLnRvdGFsX3BlcnNvbmFzfSBwZXJzLlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtyZWcuY2FudGlkYWRfdGFyaWZhXzE1ID8/IDB9XG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC00IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3JlZy5jYW50aWRhZF90YXJpZmFfMjAgPz8gMH1cbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTQgdGV4dC1zbSBmb250LWJvbGQgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgdGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgQnMuIHtOdW1iZXIocmVnLnRvdGFsX3JlY2F1ZGFkbyA/PyAwKS50b0ZpeGVkKDIpfVxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcGwtNCB0ZXh0LXNtIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgaXRhbGljXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7cmVnLm9ic2VydmFjaW9uZXMgfHwgJ+KAlCd9XG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAge3BhZ2luYXRlZExpc3QubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjb2xTcGFuPVwiNlwiIGNsYXNzTmFtZT1cInB5LTggdGV4dC1jZW50ZXIgdGV4dC1zbSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBObyBzZSBoYW4gcmVnaXN0cmFkbyBpbmdyZXNvcyBtYW51YWxlcyBkZSB0YXF1aWxsYSBlbiBsYSBqb3JuYWRhIGRlIGhveS5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIFRBQkxBIDM6IEFGT1JPIEPDgU1BUkEgKElBKSAqL31cbiAgICAgICAgICAgIHt0YWJsZVRhYiA9PT0gJ2NhbWFyYScgJiYgKFxuICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRhYmxlLWF1dG9cIj5cbiAgICAgICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gdGV4dC1sZWZ0XCI+XG4gICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHByLTQgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5IT1JBIERFIENBUFRVUkE8L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHRleHQtY2VudGVyXCI+UEVSU09OQVMgREVURUNUQURBUzwvdGg+XG4gICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTQgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgdGV4dC1jZW50ZXJcIj5OSVZFTCBERSBBRkxVRU5DSUE8L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBwbC00IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+RElTUE9TSVRJVk88L3RoPlxuICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgICAgICAgIHtwYWdpbmF0ZWRMaXN0Lm1hcCgocmVnLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtyZWcuaWRfcmVnaXN0cm8gfHwgaW5kZXh9IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItWyMzMTNENEFdIGxhc3Q6Ym9yZGVyLTAgaG92ZXI6Ymctc2xhdGUtNTAgZGFyazpob3ZlcjpiZy1bIzMxM0Q0QV0gdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBwci00IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0VGltZShyZWcuZmVjaGFfaG9yYSB8fCByZWcuY3JlYWRvX2VuKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTQgdGV4dC1zbSB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBiZy1wdXJwbGUtNTAgZGFyazpiZy1wdXJwbGUtOTAwLzMwIHB4LTMuNSBweS0xIHRleHQtc20gZm9udC1ibGFjayB0ZXh0LXB1cnBsZS03MDAgZGFyazp0ZXh0LXB1cnBsZS0zMDAgYm9yZGVyIGJvcmRlci1wdXJwbGUtMjAwIGRhcms6Ym9yZGVyLXB1cnBsZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3JlZy5jYW50aWRhZF9wZXJzb25hc30gYmHDsWlzdGFzXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC00IHRleHQtc20gdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtiYWRnZUFmbHVlbmNpYShyZWcuY2FudGlkYWRfcGVyc29uYXMpfVxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcGwtNCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGZvbnQtbW9ubyB0ZXh0LXhzIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCBweC0yIHB5LTAuNSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICDwn5O3IHtyZWcuaWRfZGlzcG9zaXRpdm8gfHwgJ0VTUDMyLUNBTSd9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAge3BhZ2luYXRlZExpc3QubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjb2xTcGFuPVwiNFwiIGNsYXNzTmFtZT1cInB5LTggdGV4dC1jZW50ZXIgdGV4dC1zbSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBObyBoYXkgbGVjdHVyYXMgcmVnaXN0cmFkYXMgcG9yIGxhIGPDoW1hcmEgaW50ZWxpZ2VudGUgZW4gbGEgam9ybmFkYSBkZSBob3kuXG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBNT0RBTCBERVRBTExBRE8gREUgSElTVE9SSUFMIERFIEFGT1JPIERFTCBEw41BICovfVxuICAgICAge21vZGFsQWZvcm8gJiYgKFxuICAgICAgICA8ZGl2IFxuICAgICAgICAgIGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1ibGFjay82MCBiYWNrZHJvcC1ibHVyLXNtIHAtNCBvdmVyZmxvdy15LWF1dG9cIlxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vZGFsQWZvcm8obnVsbCl9XG4gICAgICAgID5cbiAgICAgICAgICA8ZGl2IFxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG1heC13LTR4bCByb3VuZGVkLTN4bCBiZy13aGl0ZSBkYXJrOmJnLVsjMjQzMDNGXSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gc2hhZG93LTJ4bCBvdmVyZmxvdy1oaWRkZW4gbXktNiBhbmltYXRlLWluIGZhZGUtaW4gem9vbS1pbi05NSBkdXJhdGlvbi0yMDBcIlxuICAgICAgICAgICAgb25DbGljaz17KGUpID0+IGUuc3RvcFByb3BhZ2F0aW9uKCl9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgey8qIEhlYWRlciBkZWwgTW9kYWwgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBweC03IHB5LTVcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgZmxleCBoLTExIHctMTEgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQteGwgJHtcbiAgICAgICAgICAgICAgICAgIG1vZGFsQWZvcm8gPT09ICdtYW51YWwnIFxuICAgICAgICAgICAgICAgICAgICA/ICdiZy1pbmRpZ28tNTAgZGFyazpiZy1pbmRpZ28tOTAwLzIwIHRleHQtaW5kaWdvLTYwMCBkYXJrOnRleHQtaW5kaWdvLTQwMCcgXG4gICAgICAgICAgICAgICAgICAgIDogJ2JnLXB1cnBsZS01MCBkYXJrOmJnLXB1cnBsZS05MDAvMjAgdGV4dC1wdXJwbGUtNjAwIGRhcms6dGV4dC1wdXJwbGUtNDAwJ1xuICAgICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICAgIHttb2RhbEFmb3JvID09PSAnbWFudWFsJyA/IChcbiAgICAgICAgICAgICAgICAgICAgPHN2ZyB3aWR0aD1cIjI0XCIgaGVpZ2h0PVwiMjRcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjJcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD1cIk0xNyAyMVYxOUMxNyAxNy45MzkxIDE2LjU3ODYgMTYuOTIxNyAxNS44Mjg0IDE2LjE3MTZDMTUuMDc4MyAxNS40MjE0IDE0LjA2MDkgMTUgMTMgMTVINUMzLjkzOTEzIDE1IDIuOTIxNzIgMTUuNDIxNCAyLjE3MTU3IDE2LjE3MTZDMS40MjE0MyAxNi45MjE3IDEgMTcuOTM5MSAxIDE5VjIxXCIvPlxuICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIGQ9XCJNOSAxMUMxMS4yMDkxIDExIDEzIDkuMjA5MTQgMTMgN0MxMyA0Ljc5MDg2IDExLjIwOTEgMyA5IDNDNi43OTA4NiAzIDUgNC43OTA4NiA1IDdDNSA5LjIwOTE0IDYuNzkwODYgMTEgOSAxMVpcIi8+XG4gICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHN2ZyB3aWR0aD1cIjI0XCIgaGVpZ2h0PVwiMjRcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjJcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD1cIk0xNSAxMEwyMSA2VjE4TDE1IDE0TTQgMThIMTNDMTQuMTA0NiAxOCAxNSAxNy4xMDQ2IDE1IDE2VjhDMTUgNi44OTU0MyAxNC4xMDQ2IDYgMTMgNkg0QzIuODk1NDMgNiAyIDYuODk1NDMgMiA4VjE2QzIgMTcuMTA0NiAyLjg5NTQzIDE4IDQgMThaXCIvPlxuICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgUmVnaXN0cm9zIGRlbCBEw61hIOKAlCB7bW9kYWxBZm9ybyA9PT0gJ21hbnVhbCcgPyAnQWZvcm8gTWFudWFsIChUYXF1aWxsYSknIDogJ0Fmb3JvIEPDoW1hcmEgSW50ZWxpZ2VudGUnfVxuICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICBIaXN0b3JpYWwgY3Jvbm9sw7NnaWNvIGNvbXBsZXRvIGRlIGxhcyBsZWN0dXJhcyByZWdpc3RyYWRhcyBkdXJhbnRlIGxhIGpvcm5hZGEgZGUgaG95XG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRNb2RhbEFmb3JvKG51bGwpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQteGwgcC0yIHRleHQtc2xhdGUtNDAwIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCBob3Zlcjp0ZXh0LXNsYXRlLTYwMCBkYXJrOmhvdmVyOnRleHQtc2xhdGUtMjAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIkNlcnJhciB2ZW50YW5hXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy02IGgtNlwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNNiAxOEwxOCA2TTYgNmwxMiAxMlwiIC8+XG4gICAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBTZWxlY3RvciBkZSBQZXN0YcOxYSBkZW50cm8gZGVsIE1vZGFsICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItWyMzMTNENEFdIHB4LTcgcHQtMyBiZy1zbGF0ZS01MC81MCBkYXJrOmJnLXNsYXRlLTkwMC8yMCBnYXAtM1wiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRNb2RhbEFmb3JvKCdtYW51YWwnKTsgc2V0TW9kYWxQYWdlKDEpOyB9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJvcmRlci1iLTIgcHgtNCBweS0zIHRleHQtc20gZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgICBtb2RhbEFmb3JvID09PSAnbWFudWFsJ1xuICAgICAgICAgICAgICAgICAgICA/ICdib3JkZXItaW5kaWdvLTYwMCB0ZXh0LWluZGlnby02MDAgZGFyazp0ZXh0LWluZGlnby00MDAnXG4gICAgICAgICAgICAgICAgICAgIDogJ2JvcmRlci10cmFuc3BhcmVudCB0ZXh0LXNsYXRlLTUwMCBob3Zlcjp0ZXh0LXNsYXRlLTgwMCBkYXJrOmhvdmVyOnRleHQtc2xhdGUtMjAwJ1xuICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPHNwYW4+8J+RpSBBZm9ybyBNYW51YWwgKFRhcXVpbGxhKTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyb3VuZGVkLWZ1bGwgYmctaW5kaWdvLTUwIGRhcms6YmctaW5kaWdvLTkwMC8zMCBweC0yIHB5LTAuNSB0ZXh0LXhzIHRleHQtaW5kaWdvLTYwMCBkYXJrOnRleHQtaW5kaWdvLTQwMCBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgICB7c29ydGVkTWFudWFsUmVhZGluZ3MubGVuZ3RofVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0TW9kYWxBZm9ybygnY2FtYXJhJyk7IHNldE1vZGFsUGFnZSgxKTsgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBib3JkZXItYi0yIHB4LTQgcHktMyB0ZXh0LXNtIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgbW9kYWxBZm9ybyA9PT0gJ2NhbWFyYSdcbiAgICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLXB1cnBsZS02MDAgdGV4dC1wdXJwbGUtNjAwIGRhcms6dGV4dC1wdXJwbGUtNDAwJ1xuICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXItdHJhbnNwYXJlbnQgdGV4dC1zbGF0ZS01MDAgaG92ZXI6dGV4dC1zbGF0ZS04MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTIwMCdcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxzcGFuPvCfk7cgQWZvcm8gQ8OhbWFyYSBJQTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyb3VuZGVkLWZ1bGwgYmctcHVycGxlLTUwIGRhcms6YmctcHVycGxlLTkwMC8zMCBweC0yIHB5LTAuNSB0ZXh0LXhzIHRleHQtcHVycGxlLTYwMCBkYXJrOnRleHQtcHVycGxlLTQwMCBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgICB7c29ydGVkQ2FtZXJhUmVhZGluZ3MubGVuZ3RofVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIENvbnRlbmlkbyBkZWwgTW9kYWwgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNyBtYXgtaC1bNzB2aF0gb3ZlcmZsb3cteS1hdXRvXCI+XG4gICAgICAgICAgICAgIHsvKiBUYXJqZXRhcyBkZSBtw6l0cmljYXMgZGVsIGTDrWEgZW4gZWwgTW9kYWwgKi99XG4gICAgICAgICAgICAgIHttb2RhbEFmb3JvID09PSAnbWFudWFsJyA/IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgbWQ6Z3JpZC1jb2xzLTQgZ2FwLTQgbWItNlwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC81MCBwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMFwiPlRvdGFsIFBlcnNvbmFzIEhveTwvcD5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ibGFjayB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGUgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgIHttYW51YWxTdW1tYXJ5LnRvdGFsX3BlcnNvbmFzID8/IHNlbnNvckRhdGE/LmFmb3JvX21hbnVhbCA/PyAwfVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNTAgcC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1lbWVyYWxkLTUwMFwiPlJlY2F1ZGFkbyBIb3k8L3A+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYmxhY2sgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgIEJzLiB7TnVtYmVyKG1hbnVhbFN1bW1hcnkudG90YWxfcmVjYXVkYWRvID8/IDApLnRvRml4ZWQoMil9XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC81MCBwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWJsdWUtNTAwXCI+VGFyaWZhIDE1IEJzPC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtYmx1ZS02MDAgZGFyazp0ZXh0LWJsdWUtNDAwIG10LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7bWFudWFsU3VtbWFyeS50b3RhbF90YXJpZmFfMTUgPz8gMH0gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW5vcm1hbCB0ZXh0LXNsYXRlLTQwMFwiPnBlcnMuPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNTAgcC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1pbmRpZ28tNTAwXCI+VGFyaWZhIDIwIEJzPC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtaW5kaWdvLTYwMCBkYXJrOnRleHQtaW5kaWdvLTQwMCBtdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAge21hbnVhbFN1bW1hcnkudG90YWxfdGFyaWZhXzIwID8/IDB9IDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ub3JtYWwgdGV4dC1zbGF0ZS00MDBcIj5wZXJzLjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIG1kOmdyaWQtY29scy00IGdhcC00IG1iLTZcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNTAgcC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDBcIj7Dmmx0aW1vIENvbnRlbyBlbiBWaXZvPC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZSBtdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2NhbWVyYVN1bW1hcnkudWx0aW1vX2NvbnRlbyA/PyBzZW5zb3JEYXRhPy5hZm9yb19jYW1hcmEgPz8gMH0gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW5vcm1hbCB0ZXh0LXNsYXRlLTQwMFwiPnBlcnMuPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNTAgcC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1yZWQtNTAwXCI+UGljbyBNw6F4aW1vIGRlbCBEw61hPC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtcmVkLTYwMCBkYXJrOnRleHQtcmVkLTQwMCBtdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2NhbWVyYVN1bW1hcnkucGljb19wZXJzb25hcyA/PyAwfSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbm9ybWFsIHRleHQtc2xhdGUtNDAwXCI+YmHDsWlzdGFzPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNTAgcC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1wdXJwbGUtNTAwXCI+UHJvbWVkaW8gZGVsIETDrWE8L3A+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYmxhY2sgdGV4dC1wdXJwbGUtNjAwIGRhcms6dGV4dC1wdXJwbGUtNDAwIG10LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7Y2FtZXJhU3VtbWFyeS5wcm9tZWRpb19wZXJzb25hcyA/PyAwfSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbm9ybWFsIHRleHQtc2xhdGUtNDAwXCI+YmHDsWlzdGFzPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNTAgcC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ibHVlLTUwMFwiPlRvdGFsIGRlIENhcHR1cmFzPC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtYmx1ZS02MDAgZGFyazp0ZXh0LWJsdWUtNDAwIG10LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7c29ydGVkQ2FtZXJhUmVhZGluZ3MubGVuZ3RofSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbm9ybWFsIHRleHQtc2xhdGUtNDAwXCI+cmVnaXN0cm9zPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7LyogVGFibGEgZGVudHJvIGRlbCBNb2RhbCAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG8gcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdXCI+XG4gICAgICAgICAgICAgICAge21vZGFsQWZvcm8gPT09ICdtYW51YWwnID8gKFxuICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0YWJsZS1hdXRvXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gYmctc2xhdGUtNTAvNzAgZGFyazpiZy1zbGF0ZS04MDAvNTAgdGV4dC1sZWZ0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+SE9SQTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHRleHQtY2VudGVyXCI+VE9UQUwgUEVSU09OQVM8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSB0ZXh0LWNlbnRlclwiPlRBUklGQSAxNSBCUzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHRleHQtY2VudGVyXCI+VEFSSUZBIDIwIEJTPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTQgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgdGV4dC1yaWdodFwiPlJFQ0FVREFETzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+T0JTRVJWQUNJT05FUzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICAgICAgICAgIHtwYWdpbmF0ZWRNb2RhbExpc3QubWFwKChyZWcsIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtyZWcuaWRfcmVnaXN0cm8gfHwgaW5kZXh9IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItWyMzMTNENEFdIGxhc3Q6Ym9yZGVyLTAgaG92ZXI6Ymctc2xhdGUtNTAgZGFyazpob3ZlcjpiZy1bIzMxM0Q0QV0gdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRUaW1lKHJlZy5ob3JhX2VudHJhZGEgfHwgcmVnLmNyZWFkb19lbil9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTQgdGV4dC1zbSB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGwgYmctaW5kaWdvLTUwIGRhcms6YmctaW5kaWdvLTkwMC8zMCBweC0zIHB5LTAuNSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWluZGlnby03MDAgZGFyazp0ZXh0LWluZGlnby0zMDAgYm9yZGVyIGJvcmRlci1pbmRpZ28tMjAwIGRhcms6Ym9yZGVyLWluZGlnby04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZWcudG90YWxfcGVyc29uYXN9IHBlcnMuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC00IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZWcuY2FudGlkYWRfdGFyaWZhXzE1ID8/IDB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTQgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3JlZy5jYW50aWRhZF90YXJpZmFfMjAgPz8gMH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCB0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQnMuIHtOdW1iZXIocmVnLnRvdGFsX3JlY2F1ZGFkbyA/PyAwKS50b0ZpeGVkKDIpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC00IHRleHQtc20gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBpdGFsaWNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVnLm9ic2VydmFjaW9uZXMgfHwgJ+KAlCd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgIHtwYWdpbmF0ZWRNb2RhbExpc3QubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNvbFNwYW49XCI2XCIgY2xhc3NOYW1lPVwicHktOCB0ZXh0LWNlbnRlciB0ZXh0LXNtIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBObyBzZSBoYW4gcmVnaXN0cmFkbyBlbnRyYWRhcyBkZSB0YXF1aWxsYSBlbiBsYSBqb3JuYWRhIGRlIGhveS5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgdGFibGUtYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIGJnLXNsYXRlLTUwLzcwIGRhcms6Ymctc2xhdGUtODAwLzUwIHRleHQtbGVmdFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPkhPUkEgREUgQ0FQVFVSQTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHRleHQtY2VudGVyXCI+UEVSU09OQVMgREVURUNUQURBUzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHRleHQtY2VudGVyXCI+TklWRUwgREUgQUZMVUVOQ0lBPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTQgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5ESVNQT1NJVElWTzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICAgICAgICAgIHtwYWdpbmF0ZWRNb2RhbExpc3QubWFwKChyZWcsIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtyZWcuaWRfcmVnaXN0cm8gfHwgaW5kZXh9IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItWyMzMTNENEFdIGxhc3Q6Ym9yZGVyLTAgaG92ZXI6Ymctc2xhdGUtNTAgZGFyazpob3ZlcjpiZy1bIzMxM0Q0QV0gdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRUaW1lKHJlZy5mZWNoYV9ob3JhIHx8IHJlZy5jcmVhZG9fZW4pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC00IHRleHQtc20gdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLXB1cnBsZS01MCBkYXJrOmJnLXB1cnBsZS05MDAvMzAgcHgtMy41IHB5LTEgdGV4dC1zbSBmb250LWJsYWNrIHRleHQtcHVycGxlLTcwMCBkYXJrOnRleHQtcHVycGxlLTMwMCBib3JkZXIgYm9yZGVyLXB1cnBsZS0yMDAgZGFyazpib3JkZXItcHVycGxlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3JlZy5jYW50aWRhZF9wZXJzb25hc30gYmHDsWlzdGFzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC00IHRleHQtc20gdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YmFkZ2VBZmx1ZW5jaWEocmVnLmNhbnRpZGFkX3BlcnNvbmFzKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBmb250LW1vbm8gdGV4dC14cyBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgcHgtMi41IHB5LTEgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIPCfk7cge3JlZy5pZF9kaXNwb3NpdGl2byB8fCAnRVNQMzItQ0FNJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgIHtwYWdpbmF0ZWRNb2RhbExpc3QubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNvbFNwYW49XCI0XCIgY2xhc3NOYW1lPVwicHktOCB0ZXh0LWNlbnRlciB0ZXh0LXNtIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBObyBoYXkgbGVjdHVyYXMgcmVnaXN0cmFkYXMgcG9yIGxhIGPDoW1hcmEgaW50ZWxpZ2VudGUgZW4gbGEgam9ybmFkYSBkZSBob3kuXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBQYWdpbmFjacOzbiBkZWwgTW9kYWwgKi99XG4gICAgICAgICAgICAgIHttb2RhbExpc3QubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC01IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIE1vc3RyYW5kbyB7KG1vZGFsUGFnZSAtIDEpICogaXRlbXNQZXJQYWdlICsgMX0gLSB7TWF0aC5taW4obW9kYWxQYWdlICogaXRlbXNQZXJQYWdlLCBtb2RhbExpc3QubGVuZ3RoKX0gZGUge21vZGFsTGlzdC5sZW5ndGh9IHJlZ2lzdHJvc1xuICAgICAgICAgICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRNb2RhbFBhZ2UoKHByZXYpID0+IE1hdGgubWF4KHByZXYgLSAxLCAxKSl9XG4gICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e21vZGFsUGFnZSA9PT0gMX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGgtOCB3LTggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgdHJhbnNpdGlvbi1hbGwgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtNzAwIGRpc2FibGVkOm9wYWNpdHktNDAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIHRleHQteHMgZm9udC1ib2xkXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIOKGkFxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICBQw6FnaW5hIHttb2RhbFBhZ2V9IGRlIHttb2RhbFRvdGFsUGFnZXN9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vZGFsUGFnZSgocHJldikgPT4gTWF0aC5taW4ocHJldiArIDEsIG1vZGFsVG90YWxQYWdlcykpfVxuICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXttb2RhbFBhZ2UgPT09IG1vZGFsVG90YWxQYWdlc31cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGgtOCB3LTggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgdHJhbnNpdGlvbi1hbGwgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtNzAwIGRpc2FibGVkOm9wYWNpdHktNDAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIHRleHQteHMgZm9udC1ib2xkXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIOKGklxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBGb290ZXIgZGVsIE1vZGFsICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBweC03IHB5LTQgYmctc2xhdGUtNTAvNTAgZGFyazpiZy1zbGF0ZS05MDAvMjBcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vZGFsQWZvcm8obnVsbCl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC14bCBiZy1zbGF0ZS04MDAgZGFyazpiZy1zbGF0ZS03MDAgaG92ZXI6Ymctc2xhdGUtOTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtNjAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQtc20gcHgtNSBweS0yLjUgdHJhbnNpdGlvbi1hbGwgc2hhZG93LXNtXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIENlcnJhclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBNT0RBTCBERSBHRU5FUkFDScOTTiBZIEVYUE9SVEFDScOTTiBERSBSRVBPUlRFUyBJTlNUSVRVQ0lPTkFMRVMgKi99XG4gICAgICA8UmVwb3J0ZXNNb2RhbFxuICAgICAgICBpc09wZW49e3Nob3dSZXBvcnRNb2RhbH1cbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2hvd1JlcG9ydE1vZGFsKGZhbHNlKX1cbiAgICAgIC8+XG4gICAgPC8+XG4gIClcbn1cblxuZnVuY3Rpb24gYmFkZ2VBZmx1ZW5jaWEoY2FudGlkYWQpIHtcbiAgaWYgKGNhbnRpZGFkID4gMzApIHtcbiAgICByZXR1cm4gKFxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcm91bmRlZC1mdWxsIGJnLXJlZC01MCBkYXJrOmJnLXJlZC05MDAvMjAgcHgtMi41IHB5LTAuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1yZWQtNjAwIGRhcms6dGV4dC1yZWQtNDAwIGJvcmRlciBib3JkZXItcmVkLTIwMCBkYXJrOmJvcmRlci1yZWQtODAwXCI+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImgtMS41IHctMS41IHJvdW5kZWQtZnVsbCBiZy1yZWQtNTAwXCI+PC9zcGFuPlxuICAgICAgICBBbHRhIGFmbHVlbmNpYVxuICAgICAgPC9zcGFuPlxuICAgIClcbiAgfVxuICBpZiAoY2FudGlkYWQgPiAxNSkge1xuICAgIHJldHVybiAoXG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLWZ1bGwgYmctYW1iZXItNTAgZGFyazpiZy1hbWJlci05MDAvMjAgcHgtMi41IHB5LTAuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1hbWJlci02MDAgZGFyazp0ZXh0LWFtYmVyLTQwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCBkYXJrOmJvcmRlci1hbWJlci04MDBcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaC0xLjUgdy0xLjUgcm91bmRlZC1mdWxsIGJnLWFtYmVyLTUwMFwiPjwvc3Bhbj5cbiAgICAgICAgTW9kZXJhZGFcbiAgICAgIDwvc3Bhbj5cbiAgICApXG4gIH1cbiAgcmV0dXJuIChcbiAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtOTAwLzIwIHB4LTIuNSBweS0wLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDAgZGFyazpib3JkZXItZW1lcmFsZC04MDBcIj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImgtMS41IHctMS41IHJvdW5kZWQtZnVsbCBiZy1lbWVyYWxkLTUwMFwiPjwvc3Bhbj5cbiAgICAgIEJhamEgLyBOb3JtYWxcbiAgICA8L3NwYW4+XG4gIClcbn1cblxuZnVuY3Rpb24gZm9ybWF0VmFsdWUodmFsdWUpIHsgcmV0dXJuIHZhbHVlID09PSBudWxsIHx8IHZhbHVlID09PSB1bmRlZmluZWQgPyAn4oCUJyA6IE51bWJlcih2YWx1ZSkudG9GaXhlZCgyKSB9XG5cbmZ1bmN0aW9uIGZvcm1hdFRpbWUodmFsdWUpIHtcbiAgaWYgKCF2YWx1ZSkgcmV0dXJuICfigJQnXG4gIC8vIEV4dHJhZSBkaXJlY3RhbWVudGUgbGEgaG9yYSBkZSBsYSBjYWRlbmEgKGVqOiAnMjAyNi0wOS0xM1QyMDozMDoxNS4uLicgLT4gJzIwOjMwOjE1JylcbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycgJiYgdmFsdWUuaW5jbHVkZXMoJ1QnKSkge1xuICAgIGNvbnN0IHRpbWVQYXJ0ID0gdmFsdWUuc3BsaXQoJ1QnKVsxXVxuICAgIGlmICh0aW1lUGFydCkge1xuICAgICAgcmV0dXJuIHRpbWVQYXJ0LnN1YnN0cmluZygwLCA4KVxuICAgIH1cbiAgfVxuICBjb25zdCBkYXRlT2JqID0gbmV3IERhdGUodmFsdWUpXG4gIHJldHVybiBkYXRlT2JqLnRvTG9jYWxlVGltZVN0cmluZyhbXSwgeyBob3VyOiAnMi1kaWdpdCcsIG1pbnV0ZTogJzItZGlnaXQnLCBzZWNvbmQ6ICcyLWRpZ2l0JywgaG91cjEyOiBmYWxzZSB9KVxufVxuXG5mdW5jdGlvbiBwaFN0YXRlKHZhbHVlKSB7IGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkIHx8IHZhbHVlID09PSBudWxsKSByZXR1cm4gJ2VtcHR5JzsgcmV0dXJuIHZhbHVlIDwgNyB8fCB2YWx1ZSA+IDcuNiA/ICd3YXJuaW5nJyA6ICdub3JtYWwnIH1cbmZ1bmN0aW9uIHR1cmJpZGl0eVN0YXRlKHZhbHVlKSB7IGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkIHx8IHZhbHVlID09PSBudWxsKSByZXR1cm4gJ2VtcHR5JzsgcmV0dXJuIHZhbHVlID4gMTAgPyAnZGFuZ2VyJyA6IHZhbHVlID4gNSA/ICd3YXJuaW5nJyA6ICdub3JtYWwnIH1cbiJdfQ==