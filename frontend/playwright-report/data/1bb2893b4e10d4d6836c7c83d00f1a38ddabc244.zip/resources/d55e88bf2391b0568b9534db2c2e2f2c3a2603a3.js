import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Users/index.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=41a64c35";
import api from "/src/services/api.js";
import { useAuth } from "/src/context/AuthContext.jsx";
import { Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=41a64c35";
var _jsxFileName = "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Users/index.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=41a64c35";
var _s = $RefreshSig$();
export default function UsersPage() {
	_s();
	const { session, authConfig, showError, showMessage } = useAuth();
	const [users, setUsers] = useState([]);
	const [roles, setRoles] = useState([]);
	const [loading, setLoading] = useState(false);
	const [userForm, setUserForm] = useState(null);
	const loadData = async () => {
		setLoading(true);
		try {
			const [{ data: usersData }, { data: rolesData }] = await Promise.all([api.get("/auth/users", authConfig()), api.get("/auth/roles", authConfig())]);
			setUsers(usersData);
			setRoles(rolesData);
		} catch (requestError) {
			showError(requestError);
		} finally {
			setLoading(false);
		}
	};
	useEffect(() => {
		if (session?.usuario?.sigla_rol === "ADM") {
			loadData();
		}
	}, [session]);
	if (session?.usuario?.sigla_rol !== "ADM") {
		return /* @__PURE__ */ _jsxDEV(Navigate, {
			to: "/dashboard",
			replace: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 36,
			columnNumber: 12
		}, this);
	}
	const submitUser = async (event) => {
		event.preventDefault();
		try {
			const form = new FormData(event.currentTarget);
			const payload = Object.fromEntries(form);
			const request = userForm.id_usuario ? api.put(`/auth/users/${userForm.id_usuario}`, payload, authConfig()) : api.post("/auth/users", payload, authConfig());
			const { data } = await request;
			setUserForm(null);
			showMessage(data.mensaje);
			await loadData();
		} catch (requestError) {
			showError(requestError);
		}
	};
	const disableUser = async (user) => {
		if (!window.confirm(`¿Eliminar a ${user.nombre} ${user.primer_apellido}?`)) return;
		try {
			const { data } = await api.delete(`/auth/users/${user.id_usuario}`, authConfig());
			showMessage(data.mensaje);
			await loadData();
		} catch (requestError) {
			showError(requestError);
		}
	};
	// Mapeo rápido de sigla a nombre completo de rol
	const getRolNombre = (sigla) => {
		const rol = roles.find((r) => r.sigla === sigla);
		return rol ? rol.nombre : sigla;
	};
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV("div", {
			className: "mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
			children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-2xl font-bold text-slate-800 dark:text-white",
				children: "Administración de Usuarios"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 77,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-sm font-medium text-slate-500 dark:text-slate-400",
				children: "Gestiona los accesos y permisos del equipo operativo."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 11
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 76,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				onClick: () => setUserForm({}),
				className: "inline-flex items-center justify-center rounded-lg bg-blue-600 px-6 py-2.5 text-center font-medium text-white shadow-sm hover:bg-blue-700 transition-colors",
				children: "+ Nuevo Usuario"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 75,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "rounded-2xl border border-slate-200 dark:border-[#313D4A] bg-white dark:bg-[#24303F] p-7 shadow-sm",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "mb-6 flex items-center justify-between",
				children: [/* @__PURE__ */ _jsxDEV("h4", {
					className: "text-xl font-bold text-slate-800 dark:text-white",
					children: "Lista de Usuarios"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 90,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "rounded-full bg-slate-100 dark:bg-slate-800 px-3 py-1 text-xs font-semibold text-slate-600 dark:text-slate-400",
					children: [users.length, " usuarios"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 91,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 89,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "max-w-full overflow-x-auto",
				children: /* @__PURE__ */ _jsxDEV("table", {
					className: "w-full table-auto",
					children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
						className: "border-b border-slate-200 dark:border-[#313D4A] text-left",
						children: [
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-4 pr-4 text-sm font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider",
								children: "Usuario"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 100,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-4 px-4 text-sm font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider",
								children: "Rol"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 101,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-4 px-4 text-sm font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider",
								children: "Estado"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 102,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-4 px-4 text-sm font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider",
								children: "Acciones"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 103,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 15
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 98,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: loading ? /* @__PURE__ */ _jsxDEV("tr", { children: /* @__PURE__ */ _jsxDEV("td", {
						colSpan: "4",
						className: "py-8 text-center text-sm font-medium text-slate-500 dark:text-slate-400",
						children: "Cargando usuarios..."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 108,
						columnNumber: 21
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 108,
						columnNumber: 17
					}, this) : users.map((user) => /* @__PURE__ */ _jsxDEV("tr", {
						className: "border-b border-slate-100 dark:border-[#313D4A] last:border-0 hover:bg-slate-50 dark:hover:bg-[#313D4A]/50 transition-colors",
						children: [
							/* @__PURE__ */ _jsxDEV("td", {
								className: "py-4 pr-4",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex h-10 w-10 items-center justify-center rounded-full bg-blue-100 dark:bg-blue-900/30 text-sm font-bold text-blue-600 dark:text-blue-400",
										children: user.nombre.slice(0, 1).toUpperCase()
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 114,
										columnNumber: 25
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h5", {
										className: "font-semibold text-slate-800 dark:text-white",
										children: [
											user.nombre,
											" ",
											user.primer_apellido
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 118,
										columnNumber: 27
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-sm font-medium text-slate-500 dark:text-slate-400",
										children: user.correo
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 119,
										columnNumber: 27
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 117,
										columnNumber: 25
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 113,
									columnNumber: 23
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 112,
								columnNumber: 21
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								className: "py-4 px-4",
								children: /* @__PURE__ */ _jsxDEV("span", {
									className: "text-sm font-medium text-slate-700 dark:text-slate-300",
									children: getRolNombre(user.sigla_rol)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 124,
									columnNumber: 23
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 123,
								columnNumber: 21
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								className: "py-4 px-4",
								children: /* @__PURE__ */ _jsxDEV("span", {
									className: "inline-flex items-center gap-1.5 rounded-full bg-emerald-50 dark:bg-emerald-900/20 px-2.5 py-1 text-xs font-semibold text-emerald-600 dark:text-emerald-400",
									children: [/* @__PURE__ */ _jsxDEV("span", { className: "h-1.5 w-1.5 rounded-full bg-emerald-500" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 130,
										columnNumber: 25
									}, this), "Activo"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 129,
									columnNumber: 23
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 128,
								columnNumber: 21
							}, this),
							/* @__PURE__ */ _jsxDEV("td", {
								className: "py-4 px-4",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-4",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => setUserForm(user),
										className: "text-sm font-semibold text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300",
										children: "Editar"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 136,
										columnNumber: 25
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => disableUser(user),
										className: "text-sm font-semibold text-red-600 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300",
										children: "Eliminar"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 139,
										columnNumber: 25
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 135,
									columnNumber: 23
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 134,
								columnNumber: 21
							}, this)
						]
					}, user.id_usuario, true, {
						fileName: _jsxFileName,
						lineNumber: 111,
						columnNumber: 19
					}, this)) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 106,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 97,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 96,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 88,
			columnNumber: 7
		}, this),
		userForm && /* @__PURE__ */ _jsxDEV(UserModal, {
			user: userForm,
			roles,
			onClose: () => setUserForm(null),
			onSubmit: submitUser
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 152,
			columnNumber: 20
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 74,
		columnNumber: 5
	}, this);
}
_s(UsersPage, "Z+P86WsTsxsKbzJg3/HV+uFyBh8=", false, function() {
	return [useAuth];
});
_c = UsersPage;
function UserModal({ user, roles, onClose, onSubmit }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-[99999] flex items-center justify-center bg-slate-900/50 backdrop-blur-sm px-4 py-5",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "w-full max-w-lg rounded-2xl border border-slate-200 dark:border-[#313D4A] bg-white dark:bg-[#24303F] p-8 shadow-2xl",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "mb-6 flex items-center justify-between",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-xl font-bold text-slate-800 dark:text-white",
					children: user.id_usuario ? "Editar Usuario" : "Crear Usuario"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 162,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: onClose,
					className: "text-slate-400 hover:text-slate-600 dark:hover:text-slate-200",
					children: /* @__PURE__ */ _jsxDEV("svg", {
						width: "24",
						height: "24",
						viewBox: "0 0 24 24",
						fill: "none",
						xmlns: "http://www.w3.org/2000/svg",
						children: /* @__PURE__ */ _jsxDEV("path", {
							d: "M18 6L6 18M6 6L18 18",
							stroke: "currentColor",
							strokeWidth: "2",
							strokeLinecap: "round",
							strokeLinejoin: "round"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 167,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 166,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 165,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 161,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("form", {
				onSubmit,
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mb-4",
						children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "mb-2 block text-sm font-medium text-slate-700 dark:text-slate-300",
							children: "Nombre"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 174,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							name: "nombre",
							defaultValue: user.nombre || "",
							required: true,
							className: "w-full rounded-lg border border-slate-300 dark:border-[#313D4A] bg-transparent dark:bg-[#1A222C] px-4 py-2.5 text-slate-800 dark:text-white outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 175,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 173,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mb-4 flex gap-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex-1",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "mb-2 block text-sm font-medium text-slate-700 dark:text-slate-300",
								children: "Primer Apellido"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 180,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								name: "primer_apellido",
								defaultValue: user.primer_apellido || "",
								required: true,
								className: "w-full rounded-lg border border-slate-300 dark:border-[#313D4A] bg-transparent dark:bg-[#1A222C] px-4 py-2.5 text-slate-800 dark:text-white outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 181,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 179,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex-1",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "mb-2 block text-sm font-medium text-slate-700 dark:text-slate-300",
								children: "Segundo Apellido"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 184,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								name: "segundo_apellido",
								defaultValue: user.segundo_apellido || "",
								className: "w-full rounded-lg border border-slate-300 dark:border-[#313D4A] bg-transparent dark:bg-[#1A222C] px-4 py-2.5 text-slate-800 dark:text-white outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 185,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 183,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 178,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mb-4",
						children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "mb-2 block text-sm font-medium text-slate-700 dark:text-slate-300",
							children: "Correo Electrónico"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 190,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							name: "correo",
							type: "email",
							defaultValue: user.correo || "",
							required: true,
							className: "w-full rounded-lg border border-slate-300 dark:border-[#313D4A] bg-transparent dark:bg-[#1A222C] px-4 py-2.5 text-slate-800 dark:text-white outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 191,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 189,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mb-8",
						children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "mb-2 block text-sm font-medium text-slate-700 dark:text-slate-300",
							children: "Rol"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 195,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("select", {
							name: "sigla_rol",
							defaultValue: user.sigla_rol || (roles.length > 0 ? roles[0].sigla : "OPE"),
							className: "w-full rounded-lg border border-slate-300 dark:border-[#313D4A] bg-transparent dark:bg-[#1A222C] px-4 py-2.5 text-slate-800 dark:text-white outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600",
							children: roles.map((rol) => /* @__PURE__ */ _jsxDEV("option", {
								value: rol.sigla,
								children: [
									rol.nombre,
									" (",
									rol.sigla,
									")"
								]
							}, rol.sigla, true, {
								fileName: _jsxFileName,
								lineNumber: 198,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 196,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 194,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex gap-4",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: onClose,
							className: "flex-1 rounded-lg border border-slate-300 dark:border-[#313D4A] py-2.5 font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-[#313D4A] transition-colors",
							children: "Cancelar"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 206,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							className: "flex-1 rounded-lg bg-blue-600 py-2.5 font-medium text-white shadow-sm hover:bg-blue-700 transition-colors",
							children: "Guardar Usuario"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 209,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 205,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 172,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 160,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 159,
		columnNumber: 5
	}, this);
}
_c2 = UserModal;
var _c, _c2;
$RefreshReg$(_c, "UsersPage");
$RefreshReg$(_c2, "UserModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Users/index.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Users/index.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Users/index.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Users/index.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLGlCQUFpQjtBQUNwQyxPQUFPLFNBQVM7QUFDaEIsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsZ0JBQWdCOzs7O0FBRXpCLGVBQWUsU0FBUyxZQUFZOztDQUNsQyxNQUFNLEVBQUUsU0FBUyxZQUFZLFdBQVcsZ0JBQWdCLFFBQVE7Q0FDaEUsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLENBQUMsQ0FBQztDQUNyQyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsQ0FBQyxDQUFDO0NBQ3JDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxLQUFLO0NBQzVDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxJQUFJO0NBRTdDLE1BQU0sV0FBVyxZQUFZO0VBQzNCLFdBQVcsSUFBSTtFQUNmLElBQUk7R0FDRixNQUFNLENBQUMsRUFBRSxNQUFNLGFBQWEsRUFBRSxNQUFNLGVBQWUsTUFBTSxRQUFRLElBQUksQ0FDbkUsSUFBSSxJQUFJLGVBQWUsV0FBVyxDQUFDLEdBQ25DLElBQUksSUFBSSxlQUFlLFdBQVcsQ0FBQyxDQUNyQyxDQUFDO0dBQ0QsU0FBUyxTQUFTO0dBQ2xCLFNBQVMsU0FBUztFQUNwQixTQUFTLGNBQWM7R0FDckIsVUFBVSxZQUFZO0VBQ3hCLFVBQVU7R0FDUixXQUFXLEtBQUs7RUFDbEI7Q0FDRjtDQUVBLGdCQUFnQjtFQUNkLElBQUksU0FBUyxTQUFTLGNBQWMsT0FBTztHQUN6QyxTQUFTO0VBQ1g7Q0FDRixHQUFHLENBQUMsT0FBTyxDQUFDO0NBRVosSUFBSSxTQUFTLFNBQVMsY0FBYyxPQUFPO0VBQ3pDLE9BQU8sd0JBQUMsVUFBRDtHQUFVLElBQUc7R0FBYTtFQUFTOzs7OztDQUM1QztDQUVBLE1BQU0sYUFBYSxPQUFPLFVBQVU7RUFDbEMsTUFBTSxlQUFlO0VBQ3JCLElBQUk7R0FDRixNQUFNLE9BQU8sSUFBSSxTQUFTLE1BQU0sYUFBYTtHQUM3QyxNQUFNLFVBQVUsT0FBTyxZQUFZLElBQUk7R0FDdkMsTUFBTSxVQUFVLFNBQVMsYUFDckIsSUFBSSxJQUFJLGVBQWUsU0FBUyxjQUFjLFNBQVMsV0FBVyxDQUFDLElBQ25FLElBQUksS0FBSyxlQUFlLFNBQVMsV0FBVyxDQUFDO0dBQ2pELE1BQU0sRUFBRSxTQUFTLE1BQU07R0FDdkIsWUFBWSxJQUFJO0dBQ2hCLFlBQVksS0FBSyxPQUFPO0dBQ3hCLE1BQU0sU0FBUztFQUNqQixTQUFTLGNBQWM7R0FDckIsVUFBVSxZQUFZO0VBQ3hCO0NBQ0Y7Q0FFQSxNQUFNLGNBQWMsT0FBTyxTQUFTO0VBQ2xDLElBQUksQ0FBQyxPQUFPLFFBQVEsZUFBZSxLQUFLLE9BQU8sR0FBRyxLQUFLLGdCQUFnQixFQUFFLEdBQUc7RUFDNUUsSUFBSTtHQUNGLE1BQU0sRUFBRSxTQUFTLE1BQU0sSUFBSSxPQUFPLGVBQWUsS0FBSyxjQUFjLFdBQVcsQ0FBQztHQUNoRixZQUFZLEtBQUssT0FBTztHQUN4QixNQUFNLFNBQVM7RUFDakIsU0FBUyxjQUFjO0dBQ3JCLFVBQVUsWUFBWTtFQUN4QjtDQUNGOztDQUdBLE1BQU0sZ0JBQWdCLFVBQVU7RUFDOUIsTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLEVBQUUsVUFBVSxLQUFLO0VBQy9DLE9BQU8sTUFBTSxJQUFJLFNBQVM7Q0FDNUI7Q0FFQSxPQUNFO0VBQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUFvRDtHQUE4Qjs7OzthQUNoRyx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUF5RDtHQUF3RDs7OztXQUMzSDs7OzthQUNMLHdCQUFDLFVBQUQ7SUFDRSxlQUFlLFlBQVksQ0FBQyxDQUFDO0lBQzdCLFdBQVU7Y0FDWDtHQUVPOzs7O1dBQ0w7Ozs7OztFQUVMLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBbUQ7SUFBcUI7Ozs7Y0FDdEYsd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBaEIsQ0FDRyxNQUFNLFFBQU8sV0FDVjs7Ozs7WUFDSDs7Ozs7YUFFTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLFNBQUQ7S0FBTyxXQUFVO2VBQWpCLENBQ0Usd0JBQUMsU0FBRCxZQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFkO09BQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQTRGO09BQVc7Ozs7O09BQ3JILHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUE0RjtPQUFPOzs7OztPQUNqSCx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBNEY7T0FBVTs7Ozs7T0FDcEgsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQTRGO09BQVk7Ozs7O01BQ3BIOzs7OztjQUNDOzs7O2VBQ1Asd0JBQUMsU0FBRCxZQUNHLFVBQ0Msd0JBQUMsTUFBRCxZQUFJLHdCQUFDLE1BQUQ7TUFBSSxTQUFRO01BQUksV0FBVTtnQkFBMEU7S0FBd0I7Ozs7Y0FBSzs7OztnQkFFckksTUFBTSxLQUFLLFNBQ1Qsd0JBQUMsTUFBRDtNQUEwQixXQUFVO2dCQUFwQztPQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUNaLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ1osS0FBSyxPQUFPLE1BQU0sR0FBRSxDQUFDLENBQUMsQ0FBQyxZQUFZO1NBQ2pDOzs7O21CQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBZDtXQUE4RCxLQUFLO1dBQU87V0FBRSxLQUFLO1VBQW9COzs7OzttQkFDckcsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQTBELEtBQUs7U0FBVTs7OztpQkFDbkY7Ozs7aUJBQ0Y7Ozs7OztPQUNIOzs7OztPQUNKLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUNaLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUNiLGFBQWEsS0FBSyxTQUFTO1FBQ3hCOzs7OztPQUNKOzs7OztPQUNKLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUNaLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQixDQUNFLHdCQUFDLFFBQUQsRUFBTSxXQUFVLDBDQUFnRDs7OzttQkFBQyxRQUU3RDs7Ozs7O09BQ0o7Ozs7O09BQ0osd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQ1osd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1VBQVEsZUFBZSxZQUFZLElBQUk7VUFBRyxXQUFVO29CQUFzRztTQUVsSjs7OzttQkFDUix3QkFBQyxVQUFEO1VBQVEsZUFBZSxZQUFZLElBQUk7VUFBRyxXQUFVO29CQUFrRztTQUU5STs7OztpQkFDTDs7Ozs7O09BQ0g7Ozs7O01BQ0Y7UUFqQ0ssS0FBSzs7OztZQWlDVixDQUNMLEVBRUU7Ozs7YUFDRjs7Ozs7O0dBQ0o7Ozs7V0FDRjs7Ozs7O0VBRUosWUFBWSx3QkFBQyxXQUFEO0dBQVcsTUFBTTtHQUFpQjtHQUFPLGVBQWUsWUFBWSxJQUFJO0dBQUcsVUFBVTtFQUFhOzs7OztDQUMvRzs7Ozs7QUFFTjs7Ozs7QUFFQSxTQUFTLFVBQVUsRUFBRSxNQUFNLE9BQU8sU0FBUyxZQUFZO0NBQ3JELE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQ1gsS0FBSyxhQUFhLG1CQUFtQjtJQUNwQzs7OztjQUNKLHdCQUFDLFVBQUQ7S0FBUSxTQUFTO0tBQVMsV0FBVTtlQUNsQyx3QkFBQyxPQUFEO01BQUssT0FBTTtNQUFLLFFBQU87TUFBSyxTQUFRO01BQVksTUFBSztNQUFPLE9BQU07Z0JBQ2hFLHdCQUFDLFFBQUQ7T0FBTSxHQUFFO09BQXVCLFFBQU87T0FBZSxhQUFZO09BQUksZUFBYztPQUFRLGdCQUFlO01BQVE7Ozs7O0tBQy9HOzs7OztJQUNDOzs7O1lBQ0w7Ozs7O2FBRUwsd0JBQUMsUUFBRDtJQUFnQjtjQUFoQjtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQW9FO01BQWE7Ozs7Z0JBQ2xHLHdCQUFDLFNBQUQ7T0FBTyxNQUFLO09BQVMsY0FBYyxLQUFLLFVBQVU7T0FBSTtPQUFTLFdBQVU7TUFBbU47Ozs7Y0FDelI7Ozs7OztLQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBb0U7T0FBc0I7Ozs7aUJBQzNHLHdCQUFDLFNBQUQ7UUFBTyxNQUFLO1FBQWtCLGNBQWMsS0FBSyxtQkFBbUI7UUFBSTtRQUFTLFdBQVU7T0FBbU47Ozs7ZUFDM1M7Ozs7O2dCQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQW9FO09BQXVCOzs7O2lCQUM1Ryx3QkFBQyxTQUFEO1FBQU8sTUFBSztRQUFtQixjQUFjLEtBQUssb0JBQW9CO1FBQUksV0FBVTtPQUFtTjs7OztlQUNwUzs7Ozs7Y0FDRjs7Ozs7O0tBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBb0U7TUFBeUI7Ozs7Z0JBQzlHLHdCQUFDLFNBQUQ7T0FBTyxNQUFLO09BQVMsTUFBSztPQUFRLGNBQWMsS0FBSyxVQUFVO09BQUk7T0FBUyxXQUFVO01BQW1OOzs7O2NBQ3RTOzs7Ozs7S0FFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFvRTtNQUFVOzs7O2dCQUMvRix3QkFBQyxVQUFEO09BQVEsTUFBSztPQUFZLGNBQWMsS0FBSyxjQUFjLE1BQU0sU0FBUyxJQUFJLE1BQU0sRUFBRSxDQUFDLFFBQVE7T0FBUSxXQUFVO2lCQUM3RyxNQUFNLEtBQUssUUFDVix3QkFBQyxVQUFEO1FBQXdCLE9BQU8sSUFBSTtrQkFBbkM7U0FDRyxJQUFJO1NBQU87U0FBRyxJQUFJO1NBQU07UUFDbkI7VUFGSyxJQUFJOzs7O2NBRVQsQ0FDVDtNQUNLOzs7O2NBQ0w7Ozs7OztLQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsVUFBRDtPQUFRLE1BQUs7T0FBUyxTQUFTO09BQVMsV0FBVTtpQkFBb0w7TUFFOU47Ozs7Z0JBQ1Isd0JBQUMsVUFBRDtPQUFRLE1BQUs7T0FBUyxXQUFVO2lCQUE0RztNQUVwSTs7OztjQUNMOzs7Ozs7SUFDRDs7Ozs7V0FDSDs7Ozs7O0NBQ0Y7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiaW5kZXguanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCdcbmltcG9ydCBhcGkgZnJvbSAnLi4vLi4vc2VydmljZXMvYXBpJ1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uL2NvbnRleHQvQXV0aENvbnRleHQnXG5pbXBvcnQgeyBOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFVzZXJzUGFnZSgpIHtcbiAgY29uc3QgeyBzZXNzaW9uLCBhdXRoQ29uZmlnLCBzaG93RXJyb3IsIHNob3dNZXNzYWdlIH0gPSB1c2VBdXRoKClcbiAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW3JvbGVzLCBzZXRSb2xlc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFt1c2VyRm9ybSwgc2V0VXNlckZvcm1dID0gdXNlU3RhdGUobnVsbClcblxuICBjb25zdCBsb2FkRGF0YSA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRMb2FkaW5nKHRydWUpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IFt7IGRhdGE6IHVzZXJzRGF0YSB9LCB7IGRhdGE6IHJvbGVzRGF0YSB9XSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgICAgYXBpLmdldCgnL2F1dGgvdXNlcnMnLCBhdXRoQ29uZmlnKCkpLFxuICAgICAgICBhcGkuZ2V0KCcvYXV0aC9yb2xlcycsIGF1dGhDb25maWcoKSksXG4gICAgICBdKVxuICAgICAgc2V0VXNlcnModXNlcnNEYXRhKVxuICAgICAgc2V0Um9sZXMocm9sZXNEYXRhKVxuICAgIH0gY2F0Y2ggKHJlcXVlc3RFcnJvcikge1xuICAgICAgc2hvd0Vycm9yKHJlcXVlc3RFcnJvcilcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0TG9hZGluZyhmYWxzZSlcbiAgICB9XG4gIH1cblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChzZXNzaW9uPy51c3VhcmlvPy5zaWdsYV9yb2wgPT09ICdBRE0nKSB7XG4gICAgICBsb2FkRGF0YSgpXG4gICAgfVxuICB9LCBbc2Vzc2lvbl0pXG5cbiAgaWYgKHNlc3Npb24/LnVzdWFyaW8/LnNpZ2xhX3JvbCAhPT0gJ0FETScpIHtcbiAgICByZXR1cm4gPE5hdmlnYXRlIHRvPVwiL2Rhc2hib2FyZFwiIHJlcGxhY2UgLz5cbiAgfVxuXG4gIGNvbnN0IHN1Ym1pdFVzZXIgPSBhc3luYyAoZXZlbnQpID0+IHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGZvcm0gPSBuZXcgRm9ybURhdGEoZXZlbnQuY3VycmVudFRhcmdldClcbiAgICAgIGNvbnN0IHBheWxvYWQgPSBPYmplY3QuZnJvbUVudHJpZXMoZm9ybSlcbiAgICAgIGNvbnN0IHJlcXVlc3QgPSB1c2VyRm9ybS5pZF91c3VhcmlvXG4gICAgICAgID8gYXBpLnB1dChgL2F1dGgvdXNlcnMvJHt1c2VyRm9ybS5pZF91c3VhcmlvfWAsIHBheWxvYWQsIGF1dGhDb25maWcoKSlcbiAgICAgICAgOiBhcGkucG9zdCgnL2F1dGgvdXNlcnMnLCBwYXlsb2FkLCBhdXRoQ29uZmlnKCkpXG4gICAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IHJlcXVlc3RcbiAgICAgIHNldFVzZXJGb3JtKG51bGwpXG4gICAgICBzaG93TWVzc2FnZShkYXRhLm1lbnNhamUpXG4gICAgICBhd2FpdCBsb2FkRGF0YSgpXG4gICAgfSBjYXRjaCAocmVxdWVzdEVycm9yKSB7XG4gICAgICBzaG93RXJyb3IocmVxdWVzdEVycm9yKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGRpc2FibGVVc2VyID0gYXN5bmMgKHVzZXIpID0+IHtcbiAgICBpZiAoIXdpbmRvdy5jb25maXJtKGDCv0VsaW1pbmFyIGEgJHt1c2VyLm5vbWJyZX0gJHt1c2VyLnByaW1lcl9hcGVsbGlkb30/YCkpIHJldHVyblxuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IGFwaS5kZWxldGUoYC9hdXRoL3VzZXJzLyR7dXNlci5pZF91c3VhcmlvfWAsIGF1dGhDb25maWcoKSlcbiAgICAgIHNob3dNZXNzYWdlKGRhdGEubWVuc2FqZSlcbiAgICAgIGF3YWl0IGxvYWREYXRhKClcbiAgICB9IGNhdGNoIChyZXF1ZXN0RXJyb3IpIHtcbiAgICAgIHNob3dFcnJvcihyZXF1ZXN0RXJyb3IpXG4gICAgfVxuICB9XG5cbiAgLy8gTWFwZW8gcsOhcGlkbyBkZSBzaWdsYSBhIG5vbWJyZSBjb21wbGV0byBkZSByb2xcbiAgY29uc3QgZ2V0Um9sTm9tYnJlID0gKHNpZ2xhKSA9PiB7XG4gICAgY29uc3Qgcm9sID0gcm9sZXMuZmluZCgocikgPT4gci5zaWdsYSA9PT0gc2lnbGEpXG4gICAgcmV0dXJuIHJvbCA/IHJvbC5ub21icmUgOiBzaWdsYVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02IGZsZXggZmxleC1jb2wgZ2FwLTMgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIHNtOmp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlXCI+QWRtaW5pc3RyYWNpw7NuIGRlIFVzdWFyaW9zPC9oMj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5HZXN0aW9uYSBsb3MgYWNjZXNvcyB5IHBlcm1pc29zIGRlbCBlcXVpcG8gb3BlcmF0aXZvLjwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxidXR0b24gXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VXNlckZvcm0oe30pfSBcbiAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1sZyBiZy1ibHVlLTYwMCBweC02IHB5LTIuNSB0ZXh0LWNlbnRlciBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIHNoYWRvdy1zbSBob3ZlcjpiZy1ibHVlLTcwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgID5cbiAgICAgICAgICArIE51ZXZvIFVzdWFyaW9cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gcC03IHNoYWRvdy1zbVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTYgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZVwiPkxpc3RhIGRlIFVzdWFyaW9zPC9oND5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyb3VuZGVkLWZ1bGwgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHB4LTMgcHktMSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAge3VzZXJzLmxlbmd0aH0gdXN1YXJpb3NcbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctZnVsbCBvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRhYmxlLWF1dG9cIj5cbiAgICAgICAgICAgIDx0aGVhZD5cbiAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIHRleHQtbGVmdFwiPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS00IHByLTQgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlVzdWFyaW88L3RoPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS00IHB4LTQgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlJvbDwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTQgcHgtNCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+RXN0YWRvPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktNCBweC00IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5BY2Npb25lczwvdGg+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICB7bG9hZGluZyA/IChcbiAgICAgICAgICAgICAgICA8dHI+PHRkIGNvbFNwYW49XCI0XCIgY2xhc3NOYW1lPVwicHktOCB0ZXh0LWNlbnRlciB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5DYXJnYW5kbyB1c3Vhcmlvcy4uLjwvdGQ+PC90cj5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICB1c2Vycy5tYXAoKHVzZXIpID0+IChcbiAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e3VzZXIuaWRfdXN1YXJpb30gY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gbGFzdDpib3JkZXItMCBob3ZlcjpiZy1zbGF0ZS01MCBkYXJrOmhvdmVyOmJnLVsjMzEzRDRBXS81MCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBwci00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtMTAgdy0xMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLWJsdWUtMTAwIGRhcms6YmctYmx1ZS05MDAvMzAgdGV4dC1zbSBmb250LWJvbGQgdGV4dC1ibHVlLTYwMCBkYXJrOnRleHQtYmx1ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3VzZXIubm9tYnJlLnNsaWNlKDAsMSkudG9VcHBlckNhc2UoKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGg1IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlXCI+e3VzZXIubm9tYnJlfSB7dXNlci5wcmltZXJfYXBlbGxpZG99PC9oNT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+e3VzZXIuY29ycmVvfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBweC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Z2V0Um9sTm9tYnJlKHVzZXIuc2lnbGFfcm9sKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS00IHB4LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtOTAwLzIwIHB4LTIuNSBweS0xIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaC0xLjUgdy0xLjUgcm91bmRlZC1mdWxsIGJnLWVtZXJhbGQtNTAwXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgQWN0aXZvXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktNCBweC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRVc2VyRm9ybSh1c2VyKX0gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtYmx1ZS02MDAgaG92ZXI6dGV4dC1ibHVlLTcwMCBkYXJrOnRleHQtYmx1ZS00MDAgZGFyazpob3Zlcjp0ZXh0LWJsdWUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIEVkaXRhclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGRpc2FibGVVc2VyKHVzZXIpfSBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1yZWQtNjAwIGhvdmVyOnRleHQtcmVkLTcwMCBkYXJrOnRleHQtcmVkLTQwMCBkYXJrOmhvdmVyOnRleHQtcmVkLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICBFbGltaW5hclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICkpXG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHt1c2VyRm9ybSAmJiA8VXNlck1vZGFsIHVzZXI9e3VzZXJGb3JtfSByb2xlcz17cm9sZXN9IG9uQ2xvc2U9eygpID0+IHNldFVzZXJGb3JtKG51bGwpfSBvblN1Ym1pdD17c3VibWl0VXNlcn0gLz59XG4gICAgPC8+XG4gIClcbn1cblxuZnVuY3Rpb24gVXNlck1vZGFsKHsgdXNlciwgcm9sZXMsIG9uQ2xvc2UsIG9uU3VibWl0IH0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei1bOTk5OTldIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLXNsYXRlLTkwMC81MCBiYWNrZHJvcC1ibHVyLXNtIHB4LTQgcHktNVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXctbGcgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIGJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIHAtOCBzaGFkb3ctMnhsXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICB7dXNlci5pZF91c3VhcmlvID8gJ0VkaXRhciBVc3VhcmlvJyA6ICdDcmVhciBVc3VhcmlvJ31cbiAgICAgICAgICA8L2gzPlxuICAgICAgICAgIDxidXR0b24gb25DbGljaz17b25DbG9zZX0gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS02MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgPHN2ZyB3aWR0aD1cIjI0XCIgaGVpZ2h0PVwiMjRcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cIm5vbmVcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+XG4gICAgICAgICAgICAgIDxwYXRoIGQ9XCJNMTggNkw2IDE4TTYgNkwxOCAxOFwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMlwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIi8+XG4gICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIFxuICAgICAgICA8Zm9ybSBvblN1Ym1pdD17b25TdWJtaXR9PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1iLTIgYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+Tm9tYnJlPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dCBuYW1lPVwibm9tYnJlXCIgZGVmYXVsdFZhbHVlPXt1c2VyLm5vbWJyZSB8fCAnJ30gcmVxdWlyZWQgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgZGFyazpib3JkZXItWyMzMTNENEFdIGJnLXRyYW5zcGFyZW50IGRhcms6YmctWyMxQTIyMkNdIHB4LTQgcHktMi41IHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZSBvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWJsdWUtNjAwIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLWJsdWUtNjAwXCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICBcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTQgZmxleCBnYXAtNFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1iLTIgYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+UHJpbWVyIEFwZWxsaWRvPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGlucHV0IG5hbWU9XCJwcmltZXJfYXBlbGxpZG9cIiBkZWZhdWx0VmFsdWU9e3VzZXIucHJpbWVyX2FwZWxsaWRvIHx8ICcnfSByZXF1aXJlZCBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gYmctdHJhbnNwYXJlbnQgZGFyazpiZy1bIzFBMjIyQ10gcHgtNCBweS0yLjUgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlIG91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYmx1ZS02MDAgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYmx1ZS02MDBcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibWItMiBibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5TZWd1bmRvIEFwZWxsaWRvPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGlucHV0IG5hbWU9XCJzZWd1bmRvX2FwZWxsaWRvXCIgZGVmYXVsdFZhbHVlPXt1c2VyLnNlZ3VuZG9fYXBlbGxpZG8gfHwgJyd9IGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBiZy10cmFuc3BhcmVudCBkYXJrOmJnLVsjMUEyMjJDXSBweC00IHB5LTIuNSB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGUgb3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1ibHVlLTYwMCBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1ibHVlLTYwMFwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1iLTIgYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+Q29ycmVvIEVsZWN0csOzbmljbzwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXQgbmFtZT1cImNvcnJlb1wiIHR5cGU9XCJlbWFpbFwiIGRlZmF1bHRWYWx1ZT17dXNlci5jb3JyZW8gfHwgJyd9IHJlcXVpcmVkIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBiZy10cmFuc3BhcmVudCBkYXJrOmJnLVsjMUEyMjJDXSBweC00IHB5LTIuNSB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGUgb3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1ibHVlLTYwMCBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1ibHVlLTYwMFwiIC8+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLThcIj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJtYi0yIGJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlJvbDwvbGFiZWw+XG4gICAgICAgICAgICA8c2VsZWN0IG5hbWU9XCJzaWdsYV9yb2xcIiBkZWZhdWx0VmFsdWU9e3VzZXIuc2lnbGFfcm9sIHx8IChyb2xlcy5sZW5ndGggPiAwID8gcm9sZXNbMF0uc2lnbGEgOiAnT1BFJyl9IGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBiZy10cmFuc3BhcmVudCBkYXJrOmJnLVsjMUEyMjJDXSBweC00IHB5LTIuNSB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGUgb3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1ibHVlLTYwMCBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1ibHVlLTYwMFwiPlxuICAgICAgICAgICAgICB7cm9sZXMubWFwKChyb2wpID0+IChcbiAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17cm9sLnNpZ2xhfSB2YWx1ZT17cm9sLnNpZ2xhfT5cbiAgICAgICAgICAgICAgICAgIHtyb2wubm9tYnJlfSAoe3JvbC5zaWdsYX0pXG4gICAgICAgICAgICAgICAgPC9vcHRpb24+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTRcIj5cbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e29uQ2xvc2V9IGNsYXNzTmFtZT1cImZsZXgtMSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBweS0yLjUgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBob3ZlcjpiZy1zbGF0ZS01MCBkYXJrOmhvdmVyOmJnLVsjMzEzRDRBXSB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICBDYW5jZWxhclxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9XCJmbGV4LTEgcm91bmRlZC1sZyBiZy1ibHVlLTYwMCBweS0yLjUgZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBzaGFkb3ctc20gaG92ZXI6YmctYmx1ZS03MDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgR3VhcmRhciBVc3VhcmlvXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9mb3JtPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdfQ==