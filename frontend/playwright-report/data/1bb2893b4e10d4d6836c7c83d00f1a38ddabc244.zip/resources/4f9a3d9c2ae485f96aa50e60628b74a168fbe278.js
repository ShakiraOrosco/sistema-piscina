import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Caja/index.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=41a64c35";
import { monitoringApi } from "/src/services/api.js";
import { useAuth } from "/src/context/AuthContext.jsx";
var _jsxFileName = "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Caja/index.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=41a64c35";
var _s = $RefreshSig$();
// ─── Íconos SVG ───────────────────────────────────────────────────────────────
function IconPlus() {
	return /* @__PURE__ */ _jsxDEV("svg", {
		className: "w-5 h-5",
		fill: "none",
		stroke: "currentColor",
		viewBox: "0 0 24 24",
		children: /* @__PURE__ */ _jsxDEV("path", {
			strokeLinecap: "round",
			strokeLinejoin: "round",
			strokeWidth: "2.5",
			d: "M12 4v16m8-8H4"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 9,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 8,
		columnNumber: 5
	}, this);
}
_c = IconPlus;
function IconTicket() {
	return /* @__PURE__ */ _jsxDEV("svg", {
		className: "w-5 h-5",
		fill: "none",
		stroke: "currentColor",
		viewBox: "0 0 24 24",
		children: /* @__PURE__ */ _jsxDEV("path", {
			strokeLinecap: "round",
			strokeLinejoin: "round",
			strokeWidth: "2",
			d: "M15 5v2m0 4v2m0 4v2M5 5a2 2 0 00-2 2v3a2 2 0 110 4v3a2 2 0 002 2h14a2 2 0 002-2v-3a2 2 0 110-4V7a2 2 0 00-2-2H5z"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 17,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 16,
		columnNumber: 5
	}, this);
}
_c2 = IconTicket;
function IconCheck() {
	return /* @__PURE__ */ _jsxDEV("svg", {
		className: "w-5 h-5",
		fill: "none",
		stroke: "currentColor",
		viewBox: "0 0 24 24",
		children: /* @__PURE__ */ _jsxDEV("path", {
			strokeLinecap: "round",
			strokeLinejoin: "round",
			strokeWidth: "2.5",
			d: "M5 13l4 4L19 7"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 25,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 24,
		columnNumber: 5
	}, this);
}
_c3 = IconCheck;
function IconClock() {
	return /* @__PURE__ */ _jsxDEV("svg", {
		className: "w-4 h-4 text-slate-400",
		fill: "none",
		stroke: "currentColor",
		viewBox: "0 0 24 24",
		children: /* @__PURE__ */ _jsxDEV("path", {
			strokeLinecap: "round",
			strokeLinejoin: "round",
			strokeWidth: "2",
			d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 33,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 32,
		columnNumber: 5
	}, this);
}
_c4 = IconClock;
function IconClose() {
	return /* @__PURE__ */ _jsxDEV("svg", {
		className: "w-6 h-6",
		fill: "none",
		stroke: "currentColor",
		viewBox: "0 0 24 24",
		children: /* @__PURE__ */ _jsxDEV("path", {
			strokeLinecap: "round",
			strokeLinejoin: "round",
			strokeWidth: "2",
			d: "M6 18L18 6M6 6l12 12"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 41,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 40,
		columnNumber: 5
	}, this);
}
_c5 = IconClose;
function IconEye() {
	return /* @__PURE__ */ _jsxDEV("svg", {
		className: "w-4 h-4",
		fill: "none",
		stroke: "currentColor",
		viewBox: "0 0 24 24",
		children: [/* @__PURE__ */ _jsxDEV("path", {
			strokeLinecap: "round",
			strokeLinejoin: "round",
			strokeWidth: "2",
			d: "M15 12a3 3 0 11-6 0 3 3 0 016 0z"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 49,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("path", {
			strokeLinecap: "round",
			strokeLinejoin: "round",
			strokeWidth: "2",
			d: "M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 50,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 48,
		columnNumber: 5
	}, this);
}
_c6 = IconEye;
// ─── Componente Contador con Input Manual ─────────────────────────────────────
function TicketCounter({ label, price, count, onChange, color }) {
	const handleInputChange = (e) => {
		let rawVal = e.target.value;
		// Limitar a máximo 2 dígitos en el string
		if (rawVal.length > 2) {
			rawVal = rawVal.slice(0, 2);
		}
		const val = parseInt(rawVal, 10);
		if (isNaN(val) || val < 0) {
			onChange(0);
		} else {
			onChange(Math.min(99, val));
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `bg-white rounded-2xl border ${color.border} p-5 flex flex-col justify-between shadow-sm transition-all duration-200 hover:shadow-md`,
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center justify-between mb-3",
			children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
				className: "text-xs font-bold uppercase tracking-wider text-slate-400",
				children: label
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: `text-2xl font-black ${color.text}`,
				children: ["Bs. ", price]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 76,
				columnNumber: 11
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 74,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: `w-10 h-10 rounded-xl ${color.bg} flex items-center justify-center`,
				children: /* @__PURE__ */ _jsxDEV(IconTicket, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 79,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 73,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center justify-between gap-2 mt-2",
			children: [
				/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => onChange(Math.max(0, count - 1)),
					className: "w-10 h-10 rounded-xl bg-slate-100 text-slate-600 font-bold text-xl hover:bg-slate-200 active:scale-95 transition-all flex items-center justify-center",
					children: "-"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 83,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("input", {
					type: "number",
					min: "0",
					max: "99",
					value: count === 0 ? "" : count,
					onChange: handleInputChange,
					onKeyDown: (e) => {
						if ([
							"e",
							"E",
							"+",
							"-",
							"."
						].includes(e.key)) {
							e.preventDefault();
						}
					},
					onInput: (e) => {
						if (e.target.value.length > 2) {
							e.target.value = e.target.value.slice(0, 2);
						}
					},
					placeholder: "0",
					className: "w-16 h-10 text-center font-black text-xl text-slate-800 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 92,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => onChange(Math.min(99, count + 1)),
					className: `w-10 h-10 rounded-xl ${color.bg} ${color.text} font-bold text-xl hover:opacity-80 active:scale-95 transition-all flex items-center justify-center`,
					children: "+"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 112,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 82,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 72,
		columnNumber: 5
	}, this);
}
_c7 = TicketCounter;
// ─── Fila de historial ────────────────────────────────────────────────────────
function HistorialRow({ registro, index, onVerDetalle }) {
	let horaStr = "—";
	if (registro.hora_entrada) {
		if (typeof registro.hora_entrada === "string" && registro.hora_entrada.includes("T")) {
			horaStr = registro.hora_entrada.split("T")[1].substring(0, 8);
		} else {
			horaStr = new Date(registro.hora_entrada).toLocaleTimeString([], {
				hour: "2-digit",
				minute: "2-digit",
				second: "2-digit",
				hour12: false
			});
		}
	}
	return /* @__PURE__ */ _jsxDEV("tr", {
		className: index % 2 === 0 ? "bg-white" : "bg-slate-50",
		children: [
			/* @__PURE__ */ _jsxDEV("td", {
				className: "px-5 py-4 text-sm text-slate-700 font-semibold whitespace-nowrap",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-1.5",
					children: [/* @__PURE__ */ _jsxDEV(IconClock, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 139,
						columnNumber: 11
					}, this), horaStr]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 138,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 137,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("td", {
				className: "px-5 py-4 text-center",
				children: /* @__PURE__ */ _jsxDEV("span", {
					className: "inline-flex items-center justify-center px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-sm font-bold border border-blue-100",
					children: [registro.total_personas, " pers."]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 144,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 143,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("td", {
				className: "px-5 py-4 text-right font-black text-slate-800 text-base",
				children: ["Bs. ", parseFloat(registro.total_recaudado).toFixed(2)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 148,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("td", {
				className: "px-5 py-4 text-center",
				children: /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => onVerDetalle(registro),
					className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-blue-50 text-slate-600 hover:text-blue-600 font-bold text-xs transition-all border border-slate-200 hover:border-blue-200",
					children: [/* @__PURE__ */ _jsxDEV(IconEye, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 156,
						columnNumber: 11
					}, this), "Ver Detalle"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 152,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 151,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 136,
		columnNumber: 5
	}, this);
}
_c8 = HistorialRow;
// ─── Funciones Auxiliares para Fechas ─────────────────────────────────────────
function getHoyISO() {
	const now = new Date();
	const year = now.getFullYear();
	const month = String(now.getMonth() + 1).padStart(2, "0");
	const day = String(now.getDate()).padStart(2, "0");
	return `${year}-${month}-${day}`;
}
function formatearFechaLegible(fechaStr) {
	if (!fechaStr) return "";
	const partes = fechaStr.split("-");
	if (partes.length !== 3) return fechaStr;
	const [y, m, d] = partes.map(Number);
	const fecha = new Date(y, m - 1, d);
	return fecha.toLocaleDateString("es-ES", {
		weekday: "long",
		year: "numeric",
		month: "long",
		day: "numeric"
	});
}
// ─── Página Principal ─────────────────────────────────────────────────────────
export default function CajaPage() {
	_s();
	const { session } = useAuth();
	const [tarifa15, setTarifa15] = useState(0);
	const [tarifa20, setTarifa20] = useState(0);
	const [observaciones, setObservaciones] = useState("");
	const [loading, setLoading] = useState(false);
	const [historial, setHistorial] = useState([]);
	const [resumen, setResumen] = useState(null);
	const [notification, setNotification] = useState(null);
	const [loadingHistorial, setLoadingHistorial] = useState(true);
	const [showModal, setShowModal] = useState(false);
	const [registroDetalle, setRegistroDetalle] = useState(null);
	// Filtro por fecha (por defecto hoy)
	const [fechaFiltro, setFechaFiltro] = useState(getHoyISO());
	const esHoy = fechaFiltro === getHoyISO();
	// Hora actual en tiempo real
	const [horaActual, setHoraActual] = useState(new Date());
	useEffect(() => {
		const timer = setInterval(() => setHoraActual(new Date()), 1e3);
		return () => clearInterval(timer);
	}, []);
	const fetchHistorial = useCallback(async (fecha = fechaFiltro) => {
		try {
			setLoadingHistorial(true);
			const res = await monitoringApi.get("/api/caja/historial", { params: { fecha } });
			if (res.data) {
				setHistorial(res.data.registros || []);
				setResumen(res.data.resumen || null);
			}
		} catch {
			setNotification({
				type: "error",
				msg: "No se pudo cargar el historial de la fecha seleccionada"
			});
		} finally {
			setLoadingHistorial(false);
		}
	}, [fechaFiltro]);
	useEffect(() => {
		fetchHistorial(fechaFiltro);
	}, [fechaFiltro, fetchHistorial]);
	const totalPersonas = tarifa15 + tarifa20;
	const totalRecaudado = tarifa15 * 15 + tarifa20 * 20;
	const handleRegister = async (e) => {
		e.preventDefault();
		if (totalPersonas === 0) {
			setNotification({
				type: "error",
				msg: "Debe ingresar al menos 1 persona"
			});
			return;
		}
		setLoading(true);
		try {
			await monitoringApi.post("/api/caja/registro", {
				cantidad_tarifa_15: tarifa15,
				cantidad_tarifa_20: tarifa20,
				id_usuario: session?.usuario?.id_usuario || null,
				observaciones: observaciones.trim() || null
			});
			setNotification({
				type: "success",
				msg: `✓ Registrado: ${totalPersonas} persona(s) — Bs. ${totalRecaudado.toFixed(2)}`
			});
			setTarifa15(0);
			setTarifa20(0);
			setObservaciones("");
			setShowModal(false);
			// Si estaba en otra fecha, volver a hoy para visualizar la venta realizada
			const hoy = getHoyISO();
			if (fechaFiltro !== hoy) {
				setFechaFiltro(hoy);
			} else {
				fetchHistorial(hoy);
			}
		} catch (err) {
			const msg = err.response?.data?.detail || "Error al registrar entrada";
			setNotification({
				type: "error",
				msg: `✗ ${msg}`
			});
		} finally {
			setLoading(false);
			setTimeout(() => setNotification(null), 4e3);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-50 pb-12",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white border-b border-slate-200 px-6 py-6 shadow-sm",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs font-bold tracking-widest uppercase text-blue-500 mb-1",
							children: "Módulo de Caja"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 280,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("h1", {
							className: "text-2xl font-bold text-slate-800",
							children: "Control de Ingresos y Aforo"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 281,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-sm text-slate-500 mt-0.5",
							children: "Registro de taquilla y cobro de entradas"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 282,
							columnNumber: 13
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 279,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-4",
						children: /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setShowModal(true),
							className: "flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-5 py-3 rounded-xl font-bold text-sm shadow-md shadow-blue-500/20 active:scale-95 transition-all",
							children: [/* @__PURE__ */ _jsxDEV(IconPlus, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 290,
								columnNumber: 15
							}, this), "Registrar Ingreso"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 286,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 285,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 278,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 277,
				columnNumber: 7
			}, this),
			notification && /* @__PURE__ */ _jsxDEV("div", {
				className: `max-w-6xl mx-auto px-4 py-3 mt-4 rounded-xl font-semibold text-sm flex items-center gap-3 shadow-md
          ${notification.type === "success" ? "bg-emerald-50 border border-emerald-200 text-emerald-700" : "bg-red-50 border border-red-200 text-red-700"}`,
				children: [notification.type === "success" ? /* @__PURE__ */ _jsxDEV(IconCheck, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 305,
					columnNumber: 46
				}, this) : "⚠", notification.msg]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 299,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "max-w-6xl mx-auto px-6 mt-6",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-wrap items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								htmlFor: "fechaFiltroCaja",
								className: "text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV("svg", {
									className: "w-4 h-4 text-blue-600",
									fill: "none",
									stroke: "currentColor",
									viewBox: "0 0 24 24",
									children: /* @__PURE__ */ _jsxDEV("path", {
										strokeLinecap: "round",
										strokeLinejoin: "round",
										strokeWidth: "2",
										d: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 317,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 316,
									columnNumber: 17
								}, this), "Filtrar por fecha:"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 315,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								id: "fechaFiltroCaja",
								type: "date",
								value: fechaFiltro,
								onChange: (e) => {
									if (e.target.value) setFechaFiltro(e.target.value);
								},
								className: "px-3.5 py-2 rounded-xl border border-slate-300 font-bold text-sm text-slate-800 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all cursor-pointer"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 321,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 314,
							columnNumber: 13
						}, this), !esHoy && /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => setFechaFiltro(getHoyISO()),
							className: "px-3.5 py-2 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-black transition-all border border-blue-200 active:scale-95 flex items-center gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV("svg", {
								className: "w-3.5 h-3.5",
								fill: "none",
								stroke: "currentColor",
								viewBox: "0 0 24 24",
								children: /* @__PURE__ */ _jsxDEV("path", {
									strokeLinecap: "round",
									strokeLinejoin: "round",
									strokeWidth: "2.5",
									d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 339,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 338,
								columnNumber: 17
							}, this), "Volver a Hoy"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 333,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 313,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-bold text-slate-600 capitalize",
							children: formatearFechaLegible(fechaFiltro)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 347,
							columnNumber: 13
						}, this), esHoy ? /* @__PURE__ */ _jsxDEV("span", {
							className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-extrabold bg-emerald-50 text-emerald-700 border border-emerald-200",
							children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-emerald-500 animate-pulse" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 352,
								columnNumber: 17
							}, this), "Hoy"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 351,
							columnNumber: 15
						}, this) : /* @__PURE__ */ _jsxDEV("span", {
							className: "inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-600 border border-slate-200",
							children: "Historial Pasado"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 356,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 346,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 312,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 311,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "max-w-6xl mx-auto px-6 mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white p-5 rounded-2xl border border-slate-200 shadow-sm",
						children: [/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs font-bold uppercase tracking-wider text-slate-400",
							children: esHoy ? "Total Taquilla Hoy" : "Total Bañistas"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 367,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("h3", {
							className: "text-3xl font-black text-slate-800 mt-2",
							children: [
								resumen?.total_personas ?? 0,
								" ",
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-sm font-semibold text-slate-400",
									children: "pers."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 371,
									columnNumber: 44
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 370,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 366,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white p-5 rounded-2xl border border-slate-200 shadow-sm",
						children: [/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs font-bold uppercase tracking-wider text-blue-500",
							children: "Tarifa 15 Bs"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 375,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("h3", {
							className: "text-3xl font-black text-blue-600 mt-2",
							children: [
								resumen?.total_tarifa_15 ?? 0,
								" ",
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-sm font-semibold text-slate-400",
									children: "pers."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 377,
									columnNumber: 45
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 376,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 374,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white p-5 rounded-2xl border border-slate-200 shadow-sm",
						children: [/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs font-bold uppercase tracking-wider text-emerald-500",
							children: "Tarifa 20 Bs"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 381,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("h3", {
							className: "text-3xl font-black text-emerald-600 mt-2",
							children: [
								resumen?.total_tarifa_20 ?? 0,
								" ",
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-sm font-semibold text-slate-400",
									children: "pers."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 383,
									columnNumber: 45
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 382,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 380,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-gradient-to-br from-emerald-500 to-emerald-600 text-white p-5 rounded-2xl shadow-md",
						children: [/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs font-bold uppercase tracking-wider opacity-80",
							children: "Total Recaudado"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 387,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("h3", {
							className: "text-3xl font-black mt-2",
							children: ["Bs. ", parseFloat(resumen?.total_recaudado ?? 0).toFixed(2)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 388,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 386,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 365,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "max-w-6xl mx-auto px-6 mt-8",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-wrap items-center justify-between px-6 py-4 border-b border-slate-100 gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ _jsxDEV("h2", {
								className: "text-base font-bold text-slate-800 flex items-center gap-2",
								children: /* @__PURE__ */ _jsxDEV("span", { children: "👥 Registros de Taquilla" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 402,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 401,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "rounded-full bg-blue-50 text-blue-700 border border-blue-100 px-3 py-0.5 text-xs font-bold",
								children: [
									historial.length,
									" ",
									historial.length === 1 ? "registro" : "registros"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 404,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 400,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => fetchHistorial(fechaFiltro),
								className: "text-xs font-bold text-slate-600 hover:text-blue-600 flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-all active:scale-95",
								title: "Actualizar datos",
								children: [/* @__PURE__ */ _jsxDEV("svg", {
									className: "w-3.5 h-3.5",
									fill: "none",
									stroke: "currentColor",
									viewBox: "0 0 24 24",
									children: /* @__PURE__ */ _jsxDEV("path", {
										strokeLinecap: "round",
										strokeLinejoin: "round",
										strokeWidth: "2",
										d: "M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 416,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 415,
									columnNumber: 17
								}, this), "Actualizar"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 410,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold text-slate-400",
								children: esHoy ? "Jornada de Hoy" : `Fecha: ${fechaFiltro}`
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 420,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 409,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 399,
						columnNumber: 11
					}, this), loadingHistorial ? /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-center py-16",
						children: /* @__PURE__ */ _jsxDEV("svg", {
							className: "animate-spin w-8 h-8 text-blue-500",
							fill: "none",
							viewBox: "0 0 24 24",
							children: [/* @__PURE__ */ _jsxDEV("circle", {
								className: "opacity-25",
								cx: "12",
								cy: "12",
								r: "10",
								stroke: "currentColor",
								strokeWidth: "4"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 429,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("path", {
								className: "opacity-75",
								fill: "currentColor",
								d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 430,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 428,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 427,
						columnNumber: 13
					}, this) : historial.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
						className: "text-center py-16",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-center w-16 h-16 rounded-full bg-slate-100 mx-auto mb-4 text-slate-400",
								children: /* @__PURE__ */ _jsxDEV(IconTicket, {}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 436,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 435,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-slate-700 font-bold",
								children: esHoy ? "Sin registros de taquilla en esta jornada" : `Sin registros de taquilla para el ${fechaFiltro}`
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 438,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-slate-400 text-sm mt-1",
								children: esHoy ? "Haz clic en \"+ Registrar Ingreso\" para añadir bañistas" : "Selecciona otra fecha en el filtro superior o presiona \"Volver a Hoy\""
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 441,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 434,
						columnNumber: 13
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ _jsxDEV("table", {
							className: "w-full text-left",
							children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
								className: "bg-slate-50 border-b border-slate-100",
								children: [
									/* @__PURE__ */ _jsxDEV("th", {
										className: "px-5 py-3.5 text-xs font-bold uppercase tracking-wider text-slate-400",
										children: "Hora"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 452,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "px-5 py-3.5 text-xs font-bold uppercase tracking-wider text-slate-400 text-center",
										children: "Total Personas"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 453,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "px-5 py-3.5 text-xs font-bold uppercase tracking-wider text-slate-400 text-right",
										children: "Monto Recaudado"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 454,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "px-5 py-3.5 text-xs font-bold uppercase tracking-wider text-slate-400 text-center",
										children: "Acciones"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 455,
										columnNumber: 21
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 451,
								columnNumber: 19
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 450,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("tbody", {
								className: "divide-y divide-slate-50",
								children: historial.map((reg, i) => /* @__PURE__ */ _jsxDEV(HistorialRow, {
									registro: reg,
									index: i,
									onVerDetalle: setRegistroDetalle
								}, reg.id_registro, false, {
									fileName: _jsxFileName,
									lineNumber: 460,
									columnNumber: 21
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 458,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 449,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 448,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 396,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 395,
				columnNumber: 7
			}, this),
			showModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-[9999] flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-slate-100 relative max-h-[90vh] overflow-y-auto",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between pb-4 border-b border-slate-100 mb-5",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-xl font-bold text-slate-800",
							children: "Registrar Nuevo Ingreso"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 477,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400",
							children: "Selecciona o escribe la cantidad de entradas vendidas"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 478,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 476,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setShowModal(false),
							className: "w-9 h-9 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center transition-all",
							children: /* @__PURE__ */ _jsxDEV(IconClose, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 484,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 480,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 475,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleRegister,
						className: "space-y-6",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
								children: [/* @__PURE__ */ _jsxDEV(TicketCounter, {
									label: "Tarifa 15 Bs",
									price: 15,
									count: tarifa15,
									onChange: setTarifa15,
									color: {
										border: "border-blue-200",
										text: "text-blue-600",
										bg: "bg-blue-50"
									}
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 491,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV(TicketCounter, {
									label: "Tarifa 20 Bs",
									price: 20,
									count: tarifa20,
									onChange: setTarifa20,
									color: {
										border: "border-emerald-200",
										text: "text-emerald-600",
										bg: "bg-emerald-50"
									}
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 502,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 490,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs font-bold uppercase tracking-wider text-slate-400 mb-2",
								children: "Atajos Rápidos"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 517,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 sm:grid-cols-4 gap-2",
								children: [
									{
										label: "1 adulto",
										t15: 0,
										t20: 1
									},
									{
										label: "1 niño",
										t15: 1,
										t20: 0
									},
									{
										label: "Pareja (2×20)",
										t15: 0,
										t20: 2
									},
									{
										label: "Familia (2×20 + 2×15)",
										t15: 2,
										t20: 2
									}
								].map(({ label, t15, t20 }) => /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setTarifa15(t15);
										setTarifa20(t20);
									},
									className: "px-3 py-2 rounded-xl border border-slate-200 hover:border-blue-400 hover:bg-blue-50/50 text-xs font-semibold text-slate-600 text-center transition-all",
									children: label
								}, label, false, {
									fileName: _jsxFileName,
									lineNumber: 525,
									columnNumber: 21
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 518,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 516,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1",
								children: "Observaciones (opcional)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 539,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								placeholder: "Ej: Grupo escolar, pago con QR, etc.",
								value: observaciones,
								onChange: (e) => setObservaciones(e.target.value),
								className: "w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 542,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 538,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-50 p-4 rounded-2xl flex items-center justify-between border border-slate-200/60",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-400 font-bold uppercase",
									children: "Total a pagar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 554,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-2xl font-black text-emerald-600",
									children: ["Bs. ", totalRecaudado.toFixed(2)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 555,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 553,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "text-right",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-400 font-bold uppercase",
										children: "Personas"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 558,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xl font-bold text-slate-700",
										children: [totalPersonas, " pers."]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 559,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 557,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 552,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3 pt-2",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setShowModal(false),
									className: "w-1/3 py-3 rounded-xl border border-slate-200 text-slate-600 font-bold text-sm hover:bg-slate-100 transition-all",
									children: "Cancelar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 564,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "submit",
									disabled: loading || totalPersonas === 0,
									className: "w-2/3 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold text-sm shadow-md shadow-blue-500/20 transition-all flex items-center justify-center gap-2",
									children: loading ? "Guardando..." : "Confirmar e Inscribir"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 571,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 563,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 488,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 472,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 471,
				columnNumber: 9
			}, this),
			registroDetalle && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-[9999] flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 relative",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between pb-4 border-b border-slate-100 mb-4",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-lg font-bold text-slate-800",
								children: "Detalles del Registro"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 590,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-400",
								children: ["Hora: ", typeof registroDetalle.hora_entrada === "string" && registroDetalle.hora_entrada.includes("T") ? registroDetalle.hora_entrada.split("T")[1].substring(0, 8) : "—"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 591,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 589,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setRegistroDetalle(null),
								className: "w-8 h-8 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center transition-all",
								children: /* @__PURE__ */ _jsxDEV(IconClose, {}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 599,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 595,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 588,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between p-3 rounded-xl bg-blue-50/70 border border-blue-100",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-sm font-semibold text-blue-700",
										children: "Entradas 15 Bs"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 605,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-base text-blue-800",
										children: [registroDetalle.cantidad_tarifa_15, " personas"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 606,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 604,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between p-3 rounded-xl bg-emerald-50/70 border border-emerald-100",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-sm font-semibold text-emerald-700",
										children: "Entradas 20 Bs"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 610,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-base text-emerald-800",
										children: [registroDetalle.cantidad_tarifa_20, " personas"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 611,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 609,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-sm font-semibold text-slate-600",
										children: "Total Personas"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 615,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-base text-slate-800",
										children: [registroDetalle.total_personas, " pers."]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 616,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 614,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between p-3 rounded-xl bg-slate-900 text-white",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-sm font-semibold",
										children: "Total Recaudado"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 620,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-black text-lg",
										children: ["Bs. ", parseFloat(registroDetalle.total_recaudado).toFixed(2)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 621,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 619,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "pt-2",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs font-bold uppercase tracking-wider text-slate-400 mb-1",
										children: "Observaciones"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 625,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "p-3 rounded-xl bg-slate-50 border border-slate-200 text-sm text-slate-700 italic",
										children: registroDetalle.observaciones || "Sin observaciones registradas"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 626,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 624,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 603,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setRegistroDetalle(null),
							className: "w-full mt-6 py-3 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-bold text-sm transition-all",
							children: "Cerrar"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 632,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 587,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 586,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 275,
		columnNumber: 5
	}, this);
}
_s(CajaPage, "gLw6ODqU6KTBqsfFn9qPYQ2ACzI=", false, function() {
	return [useAuth];
});
_c9 = CajaPage;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9;
$RefreshReg$(_c, "IconPlus");
$RefreshReg$(_c2, "IconTicket");
$RefreshReg$(_c3, "IconCheck");
$RefreshReg$(_c4, "IconClock");
$RefreshReg$(_c5, "IconClose");
$RefreshReg$(_c6, "IconEye");
$RefreshReg$(_c7, "TicketCounter");
$RefreshReg$(_c8, "HistorialRow");
$RefreshReg$(_c9, "CajaPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Caja/index.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Caja/index.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Caja/index.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Caja/index.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFdBQVcsbUJBQW1CO0FBQ2pELFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsZUFBZTs7Ozs7QUFHeEIsU0FBUyxXQUFXO0NBQ2xCLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7RUFBVSxNQUFLO0VBQU8sUUFBTztFQUFlLFNBQVE7WUFDakUsd0JBQUMsUUFBRDtHQUFNLGVBQWM7R0FBUSxnQkFBZTtHQUFRLGFBQVk7R0FBTSxHQUFFO0VBQWtCOzs7OztDQUN0Rjs7Ozs7QUFFVDs7QUFFQSxTQUFTLGFBQWE7Q0FDcEIsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtFQUFVLE1BQUs7RUFBTyxRQUFPO0VBQWUsU0FBUTtZQUNqRSx3QkFBQyxRQUFEO0dBQU0sZUFBYztHQUFRLGdCQUFlO0dBQVEsYUFBWTtHQUFJLEdBQUU7RUFBb0g7Ozs7O0NBQ3RMOzs7OztBQUVUOztBQUVBLFNBQVMsWUFBWTtDQUNuQixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO0VBQVUsTUFBSztFQUFPLFFBQU87RUFBZSxTQUFRO1lBQ2pFLHdCQUFDLFFBQUQ7R0FBTSxlQUFjO0dBQVEsZ0JBQWU7R0FBUSxhQUFZO0dBQU0sR0FBRTtFQUFrQjs7Ozs7Q0FDdEY7Ozs7O0FBRVQ7O0FBRUEsU0FBUyxZQUFZO0NBQ25CLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7RUFBeUIsTUFBSztFQUFPLFFBQU87RUFBZSxTQUFRO1lBQ2hGLHdCQUFDLFFBQUQ7R0FBTSxlQUFjO0dBQVEsZ0JBQWU7R0FBUSxhQUFZO0dBQUksR0FBRTtFQUErQzs7Ozs7Q0FDakg7Ozs7O0FBRVQ7O0FBRUEsU0FBUyxZQUFZO0NBQ25CLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7RUFBVSxNQUFLO0VBQU8sUUFBTztFQUFlLFNBQVE7WUFDakUsd0JBQUMsUUFBRDtHQUFNLGVBQWM7R0FBUSxnQkFBZTtHQUFRLGFBQVk7R0FBSSxHQUFFO0VBQXdCOzs7OztDQUMxRjs7Ozs7QUFFVDs7QUFFQSxTQUFTLFVBQVU7Q0FDakIsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtFQUFVLE1BQUs7RUFBTyxRQUFPO0VBQWUsU0FBUTtZQUFuRSxDQUNFLHdCQUFDLFFBQUQ7R0FBTSxlQUFjO0dBQVEsZ0JBQWU7R0FBUSxhQUFZO0dBQUksR0FBRTtFQUFvQzs7OztZQUN6Ryx3QkFBQyxRQUFEO0dBQU0sZUFBYztHQUFRLGdCQUFlO0dBQVEsYUFBWTtHQUFJLEdBQUU7RUFBMkg7Ozs7VUFDN0w7Ozs7OztBQUVUOzs7QUFHQSxTQUFTLGNBQWMsRUFBRSxPQUFPLE9BQU8sT0FBTyxVQUFVLFNBQVM7Q0FDL0QsTUFBTSxxQkFBcUIsTUFBTTtFQUMvQixJQUFJLFNBQVMsRUFBRSxPQUFPOztFQUV0QixJQUFJLE9BQU8sU0FBUyxHQUFHO0dBQ3JCLFNBQVMsT0FBTyxNQUFNLEdBQUcsQ0FBQztFQUM1QjtFQUNBLE1BQU0sTUFBTSxTQUFTLFFBQVEsRUFBRTtFQUMvQixJQUFJLE1BQU0sR0FBRyxLQUFLLE1BQU0sR0FBRztHQUN6QixTQUFTLENBQUM7RUFDWixPQUFPO0dBQ0wsU0FBUyxLQUFLLElBQUksSUFBSSxHQUFHLENBQUM7RUFDNUI7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVcsK0JBQStCLE1BQU0sT0FBTztZQUE1RCxDQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBNkQ7R0FBUzs7OzthQUNuRix3QkFBQyxLQUFEO0lBQUcsV0FBVyx1QkFBdUIsTUFBTTtjQUEzQyxDQUFtRCxRQUFLLEtBQVM7Ozs7O1dBQzlEOzs7O2FBQ0wsd0JBQUMsT0FBRDtJQUFLLFdBQVcsd0JBQXdCLE1BQU0sR0FBRztjQUMvQyx3QkFBQyxZQUFELENBQWE7Ozs7O0dBQ1Y7Ozs7V0FDRjs7Ozs7WUFDTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0Usd0JBQUMsVUFBRDtLQUNFLE1BQUs7S0FDTCxlQUFlLFNBQVMsS0FBSyxJQUFJLEdBQUcsUUFBUSxDQUFDLENBQUM7S0FDOUMsV0FBVTtlQUNYO0lBRU87Ozs7O0lBR1Isd0JBQUMsU0FBRDtLQUNFLE1BQUs7S0FDTCxLQUFJO0tBQ0osS0FBSTtLQUNKLE9BQU8sVUFBVSxJQUFJLEtBQUs7S0FDMUIsVUFBVTtLQUNWLFlBQVksTUFBTTtNQUNoQixJQUFJO09BQUM7T0FBSztPQUFLO09BQUs7T0FBSztNQUFHLENBQUMsQ0FBQyxTQUFTLEVBQUUsR0FBRyxHQUFHO09BQzdDLEVBQUUsZUFBZTtNQUNuQjtLQUNGO0tBQ0EsVUFBVSxNQUFNO01BQ2QsSUFBSSxFQUFFLE9BQU8sTUFBTSxTQUFTLEdBQUc7T0FDN0IsRUFBRSxPQUFPLFFBQVEsRUFBRSxPQUFPLE1BQU0sTUFBTSxHQUFHLENBQUM7TUFDNUM7S0FDRjtLQUNBLGFBQVk7S0FDWixXQUFVO0lBQ1g7Ozs7O0lBRUQsd0JBQUMsVUFBRDtLQUNFLE1BQUs7S0FDTCxlQUFlLFNBQVMsS0FBSyxJQUFJLElBQUksUUFBUSxDQUFDLENBQUM7S0FDL0MsV0FBVyx3QkFBd0IsTUFBTSxHQUFHLEdBQUcsTUFBTSxLQUFLO2VBQzNEO0lBRU87Ozs7O0dBQ0w7Ozs7O1VBQ0Y7Ozs7OztBQUVUOzs7QUFHQSxTQUFTLGFBQWEsRUFBRSxVQUFVLE9BQU8sZ0JBQWdCO0NBQ3ZELElBQUksVUFBVTtDQUNkLElBQUksU0FBUyxjQUFjO0VBQ3pCLElBQUksT0FBTyxTQUFTLGlCQUFpQixZQUFZLFNBQVMsYUFBYSxTQUFTLEdBQUcsR0FBRztHQUNwRixVQUFVLFNBQVMsYUFBYSxNQUFNLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxVQUFVLEdBQUcsQ0FBQztFQUM5RCxPQUFPO0dBQ0wsVUFBVSxJQUFJLEtBQUssU0FBUyxZQUFZLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHO0lBQUUsTUFBTTtJQUFXLFFBQVE7SUFBVyxRQUFRO0lBQVcsUUFBUTtHQUFNLENBQUM7RUFDM0k7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsTUFBRDtFQUFJLFdBQVcsUUFBUSxNQUFNLElBQUksYUFBYTtZQUE5QztHQUNFLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQ1osd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFdBQUQsQ0FBWTs7OztlQUNYLE9BQ0U7Ozs7OztHQUNIOzs7OztHQUNKLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQ1osd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBaEIsQ0FDRyxTQUFTLGdCQUFlLFFBQ3JCOzs7Ozs7R0FDSjs7Ozs7R0FDSix3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUFkLENBQXlFLFFBQ2xFLFdBQVcsU0FBUyxlQUFlLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FDakQ7Ozs7OztHQUNKLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQ1osd0JBQUMsVUFBRDtLQUNFLGVBQWUsYUFBYSxRQUFRO0tBQ3BDLFdBQVU7ZUFGWixDQUlFLHdCQUFDLFNBQUQsQ0FBVTs7OztlQUFDLGFBRUw7Ozs7OztHQUNOOzs7OztFQUNGOzs7Ozs7QUFFUjs7O0FBR0EsU0FBUyxZQUFZO0NBQ25CLE1BQU0sTUFBTSxJQUFJLEtBQUs7Q0FDckIsTUFBTSxPQUFPLElBQUksWUFBWTtDQUM3QixNQUFNLFFBQVEsT0FBTyxJQUFJLFNBQVMsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUcsR0FBRztDQUN4RCxNQUFNLE1BQU0sT0FBTyxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUc7Q0FDakQsT0FBTyxHQUFHLEtBQUssR0FBRyxNQUFNLEdBQUc7QUFDN0I7QUFFQSxTQUFTLHNCQUFzQixVQUFVO0NBQ3ZDLElBQUksQ0FBQyxVQUFVLE9BQU87Q0FDdEIsTUFBTSxTQUFTLFNBQVMsTUFBTSxHQUFHO0NBQ2pDLElBQUksT0FBTyxXQUFXLEdBQUcsT0FBTztDQUNoQyxNQUFNLENBQUMsR0FBRyxHQUFHLEtBQUssT0FBTyxJQUFJLE1BQU07Q0FDbkMsTUFBTSxRQUFRLElBQUksS0FBSyxHQUFHLElBQUksR0FBRyxDQUFDO0NBQ2xDLE9BQU8sTUFBTSxtQkFBbUIsU0FBUztFQUN2QyxTQUFTO0VBQ1QsTUFBTTtFQUNOLE9BQU87RUFDUCxLQUFLO0NBQ1AsQ0FBQztBQUNIOztBQUdBLGVBQWUsU0FBUyxXQUFXOztDQUNqQyxNQUFNLEVBQUUsWUFBWSxRQUFRO0NBQzVCLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxDQUFDO0NBQzFDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxDQUFDO0NBQzFDLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLEVBQUU7Q0FDckQsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLEtBQUs7Q0FDNUMsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsQ0FBQyxDQUFDO0NBQzdDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxJQUFJO0NBQzNDLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLElBQUk7Q0FDckQsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBUyxJQUFJO0NBQzdELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEtBQUs7Q0FDaEQsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxJQUFJOztDQUczRCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxVQUFVLENBQUM7Q0FFMUQsTUFBTSxRQUFRLGdCQUFnQixVQUFVOztDQUd4QyxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxJQUFJLEtBQUssQ0FBQztDQUN2RCxnQkFBZ0I7RUFDZCxNQUFNLFFBQVEsa0JBQWtCLGNBQWMsSUFBSSxLQUFLLENBQUMsR0FBRyxHQUFJO0VBQy9ELGFBQWEsY0FBYyxLQUFLO0NBQ2xDLEdBQUcsQ0FBQyxDQUFDO0NBRUwsTUFBTSxpQkFBaUIsWUFBWSxPQUFPLFFBQVEsZ0JBQWdCO0VBQ2hFLElBQUk7R0FDRixvQkFBb0IsSUFBSTtHQUN4QixNQUFNLE1BQU0sTUFBTSxjQUFjLElBQUksdUJBQXVCLEVBQ3pELFFBQVEsRUFBRSxNQUFNLEVBQ2xCLENBQUM7R0FDRCxJQUFJLElBQUksTUFBTTtJQUNaLGFBQWEsSUFBSSxLQUFLLGFBQWEsQ0FBQyxDQUFDO0lBQ3JDLFdBQVcsSUFBSSxLQUFLLFdBQVcsSUFBSTtHQUNyQztFQUNGLFFBQVE7R0FDTixnQkFBZ0I7SUFBRSxNQUFNO0lBQVMsS0FBSztHQUEwRCxDQUFDO0VBQ25HLFVBQVU7R0FDUixvQkFBb0IsS0FBSztFQUMzQjtDQUNGLEdBQUcsQ0FBQyxXQUFXLENBQUM7Q0FFaEIsZ0JBQWdCO0VBQ2QsZUFBZSxXQUFXO0NBQzVCLEdBQUcsQ0FBQyxhQUFhLGNBQWMsQ0FBQztDQUVoQyxNQUFNLGdCQUFnQixXQUFXO0NBQ2pDLE1BQU0saUJBQWlCLFdBQVcsS0FBSyxXQUFXO0NBRWxELE1BQU0saUJBQWlCLE9BQU8sTUFBTTtFQUNsQyxFQUFFLGVBQWU7RUFDakIsSUFBSSxrQkFBa0IsR0FBRztHQUN2QixnQkFBZ0I7SUFBRSxNQUFNO0lBQVMsS0FBSztHQUFtQyxDQUFDO0dBQzFFO0VBQ0Y7RUFFQSxXQUFXLElBQUk7RUFDZixJQUFJO0dBQ0YsTUFBTSxjQUFjLEtBQUssc0JBQXNCO0lBQzdDLG9CQUFvQjtJQUNwQixvQkFBb0I7SUFDcEIsWUFBWSxTQUFTLFNBQVMsY0FBYztJQUM1QyxlQUFlLGNBQWMsS0FBSyxLQUFLO0dBQ3pDLENBQUM7R0FDRCxnQkFBZ0I7SUFBRSxNQUFNO0lBQVcsS0FBSyxpQkFBaUIsY0FBYyxvQkFBb0IsZUFBZSxRQUFRLENBQUM7R0FBSSxDQUFDO0dBQ3hILFlBQVksQ0FBQztHQUNiLFlBQVksQ0FBQztHQUNiLGlCQUFpQixFQUFFO0dBQ25CLGFBQWEsS0FBSzs7R0FHbEIsTUFBTSxNQUFNLFVBQVU7R0FDdEIsSUFBSSxnQkFBZ0IsS0FBSztJQUN2QixlQUFlLEdBQUc7R0FDcEIsT0FBTztJQUNMLGVBQWUsR0FBRztHQUNwQjtFQUNGLFNBQVMsS0FBSztHQUNaLE1BQU0sTUFBTSxJQUFJLFVBQVUsTUFBTSxVQUFVO0dBQzFDLGdCQUFnQjtJQUFFLE1BQU07SUFBUyxLQUFLLEtBQUs7R0FBTSxDQUFDO0VBQ3BELFVBQVU7R0FDUixXQUFXLEtBQUs7R0FDaEIsaUJBQWlCLGdCQUFnQixJQUFJLEdBQUcsR0FBSTtFQUM5QztDQUNGO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUNFLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFpRTtNQUFpQjs7Ozs7TUFDL0Ysd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQW9DO01BQStCOzs7OztNQUNqRix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBZ0M7TUFBMkM7Ozs7O0tBQ3JGOzs7O2VBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsVUFBRDtPQUNFLGVBQWUsYUFBYSxJQUFJO09BQ2hDLFdBQVU7aUJBRlosQ0FJRSx3QkFBQyxVQUFELENBQVc7Ozs7aUJBQUMsbUJBRU47Ozs7OztLQUNMOzs7O2FBQ0Y7Ozs7OztHQUNGOzs7OztHQUdKLGdCQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFXO1lBQ1osYUFBYSxTQUFTLFlBQ3BCLDZEQUNBO2NBSE4sQ0FNRyxhQUFhLFNBQVMsWUFBWSx3QkFBQyxXQUFELENBQVk7Ozs7ZUFBSSxLQUNsRCxhQUFhLEdBQ1g7Ozs7OztHQUlQLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1FBQU8sU0FBUTtRQUFrQixXQUFVO2tCQUEzQyxDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO1NBQXdCLE1BQUs7U0FBTyxRQUFPO1NBQWUsU0FBUTttQkFDL0Usd0JBQUMsUUFBRDtVQUFNLGVBQWM7VUFBUSxnQkFBZTtVQUFRLGFBQVk7VUFBSSxHQUFFO1NBQTBGOzs7OztRQUM1Sjs7OztrQkFBQyxvQkFFRDs7Ozs7aUJBQ1Asd0JBQUMsU0FBRDtRQUNFLElBQUc7UUFDSCxNQUFLO1FBQ0wsT0FBTztRQUNQLFdBQVcsTUFBTTtTQUNmLElBQUksRUFBRSxPQUFPLE9BQU8sZUFBZSxFQUFFLE9BQU8sS0FBSztRQUNuRDtRQUNBLFdBQVU7T0FDWDs7OztlQUNFOzs7OztnQkFFSixDQUFDLFNBQ0Esd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxlQUFlLGVBQWUsVUFBVSxDQUFDO09BQ3pDLFdBQVU7aUJBSFosQ0FLRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtRQUFjLE1BQUs7UUFBTyxRQUFPO1FBQWUsU0FBUTtrQkFDckUsd0JBQUMsUUFBRDtTQUFNLGVBQWM7U0FBUSxnQkFBZTtTQUFRLGFBQVk7U0FBTSxHQUFFO1FBQStDOzs7OztPQUNuSDs7OztpQkFBQyxjQUVBOzs7OztjQUVQOzs7OztlQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQ2Isc0JBQXNCLFdBQVc7TUFDOUI7Ozs7Z0JBQ0wsUUFDQyx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBaEIsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxvREFBMEQ7Ozs7aUJBQUMsS0FFdkU7Ozs7O2lCQUVOLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUF3SDtNQUVsSTs7OztjQUVMOzs7OzthQUNGOzs7Ozs7R0FDRjs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFDVixRQUFRLHVCQUF1QjtNQUMvQjs7OztnQkFDSCx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZDtRQUNHLFNBQVMsa0JBQWtCO1FBQUU7UUFBQyx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBdUM7UUFBVzs7Ozs7T0FDL0Y7Ozs7O2NBQ0Q7Ozs7OztLQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQTJEO01BQWU7Ozs7Z0JBQ3ZGLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkO1FBQ0csU0FBUyxtQkFBbUI7UUFBRTtRQUFDLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUF1QztRQUFXOzs7OztPQUNoRzs7Ozs7Y0FDRDs7Ozs7O0tBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBOEQ7TUFBZTs7OztnQkFDMUYsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQ7UUFDRyxTQUFTLG1CQUFtQjtRQUFFO1FBQUMsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQXVDO1FBQVc7Ozs7O09BQ2hHOzs7OztjQUNEOzs7Ozs7S0FDTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUF3RDtNQUFrQjs7OztnQkFDdkYsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQsQ0FBeUMsUUFDbEMsV0FBVyxTQUFTLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FDdEQ7Ozs7O2NBQ0Q7Ozs7OztJQUNGOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FHRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQ1osd0JBQUMsUUFBRCxZQUFNLDJCQUE4Qjs7Ozs7T0FDbEM7Ozs7aUJBQ0osd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCO1NBQ0csVUFBVTtTQUFPO1NBQUUsVUFBVSxXQUFXLElBQUksYUFBYTtRQUN0RDs7Ozs7ZUFDSDs7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1FBQ0UsZUFBZSxlQUFlLFdBQVc7UUFDekMsV0FBVTtRQUNWLE9BQU07a0JBSFIsQ0FLRSx3QkFBQyxPQUFEO1NBQUssV0FBVTtTQUFjLE1BQUs7U0FBTyxRQUFPO1NBQWUsU0FBUTttQkFDckUsd0JBQUMsUUFBRDtVQUFNLGVBQWM7VUFBUSxnQkFBZTtVQUFRLGFBQVk7VUFBSSxHQUFFO1NBQStHOzs7OztRQUNqTDs7OztrQkFBQyxZQUVBOzs7OztpQkFDUix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYixRQUFRLG1CQUFtQixVQUFVO09BQ2xDOzs7O2VBQ0g7Ozs7O2NBQ0Y7Ozs7O2VBRUosbUJBQ0Msd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsT0FBRDtPQUFLLFdBQVU7T0FBcUMsTUFBSztPQUFPLFNBQVE7aUJBQXhFLENBQ0Usd0JBQUMsVUFBRDtRQUFRLFdBQVU7UUFBYSxJQUFHO1FBQUssSUFBRztRQUFLLEdBQUU7UUFBSyxRQUFPO1FBQWUsYUFBWTtPQUFJOzs7O2lCQUM1Rix3QkFBQyxRQUFEO1FBQU0sV0FBVTtRQUFhLE1BQUs7UUFBZSxHQUFFO09BQThDOzs7O2VBQzlGOzs7Ozs7S0FDRjs7OztnQkFDSCxVQUFVLFdBQVcsSUFDdkIsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxZQUFELENBQWE7Ozs7O09BQ1Y7Ozs7O09BQ0wsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQ1YsUUFBUSw4Q0FBOEMscUNBQXFDO09BQzNGOzs7OztPQUNILHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUNWLFFBQ0csNkRBQ0E7T0FDSDs7Ozs7TUFDQTs7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQWpCLENBQ0Usd0JBQUMsU0FBRCxZQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFkO1NBQ0Usd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQXdFO1NBQVE7Ozs7O1NBQzlGLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFvRjtTQUFrQjs7Ozs7U0FDcEgsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQW1GO1NBQW1COzs7OztTQUNwSCx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBb0Y7U0FBWTs7Ozs7UUFDNUc7Ozs7O2dCQUNDOzs7O2lCQUNQLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUNkLFVBQVUsS0FBSyxLQUFLLE1BQ25CLHdCQUFDLGNBQUQ7U0FBb0MsVUFBVTtTQUFLLE9BQU87U0FBRyxjQUFjO1FBQXFCLEdBQTdFLElBQUk7Ozs7ZUFBeUUsQ0FDakc7T0FDSTs7OztlQUNGOzs7Ozs7S0FDSjs7OzthQUVKOzs7Ozs7R0FDRjs7Ozs7R0FHSixhQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUdFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFtQztNQUEyQjs7OztnQkFDNUUsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQXlCO01BQXdEOzs7O2NBQzNGOzs7O2dCQUNMLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGFBQWEsS0FBSztPQUNqQyxXQUFVO2lCQUVWLHdCQUFDLFdBQUQsQ0FBWTs7Ozs7TUFDTjs7OztjQUNMOzs7OztlQUVMLHdCQUFDLFFBQUQ7TUFBTSxVQUFVO01BQWdCLFdBQVU7Z0JBQTFDO09BRUUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxlQUFEO1NBQ0UsT0FBTTtTQUNOLE9BQU87U0FDUCxPQUFPO1NBQ1AsVUFBVTtTQUNWLE9BQU87VUFDTCxRQUFRO1VBQ1IsTUFBTTtVQUNOLElBQUk7U0FDTjtRQUNEOzs7O2tCQUNELHdCQUFDLGVBQUQ7U0FDRSxPQUFNO1NBQ04sT0FBTztTQUNQLE9BQU87U0FDUCxVQUFVO1NBQ1YsT0FBTztVQUNMLFFBQVE7VUFDUixNQUFNO1VBQ04sSUFBSTtTQUNOO1FBQ0Q7Ozs7Z0JBQ0U7Ozs7OztPQUdMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBaUU7T0FBaUI7Ozs7aUJBQy9GLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNaO1NBQ0M7VUFBRSxPQUFPO1VBQVksS0FBSztVQUFHLEtBQUs7U0FBRTtTQUNwQztVQUFFLE9BQU87VUFBVSxLQUFLO1VBQUcsS0FBSztTQUFFO1NBQ2xDO1VBQUUsT0FBTztVQUFpQixLQUFLO1VBQUcsS0FBSztTQUFFO1NBQ3pDO1VBQUUsT0FBTztVQUF5QixLQUFLO1VBQUcsS0FBSztTQUFFO1FBQ25ELENBQUMsQ0FBQyxLQUFLLEVBQUUsT0FBTyxLQUFLLFVBQ25CLHdCQUFDLFVBQUQ7U0FFRSxNQUFLO1NBQ0wsZUFBZTtVQUFFLFlBQVksR0FBRztVQUFHLFlBQVksR0FBRztTQUFFO1NBQ3BELFdBQVU7bUJBRVQ7UUFDSyxHQU5EOzs7O2VBTUMsQ0FDVDtPQUNFOzs7O2VBQ0Y7Ozs7O09BR0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUF1RTtPQUVqRjs7OztpQkFDUCx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLGFBQVk7UUFDWixPQUFPO1FBQ1AsV0FBVyxNQUFNLGlCQUFpQixFQUFFLE9BQU8sS0FBSztRQUNoRCxXQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBNkM7UUFBZ0I7Ozs7a0JBQzFFLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFiLENBQW9ELFFBQUssZUFBZSxRQUFRLENBQUMsQ0FBSzs7Ozs7Z0JBQ25GOzs7O2tCQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQTZDO1NBQVc7Ozs7bUJBQ3JFLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFiLENBQWlELGVBQWMsUUFBUzs7Ozs7aUJBQ3JFOzs7OztnQkFDRjs7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWUsYUFBYSxLQUFLO1NBQ2pDLFdBQVU7bUJBQ1g7UUFFTzs7OztrQkFDUix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLFVBQVUsV0FBVyxrQkFBa0I7U0FDdkMsV0FBVTttQkFFVCxVQUFVLGlCQUFpQjtRQUN0Qjs7OztnQkFDTDs7Ozs7O01BQ0Q7Ozs7O2FBQ0g7Ozs7OztHQUNGOzs7OztHQUlOLG1CQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFtQztPQUF5Qjs7OztpQkFDMUUsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWIsQ0FBc0MsVUFDN0IsT0FBTyxnQkFBZ0IsaUJBQWlCLFlBQVksZ0JBQWdCLGFBQWEsU0FBUyxHQUFHLElBQUksZ0JBQWdCLGFBQWEsTUFBTSxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsVUFBVSxHQUFHLENBQUMsSUFBSSxHQUNwSzs7Ozs7ZUFDQTs7OztpQkFDTCx3QkFBQyxVQUFEO1FBQ0UsZUFBZSxtQkFBbUIsSUFBSTtRQUN0QyxXQUFVO2tCQUVWLHdCQUFDLFdBQUQsQ0FBWTs7Ozs7T0FDTjs7OztlQUNMOzs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQXNDO1NBQW9COzs7O21CQUMxRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEIsQ0FBcUQsZ0JBQWdCLG9CQUFtQixXQUFlOzs7OztpQkFDcEc7Ozs7OztRQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQXlDO1NBQW9COzs7O21CQUM3RSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEIsQ0FBd0QsZ0JBQWdCLG9CQUFtQixXQUFlOzs7OztpQkFDdkc7Ozs7OztRQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQXVDO1NBQW9COzs7O21CQUMzRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEIsQ0FBc0QsZ0JBQWdCLGdCQUFlLFFBQVk7Ozs7O2lCQUM5Rjs7Ozs7O1FBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBd0I7U0FBcUI7Ozs7bUJBQzdELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUFxQyxRQUFLLFdBQVcsZ0JBQWdCLGVBQWUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFROzs7OztpQkFDcEc7Ozs7OztRQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWlFO1NBQWdCOzs7O21CQUM5Rix3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDWixnQkFBZ0IsaUJBQWlCO1NBQy9COzs7O2lCQUNGOzs7Ozs7T0FDRjs7Ozs7O01BRUwsd0JBQUMsVUFBRDtPQUNFLGVBQWUsbUJBQW1CLElBQUk7T0FDdEMsV0FBVTtpQkFDWDtNQUVPOzs7OztLQUNMOzs7Ozs7R0FDRjs7Ozs7RUFFSjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiaW5kZXguanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBtb25pdG9yaW5nQXBpIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvYXBpJ1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uL2NvbnRleHQvQXV0aENvbnRleHQnXG5cbi8vIOKUgOKUgOKUgCDDjWNvbm9zIFNWRyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmZ1bmN0aW9uIEljb25QbHVzKCkge1xuICByZXR1cm4gKFxuICAgIDxzdmcgY2xhc3NOYW1lPVwidy01IGgtNVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMi41XCIgZD1cIk0xMiA0djE2bTgtOEg0XCIgLz5cbiAgICA8L3N2Zz5cbiAgKVxufVxuXG5mdW5jdGlvbiBJY29uVGlja2V0KCkge1xuICByZXR1cm4gKFxuICAgIDxzdmcgY2xhc3NOYW1lPVwidy01IGgtNVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMTUgNXYybTAgNHYybTAgNHYyTTUgNWEyIDIgMCAwMC0yIDJ2M2EyIDIgMCAxMTAgNHYzYTIgMiAwIDAwMiAyaDE0YTIgMiAwIDAwMi0ydi0zYTIgMiAwIDExMC00VjdhMiAyIDAgMDAtMi0ySDV6XCIgLz5cbiAgICA8L3N2Zz5cbiAgKVxufVxuXG5mdW5jdGlvbiBJY29uQ2hlY2soKSB7XG4gIHJldHVybiAoXG4gICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTUgaC01XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyLjVcIiBkPVwiTTUgMTNsNCA0TDE5IDdcIiAvPlxuICAgIDwvc3ZnPlxuICApXG59XG5cbmZ1bmN0aW9uIEljb25DbG9jaygpIHtcbiAgcmV0dXJuIChcbiAgICA8c3ZnIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1zbGF0ZS00MDBcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTEyIDh2NGwzIDNtNi0zYTkgOSAwIDExLTE4IDAgOSA5IDAgMDExOCAwelwiIC8+XG4gICAgPC9zdmc+XG4gIClcbn1cblxuZnVuY3Rpb24gSWNvbkNsb3NlKCkge1xuICByZXR1cm4gKFxuICAgIDxzdmcgY2xhc3NOYW1lPVwidy02IGgtNlwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNNiAxOEwxOCA2TTYgNmwxMiAxMlwiIC8+XG4gICAgPC9zdmc+XG4gIClcbn1cblxuZnVuY3Rpb24gSWNvbkV5ZSgpIHtcbiAgcmV0dXJuIChcbiAgICA8c3ZnIGNsYXNzTmFtZT1cInctNCBoLTRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTE1IDEyYTMgMyAwIDExLTYgMCAzIDMgMCAwMTYgMHpcIiAvPlxuICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMi40NTggMTJDMy43MzIgNy45NDMgNy41MjMgNSAxMiA1YzQuNDc4IDAgOC4yNjggMi45NDMgOS41NDIgNy0xLjI3NCA0LjA1Ny01LjA2NCA3LTkuNTQyIDctNC40NzcgMC04LjI2OC0yLjk0My05LjU0Mi03elwiIC8+XG4gICAgPC9zdmc+XG4gIClcbn1cblxuLy8g4pSA4pSA4pSAIENvbXBvbmVudGUgQ29udGFkb3IgY29uIElucHV0IE1hbnVhbCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmZ1bmN0aW9uIFRpY2tldENvdW50ZXIoeyBsYWJlbCwgcHJpY2UsIGNvdW50LCBvbkNoYW5nZSwgY29sb3IgfSkge1xuICBjb25zdCBoYW5kbGVJbnB1dENoYW5nZSA9IChlKSA9PiB7XG4gICAgbGV0IHJhd1ZhbCA9IGUudGFyZ2V0LnZhbHVlXG4gICAgLy8gTGltaXRhciBhIG3DoXhpbW8gMiBkw61naXRvcyBlbiBlbCBzdHJpbmdcbiAgICBpZiAocmF3VmFsLmxlbmd0aCA+IDIpIHtcbiAgICAgIHJhd1ZhbCA9IHJhd1ZhbC5zbGljZSgwLCAyKVxuICAgIH1cbiAgICBjb25zdCB2YWwgPSBwYXJzZUludChyYXdWYWwsIDEwKVxuICAgIGlmIChpc05hTih2YWwpIHx8IHZhbCA8IDApIHtcbiAgICAgIG9uQ2hhbmdlKDApXG4gICAgfSBlbHNlIHtcbiAgICAgIG9uQ2hhbmdlKE1hdGgubWluKDk5LCB2YWwpKVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e2BiZy13aGl0ZSByb3VuZGVkLTJ4bCBib3JkZXIgJHtjb2xvci5ib3JkZXJ9IHAtNSBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiBzaGFkb3ctc20gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIGhvdmVyOnNoYWRvdy1tZGB9PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItM1wiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMFwiPntsYWJlbH08L3A+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPXtgdGV4dC0yeGwgZm9udC1ibGFjayAke2NvbG9yLnRleHR9YH0+QnMuIHtwcmljZX08L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHctMTAgaC0xMCByb3VuZGVkLXhsICR7Y29sb3IuYmd9IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyYH0+XG4gICAgICAgICAgPEljb25UaWNrZXQgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yIG10LTJcIj5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uQ2hhbmdlKE1hdGgubWF4KDAsIGNvdW50IC0gMSkpfVxuICAgICAgICAgIGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLXhsIGJnLXNsYXRlLTEwMCB0ZXh0LXNsYXRlLTYwMCBmb250LWJvbGQgdGV4dC14bCBob3ZlcjpiZy1zbGF0ZS0yMDAgYWN0aXZlOnNjYWxlLTk1IHRyYW5zaXRpb24tYWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCJcbiAgICAgICAgPlxuICAgICAgICAgIC1cbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIFxuICAgICAgICB7LyogSW5wdXQgZGlyZWN0byBwYXJhIGVzY3JpYmlyIGxhIGNhbnRpZGFkIGRlc2VhZGEgcG9yIHRlY2xhZG8gKE3DoXhpbW8gOTkgLyAyIGTDrWdpdG9zLCBibG9xdWVhICdlJywgJysnLCAnLScpICovfVxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICBtaW49XCIwXCJcbiAgICAgICAgICBtYXg9XCI5OVwiXG4gICAgICAgICAgdmFsdWU9e2NvdW50ID09PSAwID8gJycgOiBjb3VudH1cbiAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XG4gICAgICAgICAgb25LZXlEb3duPXsoZSkgPT4ge1xuICAgICAgICAgICAgaWYgKFsnZScsICdFJywgJysnLCAnLScsICcuJ10uaW5jbHVkZXMoZS5rZXkpKSB7XG4gICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH19XG4gICAgICAgICAgb25JbnB1dD17KGUpID0+IHtcbiAgICAgICAgICAgIGlmIChlLnRhcmdldC52YWx1ZS5sZW5ndGggPiAyKSB7XG4gICAgICAgICAgICAgIGUudGFyZ2V0LnZhbHVlID0gZS50YXJnZXQudmFsdWUuc2xpY2UoMCwgMilcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9fVxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMFwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwidy0xNiBoLTEwIHRleHQtY2VudGVyIGZvbnQtYmxhY2sgdGV4dC14bCB0ZXh0LXNsYXRlLTgwMCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTUwMCBiZy1zbGF0ZS01MFwiXG4gICAgICAgIC8+XG5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uQ2hhbmdlKE1hdGgubWluKDk5LCBjb3VudCArIDEpKX1cbiAgICAgICAgICBjbGFzc05hbWU9e2B3LTEwIGgtMTAgcm91bmRlZC14bCAke2NvbG9yLmJnfSAke2NvbG9yLnRleHR9IGZvbnQtYm9sZCB0ZXh0LXhsIGhvdmVyOm9wYWNpdHktODAgYWN0aXZlOnNjYWxlLTk1IHRyYW5zaXRpb24tYWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyYH1cbiAgICAgICAgPlxuICAgICAgICAgICtcbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG4vLyDilIDilIDilIAgRmlsYSBkZSBoaXN0b3JpYWwg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5mdW5jdGlvbiBIaXN0b3JpYWxSb3coeyByZWdpc3RybywgaW5kZXgsIG9uVmVyRGV0YWxsZSB9KSB7XG4gIGxldCBob3JhU3RyID0gJ+KAlCdcbiAgaWYgKHJlZ2lzdHJvLmhvcmFfZW50cmFkYSkge1xuICAgIGlmICh0eXBlb2YgcmVnaXN0cm8uaG9yYV9lbnRyYWRhID09PSAnc3RyaW5nJyAmJiByZWdpc3Ryby5ob3JhX2VudHJhZGEuaW5jbHVkZXMoJ1QnKSkge1xuICAgICAgaG9yYVN0ciA9IHJlZ2lzdHJvLmhvcmFfZW50cmFkYS5zcGxpdCgnVCcpWzFdLnN1YnN0cmluZygwLCA4KVxuICAgIH0gZWxzZSB7XG4gICAgICBob3JhU3RyID0gbmV3IERhdGUocmVnaXN0cm8uaG9yYV9lbnRyYWRhKS50b0xvY2FsZVRpbWVTdHJpbmcoW10sIHsgaG91cjogJzItZGlnaXQnLCBtaW51dGU6ICcyLWRpZ2l0Jywgc2Vjb25kOiAnMi1kaWdpdCcsIGhvdXIxMjogZmFsc2UgfSlcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDx0ciBjbGFzc05hbWU9e2luZGV4ICUgMiA9PT0gMCA/ICdiZy13aGl0ZScgOiAnYmctc2xhdGUtNTAnfT5cbiAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC01IHB5LTQgdGV4dC1zbSB0ZXh0LXNsYXRlLTcwMCBmb250LXNlbWlib2xkIHdoaXRlc3BhY2Utbm93cmFwXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgIDxJY29uQ2xvY2sgLz5cbiAgICAgICAgICB7aG9yYVN0cn1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L3RkPlxuICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTUgcHktNCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHgtMyBweS0xIHJvdW5kZWQtZnVsbCBiZy1ibHVlLTUwIHRleHQtYmx1ZS03MDAgdGV4dC1zbSBmb250LWJvbGQgYm9yZGVyIGJvcmRlci1ibHVlLTEwMFwiPlxuICAgICAgICAgIHtyZWdpc3Ryby50b3RhbF9wZXJzb25hc30gcGVycy5cbiAgICAgICAgPC9zcGFuPlxuICAgICAgPC90ZD5cbiAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC01IHB5LTQgdGV4dC1yaWdodCBmb250LWJsYWNrIHRleHQtc2xhdGUtODAwIHRleHQtYmFzZVwiPlxuICAgICAgICBCcy4ge3BhcnNlRmxvYXQocmVnaXN0cm8udG90YWxfcmVjYXVkYWRvKS50b0ZpeGVkKDIpfVxuICAgICAgPC90ZD5cbiAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC01IHB5LTQgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uVmVyRGV0YWxsZShyZWdpc3Rybyl9XG4gICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgcm91bmRlZC14bCBiZy1zbGF0ZS0xMDAgaG92ZXI6YmctYmx1ZS01MCB0ZXh0LXNsYXRlLTYwMCBob3Zlcjp0ZXh0LWJsdWUtNjAwIGZvbnQtYm9sZCB0ZXh0LXhzIHRyYW5zaXRpb24tYWxsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGhvdmVyOmJvcmRlci1ibHVlLTIwMFwiXG4gICAgICAgID5cbiAgICAgICAgICA8SWNvbkV5ZSAvPlxuICAgICAgICAgIFZlciBEZXRhbGxlXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC90ZD5cbiAgICA8L3RyPlxuICApXG59XG5cbi8vIOKUgOKUgOKUgCBGdW5jaW9uZXMgQXV4aWxpYXJlcyBwYXJhIEZlY2hhcyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmZ1bmN0aW9uIGdldEhveUlTTygpIHtcbiAgY29uc3Qgbm93ID0gbmV3IERhdGUoKVxuICBjb25zdCB5ZWFyID0gbm93LmdldEZ1bGxZZWFyKClcbiAgY29uc3QgbW9udGggPSBTdHJpbmcobm93LmdldE1vbnRoKCkgKyAxKS5wYWRTdGFydCgyLCAnMCcpXG4gIGNvbnN0IGRheSA9IFN0cmluZyhub3cuZ2V0RGF0ZSgpKS5wYWRTdGFydCgyLCAnMCcpXG4gIHJldHVybiBgJHt5ZWFyfS0ke21vbnRofS0ke2RheX1gXG59XG5cbmZ1bmN0aW9uIGZvcm1hdGVhckZlY2hhTGVnaWJsZShmZWNoYVN0cikge1xuICBpZiAoIWZlY2hhU3RyKSByZXR1cm4gJydcbiAgY29uc3QgcGFydGVzID0gZmVjaGFTdHIuc3BsaXQoJy0nKVxuICBpZiAocGFydGVzLmxlbmd0aCAhPT0gMykgcmV0dXJuIGZlY2hhU3RyXG4gIGNvbnN0IFt5LCBtLCBkXSA9IHBhcnRlcy5tYXAoTnVtYmVyKVxuICBjb25zdCBmZWNoYSA9IG5ldyBEYXRlKHksIG0gLSAxLCBkKVxuICByZXR1cm4gZmVjaGEudG9Mb2NhbGVEYXRlU3RyaW5nKCdlcy1FUycsIHtcbiAgICB3ZWVrZGF5OiAnbG9uZycsXG4gICAgeWVhcjogJ251bWVyaWMnLFxuICAgIG1vbnRoOiAnbG9uZycsXG4gICAgZGF5OiAnbnVtZXJpYycsXG4gIH0pXG59XG5cbi8vIOKUgOKUgOKUgCBQw6FnaW5hIFByaW5jaXBhbCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENhamFQYWdlKCkge1xuICBjb25zdCB7IHNlc3Npb24gfSA9IHVzZUF1dGgoKVxuICBjb25zdCBbdGFyaWZhMTUsIHNldFRhcmlmYTE1XSA9IHVzZVN0YXRlKDApXG4gIGNvbnN0IFt0YXJpZmEyMCwgc2V0VGFyaWZhMjBdID0gdXNlU3RhdGUoMClcbiAgY29uc3QgW29ic2VydmFjaW9uZXMsIHNldE9ic2VydmFjaW9uZXNdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbaGlzdG9yaWFsLCBzZXRIaXN0b3JpYWxdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtyZXN1bWVuLCBzZXRSZXN1bWVuXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFtub3RpZmljYXRpb24sIHNldE5vdGlmaWNhdGlvbl0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbbG9hZGluZ0hpc3RvcmlhbCwgc2V0TG9hZGluZ0hpc3RvcmlhbF0gPSB1c2VTdGF0ZSh0cnVlKVxuICBjb25zdCBbc2hvd01vZGFsLCBzZXRTaG93TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtyZWdpc3Ryb0RldGFsbGUsIHNldFJlZ2lzdHJvRGV0YWxsZV0gPSB1c2VTdGF0ZShudWxsKVxuXG4gIC8vIEZpbHRybyBwb3IgZmVjaGEgKHBvciBkZWZlY3RvIGhveSlcbiAgY29uc3QgW2ZlY2hhRmlsdHJvLCBzZXRGZWNoYUZpbHRyb10gPSB1c2VTdGF0ZShnZXRIb3lJU08oKSlcblxuICBjb25zdCBlc0hveSA9IGZlY2hhRmlsdHJvID09PSBnZXRIb3lJU08oKVxuXG4gIC8vIEhvcmEgYWN0dWFsIGVuIHRpZW1wbyByZWFsXG4gIGNvbnN0IFtob3JhQWN0dWFsLCBzZXRIb3JhQWN0dWFsXSA9IHVzZVN0YXRlKG5ldyBEYXRlKCkpXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgdGltZXIgPSBzZXRJbnRlcnZhbCgoKSA9PiBzZXRIb3JhQWN0dWFsKG5ldyBEYXRlKCkpLCAxMDAwKVxuICAgIHJldHVybiAoKSA9PiBjbGVhckludGVydmFsKHRpbWVyKVxuICB9LCBbXSlcblxuICBjb25zdCBmZXRjaEhpc3RvcmlhbCA9IHVzZUNhbGxiYWNrKGFzeW5jIChmZWNoYSA9IGZlY2hhRmlsdHJvKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIHNldExvYWRpbmdIaXN0b3JpYWwodHJ1ZSlcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IG1vbml0b3JpbmdBcGkuZ2V0KCcvYXBpL2NhamEvaGlzdG9yaWFsJywge1xuICAgICAgICBwYXJhbXM6IHsgZmVjaGEgfVxuICAgICAgfSlcbiAgICAgIGlmIChyZXMuZGF0YSkge1xuICAgICAgICBzZXRIaXN0b3JpYWwocmVzLmRhdGEucmVnaXN0cm9zIHx8IFtdKVxuICAgICAgICBzZXRSZXN1bWVuKHJlcy5kYXRhLnJlc3VtZW4gfHwgbnVsbClcbiAgICAgIH1cbiAgICB9IGNhdGNoIHtcbiAgICAgIHNldE5vdGlmaWNhdGlvbih7IHR5cGU6ICdlcnJvcicsIG1zZzogJ05vIHNlIHB1ZG8gY2FyZ2FyIGVsIGhpc3RvcmlhbCBkZSBsYSBmZWNoYSBzZWxlY2Npb25hZGEnIH0pXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldExvYWRpbmdIaXN0b3JpYWwoZmFsc2UpXG4gICAgfVxuICB9LCBbZmVjaGFGaWx0cm9dKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZmV0Y2hIaXN0b3JpYWwoZmVjaGFGaWx0cm8pXG4gIH0sIFtmZWNoYUZpbHRybywgZmV0Y2hIaXN0b3JpYWxdKVxuXG4gIGNvbnN0IHRvdGFsUGVyc29uYXMgPSB0YXJpZmExNSArIHRhcmlmYTIwXG4gIGNvbnN0IHRvdGFsUmVjYXVkYWRvID0gdGFyaWZhMTUgKiAxNSArIHRhcmlmYTIwICogMjBcblxuICBjb25zdCBoYW5kbGVSZWdpc3RlciA9IGFzeW5jIChlKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgaWYgKHRvdGFsUGVyc29uYXMgPT09IDApIHtcbiAgICAgIHNldE5vdGlmaWNhdGlvbih7IHR5cGU6ICdlcnJvcicsIG1zZzogJ0RlYmUgaW5ncmVzYXIgYWwgbWVub3MgMSBwZXJzb25hJyB9KVxuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgc2V0TG9hZGluZyh0cnVlKVxuICAgIHRyeSB7XG4gICAgICBhd2FpdCBtb25pdG9yaW5nQXBpLnBvc3QoJy9hcGkvY2FqYS9yZWdpc3RybycsIHtcbiAgICAgICAgY2FudGlkYWRfdGFyaWZhXzE1OiB0YXJpZmExNSxcbiAgICAgICAgY2FudGlkYWRfdGFyaWZhXzIwOiB0YXJpZmEyMCxcbiAgICAgICAgaWRfdXN1YXJpbzogc2Vzc2lvbj8udXN1YXJpbz8uaWRfdXN1YXJpbyB8fCBudWxsLFxuICAgICAgICBvYnNlcnZhY2lvbmVzOiBvYnNlcnZhY2lvbmVzLnRyaW0oKSB8fCBudWxsLFxuICAgICAgfSlcbiAgICAgIHNldE5vdGlmaWNhdGlvbih7IHR5cGU6ICdzdWNjZXNzJywgbXNnOiBg4pyTIFJlZ2lzdHJhZG86ICR7dG90YWxQZXJzb25hc30gcGVyc29uYShzKSDigJQgQnMuICR7dG90YWxSZWNhdWRhZG8udG9GaXhlZCgyKX1gIH0pXG4gICAgICBzZXRUYXJpZmExNSgwKVxuICAgICAgc2V0VGFyaWZhMjAoMClcbiAgICAgIHNldE9ic2VydmFjaW9uZXMoJycpXG4gICAgICBzZXRTaG93TW9kYWwoZmFsc2UpXG5cbiAgICAgIC8vIFNpIGVzdGFiYSBlbiBvdHJhIGZlY2hhLCB2b2x2ZXIgYSBob3kgcGFyYSB2aXN1YWxpemFyIGxhIHZlbnRhIHJlYWxpemFkYVxuICAgICAgY29uc3QgaG95ID0gZ2V0SG95SVNPKClcbiAgICAgIGlmIChmZWNoYUZpbHRybyAhPT0gaG95KSB7XG4gICAgICAgIHNldEZlY2hhRmlsdHJvKGhveSlcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGZldGNoSGlzdG9yaWFsKGhveSlcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnN0IG1zZyA9IGVyci5yZXNwb25zZT8uZGF0YT8uZGV0YWlsIHx8ICdFcnJvciBhbCByZWdpc3RyYXIgZW50cmFkYSdcbiAgICAgIHNldE5vdGlmaWNhdGlvbih7IHR5cGU6ICdlcnJvcicsIG1zZzogYOKclyAke21zZ31gIH0pXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldE5vdGlmaWNhdGlvbihudWxsKSwgNDAwMClcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLXNsYXRlLTUwIHBiLTEyXCI+XG4gICAgICB7Lyog4pSA4pSAIEhlYWRlciBkZSBww6FnaW5hIOKUgOKUgCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBweC02IHB5LTYgc2hhZG93LXNtXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctNnhsIG14LWF1dG8gZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0cmFja2luZy13aWRlc3QgdXBwZXJjYXNlIHRleHQtYmx1ZS01MDAgbWItMVwiPk3Ds2R1bG8gZGUgQ2FqYTwvcD5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDBcIj5Db250cm9sIGRlIEluZ3Jlc29zIHkgQWZvcm88L2gxPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTUwMCBtdC0wLjVcIj5SZWdpc3RybyBkZSB0YXF1aWxsYSB5IGNvYnJvIGRlIGVudHJhZGFzPC9wPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TW9kYWwodHJ1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNzAwIHRleHQtd2hpdGUgcHgtNSBweS0zIHJvdW5kZWQteGwgZm9udC1ib2xkIHRleHQtc20gc2hhZG93LW1kIHNoYWRvdy1ibHVlLTUwMC8yMCBhY3RpdmU6c2NhbGUtOTUgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8SWNvblBsdXMgLz5cbiAgICAgICAgICAgICAgUmVnaXN0cmFyIEluZ3Jlc29cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7Lyog4pSA4pSAIE5vdGlmaWNhY2nDs24g4pSA4pSAICovfVxuICAgICAge25vdGlmaWNhdGlvbiAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgbWF4LXctNnhsIG14LWF1dG8gcHgtNCBweS0zIG10LTQgcm91bmRlZC14bCBmb250LXNlbWlib2xkIHRleHQtc20gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgc2hhZG93LW1kXG4gICAgICAgICAgJHtub3RpZmljYXRpb24udHlwZSA9PT0gJ3N1Y2Nlc3MnXG4gICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTUwIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDAgdGV4dC1lbWVyYWxkLTcwMCdcbiAgICAgICAgICAgIDogJ2JnLXJlZC01MCBib3JkZXIgYm9yZGVyLXJlZC0yMDAgdGV4dC1yZWQtNzAwJ1xuICAgICAgICAgIH1gfVxuICAgICAgICA+XG4gICAgICAgICAge25vdGlmaWNhdGlvbi50eXBlID09PSAnc3VjY2VzcycgPyA8SWNvbkNoZWNrIC8+IDogJ+KaoCd9XG4gICAgICAgICAge25vdGlmaWNhdGlvbi5tc2d9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIOKUgOKUgCBCYXJyYSBkZSBGaWx0cm8gcG9yIEZlY2hhIChQb3IgZGVmZWN0byBIT1kpIOKUgOKUgCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctNnhsIG14LWF1dG8gcHgtNiBtdC02XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC00IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHNoYWRvdy1zbSBmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJmZWNoYUZpbHRyb0NhamFcIiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS01MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWJsdWUtNjAwXCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk04IDdWM204IDRWM20tOSA4aDEwTTUgMjFoMTRhMiAyIDAgMDAyLTJWN2EyIDIgMCAwMC0yLTJINWEyIDIgMCAwMC0yIDJ2MTJhMiAyIDAgMDAyIDJ6XCIgLz5cbiAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgICBGaWx0cmFyIHBvciBmZWNoYTpcbiAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgaWQ9XCJmZWNoYUZpbHRyb0NhamFcIlxuICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17ZmVjaGFGaWx0cm99XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICBpZiAoZS50YXJnZXQudmFsdWUpIHNldEZlY2hhRmlsdHJvKGUudGFyZ2V0LnZhbHVlKVxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMy41IHB5LTIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBmb250LWJvbGQgdGV4dC1zbSB0ZXh0LXNsYXRlLTgwMCBiZy1zbGF0ZS01MCBmb2N1czpiZy13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS01MDAgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHshZXNIb3kgJiYgKFxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RmVjaGFGaWx0cm8oZ2V0SG95SVNPKCkpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMuNSBweS0yIHJvdW5kZWQteGwgYmctYmx1ZS01MCBob3ZlcjpiZy1ibHVlLTEwMCB0ZXh0LWJsdWUtNzAwIHRleHQteHMgZm9udC1ibGFjayB0cmFuc2l0aW9uLWFsbCBib3JkZXIgYm9yZGVyLWJsdWUtMjAwIGFjdGl2ZTpzY2FsZS05NSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjIuNVwiIGQ9XCJNMTIgOHY0bDMgM202LTNhOSA5IDAgMTEtMTggMCA5IDkgMCAwMTE4IDB6XCIgLz5cbiAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgICBWb2x2ZXIgYSBIb3lcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS02MDAgY2FwaXRhbGl6ZVwiPlxuICAgICAgICAgICAgICB7Zm9ybWF0ZWFyRmVjaGFMZWdpYmxlKGZlY2hhRmlsdHJvKX1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIHtlc0hveSA/IChcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xIHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtZXh0cmFib2xkIGJnLWVtZXJhbGQtNTAgdGV4dC1lbWVyYWxkLTcwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC01MDAgYW5pbWF0ZS1wdWxzZVwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICBIb3lcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTMgcHktMSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LWJvbGQgYmctc2xhdGUtMTAwIHRleHQtc2xhdGUtNjAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwXCI+XG4gICAgICAgICAgICAgICAgSGlzdG9yaWFsIFBhc2Fkb1xuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7Lyog4pSA4pSAIFJlc3VtZW4gZGUgQ2FqYSAoNCB0YXJqZXRhcyBsaW1waWFzIHBhcmEgVGFxdWlsbGEpIOKUgOKUgCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctNnhsIG14LWF1dG8gcHgtNiBtdC02IGdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgc2hhZG93LXNtXCI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICB7ZXNIb3kgPyAnVG90YWwgVGFxdWlsbGEgSG95JyA6ICdUb3RhbCBCYcOxaXN0YXMnfVxuICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ibGFjayB0ZXh0LXNsYXRlLTgwMCBtdC0yXCI+XG4gICAgICAgICAgICB7cmVzdW1lbj8udG90YWxfcGVyc29uYXMgPz8gMH0gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNDAwXCI+cGVycy48L3NwYW4+XG4gICAgICAgICAgPC9oMz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC01IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHNoYWRvdy1zbVwiPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWJsdWUtNTAwXCI+VGFyaWZhIDE1IEJzPC9wPlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJsYWNrIHRleHQtYmx1ZS02MDAgbXQtMlwiPlxuICAgICAgICAgICAge3Jlc3VtZW4/LnRvdGFsX3RhcmlmYV8xNSA/PyAwfSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS00MDBcIj5wZXJzLjwvc3Bhbj5cbiAgICAgICAgICA8L2gzPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgc2hhZG93LXNtXCI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZW1lcmFsZC01MDBcIj5UYXJpZmEgMjAgQnM8L3A+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYmxhY2sgdGV4dC1lbWVyYWxkLTYwMCBtdC0yXCI+XG4gICAgICAgICAgICB7cmVzdW1lbj8udG90YWxfdGFyaWZhXzIwID8/IDB9IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTQwMFwiPnBlcnMuPC9zcGFuPlxuICAgICAgICAgIDwvaDM+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tZW1lcmFsZC01MDAgdG8tZW1lcmFsZC02MDAgdGV4dC13aGl0ZSBwLTUgcm91bmRlZC0yeGwgc2hhZG93LW1kXCI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG9wYWNpdHktODBcIj5Ub3RhbCBSZWNhdWRhZG88L3A+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYmxhY2sgbXQtMlwiPlxuICAgICAgICAgICAgQnMuIHtwYXJzZUZsb2F0KHJlc3VtZW4/LnRvdGFsX3JlY2F1ZGFkbyA/PyAwKS50b0ZpeGVkKDIpfVxuICAgICAgICAgIDwvaDM+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiDilIDilIAgVGFibGEgUHJpbmNpcGFsIGRlIFJlZ2lzdHJvcyBkZSBUYXF1aWxsYSDilIDilIAgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTZ4bCBteC1hdXRvIHB4LTYgbXQtOFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHNoYWRvdy1zbSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICBcbiAgICAgICAgICB7LyogSGVhZGVyIGRlIGxhIFRhYmxhICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC02IHB5LTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBnYXAtM1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxzcGFuPvCfkaUgUmVnaXN0cm9zIGRlIFRhcXVpbGxhPC9zcGFuPlxuICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyb3VuZGVkLWZ1bGwgYmctYmx1ZS01MCB0ZXh0LWJsdWUtNzAwIGJvcmRlciBib3JkZXItYmx1ZS0xMDAgcHgtMyBweS0wLjUgdGV4dC14cyBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgICB7aGlzdG9yaWFsLmxlbmd0aH0ge2hpc3RvcmlhbC5sZW5ndGggPT09IDEgPyAncmVnaXN0cm8nIDogJ3JlZ2lzdHJvcyd9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBmZXRjaEhpc3RvcmlhbChmZWNoYUZpbHRybyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS02MDAgaG92ZXI6dGV4dC1ibHVlLTYwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMS41IHJvdW5kZWQteGwgYmctc2xhdGUtNTAgaG92ZXI6Ymctc2xhdGUtMTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHRyYW5zaXRpb24tYWxsIGFjdGl2ZTpzY2FsZS05NVwiXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJBY3R1YWxpemFyIGRhdG9zXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTQgNHY1aC41ODJtMTUuMzU2IDJBOC4wMDEgOC4wMDEgMCAwMDQuNTgyIDltMCAwSDltMTEgMTF2LTVoLS41ODFtMCAwYTguMDAzIDguMDAzIDAgMDEtMTUuMzU3LTJtMTUuMzU3IDJIMTVcIiAvPlxuICAgICAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgICAgIEFjdHVhbGl6YXJcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgIHtlc0hveSA/ICdKb3JuYWRhIGRlIEhveScgOiBgRmVjaGE6ICR7ZmVjaGFGaWx0cm99YH1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7bG9hZGluZ0hpc3RvcmlhbCA/IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHktMTZcIj5cbiAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gdy04IGgtOCB0ZXh0LWJsdWUtNTAwXCIgZmlsbD1cIm5vbmVcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgICAgICAgICAgICAgPGNpcmNsZSBjbGFzc05hbWU9XCJvcGFjaXR5LTI1XCIgY3g9XCIxMlwiIGN5PVwiMTJcIiByPVwiMTBcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjRcIi8+XG4gICAgICAgICAgICAgICAgPHBhdGggY2xhc3NOYW1lPVwib3BhY2l0eS03NVwiIGZpbGw9XCJjdXJyZW50Q29sb3JcIiBkPVwiTTQgMTJhOCA4IDAgMDE4LThWMEM1LjM3MyAwIDAgNS4zNzMgMCAxMmg0elwiLz5cbiAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogaGlzdG9yaWFsLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTZcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB3LTE2IGgtMTYgcm91bmRlZC1mdWxsIGJnLXNsYXRlLTEwMCBteC1hdXRvIG1iLTQgdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICA8SWNvblRpY2tldCAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS03MDAgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAge2VzSG95ID8gJ1NpbiByZWdpc3Ryb3MgZGUgdGFxdWlsbGEgZW4gZXN0YSBqb3JuYWRhJyA6IGBTaW4gcmVnaXN0cm9zIGRlIHRhcXVpbGxhIHBhcmEgZWwgJHtmZWNoYUZpbHRyb31gfVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIHRleHQtc20gbXQtMVwiPlxuICAgICAgICAgICAgICAgIHtlc0hveVxuICAgICAgICAgICAgICAgICAgPyAnSGF6IGNsaWMgZW4gXCIrIFJlZ2lzdHJhciBJbmdyZXNvXCIgcGFyYSBhw7FhZGlyIGJhw7Fpc3RhcydcbiAgICAgICAgICAgICAgICAgIDogJ1NlbGVjY2lvbmEgb3RyYSBmZWNoYSBlbiBlbCBmaWx0cm8gc3VwZXJpb3IgbyBwcmVzaW9uYSBcIlZvbHZlciBhIEhveVwiJ31cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvXCI+XG4gICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1sZWZ0XCI+XG4gICAgICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJnLXNsYXRlLTUwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTUgcHktMy41IHRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMFwiPkhvcmE8L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNSBweS0zLjUgdGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwIHRleHQtY2VudGVyXCI+VG90YWwgUGVyc29uYXM8L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNSBweS0zLjUgdGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwIHRleHQtcmlnaHRcIj5Nb250byBSZWNhdWRhZG88L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNSBweS0zLjUgdGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwIHRleHQtY2VudGVyXCI+QWNjaW9uZXM8L3RoPlxuICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtNTBcIj5cbiAgICAgICAgICAgICAgICAgIHtoaXN0b3JpYWwubWFwKChyZWcsIGkpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPEhpc3RvcmlhbFJvdyBrZXk9e3JlZy5pZF9yZWdpc3Ryb30gcmVnaXN0cm89e3JlZ30gaW5kZXg9e2l9IG9uVmVyRGV0YWxsZT17c2V0UmVnaXN0cm9EZXRhbGxlfSAvPlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiDilIDilIAgTU9EQUwgUEFSQSBSRUdJU1RSQVIgSU5HUkVTTyAoei1bOTk5OV0gUEFSQSBFVklUQVIgVFJBU0xBUEVTKSDilIDilIAgKi99XG4gICAgICB7c2hvd01vZGFsICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotWzk5OTldIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLXNsYXRlLTkwMC82MCBiYWNrZHJvcC1ibHVyLXNtIHAtNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0zeGwgbWF4LXcteGwgdy1mdWxsIHAtNiBzaGFkb3ctMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMTAwIHJlbGF0aXZlIG1heC1oLVs5MHZoXSBvdmVyZmxvdy15LWF1dG9cIj5cbiAgICAgICAgICAgIFxuICAgICAgICAgICAgey8qIEhlYWRlciBNb2RhbCAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBtYi01XCI+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwXCI+UmVnaXN0cmFyIE51ZXZvIEluZ3Jlc288L2gzPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5TZWxlY2Npb25hIG8gZXNjcmliZSBsYSBjYW50aWRhZCBkZSBlbnRyYWRhcyB2ZW5kaWRhczwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TW9kYWwoZmFsc2UpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctOSBoLTkgcm91bmRlZC1mdWxsIGJnLXNsYXRlLTEwMCB0ZXh0LXNsYXRlLTUwMCBob3ZlcjpiZy1zbGF0ZS0yMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPEljb25DbG9zZSAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlUmVnaXN0ZXJ9IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxuICAgICAgICAgICAgICB7LyogQ29udGFkb3JlcyBjb24gZW50cmFkYSBkZSB0ZXh0by9uw7ptZXJvICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICA8VGlja2V0Q291bnRlclxuICAgICAgICAgICAgICAgICAgbGFiZWw9XCJUYXJpZmEgMTUgQnNcIlxuICAgICAgICAgICAgICAgICAgcHJpY2U9ezE1fVxuICAgICAgICAgICAgICAgICAgY291bnQ9e3RhcmlmYTE1fVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldFRhcmlmYTE1fVxuICAgICAgICAgICAgICAgICAgY29sb3I9e3tcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAnYm9yZGVyLWJsdWUtMjAwJyxcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogJ3RleHQtYmx1ZS02MDAnLFxuICAgICAgICAgICAgICAgICAgICBiZzogJ2JnLWJsdWUtNTAnLFxuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDxUaWNrZXRDb3VudGVyXG4gICAgICAgICAgICAgICAgICBsYWJlbD1cIlRhcmlmYSAyMCBCc1wiXG4gICAgICAgICAgICAgICAgICBwcmljZT17MjB9XG4gICAgICAgICAgICAgICAgICBjb3VudD17dGFyaWZhMjB9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0VGFyaWZhMjB9XG4gICAgICAgICAgICAgICAgICBjb2xvcj17e1xuICAgICAgICAgICAgICAgICAgICBib3JkZXI6ICdib3JkZXItZW1lcmFsZC0yMDAnLFxuICAgICAgICAgICAgICAgICAgICB0ZXh0OiAndGV4dC1lbWVyYWxkLTYwMCcsXG4gICAgICAgICAgICAgICAgICAgIGJnOiAnYmctZW1lcmFsZC01MCcsXG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBDb21ib3MgUsOhcGlkb3MgKi99XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwIG1iLTJcIj5BdGFqb3MgUsOhcGlkb3M8L3A+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy00IGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICB7W1xuICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiAnMSBhZHVsdG8nLCB0MTU6IDAsIHQyMDogMSB9LFxuICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiAnMSBuacOxbycsIHQxNTogMSwgdDIwOiAwIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6ICdQYXJlamEgKDLDlzIwKScsIHQxNTogMCwgdDIwOiAyIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6ICdGYW1pbGlhICgyw5cyMCArIDLDlzE1KScsIHQxNTogMiwgdDIwOiAyIH0sXG4gICAgICAgICAgICAgICAgICBdLm1hcCgoeyBsYWJlbCwgdDE1LCB0MjAgfSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtsYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldFRhcmlmYTE1KHQxNSk7IHNldFRhcmlmYTIwKHQyMCkgfX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBob3Zlcjpib3JkZXItYmx1ZS00MDAgaG92ZXI6YmctYmx1ZS01MC81MCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS02MDAgdGV4dC1jZW50ZXIgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAge2xhYmVsfVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogT2JzZXJ2YWNpb25lcyAqL31cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgIE9ic2VydmFjaW9uZXMgKG9wY2lvbmFsKVxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqOiBHcnVwbyBlc2NvbGFyLCBwYWdvIGNvbiBRUiwgZXRjLlwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17b2JzZXJ2YWNpb25lc31cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0T2JzZXJ2YWNpb25lcyhlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0zIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwIHRleHQtc21cIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBUb3RhbCB5IEJvdMOzbiAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MCBwLTQgcm91bmRlZC0yeGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzYwXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgZm9udC1ib2xkIHVwcGVyY2FzZVwiPlRvdGFsIGEgcGFnYXI8L3A+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtZW1lcmFsZC02MDBcIj5Ccy4ge3RvdGFsUmVjYXVkYWRvLnRvRml4ZWQoMil9PC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBmb250LWJvbGQgdXBwZXJjYXNlXCI+UGVyc29uYXM8L3A+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMFwiPnt0b3RhbFBlcnNvbmFzfSBwZXJzLjwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBwdC0yXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TW9kYWwoZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzMgcHktMyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHRleHQtc2xhdGUtNjAwIGZvbnQtYm9sZCB0ZXh0LXNtIGhvdmVyOmJnLXNsYXRlLTEwMCB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgQ2FuY2VsYXJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nIHx8IHRvdGFsUGVyc29uYXMgPT09IDB9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTIvMyBweS0zIHJvdW5kZWQteGwgYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS03MDAgZGlzYWJsZWQ6b3BhY2l0eS01MCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCB0ZXh0LXNtIHNoYWRvdy1tZCBzaGFkb3ctYmx1ZS01MDAvMjAgdHJhbnNpdGlvbi1hbGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTJcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHtsb2FkaW5nID8gJ0d1YXJkYW5kby4uLicgOiAnQ29uZmlybWFyIGUgSW5zY3JpYmlyJ31cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIOKUgOKUgCBNT0RBTCBQQVJBIFZFUiBERVRBTExFUyBERSBSRUdJU1RSTyDilIDilIAgKi99XG4gICAgICB7cmVnaXN0cm9EZXRhbGxlICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotWzk5OTldIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLXNsYXRlLTkwMC82MCBiYWNrZHJvcC1ibHVyLXNtIHAtNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0zeGwgbWF4LXctbWQgdy1mdWxsIHAtNiBzaGFkb3ctMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMTAwIHJlbGF0aXZlXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwYi00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgbWItNFwiPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMFwiPkRldGFsbGVzIGRlbCBSZWdpc3RybzwvaDM+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgSG9yYToge3R5cGVvZiByZWdpc3Ryb0RldGFsbGUuaG9yYV9lbnRyYWRhID09PSAnc3RyaW5nJyAmJiByZWdpc3Ryb0RldGFsbGUuaG9yYV9lbnRyYWRhLmluY2x1ZGVzKCdUJykgPyByZWdpc3Ryb0RldGFsbGUuaG9yYV9lbnRyYWRhLnNwbGl0KCdUJylbMV0uc3Vic3RyaW5nKDAsIDgpIDogJ+KAlCd9XG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFJlZ2lzdHJvRGV0YWxsZShudWxsKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS01MDAgaG92ZXI6Ymctc2xhdGUtMjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxJY29uQ2xvc2UgLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcC0zIHJvdW5kZWQteGwgYmctYmx1ZS01MC83MCBib3JkZXIgYm9yZGVyLWJsdWUtMTAwXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtYmx1ZS03MDBcIj5FbnRyYWRhcyAxNSBCczwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1iYXNlIHRleHQtYmx1ZS04MDBcIj57cmVnaXN0cm9EZXRhbGxlLmNhbnRpZGFkX3RhcmlmYV8xNX0gcGVyc29uYXM8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHAtMyByb3VuZGVkLXhsIGJnLWVtZXJhbGQtNTAvNzAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTEwMFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWVtZXJhbGQtNzAwXCI+RW50cmFkYXMgMjAgQnM8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtYmFzZSB0ZXh0LWVtZXJhbGQtODAwXCI+e3JlZ2lzdHJvRGV0YWxsZS5jYW50aWRhZF90YXJpZmFfMjB9IHBlcnNvbmFzPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwLTMgcm91bmRlZC14bCBiZy1zbGF0ZS01MCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTYwMFwiPlRvdGFsIFBlcnNvbmFzPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWJhc2UgdGV4dC1zbGF0ZS04MDBcIj57cmVnaXN0cm9EZXRhbGxlLnRvdGFsX3BlcnNvbmFzfSBwZXJzLjwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcC0zIHJvdW5kZWQteGwgYmctc2xhdGUtOTAwIHRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGRcIj5Ub3RhbCBSZWNhdWRhZG88L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ibGFjayB0ZXh0LWxnXCI+QnMuIHtwYXJzZUZsb2F0KHJlZ2lzdHJvRGV0YWxsZS50b3RhbF9yZWNhdWRhZG8pLnRvRml4ZWQoMil9PC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTJcIj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgbWItMVwiPk9ic2VydmFjaW9uZXM8L3A+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgcm91bmRlZC14bCBiZy1zbGF0ZS01MCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCB0ZXh0LXNtIHRleHQtc2xhdGUtNzAwIGl0YWxpY1wiPlxuICAgICAgICAgICAgICAgICAge3JlZ2lzdHJvRGV0YWxsZS5vYnNlcnZhY2lvbmVzIHx8ICdTaW4gb2JzZXJ2YWNpb25lcyByZWdpc3RyYWRhcyd9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UmVnaXN0cm9EZXRhbGxlKG51bGwpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgbXQtNiBweS0zIHJvdW5kZWQteGwgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTkwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCB0ZXh0LXNtIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgQ2VycmFyXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApXG59XG5cbiJdfQ==