import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Reportes/index.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=41a64c35";
import api from "/src/services/api.js";
import { useAuth } from "/src/context/AuthContext.jsx";
import { ResponsiveContainer, LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ReferenceLine } from "/node_modules/.vite/deps/recharts.js?v=41a64c35";
var _jsxFileName = "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Reportes/index.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=41a64c35";
var _s = $RefreshSig$();
export default function ReportesPage() {
	_s();
	const { session } = useAuth();
	// Filtros de navegación
	const [tipoReporte, setTipoReporte] = useState("calidad_agua");
	const [tipoRango, setTipoRango] = useState("semana");
	const [fechaInicio, setFechaInicio] = useState("");
	const [fechaFin, setFechaFin] = useState("");
	// Estados de carga y datos
	const [loading, setLoading] = useState(false);
	const [exportingPdf, setExportingPdf] = useState(false);
	const [dataCalidad, setDataCalidad] = useState(null);
	const [dataQuimicos, setDataQuimicos] = useState(null);
	const [dataAfluencia, setDataAfluencia] = useState(null);
	const [notification, setNotification] = useState(null);
	// Paginación para la tabla de mediciones
	const [paginaActual, setPaginaActual] = useState(1);
	const elementosPorPagina = 12;
	// Establecer fechas iniciales para personalizado si están vacías
	useEffect(() => {
		const hoyStr = new Date().toISOString().split("T")[0];
		const hace7dias = new Date(Date.now() - 6 * 24 * 60 * 60 * 1e3).toISOString().split("T")[0];
		setFechaInicio(hace7dias);
		setFechaFin(hoyStr);
	}, []);
	// Carga de datos
	const cargarReporte = useCallback(async () => {
		setLoading(true);
		setNotification(null);
		const params = {
			tipo_rango: tipoRango,
			fecha_inicio: tipoRango === "personalizado" ? fechaInicio : undefined,
			fecha_fin: tipoRango === "personalizado" ? fechaFin : undefined
		};
		try {
			if (tipoReporte === "calidad_agua" || tipoReporte === "completo") {
				const { data } = await api.get("/reportes/calidad-agua", { params });
				setDataCalidad(data);
			}
			if (tipoReporte === "dosificacion" || tipoReporte === "completo") {
				const { data } = await api.get("/reportes/quimicos-dosificacion", { params });
				setDataQuimicos(data);
			}
			if (tipoReporte === "afluencia" || tipoReporte === "completo") {
				const { data } = await api.get("/reportes/afluencia", { params });
				setDataAfluencia(data);
			}
		} catch (error) {
			console.error("Error cargando reportes:", error);
			const errorMsg = error.response?.data?.detail || "No se pudo cargar la información del reporte. Intente nuevamente.";
			setNotification({
				type: "error",
				msg: errorMsg
			});
		} finally {
			setLoading(false);
		}
	}, [
		tipoReporte,
		tipoRango,
		fechaInicio,
		fechaFin
	]);
	useEffect(() => {
		cargarReporte();
	}, [cargarReporte]);
	// Exportar PDF formal (RF-05 / RF-20)
	const handleExportarPdf = async () => {
		setExportingPdf(true);
		setNotification(null);
		try {
			const nombreUsuario = session?.usuario ? `${session.usuario.nombre || ""} ${session.usuario.primer_apellido || ""}`.trim() : "Administrador";
			const response = await api.get("/reportes/pdf", {
				params: {
					tipo_reporte: tipoReporte,
					tipo_rango: tipoRango,
					fecha_inicio: tipoRango === "personalizado" ? fechaInicio : undefined,
					fecha_fin: tipoRango === "personalizado" ? fechaFin : undefined,
					usuario_generador: nombreUsuario || "Administrador General"
				},
				responseType: "blob"
			});
			// Crear enlace temporal de descarga
			const blob = new Blob([response.data], { type: "application/pdf" });
			const url = window.URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			const hoyStr = new Date().toISOString().split("T")[0];
			a.download = `reporte_playa_azul_${tipoReporte}_${hoyStr}.pdf`;
			document.body.appendChild(a);
			a.click();
			window.URL.revokeObjectURL(url);
			a.remove();
			setNotification({
				type: "success",
				msg: "Reporte oficial en PDF generado y descargado exitosamente."
			});
		} catch (error) {
			console.error("Error al exportar PDF:", error);
			setNotification({
				type: "error",
				msg: "Ocurrió un error al generar el archivo PDF. Verifique la conexión con el servidor."
			});
		} finally {
			setExportingPdf(false);
		}
	};
	// Paginación de mediciones
	const mediciones = dataCalidad?.mediciones || [];
	const totalPaginas = Math.ceil(mediciones.length / elementosPorPagina) || 1;
	const medicionesPaginadas = mediciones.slice((paginaActual - 1) * elementosPorPagina, paginaActual * elementosPorPagina);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-50 pb-16 dark:bg-[#1A222C]",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white dark:bg-[#24303F] border-b border-slate-200 dark:border-[#313D4A] px-6 py-6 shadow-sm",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 mb-1",
						children: [/* @__PURE__ */ _jsxDEV("span", { className: "h-2 w-2 rounded-full bg-blue-600 animate-pulse" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 143,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs font-bold tracking-widest uppercase text-blue-600 dark:text-blue-400",
							children: "Piscina Playa Azul — Reyes, Beni"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 142,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-2xl font-black text-slate-800 dark:text-white flex items-center gap-3",
						children: /* @__PURE__ */ _jsxDEV("span", { children: "📊 Módulo de Reportes Institucionales" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 149,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 148,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1",
						children: "Documentación técnica, estadísticas fisicoquímicas, consumo de insumos y cumplimiento normativo (Ley Municipal 020 / RD 742/2013)."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 151,
						columnNumber: 13
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 141,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: cargarReporte,
						disabled: loading,
						className: "flex items-center gap-2 bg-slate-100 hover:bg-slate-200 dark:bg-[#313D4A] dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 px-4 py-2.5 rounded-xl font-semibold text-sm transition-all shadow-sm disabled:opacity-50",
						children: [/* @__PURE__ */ _jsxDEV("svg", {
							className: `w-4 h-4 ${loading ? "animate-spin" : ""}`,
							fill: "none",
							stroke: "currentColor",
							viewBox: "0 0 24 24",
							children: /* @__PURE__ */ _jsxDEV("path", {
								strokeLinecap: "round",
								strokeLinejoin: "round",
								strokeWidth: "2",
								d: "M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 163,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 162,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: loading ? "Actualizando..." : "Actualizar" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 165,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 157,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: handleExportarPdf,
						disabled: exportingPdf || loading,
						className: "flex items-center gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-5 py-2.5 rounded-xl font-bold text-sm transition-all shadow-md hover:shadow-lg disabled:opacity-50",
						children: exportingPdf ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("svg", {
							className: "w-4 h-4 animate-spin",
							fill: "none",
							stroke: "currentColor",
							viewBox: "0 0 24 24",
							children: [/* @__PURE__ */ _jsxDEV("circle", {
								className: "opacity-25",
								cx: "12",
								cy: "12",
								r: "10",
								stroke: "currentColor",
								strokeWidth: "4"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 176,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV("path", {
								className: "opacity-75",
								fill: "currentColor",
								d: "M4 12a8 8 0 018-8v8H4z"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 177,
								columnNumber: 21
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 175,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Generando PDF..." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 179,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 174,
							columnNumber: 17
						}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("svg", {
							className: "w-4 h-4",
							fill: "none",
							stroke: "currentColor",
							viewBox: "0 0 24 24",
							children: /* @__PURE__ */ _jsxDEV("path", {
								strokeLinecap: "round",
								strokeLinejoin: "round",
								strokeWidth: "2",
								d: "M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 184,
								columnNumber: 21
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 183,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Exportar a PDF" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 186,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 182,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 168,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 156,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 140,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 139,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "max-w-7xl mx-auto px-6 mt-6 space-y-6",
			children: [
				notification && /* @__PURE__ */ _jsxDEV("div", {
					className: `p-4 rounded-xl flex items-center justify-between text-sm font-medium ${notification.type === "error" ? "bg-rose-50 border border-rose-200 text-rose-700 dark:bg-rose-950/30 dark:border-rose-900/50 dark:text-rose-400" : "bg-emerald-50 border border-emerald-200 text-emerald-700 dark:bg-emerald-950/30 dark:border-emerald-900/50 dark:text-emerald-400"}`,
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: notification.type === "error" ? "⚠️" : "✅" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 205,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: notification.msg }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 206,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 204,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setNotification(null),
						className: "text-xs underline opacity-70 hover:opacity-100",
						children: "Cerrar"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 208,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 197,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-[#24303F] rounded-2xl p-5 border border-slate-200 dark:border-[#313D4A] shadow-sm flex flex-col lg:flex-row lg:items-center justify-between gap-5",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							{
								id: "calidad_agua",
								label: "💧 Calidad del Agua",
								desc: "pH, Turbidez, Temp."
							},
							{
								id: "dosificacion",
								label: "🧪 Químicos y Dosis",
								desc: "Cloro, Cobre, Aluminio"
							},
							{
								id: "afluencia",
								label: "👥 Afluencia Bañistas",
								desc: "Taquilla y Cámara"
							},
							{
								id: "completo",
								label: "📑 Consolidado Global",
								desc: "Informe Integral"
							}
						].map((tab) => /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => {
								setTipoReporte(tab.id);
								setPaginaActual(1);
							},
							className: `px-4 py-2 rounded-xl text-xs md:text-sm font-bold transition-all flex flex-col text-left ${tipoReporte === tab.id ? "bg-blue-600 text-white shadow-md shadow-blue-500/20" : "bg-slate-50 dark:bg-[#1A222C] text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"}`,
							children: [/* @__PURE__ */ _jsxDEV("span", { children: tab.label }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 236,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: `text-[10px] font-normal ${tipoReporte === tab.id ? "text-blue-100" : "text-slate-400"}`,
								children: tab.desc
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 237,
								columnNumber: 17
							}, this)]
						}, tab.id, true, {
							fileName: _jsxFileName,
							lineNumber: 224,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 217,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-wrap items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-slate-100 dark:bg-[#1A222C] p-1 rounded-xl flex items-center gap-1 border border-slate-200 dark:border-[#313D4A]",
							children: [
								{
									id: "hoy",
									label: "Hoy"
								},
								{
									id: "semana",
									label: "7 Días"
								},
								{
									id: "mes",
									label: "30 Días"
								},
								{
									id: "personalizado",
									label: "Rango libre"
								}
							].map((rango) => /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => {
									setTipoRango(rango.id);
									setPaginaActual(1);
								},
								className: `px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${tipoRango === rango.id ? "bg-white dark:bg-[#24303F] text-blue-600 dark:text-blue-400 shadow-sm" : "text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white"}`,
								children: rango.label
							}, rango.id, false, {
								fileName: _jsxFileName,
								lineNumber: 253,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 246,
							columnNumber: 13
						}, this), tipoRango === "personalizado" && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("input", {
									type: "date",
									value: fechaInicio,
									onChange: (e) => setFechaInicio(e.target.value),
									className: "px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-[#313D4A] bg-slate-50 dark:bg-[#1A222C] text-slate-800 dark:text-white"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 272,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400",
									children: "a"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 278,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									type: "date",
									value: fechaFin,
									onChange: (e) => setFechaFin(e.target.value),
									className: "px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-[#313D4A] bg-slate-50 dark:bg-[#1A222C] text-slate-800 dark:text-white"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 279,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 271,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 245,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 215,
					columnNumber: 9
				}, this),
				(tipoReporte === "calidad_agua" || tipoReporte === "completo") && dataCalidad && /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-6",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-white dark:bg-[#24303F] p-5 rounded-2xl border border-slate-200 dark:border-[#313D4A] shadow-sm relative overflow-hidden",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs font-bold uppercase tracking-wider text-slate-400",
												children: "pH Promedio"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 298,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs px-2 py-0.5 rounded-full font-bold bg-blue-50 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400",
												children: "Norma: 7.2 - 7.6"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 299,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 297,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "mt-3 flex items-baseline gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-3xl font-black text-slate-800 dark:text-white",
												children: dataCalidad.estadisticas.ph.promedio ?? "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 304,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs text-slate-500 dark:text-slate-400",
												children: [
													"(Mín: ",
													dataCalidad.estadisticas.ph.min ?? "—",
													" / Máx: ",
													dataCalidad.estadisticas.ph.max ?? "—",
													")"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 307,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 303,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "mt-3",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between text-xs font-semibold mb-1",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "text-slate-500",
													children: "Cumplimiento:"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 313,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-emerald-600 dark:text-emerald-400 font-bold",
													children: [dataCalidad.estadisticas.ph.pct_cumplimiento, "%"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 314,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 312,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "w-full h-1.5 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "h-full bg-emerald-500 rounded-full",
													style: { width: `${dataCalidad.estadisticas.ph.pct_cumplimiento}%` }
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 319,
													columnNumber: 21
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 318,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 311,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 296,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-white dark:bg-[#24303F] p-5 rounded-2xl border border-slate-200 dark:border-[#313D4A] shadow-sm relative overflow-hidden",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs font-bold uppercase tracking-wider text-slate-400",
												children: "Turbidez Media"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 330,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs px-2 py-0.5 rounded-full font-bold bg-amber-50 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400",
												children: "Límite: < 5.0 NTU"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 331,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 329,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "mt-3 flex items-baseline gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-3xl font-black text-slate-800 dark:text-white",
												children: dataCalidad.estadisticas.turbidez.promedio ?? "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 336,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs text-slate-500 dark:text-slate-400",
												children: "NTU"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 339,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 335,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "mt-3",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between text-xs font-semibold mb-1",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "text-slate-500",
													children: "Cumplimiento:"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 343,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-emerald-600 dark:text-emerald-400 font-bold",
													children: [dataCalidad.estadisticas.turbidez.pct_cumplimiento, "%"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 344,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 342,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "w-full h-1.5 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "h-full bg-amber-500 rounded-full",
													style: { width: `${dataCalidad.estadisticas.turbidez.pct_cumplimiento}%` }
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 349,
													columnNumber: 21
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 348,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 341,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 328,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-white dark:bg-[#24303F] p-5 rounded-2xl border border-slate-200 dark:border-[#313D4A] shadow-sm relative overflow-hidden",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs font-bold uppercase tracking-wider text-slate-400",
												children: "Temperatura Media"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 360,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs px-2 py-0.5 rounded-full font-bold bg-teal-50 text-teal-600 dark:bg-teal-900/30 dark:text-teal-400",
												children: "26°C - 28°C"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 361,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 359,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "mt-3 flex items-baseline gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-3xl font-black text-slate-800 dark:text-white",
												children: dataCalidad.estadisticas.temperatura.promedio ?? "—"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 366,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs text-slate-500 dark:text-slate-400",
												children: "°C"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 369,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 365,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "mt-3",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between text-xs font-semibold mb-1",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "text-slate-500",
													children: "Cumplimiento:"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 373,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-emerald-600 dark:text-emerald-400 font-bold",
													children: [dataCalidad.estadisticas.temperatura.pct_cumplimiento, "%"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 374,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 372,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "w-full h-1.5 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "h-full bg-teal-500 rounded-full",
													style: { width: `${dataCalidad.estadisticas.temperatura.pct_cumplimiento}%` }
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 379,
													columnNumber: 21
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 378,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 371,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 358,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-gradient-to-br from-blue-600 to-indigo-700 p-5 rounded-2xl text-white shadow-md relative overflow-hidden",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs font-bold uppercase tracking-wider text-blue-200",
											children: "Índice Sanitario Global"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 390,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs bg-white/20 px-2 py-0.5 rounded-full font-bold",
											children: [dataCalidad.total_mediciones, " muestras"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 391,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 389,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "mt-3 flex items-baseline gap-2",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-4xl font-black",
											children: [dataCalidad.indice_global_cumplimiento, "%"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 396,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs text-blue-100 font-medium",
											children: "conforme a norma"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 397,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 395,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 388,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 294,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 lg:grid-cols-2 gap-6",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-white dark:bg-[#24303F] p-6 rounded-2xl border border-slate-200 dark:border-[#313D4A] shadow-sm",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between mb-4",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
											className: "font-bold text-slate-800 dark:text-white",
											children: "Evolución del pH del Agua"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 409,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-400",
											children: "Rango normativo óptimo entre 7.20 y 7.60"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 410,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 408,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs font-semibold px-2 py-1 rounded-lg bg-blue-50 text-blue-600 dark:bg-blue-900/30 dark:text-blue-300",
											children: "Ideal: 7.4"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 412,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 407,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "h-64",
										children: /* @__PURE__ */ _jsxDEV(ResponsiveContainer, {
											width: "100%",
											height: "100%",
											children: /* @__PURE__ */ _jsxDEV(LineChart, {
												data: dataCalidad.mediciones,
												children: [
													/* @__PURE__ */ _jsxDEV(CartesianGrid, {
														strokeDasharray: "3 3",
														opacity: .2
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 419,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ _jsxDEV(XAxis, {
														dataKey: "hora",
														tick: { fontSize: 10 }
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 420,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ _jsxDEV(YAxis, {
														domain: [6.5, 9],
														tick: { fontSize: 10 }
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 421,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ _jsxDEV(Tooltip, { contentStyle: {
														backgroundColor: "#1E293B",
														borderRadius: "8px",
														border: "none",
														color: "#fff",
														fontSize: "11px"
													} }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 422,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ _jsxDEV(ReferenceLine, {
														y: 7.2,
														stroke: "#EF4444",
														strokeDasharray: "4 4",
														label: {
															value: "Mín 7.2",
															fill: "#EF4444",
															fontSize: 10
														}
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 431,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ _jsxDEV(ReferenceLine, {
														y: 7.6,
														stroke: "#EF4444",
														strokeDasharray: "4 4",
														label: {
															value: "Máx 7.6",
															fill: "#EF4444",
															fontSize: 10
														}
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 432,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ _jsxDEV(Line, {
														type: "monotone",
														dataKey: "ph",
														stroke: "#2563EB",
														strokeWidth: 2.5,
														dot: { r: 2 },
														activeDot: { r: 5 },
														name: "pH Medido"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 433,
														columnNumber: 23
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 418,
												columnNumber: 21
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 417,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 416,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 406,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-white dark:bg-[#24303F] p-6 rounded-2xl border border-slate-200 dark:border-[#313D4A] shadow-sm",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between mb-4",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
											className: "font-bold text-slate-800 dark:text-white",
											children: "Evolución de Turbidez (NTU)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 443,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-400",
											children: "Límite normativo máximo: 5.0 NTU"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 444,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 442,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs font-semibold px-2 py-1 rounded-lg bg-amber-50 text-amber-600 dark:bg-amber-900/30 dark:text-amber-300",
											children: "< 5.0 NTU"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 446,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 441,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "h-64",
										children: /* @__PURE__ */ _jsxDEV(ResponsiveContainer, {
											width: "100%",
											height: "100%",
											children: /* @__PURE__ */ _jsxDEV(LineChart, {
												data: dataCalidad.mediciones,
												children: [
													/* @__PURE__ */ _jsxDEV(CartesianGrid, {
														strokeDasharray: "3 3",
														opacity: .2
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 453,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ _jsxDEV(XAxis, {
														dataKey: "hora",
														tick: { fontSize: 10 }
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 454,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ _jsxDEV(YAxis, {
														domain: [0, 15],
														tick: { fontSize: 10 }
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 455,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ _jsxDEV(Tooltip, { contentStyle: {
														backgroundColor: "#1E293B",
														borderRadius: "8px",
														border: "none",
														color: "#fff",
														fontSize: "11px"
													} }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 456,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ _jsxDEV(ReferenceLine, {
														y: 5,
														stroke: "#F59E0B",
														strokeDasharray: "4 4",
														label: {
															value: "Límite 5.0",
															fill: "#F59E0B",
															fontSize: 10
														}
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 465,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ _jsxDEV(Line, {
														type: "monotone",
														dataKey: "turbidez",
														stroke: "#F59E0B",
														strokeWidth: 2.5,
														dot: { r: 2 },
														activeDot: { r: 5 },
														name: "Turbidez (NTU)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 466,
														columnNumber: 23
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 452,
												columnNumber: 21
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 451,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 450,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 440,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-white dark:bg-[#24303F] p-6 rounded-2xl border border-slate-200 dark:border-[#313D4A] shadow-sm lg:col-span-2",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between mb-4",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
											className: "font-bold text-slate-800 dark:text-white",
											children: "Evolución de Temperatura del Agua (°C)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 476,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-400",
											children: "Rango de confort recreativo entre 26.0 °C y 28.0 °C (Límites permitidos: 24.0 °C – 30.0 °C)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 477,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 475,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs font-semibold px-2 py-1 rounded-lg bg-teal-50 text-teal-600 dark:bg-teal-900/30 dark:text-teal-300",
											children: "Confort: 26°C - 28°C"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 479,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 474,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "h-64",
										children: /* @__PURE__ */ _jsxDEV(ResponsiveContainer, {
											width: "100%",
											height: "100%",
											children: /* @__PURE__ */ _jsxDEV(LineChart, {
												data: dataCalidad.mediciones,
												children: [
													/* @__PURE__ */ _jsxDEV(CartesianGrid, {
														strokeDasharray: "3 3",
														opacity: .2
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 486,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ _jsxDEV(XAxis, {
														dataKey: tipoRango === "hoy" ? "hora" : "fecha_hora",
														tick: { fontSize: 10 }
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 487,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ _jsxDEV(YAxis, {
														domain: [20, 35],
														tick: { fontSize: 10 }
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 488,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ _jsxDEV(Tooltip, { contentStyle: {
														backgroundColor: "#1E293B",
														borderRadius: "8px",
														border: "none",
														color: "#fff",
														fontSize: "11px"
													} }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 489,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ _jsxDEV(ReferenceLine, {
														y: 24,
														stroke: "#0D9488",
														strokeDasharray: "4 4",
														label: {
															value: "Mín 24°C",
															fill: "#0D9488",
															fontSize: 10
														}
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 498,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ _jsxDEV(ReferenceLine, {
														y: 30,
														stroke: "#0D9488",
														strokeDasharray: "4 4",
														label: {
															value: "Máx 30°C",
															fill: "#0D9488",
															fontSize: 10
														}
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 499,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ _jsxDEV(Line, {
														type: "monotone",
														dataKey: "temperatura",
														stroke: "#0D9488",
														strokeWidth: 2.5,
														dot: { r: 2 },
														activeDot: { r: 5 },
														name: "Temperatura (°C)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 500,
														columnNumber: 23
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 485,
												columnNumber: 21
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 484,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 483,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 473,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 404,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-white dark:bg-[#24303F] p-6 rounded-2xl border border-slate-200 dark:border-[#313D4A] shadow-sm",
							children: [
								/* @__PURE__ */ _jsxDEV("h3", {
									className: "font-bold text-slate-800 dark:text-white flex items-center gap-2 mb-3",
									children: /* @__PURE__ */ _jsxDEV("span", { children: "📋 Dictamen y Recomendaciones Técnicas" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 510,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 509,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-1 md:grid-cols-3 gap-4 mb-4",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-3.5 rounded-xl bg-slate-50 dark:bg-[#1A222C] border border-slate-100 dark:border-[#313D4A]",
											children: [
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-xs text-slate-400",
													children: "Alertas de pH ácido / alcalino"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 514,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-xl font-bold text-slate-800 dark:text-white mt-1",
													children: [dataCalidad.alertas.ph_acido + dataCalidad.alertas.ph_alcalino, " eventos"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 515,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[11px] text-slate-400",
													children: [
														"(",
														dataCalidad.alertas.ph_acido,
														" ácidos / ",
														dataCalidad.alertas.ph_alcalino,
														" alcalinos)"
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 518,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 513,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-3.5 rounded-xl bg-slate-50 dark:bg-[#1A222C] border border-slate-100 dark:border-[#313D4A]",
											children: [
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-xs text-slate-400",
													children: "Alertas de turbidez (≥ 5 NTU)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 523,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-xl font-bold text-slate-800 dark:text-white mt-1",
													children: [dataCalidad.alertas.turbidez_alta + dataCalidad.alertas.turbidez_critica, " eventos"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 524,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[11px] text-slate-400",
													children: [
														"(",
														dataCalidad.alertas.turbidez_critica,
														" críticas ≥ 10 NTU)"
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 527,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 522,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-3.5 rounded-xl bg-slate-50 dark:bg-[#1A222C] border border-slate-100 dark:border-[#313D4A]",
											children: [
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-xs text-slate-400",
													children: "Desviaciones de temperatura"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 532,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-xl font-bold text-slate-800 dark:text-white mt-1",
													children: [dataCalidad.alertas.temp_fuera_rango, " eventos"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 533,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[11px] text-slate-400",
													children: "Fuera de 24°C - 30°C"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 536,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 531,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 512,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("ul", {
									className: "space-y-1.5 text-xs md:text-sm text-slate-600 dark:text-slate-300",
									children: dataCalidad.evaluacion_tecnica?.map((item, idx) => /* @__PURE__ */ _jsxDEV("li", {
										className: "flex items-start gap-2",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-blue-500 font-bold",
											children: "•"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 542,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: item }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 543,
											columnNumber: 21
										}, this)]
									}, idx, true, {
										fileName: _jsxFileName,
										lineNumber: 541,
										columnNumber: 19
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 539,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 508,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-white dark:bg-[#24303F] rounded-2xl border border-slate-200 dark:border-[#313D4A] shadow-sm overflow-hidden",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "px-6 py-4 border-b border-slate-100 dark:border-[#313D4A] flex items-center justify-between",
									children: /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
										className: "font-bold text-slate-800 dark:text-white",
										children: "Registros de Muestreo de Calidad"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 553,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-400",
										children: [
											"Mostrando página ",
											paginaActual,
											" de ",
											totalPaginas,
											" (",
											mediciones.length,
											" lecturas totales)"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 554,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 552,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 551,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "overflow-x-auto",
									children: /* @__PURE__ */ _jsxDEV("table", {
										className: "w-full text-left text-xs",
										children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
											className: "bg-slate-50 dark:bg-[#1A222C] border-b border-slate-100 dark:border-[#313D4A]",
											children: [
												/* @__PURE__ */ _jsxDEV("th", {
													className: "px-5 py-3 text-slate-400 font-bold uppercase",
													children: "Fecha y Hora"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 563,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("th", {
													className: "px-5 py-3 text-slate-400 font-bold uppercase",
													children: "pH"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 564,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("th", {
													className: "px-5 py-3 text-slate-400 font-bold uppercase",
													children: "Turbidez (NTU)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 565,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("th", {
													className: "px-5 py-3 text-slate-400 font-bold uppercase",
													children: "Temperatura (°C)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 566,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("th", {
													className: "px-5 py-3 text-slate-400 font-bold uppercase",
													children: "Estado Sanitario"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 567,
													columnNumber: 23
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 562,
											columnNumber: 21
										}, this) }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 561,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("tbody", {
											className: "divide-y divide-slate-100 dark:divide-[#313D4A]",
											children: medicionesPaginadas.length === 0 ? /* @__PURE__ */ _jsxDEV("tr", { children: /* @__PURE__ */ _jsxDEV("td", {
												colSpan: "5",
												className: "text-center py-8 text-slate-400 font-medium",
												children: "No se encontraron lecturas en el rango seleccionado"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 573,
												columnNumber: 25
											}, this) }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 572,
												columnNumber: 23
											}, this) : medicionesPaginadas.map((m) => /* @__PURE__ */ _jsxDEV("tr", {
												className: "hover:bg-slate-50 dark:hover:bg-[#313D4A]/30 transition-colors",
												children: [
													/* @__PURE__ */ _jsxDEV("td", {
														className: "px-5 py-3 font-medium text-slate-700 dark:text-slate-300",
														children: m.fecha_hora
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 580,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("td", {
														className: "px-5 py-3 font-semibold",
														children: /* @__PURE__ */ _jsxDEV("span", {
															className: `px-2 py-0.5 rounded-full font-bold ${m.estado_ph === "OPTIMO" ? "bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400" : "bg-rose-50 text-rose-600 dark:bg-rose-950/40 dark:text-rose-400"}`,
															children: [
																m.ph !== null ? m.ph.toFixed(2) : "—",
																" (",
																m.estado_ph,
																")"
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 584,
															columnNumber: 29
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 583,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("td", {
														className: "px-5 py-3 font-semibold",
														children: /* @__PURE__ */ _jsxDEV("span", {
															className: `px-2 py-0.5 rounded-full font-bold ${m.estado_turbidez === "OPTIMA" ? "bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400" : "bg-amber-50 text-amber-600 dark:bg-amber-950/40 dark:text-amber-400"}`,
															children: [m.turbidez !== null ? m.turbidez.toFixed(2) : "—", " NTU"]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 595,
															columnNumber: 29
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 594,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("td", {
														className: "px-5 py-3 text-slate-700 dark:text-slate-300",
														children: m.temperatura !== null ? `${m.temperatura.toFixed(1)} °C` : "—"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 605,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("td", {
														className: "px-5 py-3",
														children: /* @__PURE__ */ _jsxDEV("span", {
															className: `inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold ${m.conforme ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300" : "bg-rose-100 text-rose-800 dark:bg-rose-900/40 dark:text-rose-300"}`,
															children: [/* @__PURE__ */ _jsxDEV("span", { className: `w-1.5 h-1.5 rounded-full ${m.conforme ? "bg-emerald-500" : "bg-rose-500"}` }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 616,
																columnNumber: 31
															}, this), m.conforme ? "CONFORME" : "FUERA DE NORMA"]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 609,
															columnNumber: 29
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 608,
														columnNumber: 27
													}, this)
												]
											}, m.id_medicion, true, {
												fileName: _jsxFileName,
												lineNumber: 579,
												columnNumber: 25
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 570,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 560,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 559,
									columnNumber: 15
								}, this),
								totalPaginas > 1 && /* @__PURE__ */ _jsxDEV("div", {
									className: "px-6 py-3 border-t border-slate-100 dark:border-[#313D4A] flex items-center justify-between",
									children: [
										/* @__PURE__ */ _jsxDEV("button", {
											disabled: paginaActual === 1,
											onClick: () => setPaginaActual((p) => Math.max(1, p - 1)),
											className: "px-3 py-1 rounded-lg border border-slate-200 dark:border-[#313D4A] text-xs font-semibold text-slate-600 dark:text-slate-300 disabled:opacity-40",
											children: "Anterior"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 630,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs text-slate-500",
											children: [
												"Página ",
												paginaActual,
												" de ",
												totalPaginas
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 637,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											disabled: paginaActual === totalPaginas,
											onClick: () => setPaginaActual((p) => Math.min(totalPaginas, p + 1)),
											className: "px-3 py-1 rounded-lg border border-slate-200 dark:border-[#313D4A] text-xs font-semibold text-slate-600 dark:text-slate-300 disabled:opacity-40",
											children: "Siguiente"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 640,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 629,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 550,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 292,
					columnNumber: 11
				}, this),
				(tipoReporte === "dosificacion" || tipoReporte === "completo") && dataQuimicos && /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-6",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white dark:bg-[#24303F] p-5 rounded-2xl border border-slate-200 dark:border-[#313D4A] shadow-sm",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold uppercase text-slate-400",
										children: "Cloro Aplicado"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 658,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-2xl font-black text-slate-800 dark:text-white mt-2",
										children: [dataQuimicos.totales_dosificados_kg.cloro, " kg"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 659,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "mt-2 text-xs flex justify-between text-slate-500",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: [dataQuimicos.conteo_activaciones.cloro, " dosis"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 663,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-blue-600 dark:text-blue-400",
											children: ["Bs. ", dataQuimicos.costos_estimados_bs.cloro.toFixed(2)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 664,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 662,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 657,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white dark:bg-[#24303F] p-5 rounded-2xl border border-slate-200 dark:border-[#313D4A] shadow-sm",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold uppercase text-slate-400",
										children: "Sulfato de Aluminio"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 671,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-2xl font-black text-slate-800 dark:text-white mt-2",
										children: [dataQuimicos.totales_dosificados_kg["sulfato de aluminio"], " kg"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 672,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "mt-2 text-xs flex justify-between text-slate-500",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: [dataQuimicos.conteo_activaciones["sulfato de aluminio"], " dosis"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 676,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-blue-600 dark:text-blue-400",
											children: ["Bs. ", dataQuimicos.costos_estimados_bs["sulfato de aluminio"].toFixed(2)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 677,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 675,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 670,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white dark:bg-[#24303F] p-5 rounded-2xl border border-slate-200 dark:border-[#313D4A] shadow-sm",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold uppercase text-slate-400",
										children: "Sulfato de Cobre"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 684,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-2xl font-black text-slate-800 dark:text-white mt-2",
										children: [dataQuimicos.totales_dosificados_kg["sulfato de cobre"], " kg"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 685,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "mt-2 text-xs flex justify-between text-slate-500",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: [dataQuimicos.conteo_activaciones["sulfato de cobre"], " dosis"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 689,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-blue-600 dark:text-blue-400",
											children: ["Bs. ", dataQuimicos.costos_estimados_bs["sulfato de cobre"].toFixed(2)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 690,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 688,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 683,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-gradient-to-br from-emerald-600 to-teal-700 p-5 rounded-2xl text-white shadow-md",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold uppercase tracking-wider text-emerald-100",
										children: "Costo Total de Insumos"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 697,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-3xl font-black mt-2",
										children: ["Bs. ", dataQuimicos.costo_total_bs.toFixed(2)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 698,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "mt-2 text-xs text-emerald-100",
										children: [
											"Total de ",
											dataQuimicos.total_registros_dosificacion,
											" dosificaciones en el período."
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 699,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 696,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 656,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-[#24303F] p-6 rounded-2xl border border-slate-200 dark:border-[#313D4A] shadow-sm",
						children: [
							/* @__PURE__ */ _jsxDEV("h3", {
								className: "font-bold text-slate-800 dark:text-white mb-1",
								children: "Comparativa de Consumo por Insumo Químico"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 707,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-400 mb-4",
								children: "Gramos dosificados según registros del sistema"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 710,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "h-64",
								children: /* @__PURE__ */ _jsxDEV(ResponsiveContainer, {
									width: "100%",
									height: "100%",
									children: /* @__PURE__ */ _jsxDEV(BarChart, {
										data: [
											{
												name: "Cloro",
												gramos: dataQuimicos.totales_dosificados_g.cloro,
												costoBs: dataQuimicos.costos_estimados_bs.cloro
											},
											{
												name: "Sulfato Aluminio",
												gramos: dataQuimicos.totales_dosificados_g["sulfato de aluminio"],
												costoBs: dataQuimicos.costos_estimados_bs["sulfato de aluminio"]
											},
											{
												name: "Sulfato Cobre",
												gramos: dataQuimicos.totales_dosificados_g["sulfato de cobre"],
												costoBs: dataQuimicos.costos_estimados_bs["sulfato de cobre"]
											}
										],
										children: [
											/* @__PURE__ */ _jsxDEV(CartesianGrid, {
												strokeDasharray: "3 3",
												opacity: .2
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 732,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV(XAxis, {
												dataKey: "name",
												tick: { fontSize: 11 }
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 733,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV(YAxis, { tick: { fontSize: 10 } }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 734,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV(Tooltip, { contentStyle: {
												backgroundColor: "#1E293B",
												borderRadius: "8px",
												border: "none",
												color: "#fff",
												fontSize: "11px"
											} }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 735,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV(Legend, {}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 744,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV(Bar, {
												dataKey: "gramos",
												fill: "#0284C7",
												name: "Gramos Dosificados",
												radius: [
													6,
													6,
													0,
													0
												]
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 745,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV(Bar, {
												dataKey: "costoBs",
												fill: "#10B981",
												name: "Costo en Bolivianos (Bs.)",
												radius: [
													6,
													6,
													0,
													0
												]
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 746,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 713,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 712,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 711,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 706,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 655,
					columnNumber: 11
				}, this),
				(tipoReporte === "afluencia" || tipoReporte === "completo") && dataAfluencia && /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-6",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white dark:bg-[#24303F] p-5 rounded-2xl border border-slate-200 dark:border-[#313D4A] shadow-sm",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold uppercase text-slate-400",
										children: "Total Bañistas"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 759,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-3xl font-black text-slate-800 dark:text-white mt-2",
										children: dataAfluencia.resumen.total_banistas
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 760,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs text-slate-500",
										children: [
											"en ",
											dataAfluencia.rango.dias,
											" días"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 763,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 758,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white dark:bg-[#24303F] p-5 rounded-2xl border border-slate-200 dark:border-[#313D4A] shadow-sm",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold uppercase text-slate-400",
										children: "Recaudación Taquilla"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 767,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-3xl font-black text-emerald-600 dark:text-emerald-400 mt-2",
										children: ["Bs. ", dataAfluencia.resumen.total_recaudado_bs.toFixed(2)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 768,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs text-slate-500",
										children: "Ingreso por venta de boletos"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 771,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 766,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white dark:bg-[#24303F] p-5 rounded-2xl border border-slate-200 dark:border-[#313D4A] shadow-sm",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold uppercase text-slate-400",
										children: "Promedio Diario"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 775,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-3xl font-black text-slate-800 dark:text-white mt-2",
										children: dataAfluencia.resumen.promedio_diario_banistas
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 776,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs text-slate-500",
										children: "personas por jornada"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 779,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 774,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white dark:bg-[#24303F] p-5 rounded-2xl border border-slate-200 dark:border-[#313D4A] shadow-sm",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold uppercase text-slate-400",
										children: "Horario Pico"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 783,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-2xl font-black text-indigo-600 dark:text-indigo-400 mt-2",
										children: dataAfluencia.resumen.hora_pico
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 784,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs text-slate-500",
										children: [dataAfluencia.resumen.personas_hora_pico, " personas registradas"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 787,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 782,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 757,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-[#24303F] p-6 rounded-2xl border border-slate-200 dark:border-[#313D4A] shadow-sm",
						children: [
							/* @__PURE__ */ _jsxDEV("h3", {
								className: "font-bold text-slate-800 dark:text-white mb-1",
								children: "Curva de Afluencia por Horario del Día"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 795,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-400 mb-4",
								children: "Permite correlacionar el flujo de personas con incrementos de turbidez y demanda de desinfectante"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 798,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "h-64",
								children: /* @__PURE__ */ _jsxDEV(ResponsiveContainer, {
									width: "100%",
									height: "100%",
									children: /* @__PURE__ */ _jsxDEV(BarChart, {
										data: dataAfluencia.distribucion_por_hora,
										children: [
											/* @__PURE__ */ _jsxDEV(CartesianGrid, {
												strokeDasharray: "3 3",
												opacity: .2
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 804,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV(XAxis, {
												dataKey: "hora",
												tick: { fontSize: 10 }
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 805,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV(YAxis, { tick: { fontSize: 10 } }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 806,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV(Tooltip, { contentStyle: {
												backgroundColor: "#1E293B",
												borderRadius: "8px",
												border: "none",
												color: "#fff",
												fontSize: "11px"
											} }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 807,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV(Bar, {
												dataKey: "personas",
												fill: "#3B82F6",
												name: "Bañistas ingresados",
												radius: [
													6,
													6,
													0,
													0
												]
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 816,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 803,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 802,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 801,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 794,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 756,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 194,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 137,
		columnNumber: 5
	}, this);
}
_s(ReportesPage, "KrEGivKn8cY6O8Le77kZHAEDiG4=", false, function() {
	return [useAuth];
});
_c = ReportesPage;
var _c;
$RefreshReg$(_c, "ReportesPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Reportes/index.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Reportes/index.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Reportes/index.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Reportes/index.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFdBQVcsbUJBQW1CO0FBQ2pELE9BQU8sU0FBUztBQUNoQixTQUFTLGVBQWU7QUFDeEIsU0FDRSxxQkFDQSxXQUNBLE1BQ0EsVUFDQSxLQUNBLE9BQ0EsT0FDQSxlQUNBLFNBQ0EsUUFDQSxxQkFDSzs7OztBQUVQLGVBQWUsU0FBUyxlQUFlOztDQUNyQyxNQUFNLEVBQUUsWUFBWSxRQUFROztDQUc1QixNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxjQUFjO0NBQzdELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLFFBQVE7Q0FDbkQsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsRUFBRTtDQUNqRCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsRUFBRTs7Q0FHM0MsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLEtBQUs7Q0FDNUMsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsS0FBSztDQUN0RCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxJQUFJO0NBQ25ELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLElBQUk7Q0FDckQsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsSUFBSTtDQUN2RCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxJQUFJOztDQUdyRCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxDQUFDO0NBQ2xELE1BQU0scUJBQXFCOztDQUczQixnQkFBZ0I7RUFDZCxNQUFNLFNBQVMsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0VBQ25ELE1BQU0sWUFBWSxJQUFJLEtBQUssS0FBSyxJQUFJLElBQUksSUFBSSxLQUFLLEtBQUssS0FBSyxHQUFJLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0VBQzFGLGVBQWUsU0FBUztFQUN4QixZQUFZLE1BQU07Q0FDcEIsR0FBRyxDQUFDLENBQUM7O0NBR0wsTUFBTSxnQkFBZ0IsWUFBWSxZQUFZO0VBQzVDLFdBQVcsSUFBSTtFQUNmLGdCQUFnQixJQUFJO0VBRXBCLE1BQU0sU0FBUztHQUNiLFlBQVk7R0FDWixjQUFjLGNBQWMsa0JBQWtCLGNBQWM7R0FDNUQsV0FBVyxjQUFjLGtCQUFrQixXQUFXO0VBQ3hEO0VBRUEsSUFBSTtHQUNGLElBQUksZ0JBQWdCLGtCQUFrQixnQkFBZ0IsWUFBWTtJQUNoRSxNQUFNLEVBQUUsU0FBUyxNQUFNLElBQUksSUFBSSwwQkFBMEIsRUFBRSxPQUFPLENBQUM7SUFDbkUsZUFBZSxJQUFJO0dBQ3JCO0dBQ0EsSUFBSSxnQkFBZ0Isa0JBQWtCLGdCQUFnQixZQUFZO0lBQ2hFLE1BQU0sRUFBRSxTQUFTLE1BQU0sSUFBSSxJQUFJLG1DQUFtQyxFQUFFLE9BQU8sQ0FBQztJQUM1RSxnQkFBZ0IsSUFBSTtHQUN0QjtHQUNBLElBQUksZ0JBQWdCLGVBQWUsZ0JBQWdCLFlBQVk7SUFDN0QsTUFBTSxFQUFFLFNBQVMsTUFBTSxJQUFJLElBQUksdUJBQXVCLEVBQUUsT0FBTyxDQUFDO0lBQ2hFLGlCQUFpQixJQUFJO0dBQ3ZCO0VBQ0YsU0FBUyxPQUFPO0dBQ2QsUUFBUSxNQUFNLDRCQUE0QixLQUFLO0dBQy9DLE1BQU0sV0FBVyxNQUFNLFVBQVUsTUFBTSxVQUFVO0dBQ2pELGdCQUFnQjtJQUFFLE1BQU07SUFBUyxLQUFLO0dBQVMsQ0FBQztFQUNsRCxVQUFVO0dBQ1IsV0FBVyxLQUFLO0VBQ2xCO0NBQ0YsR0FBRztFQUFDO0VBQWE7RUFBVztFQUFhO0NBQVEsQ0FBQztDQUVsRCxnQkFBZ0I7RUFDZCxjQUFjO0NBQ2hCLEdBQUcsQ0FBQyxhQUFhLENBQUM7O0NBR2xCLE1BQU0sb0JBQW9CLFlBQVk7RUFDcEMsZ0JBQWdCLElBQUk7RUFDcEIsZ0JBQWdCLElBQUk7RUFDcEIsSUFBSTtHQUNGLE1BQU0sZ0JBQWdCLFNBQVMsVUFDM0IsR0FBRyxRQUFRLFFBQVEsVUFBVSxHQUFHLEdBQUcsUUFBUSxRQUFRLG1CQUFtQixLQUFLLEtBQUssSUFDaEY7R0FFSixNQUFNLFdBQVcsTUFBTSxJQUFJLElBQUksaUJBQWlCO0lBQzlDLFFBQVE7S0FDTixjQUFjO0tBQ2QsWUFBWTtLQUNaLGNBQWMsY0FBYyxrQkFBa0IsY0FBYztLQUM1RCxXQUFXLGNBQWMsa0JBQWtCLFdBQVc7S0FDdEQsbUJBQW1CLGlCQUFpQjtJQUN0QztJQUNBLGNBQWM7R0FDaEIsQ0FBQzs7R0FHRCxNQUFNLE9BQU8sSUFBSSxLQUFLLENBQUMsU0FBUyxJQUFJLEdBQUcsRUFBRSxNQUFNLGtCQUFrQixDQUFDO0dBQ2xFLE1BQU0sTUFBTSxPQUFPLElBQUksZ0JBQWdCLElBQUk7R0FDM0MsTUFBTSxJQUFJLFNBQVMsY0FBYyxHQUFHO0dBQ3BDLEVBQUUsT0FBTztHQUNULE1BQU0sU0FBUyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7R0FDbkQsRUFBRSxXQUFXLHNCQUFzQixZQUFZLEdBQUcsT0FBTztHQUN6RCxTQUFTLEtBQUssWUFBWSxDQUFDO0dBQzNCLEVBQUUsTUFBTTtHQUNSLE9BQU8sSUFBSSxnQkFBZ0IsR0FBRztHQUM5QixFQUFFLE9BQU87R0FFVCxnQkFBZ0I7SUFBRSxNQUFNO0lBQVcsS0FBSztHQUE2RCxDQUFDO0VBQ3hHLFNBQVMsT0FBTztHQUNkLFFBQVEsTUFBTSwwQkFBMEIsS0FBSztHQUM3QyxnQkFBZ0I7SUFDZCxNQUFNO0lBQ04sS0FBSztHQUNQLENBQUM7RUFDSCxVQUFVO0dBQ1IsZ0JBQWdCLEtBQUs7RUFDdkI7Q0FDRjs7Q0FHQSxNQUFNLGFBQWEsYUFBYSxjQUFjLENBQUM7Q0FDL0MsTUFBTSxlQUFlLEtBQUssS0FBSyxXQUFXLFNBQVMsa0JBQWtCLEtBQUs7Q0FDMUUsTUFBTSxzQkFBc0IsV0FBVyxPQUNwQyxlQUFlLEtBQUssb0JBQ3JCLGVBQWUsa0JBQ2pCO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBRUUsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDYix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsaURBQXVEOzs7O2dCQUN2RSx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBK0U7TUFFekY7Ozs7Y0FDQTs7Ozs7O0tBQ0wsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQ1osd0JBQUMsUUFBRCxZQUFNLHdDQUEyQzs7Ozs7S0FDL0M7Ozs7O0tBQ0osd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQTZEO0tBRXZFOzs7OztJQUNBOzs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsVUFBVTtNQUNWLFdBQVU7Z0JBSFosQ0FLRSx3QkFBQyxPQUFEO09BQUssV0FBVyxXQUFXLFVBQVUsaUJBQWlCO09BQU0sTUFBSztPQUFPLFFBQU87T0FBZSxTQUFRO2lCQUNwRyx3QkFBQyxRQUFEO1FBQU0sZUFBYztRQUFRLGdCQUFlO1FBQVEsYUFBWTtRQUFJLEdBQUU7T0FBK0c7Ozs7O01BQ2pMOzs7O2dCQUNMLHdCQUFDLFFBQUQsWUFBTyxVQUFVLG9CQUFvQixhQUFtQjs7OztjQUNsRDs7Ozs7ZUFFUix3QkFBQyxVQUFEO01BQ0UsU0FBUztNQUNULFVBQVUsZ0JBQWdCO01BQzFCLFdBQVU7Z0JBRVQsZUFDQyxnREFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtPQUF1QixNQUFLO09BQU8sUUFBTztPQUFlLFNBQVE7aUJBQWhGLENBQ0Usd0JBQUMsVUFBRDtRQUFRLFdBQVU7UUFBYSxJQUFHO1FBQUssSUFBRztRQUFLLEdBQUU7UUFBSyxRQUFPO1FBQWUsYUFBWTtPQUFZOzs7O2lCQUNwRyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtRQUFhLE1BQUs7UUFBZSxHQUFFO09BQStCOzs7O2VBQy9FOzs7OztnQkFDTCx3QkFBQyxRQUFELFlBQU0sbUJBQXNCOzs7O2NBQzVCOzs7O2lCQUVGLGdEQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO09BQVUsTUFBSztPQUFPLFFBQU87T0FBZSxTQUFRO2lCQUNqRSx3QkFBQyxRQUFEO1FBQU0sZUFBYztRQUFRLGdCQUFlO1FBQVEsYUFBWTtRQUFJLEdBQUU7T0FBbUk7Ozs7O01BQ3JNOzs7O2dCQUNMLHdCQUFDLFFBQUQsWUFBTSxpQkFBb0I7Ozs7Y0FDMUI7Ozs7O0tBRUU7Ozs7YUFDTDs7Ozs7WUFDRjs7Ozs7O0VBQ0Y7Ozs7WUFFTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBRUcsZ0JBQ0Msd0JBQUMsT0FBRDtLQUNFLFdBQVcsd0VBQ1QsYUFBYSxTQUFTLFVBQ2xCLG1IQUNBO2VBSlIsQ0FPRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTyxhQUFhLFNBQVMsVUFBVSxPQUFPLElBQVU7Ozs7Z0JBQ3hELHdCQUFDLFFBQUQsWUFBTyxhQUFhLElBQVU7Ozs7Y0FDM0I7Ozs7O2VBQ0wsd0JBQUMsVUFBRDtNQUFRLGVBQWUsZ0JBQWdCLElBQUk7TUFBRyxXQUFVO2dCQUFpRDtLQUVqRzs7OzthQUNMOzs7Ozs7SUFJUCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBRUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1o7T0FDQztRQUFFLElBQUk7UUFBZ0IsT0FBTztRQUF1QixNQUFNO09BQXNCO09BQ2hGO1FBQUUsSUFBSTtRQUFnQixPQUFPO1FBQXVCLE1BQU07T0FBeUI7T0FDbkY7UUFBRSxJQUFJO1FBQWEsT0FBTztRQUF5QixNQUFNO09BQW9CO09BQzdFO1FBQUUsSUFBSTtRQUFZLE9BQU87UUFBeUIsTUFBTTtPQUFtQjtNQUM3RSxDQUFDLENBQUMsS0FBSyxRQUNMLHdCQUFDLFVBQUQ7T0FFRSxlQUFlO1FBQ2IsZUFBZSxJQUFJLEVBQUU7UUFDckIsZ0JBQWdCLENBQUM7T0FDbkI7T0FDQSxXQUFXLDRGQUNULGdCQUFnQixJQUFJLEtBQ2hCLHdEQUNBO2lCQVRSLENBWUUsd0JBQUMsUUFBRCxZQUFPLElBQUksTUFBWTs7OztpQkFDdkIsd0JBQUMsUUFBRDtRQUFNLFdBQVcsMkJBQTJCLGdCQUFnQixJQUFJLEtBQUssa0JBQWtCO2tCQUNwRixJQUFJO09BQ0Q7Ozs7ZUFDQTtTQWZELElBQUk7Ozs7YUFlSCxDQUNUO0tBQ0U7Ozs7ZUFHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaO1FBQ0M7U0FBRSxJQUFJO1NBQU8sT0FBTztRQUFNO1FBQzFCO1NBQUUsSUFBSTtTQUFVLE9BQU87UUFBUztRQUNoQztTQUFFLElBQUk7U0FBTyxPQUFPO1FBQVU7UUFDOUI7U0FBRSxJQUFJO1NBQWlCLE9BQU87UUFBYztPQUM5QyxDQUFDLENBQUMsS0FBSyxVQUNMLHdCQUFDLFVBQUQ7UUFFRSxlQUFlO1NBQ2IsYUFBYSxNQUFNLEVBQUU7U0FDckIsZ0JBQWdCLENBQUM7UUFDbkI7UUFDQSxXQUFXLCtEQUNULGNBQWMsTUFBTSxLQUNoQiwwRUFDQTtrQkFHTCxNQUFNO09BQ0QsR0FaRCxNQUFNOzs7O2NBWUwsQ0FDVDtNQUNFOzs7O2dCQUVKLGNBQWMsbUJBQ2Isd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLE9BQU87U0FDUCxXQUFXLE1BQU0sZUFBZSxFQUFFLE9BQU8sS0FBSztTQUM5QyxXQUFVO1FBQ1g7Ozs7O1FBQ0Qsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWlCO1FBQU87Ozs7O1FBQ3hDLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsT0FBTztTQUNQLFdBQVcsTUFBTSxZQUFZLEVBQUUsT0FBTyxLQUFLO1NBQzNDLFdBQVU7UUFDWDs7Ozs7T0FDRTs7Ozs7Y0FFSjs7Ozs7YUFDRjs7Ozs7O0tBR0gsZ0JBQWdCLGtCQUFrQixnQkFBZ0IsZUFBZSxlQUNqRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BRUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFFRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQTREO1dBQWlCOzs7O3FCQUM3Rix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBNkc7V0FFdkg7Ozs7bUJBQ0g7Ozs7OztVQUNMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQ2IsWUFBWSxhQUFhLEdBQUcsWUFBWTtXQUNyQzs7OztxQkFDTix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaEI7YUFBNkQ7YUFDcEQsWUFBWSxhQUFhLEdBQUcsT0FBTzthQUFJO2FBQVMsWUFBWSxhQUFhLEdBQUcsT0FBTzthQUFJO1lBQzFGOzs7OzttQkFDSDs7Ozs7O1VBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFpQjtZQUFtQjs7OztzQkFDcEQsd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWhCLENBQ0csWUFBWSxhQUFhLEdBQUcsa0JBQWlCLEdBQzFDOzs7OztvQkFDSDs7Ozs7cUJBQ0wsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQ2Isd0JBQUMsT0FBRDthQUNFLFdBQVU7YUFDVixPQUFPLEVBQUUsT0FBTyxHQUFHLFlBQVksYUFBYSxHQUFHLGlCQUFpQixHQUFHO1lBQy9EOzs7OztXQUNIOzs7O21CQUNGOzs7Ozs7U0FDRjs7Ozs7O1FBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUE0RDtXQUFvQjs7OztxQkFDaEcsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQWlIO1dBRTNIOzs7O21CQUNIOzs7Ozs7VUFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUNiLFlBQVksYUFBYSxTQUFTLFlBQVk7V0FDM0M7Ozs7cUJBQ04sd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQTZDO1dBQVM7Ozs7bUJBQ25FOzs7Ozs7VUFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWlCO1lBQW1COzs7O3NCQUNwRCx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBaEIsQ0FDRyxZQUFZLGFBQWEsU0FBUyxrQkFBaUIsR0FDaEQ7Ozs7O29CQUNIOzs7OztxQkFDTCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFDYix3QkFBQyxPQUFEO2FBQ0UsV0FBVTthQUNWLE9BQU8sRUFBRSxPQUFPLEdBQUcsWUFBWSxhQUFhLFNBQVMsaUJBQWlCLEdBQUc7WUFDckU7Ozs7O1dBQ0g7Ozs7bUJBQ0Y7Ozs7OztTQUNGOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQTREO1dBQXVCOzs7O3FCQUNuRyx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBNkc7V0FFdkg7Ozs7bUJBQ0g7Ozs7OztVQUNMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQ2IsWUFBWSxhQUFhLFlBQVksWUFBWTtXQUM5Qzs7OztxQkFDTix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBNkM7V0FBUTs7OzttQkFDbEU7Ozs7OztVQUNMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBaUI7WUFBbUI7Ozs7c0JBQ3BELHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFoQixDQUNHLFlBQVksYUFBYSxZQUFZLGtCQUFpQixHQUNuRDs7Ozs7b0JBQ0g7Ozs7O3FCQUNMLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUNiLHdCQUFDLE9BQUQ7YUFDRSxXQUFVO2FBQ1YsT0FBTyxFQUFFLE9BQU8sR0FBRyxZQUFZLGFBQWEsWUFBWSxpQkFBaUIsR0FBRztZQUN4RTs7Ozs7V0FDSDs7OzttQkFDRjs7Ozs7O1NBQ0Y7Ozs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBMkQ7VUFBNkI7Ozs7b0JBQ3hHLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQixDQUNHLFlBQVksa0JBQWlCLFdBQzFCOzs7OztrQkFDSDs7Ozs7bUJBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEIsQ0FBdUMsWUFBWSw0QkFBMkIsR0FBTzs7Ozs7b0JBQ3JGLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFvQztVQUFzQjs7OztrQkFDdkU7Ozs7O2lCQUVGOzs7Ozs7T0FDRjs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFFRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUEyQztVQUE2Qjs7OztvQkFDdEYsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQXlCO1VBQTJDOzs7O2tCQUM5RTs7OztvQkFDTCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBNkc7VUFFdkg7Ozs7a0JBQ0g7Ozs7O21CQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNiLHdCQUFDLHFCQUFEO1dBQXFCLE9BQU07V0FBTyxRQUFPO3FCQUN2Qyx3QkFBQyxXQUFEO1lBQVcsTUFBTSxZQUFZO3NCQUE3QjthQUNFLHdCQUFDLGVBQUQ7Y0FBZSxpQkFBZ0I7Y0FBTSxTQUFTO2FBQU07Ozs7O2FBQ3BELHdCQUFDLE9BQUQ7Y0FBTyxTQUFRO2NBQU8sTUFBTSxFQUFFLFVBQVUsR0FBRzthQUFJOzs7OzthQUMvQyx3QkFBQyxPQUFEO2NBQU8sUUFBUSxDQUFDLEtBQUssQ0FBRztjQUFHLE1BQU0sRUFBRSxVQUFVLEdBQUc7YUFBSTs7Ozs7YUFDcEQsd0JBQUMsU0FBRCxFQUNFLGNBQWM7Y0FDWixpQkFBaUI7Y0FDakIsY0FBYztjQUNkLFFBQVE7Y0FDUixPQUFPO2NBQ1AsVUFBVTthQUNaLEVBQ0Q7Ozs7O2FBQ0Qsd0JBQUMsZUFBRDtjQUFlLEdBQUc7Y0FBSyxRQUFPO2NBQVUsaUJBQWdCO2NBQU0sT0FBTztlQUFFLE9BQU87ZUFBVyxNQUFNO2VBQVcsVUFBVTtjQUFHO2FBQUk7Ozs7O2FBQzNILHdCQUFDLGVBQUQ7Y0FBZSxHQUFHO2NBQUssUUFBTztjQUFVLGlCQUFnQjtjQUFNLE9BQU87ZUFBRSxPQUFPO2VBQVcsTUFBTTtlQUFXLFVBQVU7Y0FBRzthQUFJOzs7OzthQUMzSCx3QkFBQyxNQUFEO2NBQU0sTUFBSztjQUFXLFNBQVE7Y0FBSyxRQUFPO2NBQVUsYUFBYTtjQUFLLEtBQUssRUFBRSxHQUFHLEVBQUU7Y0FBRyxXQUFXLEVBQUUsR0FBRyxFQUFFO2NBQUcsTUFBSzthQUFhOzs7OztZQUNuSDs7Ozs7O1VBQ1E7Ozs7O1NBQ2xCOzs7O2lCQUNGOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUEyQztVQUErQjs7OztvQkFDeEYsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQXlCO1VBQW1DOzs7O2tCQUN0RTs7OztvQkFDTCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaUg7VUFFM0g7Ozs7a0JBQ0g7Ozs7O21CQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNiLHdCQUFDLHFCQUFEO1dBQXFCLE9BQU07V0FBTyxRQUFPO3FCQUN2Qyx3QkFBQyxXQUFEO1lBQVcsTUFBTSxZQUFZO3NCQUE3QjthQUNFLHdCQUFDLGVBQUQ7Y0FBZSxpQkFBZ0I7Y0FBTSxTQUFTO2FBQU07Ozs7O2FBQ3BELHdCQUFDLE9BQUQ7Y0FBTyxTQUFRO2NBQU8sTUFBTSxFQUFFLFVBQVUsR0FBRzthQUFJOzs7OzthQUMvQyx3QkFBQyxPQUFEO2NBQU8sUUFBUSxDQUFDLEdBQUcsRUFBRTtjQUFHLE1BQU0sRUFBRSxVQUFVLEdBQUc7YUFBSTs7Ozs7YUFDakQsd0JBQUMsU0FBRCxFQUNFLGNBQWM7Y0FDWixpQkFBaUI7Y0FDakIsY0FBYztjQUNkLFFBQVE7Y0FDUixPQUFPO2NBQ1AsVUFBVTthQUNaLEVBQ0Q7Ozs7O2FBQ0Qsd0JBQUMsZUFBRDtjQUFlLEdBQUc7Y0FBSyxRQUFPO2NBQVUsaUJBQWdCO2NBQU0sT0FBTztlQUFFLE9BQU87ZUFBYyxNQUFNO2VBQVcsVUFBVTtjQUFHO2FBQUk7Ozs7O2FBQzlILHdCQUFDLE1BQUQ7Y0FBTSxNQUFLO2NBQVcsU0FBUTtjQUFXLFFBQU87Y0FBVSxhQUFhO2NBQUssS0FBSyxFQUFFLEdBQUcsRUFBRTtjQUFHLFdBQVcsRUFBRSxHQUFHLEVBQUU7Y0FBRyxNQUFLO2FBQWtCOzs7OztZQUM5SDs7Ozs7O1VBQ1E7Ozs7O1NBQ2xCOzs7O2lCQUNGOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUEyQztVQUEwQzs7OztvQkFDbkcsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQXlCO1VBQThGOzs7O2tCQUNqSTs7OztvQkFDTCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBNkc7VUFFdkg7Ozs7a0JBQ0g7Ozs7O21CQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNiLHdCQUFDLHFCQUFEO1dBQXFCLE9BQU07V0FBTyxRQUFPO3FCQUN2Qyx3QkFBQyxXQUFEO1lBQVcsTUFBTSxZQUFZO3NCQUE3QjthQUNFLHdCQUFDLGVBQUQ7Y0FBZSxpQkFBZ0I7Y0FBTSxTQUFTO2FBQU07Ozs7O2FBQ3BELHdCQUFDLE9BQUQ7Y0FBTyxTQUFTLGNBQWMsUUFBUSxTQUFTO2NBQWMsTUFBTSxFQUFFLFVBQVUsR0FBRzthQUFJOzs7OzthQUN0Rix3QkFBQyxPQUFEO2NBQU8sUUFBUSxDQUFDLElBQUksRUFBRTtjQUFHLE1BQU0sRUFBRSxVQUFVLEdBQUc7YUFBSTs7Ozs7YUFDbEQsd0JBQUMsU0FBRCxFQUNFLGNBQWM7Y0FDWixpQkFBaUI7Y0FDakIsY0FBYztjQUNkLFFBQVE7Y0FDUixPQUFPO2NBQ1AsVUFBVTthQUNaLEVBQ0Q7Ozs7O2FBQ0Qsd0JBQUMsZUFBRDtjQUFlLEdBQUc7Y0FBTSxRQUFPO2NBQVUsaUJBQWdCO2NBQU0sT0FBTztlQUFFLE9BQU87ZUFBWSxNQUFNO2VBQVcsVUFBVTtjQUFHO2FBQUk7Ozs7O2FBQzdILHdCQUFDLGVBQUQ7Y0FBZSxHQUFHO2NBQU0sUUFBTztjQUFVLGlCQUFnQjtjQUFNLE9BQU87ZUFBRSxPQUFPO2VBQVksTUFBTTtlQUFXLFVBQVU7Y0FBRzthQUFJOzs7OzthQUM3SCx3QkFBQyxNQUFEO2NBQU0sTUFBSztjQUFXLFNBQVE7Y0FBYyxRQUFPO2NBQVUsYUFBYTtjQUFLLEtBQUssRUFBRSxHQUFHLEVBQUU7Y0FBRyxXQUFXLEVBQUUsR0FBRyxFQUFFO2NBQUcsTUFBSzthQUFvQjs7Ozs7WUFDbkk7Ozs7OztVQUNROzs7OztTQUNsQjs7OztpQkFDRjs7Ozs7O09BQ0Y7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1osd0JBQUMsUUFBRCxZQUFNLHlDQUE0Qzs7Ozs7UUFDaEQ7Ozs7O1FBQ0osd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZjtZQUNFLHdCQUFDLEtBQUQ7YUFBRyxXQUFVO3VCQUF5QjtZQUFpQzs7Ozs7WUFDdkUsd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQWIsQ0FDRyxZQUFZLFFBQVEsV0FBVyxZQUFZLFFBQVEsYUFBWSxVQUMvRDs7Ozs7O1lBQ0gsd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWhCO2NBQTZDO2NBQ3pDLFlBQVksUUFBUTtjQUFTO2NBQVcsWUFBWSxRQUFRO2NBQVk7YUFDdEU7Ozs7OztXQUNIOzs7Ozs7VUFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZjtZQUNFLHdCQUFDLEtBQUQ7YUFBRyxXQUFVO3VCQUF5QjtZQUFtQzs7Ozs7WUFDekUsd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQWIsQ0FDRyxZQUFZLFFBQVEsZ0JBQWdCLFlBQVksUUFBUSxrQkFBaUIsVUFDekU7Ozs7OztZQUNILHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFoQjtjQUE2QztjQUN6QyxZQUFZLFFBQVE7Y0FBaUI7YUFDbkM7Ozs7OztXQUNIOzs7Ozs7VUFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZjtZQUNFLHdCQUFDLEtBQUQ7YUFBRyxXQUFVO3VCQUF5QjtZQUE4Qjs7Ozs7WUFDcEUsd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQWIsQ0FDRyxZQUFZLFFBQVEsa0JBQWlCLFVBQ3JDOzs7Ozs7WUFDSCx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBNkI7WUFBMEI7Ozs7O1dBQ3BFOzs7Ozs7U0FDRjs7Ozs7O1FBQ0wsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1gsWUFBWSxvQkFBb0IsS0FBSyxNQUFNLFFBQzFDLHdCQUFDLE1BQUQ7VUFBYyxXQUFVO29CQUF4QixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUEwQjtVQUFPOzs7O29CQUNqRCx3QkFBQyxRQUFELFlBQU8sS0FBVzs7OztrQkFDaEI7WUFISzs7OztnQkFHTCxDQUNMO1FBQ0M7Ozs7O09BQ0Q7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ2Isd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUEyQztTQUFvQzs7OzttQkFDN0Ysd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWI7V0FBc0M7V0FDbEI7V0FBYTtXQUFLO1dBQWE7V0FBRyxXQUFXO1dBQU87VUFDckU7Ozs7O2lCQUNBOzs7OztRQUNGOzs7OztRQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNiLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUFqQixDQUNFLHdCQUFDLFNBQUQsWUFDRSx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBZDtZQUNFLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUErQztZQUFnQjs7Ozs7WUFDN0Usd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQStDO1lBQU07Ozs7O1lBQ25FLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUErQztZQUFrQjs7Ozs7WUFDL0Usd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQStDO1lBQW9COzs7OztZQUNqRix3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFBK0M7WUFBb0I7Ozs7O1dBQy9FOzs7OzttQkFDQzs7OztvQkFDUCx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFDZCxvQkFBb0IsV0FBVyxJQUM5Qix3QkFBQyxNQUFELFlBQ0Usd0JBQUMsTUFBRDtZQUFJLFNBQVE7WUFBSSxXQUFVO3NCQUE4QztXQUVwRTs7OztvQkFDRjs7OztzQkFFSixvQkFBb0IsS0FBSyxNQUN2Qix3QkFBQyxNQUFEO1lBQXdCLFdBQVU7c0JBQWxDO2FBQ0Usd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQ1gsRUFBRTthQUNEOzs7OzthQUNKLHdCQUFDLE1BQUQ7Y0FBSSxXQUFVO3dCQUNaLHdCQUFDLFFBQUQ7ZUFDRSxXQUFXLHNDQUNULEVBQUUsY0FBYyxXQUNaLGdGQUNBO3lCQUpSO2dCQU9HLEVBQUUsT0FBTyxPQUFPLEVBQUUsR0FBRyxRQUFRLENBQUMsSUFBSTtnQkFBSTtnQkFBRyxFQUFFO2dCQUFVO2VBQ2xEOzs7Ozs7YUFDSjs7Ozs7YUFDSix3QkFBQyxNQUFEO2NBQUksV0FBVTt3QkFDWix3QkFBQyxRQUFEO2VBQ0UsV0FBVyxzQ0FDVCxFQUFFLG9CQUFvQixXQUNsQixnRkFDQTt5QkFKUixDQU9HLEVBQUUsYUFBYSxPQUFPLEVBQUUsU0FBUyxRQUFRLENBQUMsSUFBSSxLQUFJLE1BQy9DOzs7Ozs7YUFDSjs7Ozs7YUFDSix3QkFBQyxNQUFEO2NBQUksV0FBVTt3QkFDWCxFQUFFLGdCQUFnQixPQUFPLEdBQUcsRUFBRSxZQUFZLFFBQVEsQ0FBQyxFQUFFLE9BQU87YUFDM0Q7Ozs7O2FBQ0osd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQ1osd0JBQUMsUUFBRDtlQUNFLFdBQVcscUZBQ1QsRUFBRSxXQUNFLGlGQUNBO3lCQUpSLENBT0Usd0JBQUMsUUFBRCxFQUFNLFdBQVcsNEJBQTRCLEVBQUUsV0FBVyxtQkFBbUIsZ0JBQXVCOzs7O3lCQUNuRyxFQUFFLFdBQVcsYUFBYSxnQkFDdkI7Ozs7OzthQUNKOzs7OztZQUNGO2NBekNLLEVBQUU7Ozs7a0JBeUNQLENBQ0w7VUFFRTs7OztrQkFDRjs7Ozs7O1FBQ0o7Ozs7O1FBR0osZUFBZSxLQUNkLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsVUFBRDtXQUNFLFVBQVUsaUJBQWlCO1dBQzNCLGVBQWUsaUJBQWlCLE1BQU0sS0FBSyxJQUFJLEdBQUcsSUFBSSxDQUFDLENBQUM7V0FDeEQsV0FBVTtxQkFDWDtVQUVPOzs7OztVQUNSLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQjtZQUF5QztZQUMvQjtZQUFhO1lBQUs7V0FDdEI7Ozs7OztVQUNOLHdCQUFDLFVBQUQ7V0FDRSxVQUFVLGlCQUFpQjtXQUMzQixlQUFlLGlCQUFpQixNQUFNLEtBQUssSUFBSSxjQUFjLElBQUksQ0FBQyxDQUFDO1dBQ25FLFdBQVU7cUJBQ1g7VUFFTzs7Ozs7U0FDTDs7Ozs7O09BRUo7Ozs7OztLQUNGOzs7Ozs7S0FJTCxnQkFBZ0Isa0JBQWtCLGdCQUFnQixlQUFlLGdCQUNqRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUE2QztTQUFvQjs7Ozs7U0FDakYsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWIsQ0FDRyxhQUFhLHVCQUF1QixPQUFNLEtBQzFDOzs7Ozs7U0FDSCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQsYUFBTyxhQUFhLG9CQUFvQixPQUFNLFFBQVk7Ozs7b0JBQzFELHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQixDQUE2RCxRQUN0RCxhQUFhLG9CQUFvQixNQUFNLFFBQVEsQ0FBQyxDQUNqRDs7Ozs7a0JBQ0g7Ozs7OztRQUNGOzs7Ozs7T0FFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUE2QztTQUF5Qjs7Ozs7U0FDdEYsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWIsQ0FDRyxhQUFhLHVCQUF1Qix3QkFBdUIsS0FDM0Q7Ozs7OztTQUNILHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRCxhQUFPLGFBQWEsb0JBQW9CLHdCQUF1QixRQUFZOzs7O29CQUMzRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEIsQ0FBNkQsUUFDdEQsYUFBYSxvQkFBb0Isc0JBQXNCLENBQUMsUUFBUSxDQUFDLENBQ2xFOzs7OztrQkFDSDs7Ozs7O1FBQ0Y7Ozs7OztPQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQTZDO1NBQXNCOzs7OztTQUNuRix3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBYixDQUNHLGFBQWEsdUJBQXVCLHFCQUFvQixLQUN4RDs7Ozs7O1NBQ0gsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFELGFBQU8sYUFBYSxvQkFBb0IscUJBQW9CLFFBQVk7Ozs7b0JBQ3hFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQixDQUE2RCxRQUN0RCxhQUFhLG9CQUFvQixtQkFBbUIsQ0FBQyxRQUFRLENBQUMsQ0FDL0Q7Ozs7O2tCQUNIOzs7Ozs7UUFDRjs7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBOEQ7U0FBNEI7Ozs7O1NBQzFHLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFiLENBQXdDLFFBQUssYUFBYSxlQUFlLFFBQVEsQ0FBQyxDQUFLOzs7Ozs7U0FDdkYsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWI7V0FBNkM7V0FDakMsYUFBYTtXQUE2QjtVQUNuRDs7Ozs7O1FBQ0E7Ozs7OztNQUNGOzs7OztlQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWdEO09BRTFEOzs7OztPQUNKLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUE4QjtPQUFpRDs7Ozs7T0FDNUYsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMscUJBQUQ7U0FBcUIsT0FBTTtTQUFPLFFBQU87bUJBQ3ZDLHdCQUFDLFVBQUQ7VUFDRSxNQUFNO1dBQ0o7WUFDRSxNQUFNO1lBQ04sUUFBUSxhQUFhLHNCQUFzQjtZQUMzQyxTQUFTLGFBQWEsb0JBQW9CO1dBQzVDO1dBQ0E7WUFDRSxNQUFNO1lBQ04sUUFBUSxhQUFhLHNCQUFzQjtZQUMzQyxTQUFTLGFBQWEsb0JBQW9CO1dBQzVDO1dBQ0E7WUFDRSxNQUFNO1lBQ04sUUFBUSxhQUFhLHNCQUFzQjtZQUMzQyxTQUFTLGFBQWEsb0JBQW9CO1dBQzVDO1VBQ0Y7b0JBakJGO1dBbUJFLHdCQUFDLGVBQUQ7WUFBZSxpQkFBZ0I7WUFBTSxTQUFTO1dBQU07Ozs7O1dBQ3BELHdCQUFDLE9BQUQ7WUFBTyxTQUFRO1lBQU8sTUFBTSxFQUFFLFVBQVUsR0FBRztXQUFJOzs7OztXQUMvQyx3QkFBQyxPQUFELEVBQU8sTUFBTSxFQUFFLFVBQVUsR0FBRyxFQUFJOzs7OztXQUNoQyx3QkFBQyxTQUFELEVBQ0UsY0FBYztZQUNaLGlCQUFpQjtZQUNqQixjQUFjO1lBQ2QsUUFBUTtZQUNSLE9BQU87WUFDUCxVQUFVO1dBQ1osRUFDRDs7Ozs7V0FDRCx3QkFBQyxRQUFELENBQVM7Ozs7O1dBQ1Qsd0JBQUMsS0FBRDtZQUFLLFNBQVE7WUFBUyxNQUFLO1lBQVUsTUFBSztZQUFxQixRQUFRO2FBQUM7YUFBRzthQUFHO2FBQUc7WUFBQztXQUFJOzs7OztXQUN0Rix3QkFBQyxLQUFEO1lBQUssU0FBUTtZQUFVLE1BQUs7WUFBVSxNQUFLO1lBQTRCLFFBQVE7YUFBQzthQUFHO2FBQUc7YUFBRztZQUFDO1dBQUk7Ozs7O1VBQ3RGOzs7Ozs7UUFDUzs7Ozs7T0FDbEI7Ozs7O01BQ0Y7Ozs7O2FBQ0Y7Ozs7OztLQUlMLGdCQUFnQixlQUFlLGdCQUFnQixlQUFlLGlCQUM5RCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUE2QztTQUFvQjs7Ozs7U0FDakYsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQ1YsY0FBYyxRQUFRO1NBQ3RCOzs7OztTQUNILHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQjtXQUF5QztXQUFJLGNBQWMsTUFBTTtXQUFLO1VBQVc7Ozs7OztRQUM5RTs7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBNkM7U0FBMEI7Ozs7O1NBQ3ZGLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFiLENBQStFLFFBQ3hFLGNBQWMsUUFBUSxtQkFBbUIsUUFBUSxDQUFDLENBQ3REOzs7Ozs7U0FDSCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBeUI7U0FBa0M7Ozs7O1FBQ3hFOzs7Ozs7T0FFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUE2QztTQUFxQjs7Ozs7U0FDbEYsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQ1YsY0FBYyxRQUFRO1NBQ3RCOzs7OztTQUNILHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUF5QjtTQUEwQjs7Ozs7UUFDaEU7Ozs7OztPQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQTZDO1NBQWtCOzs7OztTQUMvRSx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFDVixjQUFjLFFBQVE7U0FDdEI7Ozs7O1NBQ0gsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQ0csY0FBYyxRQUFRLG9CQUFtQix1QkFDdEM7Ozs7OztRQUNIOzs7Ozs7TUFDRjs7Ozs7ZUFHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFnRDtPQUUxRDs7Ozs7T0FDSix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBOEI7T0FFeEM7Ozs7O09BQ0gsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMscUJBQUQ7U0FBcUIsT0FBTTtTQUFPLFFBQU87bUJBQ3ZDLHdCQUFDLFVBQUQ7VUFBVSxNQUFNLGNBQWM7b0JBQTlCO1dBQ0Usd0JBQUMsZUFBRDtZQUFlLGlCQUFnQjtZQUFNLFNBQVM7V0FBTTs7Ozs7V0FDcEQsd0JBQUMsT0FBRDtZQUFPLFNBQVE7WUFBTyxNQUFNLEVBQUUsVUFBVSxHQUFHO1dBQUk7Ozs7O1dBQy9DLHdCQUFDLE9BQUQsRUFBTyxNQUFNLEVBQUUsVUFBVSxHQUFHLEVBQUk7Ozs7O1dBQ2hDLHdCQUFDLFNBQUQsRUFDRSxjQUFjO1lBQ1osaUJBQWlCO1lBQ2pCLGNBQWM7WUFDZCxRQUFRO1lBQ1IsT0FBTztZQUNQLFVBQVU7V0FDWixFQUNEOzs7OztXQUNELHdCQUFDLEtBQUQ7WUFBSyxTQUFRO1lBQVcsTUFBSztZQUFVLE1BQUs7WUFBc0IsUUFBUTthQUFDO2FBQUc7YUFBRzthQUFHO1lBQUM7V0FBSTs7Ozs7VUFDakY7Ozs7OztRQUNTOzs7OztPQUNsQjs7Ozs7TUFDRjs7Ozs7YUFDRjs7Ozs7O0dBRUo7Ozs7O1VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VDYWxsYmFjayB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IGFwaSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9hcGknXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vY29udGV4dC9BdXRoQ29udGV4dCdcbmltcG9ydCB7XG4gIFJlc3BvbnNpdmVDb250YWluZXIsXG4gIExpbmVDaGFydCxcbiAgTGluZSxcbiAgQmFyQ2hhcnQsXG4gIEJhcixcbiAgWEF4aXMsXG4gIFlBeGlzLFxuICBDYXJ0ZXNpYW5HcmlkLFxuICBUb29sdGlwLFxuICBMZWdlbmQsXG4gIFJlZmVyZW5jZUxpbmUsXG59IGZyb20gJ3JlY2hhcnRzJ1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBSZXBvcnRlc1BhZ2UoKSB7XG4gIGNvbnN0IHsgc2Vzc2lvbiB9ID0gdXNlQXV0aCgpXG5cbiAgLy8gRmlsdHJvcyBkZSBuYXZlZ2FjacOzblxuICBjb25zdCBbdGlwb1JlcG9ydGUsIHNldFRpcG9SZXBvcnRlXSA9IHVzZVN0YXRlKCdjYWxpZGFkX2FndWEnKSAvLyAnY2FsaWRhZF9hZ3VhJywgJ2Rvc2lmaWNhY2lvbicsICdhZmx1ZW5jaWEnLCAnY29tcGxldG8nXG4gIGNvbnN0IFt0aXBvUmFuZ28sIHNldFRpcG9SYW5nb10gPSB1c2VTdGF0ZSgnc2VtYW5hJykgLy8gJ2hveScsICdzZW1hbmEnLCAnbWVzJywgJ3BlcnNvbmFsaXphZG8nXG4gIGNvbnN0IFtmZWNoYUluaWNpbywgc2V0RmVjaGFJbmljaW9dID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtmZWNoYUZpbiwgc2V0RmVjaGFGaW5dID0gdXNlU3RhdGUoJycpXG5cbiAgLy8gRXN0YWRvcyBkZSBjYXJnYSB5IGRhdG9zXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbZXhwb3J0aW5nUGRmLCBzZXRFeHBvcnRpbmdQZGZdID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtkYXRhQ2FsaWRhZCwgc2V0RGF0YUNhbGlkYWRdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW2RhdGFRdWltaWNvcywgc2V0RGF0YVF1aW1pY29zXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFtkYXRhQWZsdWVuY2lhLCBzZXREYXRhQWZsdWVuY2lhXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFtub3RpZmljYXRpb24sIHNldE5vdGlmaWNhdGlvbl0gPSB1c2VTdGF0ZShudWxsKVxuXG4gIC8vIFBhZ2luYWNpw7NuIHBhcmEgbGEgdGFibGEgZGUgbWVkaWNpb25lc1xuICBjb25zdCBbcGFnaW5hQWN0dWFsLCBzZXRQYWdpbmFBY3R1YWxdID0gdXNlU3RhdGUoMSlcbiAgY29uc3QgZWxlbWVudG9zUG9yUGFnaW5hID0gMTJcblxuICAvLyBFc3RhYmxlY2VyIGZlY2hhcyBpbmljaWFsZXMgcGFyYSBwZXJzb25hbGl6YWRvIHNpIGVzdMOhbiB2YWPDrWFzXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgaG95U3RyID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF1cbiAgICBjb25zdCBoYWNlN2RpYXMgPSBuZXcgRGF0ZShEYXRlLm5vdygpIC0gNiAqIDI0ICogNjAgKiA2MCAqIDEwMDApLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXVxuICAgIHNldEZlY2hhSW5pY2lvKGhhY2U3ZGlhcylcbiAgICBzZXRGZWNoYUZpbihob3lTdHIpXG4gIH0sIFtdKVxuXG4gIC8vIENhcmdhIGRlIGRhdG9zXG4gIGNvbnN0IGNhcmdhclJlcG9ydGUgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgc2V0TG9hZGluZyh0cnVlKVxuICAgIHNldE5vdGlmaWNhdGlvbihudWxsKVxuXG4gICAgY29uc3QgcGFyYW1zID0ge1xuICAgICAgdGlwb19yYW5nbzogdGlwb1JhbmdvLFxuICAgICAgZmVjaGFfaW5pY2lvOiB0aXBvUmFuZ28gPT09ICdwZXJzb25hbGl6YWRvJyA/IGZlY2hhSW5pY2lvIDogdW5kZWZpbmVkLFxuICAgICAgZmVjaGFfZmluOiB0aXBvUmFuZ28gPT09ICdwZXJzb25hbGl6YWRvJyA/IGZlY2hhRmluIDogdW5kZWZpbmVkLFxuICAgIH1cblxuICAgIHRyeSB7XG4gICAgICBpZiAodGlwb1JlcG9ydGUgPT09ICdjYWxpZGFkX2FndWEnIHx8IHRpcG9SZXBvcnRlID09PSAnY29tcGxldG8nKSB7XG4gICAgICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXBpLmdldCgnL3JlcG9ydGVzL2NhbGlkYWQtYWd1YScsIHsgcGFyYW1zIH0pXG4gICAgICAgIHNldERhdGFDYWxpZGFkKGRhdGEpXG4gICAgICB9XG4gICAgICBpZiAodGlwb1JlcG9ydGUgPT09ICdkb3NpZmljYWNpb24nIHx8IHRpcG9SZXBvcnRlID09PSAnY29tcGxldG8nKSB7XG4gICAgICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXBpLmdldCgnL3JlcG9ydGVzL3F1aW1pY29zLWRvc2lmaWNhY2lvbicsIHsgcGFyYW1zIH0pXG4gICAgICAgIHNldERhdGFRdWltaWNvcyhkYXRhKVxuICAgICAgfVxuICAgICAgaWYgKHRpcG9SZXBvcnRlID09PSAnYWZsdWVuY2lhJyB8fCB0aXBvUmVwb3J0ZSA9PT0gJ2NvbXBsZXRvJykge1xuICAgICAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IGFwaS5nZXQoJy9yZXBvcnRlcy9hZmx1ZW5jaWEnLCB7IHBhcmFtcyB9KVxuICAgICAgICBzZXREYXRhQWZsdWVuY2lhKGRhdGEpXG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGNhcmdhbmRvIHJlcG9ydGVzOicsIGVycm9yKVxuICAgICAgY29uc3QgZXJyb3JNc2cgPSBlcnJvci5yZXNwb25zZT8uZGF0YT8uZGV0YWlsIHx8ICdObyBzZSBwdWRvIGNhcmdhciBsYSBpbmZvcm1hY2nDs24gZGVsIHJlcG9ydGUuIEludGVudGUgbnVldmFtZW50ZS4nXG4gICAgICBzZXROb3RpZmljYXRpb24oeyB0eXBlOiAnZXJyb3InLCBtc2c6IGVycm9yTXNnIH0pXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpXG4gICAgfVxuICB9LCBbdGlwb1JlcG9ydGUsIHRpcG9SYW5nbywgZmVjaGFJbmljaW8sIGZlY2hhRmluXSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNhcmdhclJlcG9ydGUoKVxuICB9LCBbY2FyZ2FyUmVwb3J0ZV0pXG5cbiAgLy8gRXhwb3J0YXIgUERGIGZvcm1hbCAoUkYtMDUgLyBSRi0yMClcbiAgY29uc3QgaGFuZGxlRXhwb3J0YXJQZGYgPSBhc3luYyAoKSA9PiB7XG4gICAgc2V0RXhwb3J0aW5nUGRmKHRydWUpXG4gICAgc2V0Tm90aWZpY2F0aW9uKG51bGwpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IG5vbWJyZVVzdWFyaW8gPSBzZXNzaW9uPy51c3VhcmlvXG4gICAgICAgID8gYCR7c2Vzc2lvbi51c3VhcmlvLm5vbWJyZSB8fCAnJ30gJHtzZXNzaW9uLnVzdWFyaW8ucHJpbWVyX2FwZWxsaWRvIHx8ICcnfWAudHJpbSgpXG4gICAgICAgIDogJ0FkbWluaXN0cmFkb3InXG5cbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldCgnL3JlcG9ydGVzL3BkZicsIHtcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgdGlwb19yZXBvcnRlOiB0aXBvUmVwb3J0ZSxcbiAgICAgICAgICB0aXBvX3JhbmdvOiB0aXBvUmFuZ28sXG4gICAgICAgICAgZmVjaGFfaW5pY2lvOiB0aXBvUmFuZ28gPT09ICdwZXJzb25hbGl6YWRvJyA/IGZlY2hhSW5pY2lvIDogdW5kZWZpbmVkLFxuICAgICAgICAgIGZlY2hhX2ZpbjogdGlwb1JhbmdvID09PSAncGVyc29uYWxpemFkbycgPyBmZWNoYUZpbiA6IHVuZGVmaW5lZCxcbiAgICAgICAgICB1c3VhcmlvX2dlbmVyYWRvcjogbm9tYnJlVXN1YXJpbyB8fCAnQWRtaW5pc3RyYWRvciBHZW5lcmFsJyxcbiAgICAgICAgfSxcbiAgICAgICAgcmVzcG9uc2VUeXBlOiAnYmxvYicsXG4gICAgICB9KVxuXG4gICAgICAvLyBDcmVhciBlbmxhY2UgdGVtcG9yYWwgZGUgZGVzY2FyZ2FcbiAgICAgIGNvbnN0IGJsb2IgPSBuZXcgQmxvYihbcmVzcG9uc2UuZGF0YV0sIHsgdHlwZTogJ2FwcGxpY2F0aW9uL3BkZicgfSlcbiAgICAgIGNvbnN0IHVybCA9IHdpbmRvdy5VUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpXG4gICAgICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpXG4gICAgICBhLmhyZWYgPSB1cmxcbiAgICAgIGNvbnN0IGhveVN0ciA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdXG4gICAgICBhLmRvd25sb2FkID0gYHJlcG9ydGVfcGxheWFfYXp1bF8ke3RpcG9SZXBvcnRlfV8ke2hveVN0cn0ucGRmYFxuICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChhKVxuICAgICAgYS5jbGljaygpXG4gICAgICB3aW5kb3cuVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpXG4gICAgICBhLnJlbW92ZSgpXG5cbiAgICAgIHNldE5vdGlmaWNhdGlvbih7IHR5cGU6ICdzdWNjZXNzJywgbXNnOiAnUmVwb3J0ZSBvZmljaWFsIGVuIFBERiBnZW5lcmFkbyB5IGRlc2NhcmdhZG8gZXhpdG9zYW1lbnRlLicgfSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgYWwgZXhwb3J0YXIgUERGOicsIGVycm9yKVxuICAgICAgc2V0Tm90aWZpY2F0aW9uKHtcbiAgICAgICAgdHlwZTogJ2Vycm9yJyxcbiAgICAgICAgbXNnOiAnT2N1cnJpw7MgdW4gZXJyb3IgYWwgZ2VuZXJhciBlbCBhcmNoaXZvIFBERi4gVmVyaWZpcXVlIGxhIGNvbmV4acOzbiBjb24gZWwgc2Vydmlkb3IuJyxcbiAgICAgIH0pXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldEV4cG9ydGluZ1BkZihmYWxzZSlcbiAgICB9XG4gIH1cblxuICAvLyBQYWdpbmFjacOzbiBkZSBtZWRpY2lvbmVzXG4gIGNvbnN0IG1lZGljaW9uZXMgPSBkYXRhQ2FsaWRhZD8ubWVkaWNpb25lcyB8fCBbXVxuICBjb25zdCB0b3RhbFBhZ2luYXMgPSBNYXRoLmNlaWwobWVkaWNpb25lcy5sZW5ndGggLyBlbGVtZW50b3NQb3JQYWdpbmEpIHx8IDFcbiAgY29uc3QgbWVkaWNpb25lc1BhZ2luYWRhcyA9IG1lZGljaW9uZXMuc2xpY2UoXG4gICAgKHBhZ2luYUFjdHVhbCAtIDEpICogZWxlbWVudG9zUG9yUGFnaW5hLFxuICAgIHBhZ2luYUFjdHVhbCAqIGVsZW1lbnRvc1BvclBhZ2luYVxuICApXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1zbGF0ZS01MCBwYi0xNiBkYXJrOmJnLVsjMUEyMjJDXVwiPlxuICAgICAgey8qIOKUgOKUgCBFbmNhYmV6YWRvIFByaW5jaXBhbCDilIDilIAgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIHB4LTYgcHktNiBzaGFkb3ctc21cIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy03eGwgbXgtYXV0byBmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItMVwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoLTIgdy0yIHJvdW5kZWQtZnVsbCBiZy1ibHVlLTYwMCBhbmltYXRlLXB1bHNlXCI+PC9zcGFuPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0cmFja2luZy13aWRlc3QgdXBwZXJjYXNlIHRleHQtYmx1ZS02MDAgZGFyazp0ZXh0LWJsdWUtNDAwXCI+XG4gICAgICAgICAgICAgICAgUGlzY2luYSBQbGF5YSBBenVsIOKAlCBSZXllcywgQmVuaVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICA8c3Bhbj7wn5OKIE3Ds2R1bG8gZGUgUmVwb3J0ZXMgSW5zdGl0dWNpb25hbGVzPC9zcGFuPlxuICAgICAgICAgICAgPC9oMT5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgbWQ6dGV4dC1zbSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIG10LTFcIj5cbiAgICAgICAgICAgICAgRG9jdW1lbnRhY2nDs24gdMOpY25pY2EsIGVzdGFkw61zdGljYXMgZmlzaWNvcXXDrW1pY2FzLCBjb25zdW1vIGRlIGluc3Vtb3MgeSBjdW1wbGltaWVudG8gbm9ybWF0aXZvIChMZXkgTXVuaWNpcGFsIDAyMCAvIFJEIDc0Mi8yMDEzKS5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17Y2FyZ2FyUmVwb3J0ZX1cbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmd9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJnLXNsYXRlLTEwMCBob3ZlcjpiZy1zbGF0ZS0yMDAgZGFyazpiZy1bIzMxM0Q0QV0gZGFyazpob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBweC00IHB5LTIuNSByb3VuZGVkLXhsIGZvbnQtc2VtaWJvbGQgdGV4dC1zbSB0cmFuc2l0aW9uLWFsbCBzaGFkb3ctc20gZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPXtgdy00IGgtNCAke2xvYWRpbmcgPyAnYW5pbWF0ZS1zcGluJyA6ICcnfWB9IGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTQgNHY1aC41ODJtMTUuMzU2IDJBOC4wMDEgOC4wMDEgMCAwMDQuNTgyIDltMCAwSDltMTEgMTF2LTVoLS41ODFtMCAwYTguMDAzIDguMDAzIDAgMDEtMTUuMzU3LTJtMTUuMzU3IDJIMTVcIiAvPlxuICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgPHNwYW4+e2xvYWRpbmcgPyAnQWN0dWFsaXphbmRvLi4uJyA6ICdBY3R1YWxpemFyJ308L3NwYW4+XG4gICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVFeHBvcnRhclBkZn1cbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2V4cG9ydGluZ1BkZiB8fCBsb2FkaW5nfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS02MDAgdG8taW5kaWdvLTYwMCBob3Zlcjpmcm9tLWJsdWUtNzAwIGhvdmVyOnRvLWluZGlnby03MDAgdGV4dC13aGl0ZSBweC01IHB5LTIuNSByb3VuZGVkLXhsIGZvbnQtYm9sZCB0ZXh0LXNtIHRyYW5zaXRpb24tYWxsIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtleHBvcnRpbmdQZGYgPyAoXG4gICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy00IGgtNCBhbmltYXRlLXNwaW5cIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGNpcmNsZSBjbGFzc05hbWU9XCJvcGFjaXR5LTI1XCIgY3g9XCIxMlwiIGN5PVwiMTJcIiByPVwiMTBcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjRcIj48L2NpcmNsZT5cbiAgICAgICAgICAgICAgICAgICAgPHBhdGggY2xhc3NOYW1lPVwib3BhY2l0eS03NVwiIGZpbGw9XCJjdXJyZW50Q29sb3JcIiBkPVwiTTQgMTJhOCA4IDAgMDE4LTh2OEg0elwiPjwvcGF0aD5cbiAgICAgICAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+R2VuZXJhbmRvIFBERi4uLjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTEyIDEwdjZtMCAwbC0zLTNtMyAzbDMtM20yIDhIN2EyIDIgMCAwMS0yLTJWNWEyIDIgMCAwMTItMmg1LjU4NmExIDEgMCAwMS43MDcuMjkzbDUuNDE0IDUuNDE0YTEgMSAwIDAxLjI5My43MDdWMTlhMiAyIDAgMDEtMiAyelwiIC8+XG4gICAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPkV4cG9ydGFyIGEgUERGPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctN3hsIG14LWF1dG8gcHgtNiBtdC02IHNwYWNlLXktNlwiPlxuICAgICAgICB7LyogTm90aWZpY2FjaW9uZXMgKi99XG4gICAgICAgIHtub3RpZmljYXRpb24gJiYgKFxuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtNCByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNtIGZvbnQtbWVkaXVtICR7XG4gICAgICAgICAgICAgIG5vdGlmaWNhdGlvbi50eXBlID09PSAnZXJyb3InXG4gICAgICAgICAgICAgICAgPyAnYmctcm9zZS01MCBib3JkZXIgYm9yZGVyLXJvc2UtMjAwIHRleHQtcm9zZS03MDAgZGFyazpiZy1yb3NlLTk1MC8zMCBkYXJrOmJvcmRlci1yb3NlLTkwMC81MCBkYXJrOnRleHQtcm9zZS00MDAnXG4gICAgICAgICAgICAgICAgOiAnYmctZW1lcmFsZC01MCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwIHRleHQtZW1lcmFsZC03MDAgZGFyazpiZy1lbWVyYWxkLTk1MC8zMCBkYXJrOmJvcmRlci1lbWVyYWxkLTkwMC81MCBkYXJrOnRleHQtZW1lcmFsZC00MDAnXG4gICAgICAgICAgICB9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxzcGFuPntub3RpZmljYXRpb24udHlwZSA9PT0gJ2Vycm9yJyA/ICfimqDvuI8nIDogJ+KchSd9PC9zcGFuPlxuICAgICAgICAgICAgICA8c3Bhbj57bm90aWZpY2F0aW9uLm1zZ308L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0Tm90aWZpY2F0aW9uKG51bGwpfSBjbGFzc05hbWU9XCJ0ZXh0LXhzIHVuZGVybGluZSBvcGFjaXR5LTcwIGhvdmVyOm9wYWNpdHktMTAwXCI+XG4gICAgICAgICAgICAgIENlcnJhclxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIOKUgOKUgCBCYXJyYSBkZSBOYXZlZ2FjacOzbiBkZSBQZXN0YcOxYXMgeSBGaWx0cm9zIFRlbXBvcmFsZXMg4pSA4pSAICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIHJvdW5kZWQtMnhsIHAtNSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gc2hhZG93LXNtIGZsZXggZmxleC1jb2wgbGc6ZmxleC1yb3cgbGc6aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNVwiPlxuICAgICAgICAgIHsvKiBTZWxlY3RvciBkZSBUaXBvIGRlIFJlcG9ydGUgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIHtbXG4gICAgICAgICAgICAgIHsgaWQ6ICdjYWxpZGFkX2FndWEnLCBsYWJlbDogJ/CfkqcgQ2FsaWRhZCBkZWwgQWd1YScsIGRlc2M6ICdwSCwgVHVyYmlkZXosIFRlbXAuJyB9LFxuICAgICAgICAgICAgICB7IGlkOiAnZG9zaWZpY2FjaW9uJywgbGFiZWw6ICfwn6eqIFF1w61taWNvcyB5IERvc2lzJywgZGVzYzogJ0Nsb3JvLCBDb2JyZSwgQWx1bWluaW8nIH0sXG4gICAgICAgICAgICAgIHsgaWQ6ICdhZmx1ZW5jaWEnLCBsYWJlbDogJ/CfkaUgQWZsdWVuY2lhIEJhw7Fpc3RhcycsIGRlc2M6ICdUYXF1aWxsYSB5IEPDoW1hcmEnIH0sXG4gICAgICAgICAgICAgIHsgaWQ6ICdjb21wbGV0bycsIGxhYmVsOiAn8J+TkSBDb25zb2xpZGFkbyBHbG9iYWwnLCBkZXNjOiAnSW5mb3JtZSBJbnRlZ3JhbCcgfSxcbiAgICAgICAgICAgIF0ubWFwKCh0YWIpID0+IChcbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIGtleT17dGFiLmlkfVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgIHNldFRpcG9SZXBvcnRlKHRhYi5pZClcbiAgICAgICAgICAgICAgICAgIHNldFBhZ2luYUFjdHVhbCgxKVxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIHJvdW5kZWQteGwgdGV4dC14cyBtZDp0ZXh0LXNtIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCBmbGV4IGZsZXgtY29sIHRleHQtbGVmdCAke1xuICAgICAgICAgICAgICAgICAgdGlwb1JlcG9ydGUgPT09IHRhYi5pZFxuICAgICAgICAgICAgICAgICAgICA/ICdiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdy1tZCBzaGFkb3ctYmx1ZS01MDAvMjAnXG4gICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTUwIGRhcms6YmctWyMxQTIyMkNdIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwJ1xuICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPHNwYW4+e3RhYi5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdGV4dC1bMTBweF0gZm9udC1ub3JtYWwgJHt0aXBvUmVwb3J0ZSA9PT0gdGFiLmlkID8gJ3RleHQtYmx1ZS0xMDAnIDogJ3RleHQtc2xhdGUtNDAwJ31gfT5cbiAgICAgICAgICAgICAgICAgIHt0YWIuZGVzY31cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogU2VsZWN0b3IgZGUgUmFuZ28gVGVtcG9yYWwgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtMTAwIGRhcms6YmctWyMxQTIyMkNdIHAtMSByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXVwiPlxuICAgICAgICAgICAgICB7W1xuICAgICAgICAgICAgICAgIHsgaWQ6ICdob3knLCBsYWJlbDogJ0hveScgfSxcbiAgICAgICAgICAgICAgICB7IGlkOiAnc2VtYW5hJywgbGFiZWw6ICc3IETDrWFzJyB9LFxuICAgICAgICAgICAgICAgIHsgaWQ6ICdtZXMnLCBsYWJlbDogJzMwIETDrWFzJyB9LFxuICAgICAgICAgICAgICAgIHsgaWQ6ICdwZXJzb25hbGl6YWRvJywgbGFiZWw6ICdSYW5nbyBsaWJyZScgfSxcbiAgICAgICAgICAgICAgXS5tYXAoKHJhbmdvKSA9PiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAga2V5PXtyYW5nby5pZH1cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgc2V0VGlwb1JhbmdvKHJhbmdvLmlkKVxuICAgICAgICAgICAgICAgICAgICBzZXRQYWdpbmFBY3R1YWwoMSlcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zIHB5LTEuNSByb3VuZGVkLWxnIHRleHQteHMgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICB0aXBvUmFuZ28gPT09IHJhbmdvLmlkXG4gICAgICAgICAgICAgICAgICAgICAgPyAnYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gdGV4dC1ibHVlLTYwMCBkYXJrOnRleHQtYmx1ZS00MDAgc2hhZG93LXNtJ1xuICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS04MDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAge3JhbmdvLmxhYmVsfVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7dGlwb1JhbmdvID09PSAncGVyc29uYWxpemFkbycgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmZWNoYUluaWNpb31cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RmVjaGFJbmljaW8oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMi41IHB5LTEuNSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBiZy1zbGF0ZS01MCBkYXJrOmJnLVsjMUEyMjJDXSB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIj5hPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2ZlY2hhRmlufVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGZWNoYUZpbihlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yLjUgcHktMS41IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIGJnLXNsYXRlLTUwIGRhcms6YmctWyMxQTIyMkNdIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7Lyog4pSA4pSAIFNFQ0NJw5NOIDE6IFJFUE9SVEUgREUgQ0FMSURBRCBERUwgQUdVQSAoUkYtMDUgLyBIVS0wMDUpIOKUgOKUgCAqL31cbiAgICAgICAgeyh0aXBvUmVwb3J0ZSA9PT0gJ2NhbGlkYWRfYWd1YScgfHwgdGlwb1JlcG9ydGUgPT09ICdjb21wbGV0bycpICYmIGRhdGFDYWxpZGFkICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxuICAgICAgICAgICAgey8qIFRhcmpldGFzIEtQSSBkZSBDYWxpZGFkIGRlbCBBZ3VhICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC00XCI+XG4gICAgICAgICAgICAgIHsvKiBUYXJqZXRhIHBIICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIHAtNSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gc2hhZG93LXNtIHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDBcIj5wSCBQcm9tZWRpbzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIGZvbnQtYm9sZCBiZy1ibHVlLTUwIHRleHQtYmx1ZS02MDAgZGFyazpiZy1ibHVlLTkwMC8zMCBkYXJrOnRleHQtYmx1ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgTm9ybWE6IDcuMiAtIDcuNlxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBmbGV4IGl0ZW1zLWJhc2VsaW5lIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJsYWNrIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICB7ZGF0YUNhbGlkYWQuZXN0YWRpc3RpY2FzLnBoLnByb21lZGlvID8/ICfigJQnfVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIChNw61uOiB7ZGF0YUNhbGlkYWQuZXN0YWRpc3RpY2FzLnBoLm1pbiA/PyAn4oCUJ30gLyBNw6F4OiB7ZGF0YUNhbGlkYWQuZXN0YWRpc3RpY2FzLnBoLm1heCA/PyAn4oCUJ30pXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQteHMgZm9udC1zZW1pYm9sZCBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwXCI+Q3VtcGxpbWllbnRvOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2RhdGFDYWxpZGFkLmVzdGFkaXN0aWNhcy5waC5wY3RfY3VtcGxpbWllbnRvfSVcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBoLTEuNSBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS03MDAgcm91bmRlZC1mdWxsIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC1mdWxsIGJnLWVtZXJhbGQtNTAwIHJvdW5kZWQtZnVsbFwiXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IGAke2RhdGFDYWxpZGFkLmVzdGFkaXN0aWNhcy5waC5wY3RfY3VtcGxpbWllbnRvfSVgIH19XG4gICAgICAgICAgICAgICAgICAgID48L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogVGFyamV0YSBUdXJiaWRleiAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLVsjMjQzMDNGXSBwLTUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIHNoYWRvdy1zbSByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwXCI+VHVyYmlkZXogTWVkaWE8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCBmb250LWJvbGQgYmctYW1iZXItNTAgdGV4dC1hbWJlci02MDAgZGFyazpiZy1hbWJlci05MDAvMzAgZGFyazp0ZXh0LWFtYmVyLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICBMw61taXRlOiAmbHQ7IDUuMCBOVFVcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgZmxleCBpdGVtcy1iYXNlbGluZSBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ibGFjayB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAge2RhdGFDYWxpZGFkLmVzdGFkaXN0aWNhcy50dXJiaWRlei5wcm9tZWRpbyA/PyAn4oCUJ31cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPk5UVTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyBmb250LXNlbWlib2xkIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDBcIj5DdW1wbGltaWVudG86PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7ZGF0YUNhbGlkYWQuZXN0YWRpc3RpY2FzLnR1cmJpZGV6LnBjdF9jdW1wbGltaWVudG99JVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGgtMS41IGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTcwMCByb3VuZGVkLWZ1bGwgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLWZ1bGwgYmctYW1iZXItNTAwIHJvdW5kZWQtZnVsbFwiXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IGAke2RhdGFDYWxpZGFkLmVzdGFkaXN0aWNhcy50dXJiaWRlei5wY3RfY3VtcGxpbWllbnRvfSVgIH19XG4gICAgICAgICAgICAgICAgICAgID48L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogVGFyamV0YSBUZW1wZXJhdHVyYSAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLVsjMjQzMDNGXSBwLTUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIHNoYWRvdy1zbSByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwXCI+VGVtcGVyYXR1cmEgTWVkaWE8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCBmb250LWJvbGQgYmctdGVhbC01MCB0ZXh0LXRlYWwtNjAwIGRhcms6YmctdGVhbC05MDAvMzAgZGFyazp0ZXh0LXRlYWwtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDI2wrBDIC0gMjjCsENcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgZmxleCBpdGVtcy1iYXNlbGluZSBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ibGFjayB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAge2RhdGFDYWxpZGFkLmVzdGFkaXN0aWNhcy50ZW1wZXJhdHVyYS5wcm9tZWRpbyA/PyAn4oCUJ31cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPsKwQzwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyBmb250LXNlbWlib2xkIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDBcIj5DdW1wbGltaWVudG86PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7ZGF0YUNhbGlkYWQuZXN0YWRpc3RpY2FzLnRlbXBlcmF0dXJhLnBjdF9jdW1wbGltaWVudG99JVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGgtMS41IGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTcwMCByb3VuZGVkLWZ1bGwgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLWZ1bGwgYmctdGVhbC01MDAgcm91bmRlZC1mdWxsXCJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7ZGF0YUNhbGlkYWQuZXN0YWRpc3RpY2FzLnRlbXBlcmF0dXJhLnBjdF9jdW1wbGltaWVudG99JWAgfX1cbiAgICAgICAgICAgICAgICAgICAgPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiDDjW5kaWNlIEdsb2JhbCBkZSBDb25mb3JtaWRhZCAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWJsdWUtNjAwIHRvLWluZGlnby03MDAgcC01IHJvdW5kZWQtMnhsIHRleHQtd2hpdGUgc2hhZG93LW1kIHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ibHVlLTIwMFwiPsONbmRpY2UgU2FuaXRhcmlvIEdsb2JhbDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgYmctd2hpdGUvMjAgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICB7ZGF0YUNhbGlkYWQudG90YWxfbWVkaWNpb25lc30gbXVlc3RyYXNcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgZmxleCBpdGVtcy1iYXNlbGluZSBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC00eGwgZm9udC1ibGFja1wiPntkYXRhQ2FsaWRhZC5pbmRpY2VfZ2xvYmFsX2N1bXBsaW1pZW50b30lPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWJsdWUtMTAwIGZvbnQtbWVkaXVtXCI+Y29uZm9ybWUgYSBub3JtYTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEdyw6FmaWNvcyBSZWNoYXJ0cyBkZSBFdm9sdWNpw7NuIFRlbXBvcmFsICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0yIGdhcC02XCI+XG4gICAgICAgICAgICAgIHsvKiBHcsOhZmljbyBwSCAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLVsjMjQzMDNGXSBwLTYgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIHNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlXCI+RXZvbHVjacOzbiBkZWwgcEggZGVsIEFndWE8L2gzPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+UmFuZ28gbm9ybWF0aXZvIMOzcHRpbW8gZW50cmUgNy4yMCB5IDcuNjA8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCBweC0yIHB5LTEgcm91bmRlZC1sZyBiZy1ibHVlLTUwIHRleHQtYmx1ZS02MDAgZGFyazpiZy1ibHVlLTkwMC8zMCBkYXJrOnRleHQtYmx1ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgSWRlYWw6IDcuNFxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC02NFwiPlxuICAgICAgICAgICAgICAgICAgPFJlc3BvbnNpdmVDb250YWluZXIgd2lkdGg9XCIxMDAlXCIgaGVpZ2h0PVwiMTAwJVwiPlxuICAgICAgICAgICAgICAgICAgICA8TGluZUNoYXJ0IGRhdGE9e2RhdGFDYWxpZGFkLm1lZGljaW9uZXN9PlxuICAgICAgICAgICAgICAgICAgICAgIDxDYXJ0ZXNpYW5HcmlkIHN0cm9rZURhc2hhcnJheT1cIjMgM1wiIG9wYWNpdHk9ezAuMn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICA8WEF4aXMgZGF0YUtleT1cImhvcmFcIiB0aWNrPXt7IGZvbnRTaXplOiAxMCB9fSAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxZQXhpcyBkb21haW49e1s2LjUsIDkuMF19IHRpY2s9e3sgZm9udFNpemU6IDEwIH19IC8+XG4gICAgICAgICAgICAgICAgICAgICAgPFRvb2x0aXBcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRlbnRTdHlsZT17e1xuICAgICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICcjMUUyOTNCJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnOHB4JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAnbm9uZScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAnI2ZmZicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiAnMTFweCcsXG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPFJlZmVyZW5jZUxpbmUgeT17Ny4yfSBzdHJva2U9XCIjRUY0NDQ0XCIgc3Ryb2tlRGFzaGFycmF5PVwiNCA0XCIgbGFiZWw9e3sgdmFsdWU6ICdNw61uIDcuMicsIGZpbGw6ICcjRUY0NDQ0JywgZm9udFNpemU6IDEwIH19IC8+XG4gICAgICAgICAgICAgICAgICAgICAgPFJlZmVyZW5jZUxpbmUgeT17Ny42fSBzdHJva2U9XCIjRUY0NDQ0XCIgc3Ryb2tlRGFzaGFycmF5PVwiNCA0XCIgbGFiZWw9e3sgdmFsdWU6ICdNw6F4IDcuNicsIGZpbGw6ICcjRUY0NDQ0JywgZm9udFNpemU6IDEwIH19IC8+XG4gICAgICAgICAgICAgICAgICAgICAgPExpbmUgdHlwZT1cIm1vbm90b25lXCIgZGF0YUtleT1cInBoXCIgc3Ryb2tlPVwiIzI1NjNFQlwiIHN0cm9rZVdpZHRoPXsyLjV9IGRvdD17eyByOiAyIH19IGFjdGl2ZURvdD17eyByOiA1IH19IG5hbWU9XCJwSCBNZWRpZG9cIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L0xpbmVDaGFydD5cbiAgICAgICAgICAgICAgICAgIDwvUmVzcG9uc2l2ZUNvbnRhaW5lcj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIEdyw6FmaWNvIFR1cmJpZGV6ICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIHAtNiByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGVcIj5Fdm9sdWNpw7NuIGRlIFR1cmJpZGV6IChOVFUpPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPkzDrW1pdGUgbm9ybWF0aXZvIG3DoXhpbW86IDUuMCBOVFU8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCBweC0yIHB5LTEgcm91bmRlZC1sZyBiZy1hbWJlci01MCB0ZXh0LWFtYmVyLTYwMCBkYXJrOmJnLWFtYmVyLTkwMC8zMCBkYXJrOnRleHQtYW1iZXItMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICZsdDsgNS4wIE5UVVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC02NFwiPlxuICAgICAgICAgICAgICAgICAgPFJlc3BvbnNpdmVDb250YWluZXIgd2lkdGg9XCIxMDAlXCIgaGVpZ2h0PVwiMTAwJVwiPlxuICAgICAgICAgICAgICAgICAgICA8TGluZUNoYXJ0IGRhdGE9e2RhdGFDYWxpZGFkLm1lZGljaW9uZXN9PlxuICAgICAgICAgICAgICAgICAgICAgIDxDYXJ0ZXNpYW5HcmlkIHN0cm9rZURhc2hhcnJheT1cIjMgM1wiIG9wYWNpdHk9ezAuMn0gLz5cbiAgICAgICAgICAgICAgICAgICAgICA8WEF4aXMgZGF0YUtleT1cImhvcmFcIiB0aWNrPXt7IGZvbnRTaXplOiAxMCB9fSAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxZQXhpcyBkb21haW49e1swLCAxNV19IHRpY2s9e3sgZm9udFNpemU6IDEwIH19IC8+XG4gICAgICAgICAgICAgICAgICAgICAgPFRvb2x0aXBcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRlbnRTdHlsZT17e1xuICAgICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICcjMUUyOTNCJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnOHB4JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAnbm9uZScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAnI2ZmZicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiAnMTFweCcsXG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPFJlZmVyZW5jZUxpbmUgeT17NS4wfSBzdHJva2U9XCIjRjU5RTBCXCIgc3Ryb2tlRGFzaGFycmF5PVwiNCA0XCIgbGFiZWw9e3sgdmFsdWU6ICdMw61taXRlIDUuMCcsIGZpbGw6ICcjRjU5RTBCJywgZm9udFNpemU6IDEwIH19IC8+XG4gICAgICAgICAgICAgICAgICAgICAgPExpbmUgdHlwZT1cIm1vbm90b25lXCIgZGF0YUtleT1cInR1cmJpZGV6XCIgc3Ryb2tlPVwiI0Y1OUUwQlwiIHN0cm9rZVdpZHRoPXsyLjV9IGRvdD17eyByOiAyIH19IGFjdGl2ZURvdD17eyByOiA1IH19IG5hbWU9XCJUdXJiaWRleiAoTlRVKVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvTGluZUNoYXJ0PlxuICAgICAgICAgICAgICAgICAgPC9SZXNwb25zaXZlQ29udGFpbmVyPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogR3LDoWZpY28gVGVtcGVyYXR1cmEgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gcC02IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBzaGFkb3ctc20gbGc6Y29sLXNwYW4tMlwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlXCI+RXZvbHVjacOzbiBkZSBUZW1wZXJhdHVyYSBkZWwgQWd1YSAowrBDKTwvaDM+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5SYW5nbyBkZSBjb25mb3J0IHJlY3JlYXRpdm8gZW50cmUgMjYuMCDCsEMgeSAyOC4wIMKwQyAoTMOtbWl0ZXMgcGVybWl0aWRvczogMjQuMCDCsEMg4oCTIDMwLjAgwrBDKTwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHB4LTIgcHktMSByb3VuZGVkLWxnIGJnLXRlYWwtNTAgdGV4dC10ZWFsLTYwMCBkYXJrOmJnLXRlYWwtOTAwLzMwIGRhcms6dGV4dC10ZWFsLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICBDb25mb3J0OiAyNsKwQyAtIDI4wrBDXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTY0XCI+XG4gICAgICAgICAgICAgICAgICA8UmVzcG9uc2l2ZUNvbnRhaW5lciB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9XCIxMDAlXCI+XG4gICAgICAgICAgICAgICAgICAgIDxMaW5lQ2hhcnQgZGF0YT17ZGF0YUNhbGlkYWQubWVkaWNpb25lc30+XG4gICAgICAgICAgICAgICAgICAgICAgPENhcnRlc2lhbkdyaWQgc3Ryb2tlRGFzaGFycmF5PVwiMyAzXCIgb3BhY2l0eT17MC4yfSAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxYQXhpcyBkYXRhS2V5PXt0aXBvUmFuZ28gPT09ICdob3knID8gJ2hvcmEnIDogJ2ZlY2hhX2hvcmEnfSB0aWNrPXt7IGZvbnRTaXplOiAxMCB9fSAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxZQXhpcyBkb21haW49e1syMCwgMzVdfSB0aWNrPXt7IGZvbnRTaXplOiAxMCB9fSAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxUb29sdGlwXG4gICAgICAgICAgICAgICAgICAgICAgICBjb250ZW50U3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiAnIzFFMjkzQicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogJzhweCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlcjogJ25vbmUnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogJyNmZmYnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogJzExcHgnLFxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxSZWZlcmVuY2VMaW5lIHk9ezI0LjB9IHN0cm9rZT1cIiMwRDk0ODhcIiBzdHJva2VEYXNoYXJyYXk9XCI0IDRcIiBsYWJlbD17eyB2YWx1ZTogJ03DrW4gMjTCsEMnLCBmaWxsOiAnIzBEOTQ4OCcsIGZvbnRTaXplOiAxMCB9fSAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxSZWZlcmVuY2VMaW5lIHk9ezMwLjB9IHN0cm9rZT1cIiMwRDk0ODhcIiBzdHJva2VEYXNoYXJyYXk9XCI0IDRcIiBsYWJlbD17eyB2YWx1ZTogJ03DoXggMzDCsEMnLCBmaWxsOiAnIzBEOTQ4OCcsIGZvbnRTaXplOiAxMCB9fSAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxMaW5lIHR5cGU9XCJtb25vdG9uZVwiIGRhdGFLZXk9XCJ0ZW1wZXJhdHVyYVwiIHN0cm9rZT1cIiMwRDk0ODhcIiBzdHJva2VXaWR0aD17Mi41fSBkb3Q9e3sgcjogMiB9fSBhY3RpdmVEb3Q9e3sgcjogNSB9fSBuYW1lPVwiVGVtcGVyYXR1cmEgKMKwQylcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L0xpbmVDaGFydD5cbiAgICAgICAgICAgICAgICAgIDwvUmVzcG9uc2l2ZUNvbnRhaW5lcj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIERpYWduw7NzdGljbyB5IENvbmNsdXNpb25lcyBUw6ljbmljYXMgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIHAtNiByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTNcIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj7wn5OLIERpY3RhbWVuIHkgUmVjb21lbmRhY2lvbmVzIFTDqWNuaWNhczwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC00IG1iLTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMy41IHJvdW5kZWQteGwgYmctc2xhdGUtNTAgZGFyazpiZy1bIzFBMjIyQ10gYm9yZGVyIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItWyMzMTNENEFdXCI+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+QWxlcnRhcyBkZSBwSCDDoWNpZG8gLyBhbGNhbGlubzwvcD5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZSBtdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgIHtkYXRhQ2FsaWRhZC5hbGVydGFzLnBoX2FjaWRvICsgZGF0YUNhbGlkYWQuYWxlcnRhcy5waF9hbGNhbGlub30gZXZlbnRvc1xuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgKHtkYXRhQ2FsaWRhZC5hbGVydGFzLnBoX2FjaWRvfSDDoWNpZG9zIC8ge2RhdGFDYWxpZGFkLmFsZXJ0YXMucGhfYWxjYWxpbm99IGFsY2FsaW5vcylcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMy41IHJvdW5kZWQteGwgYmctc2xhdGUtNTAgZGFyazpiZy1bIzFBMjIyQ10gYm9yZGVyIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItWyMzMTNENEFdXCI+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+QWxlcnRhcyBkZSB0dXJiaWRleiAoJmdlOyA1IE5UVSk8L3A+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGUgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICB7ZGF0YUNhbGlkYWQuYWxlcnRhcy50dXJiaWRlel9hbHRhICsgZGF0YUNhbGlkYWQuYWxlcnRhcy50dXJiaWRlel9jcml0aWNhfSBldmVudG9zXG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAoe2RhdGFDYWxpZGFkLmFsZXJ0YXMudHVyYmlkZXpfY3JpdGljYX0gY3LDrXRpY2FzICZnZTsgMTAgTlRVKVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zLjUgcm91bmRlZC14bCBiZy1zbGF0ZS01MCBkYXJrOmJnLVsjMUEyMjJDXSBib3JkZXIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV1cIj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5EZXN2aWFjaW9uZXMgZGUgdGVtcGVyYXR1cmE8L3A+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGUgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICB7ZGF0YUNhbGlkYWQuYWxlcnRhcy50ZW1wX2Z1ZXJhX3JhbmdvfSBldmVudG9zXG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMFwiPkZ1ZXJhIGRlIDI0wrBDIC0gMzDCsEM8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwic3BhY2UteS0xLjUgdGV4dC14cyBtZDp0ZXh0LXNtIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICB7ZGF0YUNhbGlkYWQuZXZhbHVhY2lvbl90ZWNuaWNhPy5tYXAoKGl0ZW0sIGlkeCkgPT4gKFxuICAgICAgICAgICAgICAgICAgPGxpIGtleT17aWR4fSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDAgZm9udC1ib2xkXCI+4oCiPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj57aXRlbX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBUYWJsYSBEZXRhbGxhZGEgZGUgTWVkaWNpb25lcyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIHNoYWRvdy1zbSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC02IHB5LTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlXCI+UmVnaXN0cm9zIGRlIE11ZXN0cmVvIGRlIENhbGlkYWQ8L2gzPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICBNb3N0cmFuZG8gcMOhZ2luYSB7cGFnaW5hQWN0dWFsfSBkZSB7dG90YWxQYWdpbmFzfSAoe21lZGljaW9uZXMubGVuZ3RofSBsZWN0dXJhcyB0b3RhbGVzKVxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MCBkYXJrOmJnLVsjMUEyMjJDXSBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC01IHB5LTMgdGV4dC1zbGF0ZS00MDAgZm9udC1ib2xkIHVwcGVyY2FzZVwiPkZlY2hhIHkgSG9yYTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTUgcHktMyB0ZXh0LXNsYXRlLTQwMCBmb250LWJvbGQgdXBwZXJjYXNlXCI+cEg8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC01IHB5LTMgdGV4dC1zbGF0ZS00MDAgZm9udC1ib2xkIHVwcGVyY2FzZVwiPlR1cmJpZGV6IChOVFUpPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNSBweS0zIHRleHQtc2xhdGUtNDAwIGZvbnQtYm9sZCB1cHBlcmNhc2VcIj5UZW1wZXJhdHVyYSAowrBDKTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTUgcHktMyB0ZXh0LXNsYXRlLTQwMCBmb250LWJvbGQgdXBwZXJjYXNlXCI+RXN0YWRvIFNhbml0YXJpbzwvdGg+XG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1zbGF0ZS0xMDAgZGFyazpkaXZpZGUtWyMzMTNENEFdXCI+XG4gICAgICAgICAgICAgICAgICAgIHttZWRpY2lvbmVzUGFnaW5hZGFzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY29sU3Bhbj1cIjVcIiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS04IHRleHQtc2xhdGUtNDAwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIE5vIHNlIGVuY29udHJhcm9uIGxlY3R1cmFzIGVuIGVsIHJhbmdvIHNlbGVjY2lvbmFkb1xuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgIG1lZGljaW9uZXNQYWdpbmFkYXMubWFwKChtKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXttLmlkX21lZGljaW9ufSBjbGFzc05hbWU9XCJob3ZlcjpiZy1zbGF0ZS01MCBkYXJrOmhvdmVyOmJnLVsjMzEzRDRBXS8zMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNSBweS0zIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bS5mZWNoYV9ob3JhfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNSBweS0zIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIGZvbnQtYm9sZCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtLmVzdGFkb19waCA9PT0gJ09QVElNTydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTUwIHRleHQtZW1lcmFsZC02MDAgZGFyazpiZy1lbWVyYWxkLTk1MC80MCBkYXJrOnRleHQtZW1lcmFsZC00MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctcm9zZS01MCB0ZXh0LXJvc2UtNjAwIGRhcms6Ymctcm9zZS05NTAvNDAgZGFyazp0ZXh0LXJvc2UtNDAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge20ucGggIT09IG51bGwgPyBtLnBoLnRvRml4ZWQoMikgOiAn4oCUJ30gKHttLmVzdGFkb19waH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNSBweS0zIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIGZvbnQtYm9sZCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtLmVzdGFkb190dXJiaWRleiA9PT0gJ09QVElNQSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTUwIHRleHQtZW1lcmFsZC02MDAgZGFyazpiZy1lbWVyYWxkLTk1MC80MCBkYXJrOnRleHQtZW1lcmFsZC00MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctYW1iZXItNTAgdGV4dC1hbWJlci02MDAgZGFyazpiZy1hbWJlci05NTAvNDAgZGFyazp0ZXh0LWFtYmVyLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHttLnR1cmJpZGV6ICE9PSBudWxsID8gbS50dXJiaWRlei50b0ZpeGVkKDIpIDogJ+KAlCd9IE5UVVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTUgcHktMyB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge20udGVtcGVyYXR1cmEgIT09IG51bGwgPyBgJHttLnRlbXBlcmF0dXJhLnRvRml4ZWQoMSl9IMKwQ2AgOiAn4oCUJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTUgcHktM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LVsxMXB4XSBmb250LWJvbGQgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbS5jb25mb3JtZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWVtZXJhbGQtMTAwIHRleHQtZW1lcmFsZC04MDAgZGFyazpiZy1lbWVyYWxkLTkwMC80MCBkYXJrOnRleHQtZW1lcmFsZC0zMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctcm9zZS0xMDAgdGV4dC1yb3NlLTgwMCBkYXJrOmJnLXJvc2UtOTAwLzQwIGRhcms6dGV4dC1yb3NlLTMwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHctMS41IGgtMS41IHJvdW5kZWQtZnVsbCAke20uY29uZm9ybWUgPyAnYmctZW1lcmFsZC01MDAnIDogJ2JnLXJvc2UtNTAwJ31gfT48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bS5jb25mb3JtZSA/ICdDT05GT1JNRScgOiAnRlVFUkEgREUgTk9STUEnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgKSlcbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIENvbnRyb2xlcyBkZSBwYWdpbmFjacOzbiAqL31cbiAgICAgICAgICAgICAge3RvdGFsUGFnaW5hcyA+IDEgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS0zIGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItWyMzMTNENEFdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17cGFnaW5hQWN0dWFsID09PSAxfVxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRQYWdpbmFBY3R1YWwoKHApID0+IE1hdGgubWF4KDEsIHAgLSAxKSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBkaXNhYmxlZDpvcGFjaXR5LTQwXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgQW50ZXJpb3JcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICBQw6FnaW5hIHtwYWdpbmFBY3R1YWx9IGRlIHt0b3RhbFBhZ2luYXN9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtwYWdpbmFBY3R1YWwgPT09IHRvdGFsUGFnaW5hc31cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UGFnaW5hQWN0dWFsKChwKSA9PiBNYXRoLm1pbih0b3RhbFBhZ2luYXMsIHAgKyAxKSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBkaXNhYmxlZDpvcGFjaXR5LTQwXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgU2lndWllbnRlXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICAgIHsvKiDilIDilIAgU0VDQ0nDk04gMjogUkVQT1JURSBERSBET1NJRklDQUNJw5NOIFkgUVXDjU1JQ09TIOKUgOKUgCAqL31cbiAgICAgICAgeyh0aXBvUmVwb3J0ZSA9PT0gJ2Rvc2lmaWNhY2lvbicgfHwgdGlwb1JlcG9ydGUgPT09ICdjb21wbGV0bycpICYmIGRhdGFRdWltaWNvcyAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIHAtNSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRleHQtc2xhdGUtNDAwXCI+Q2xvcm8gQXBsaWNhZG88L3NwYW4+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ibGFjayB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGUgbXQtMlwiPlxuICAgICAgICAgICAgICAgICAge2RhdGFRdWltaWNvcy50b3RhbGVzX2Rvc2lmaWNhZG9zX2tnLmNsb3JvfSBrZ1xuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgdGV4dC14cyBmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+e2RhdGFRdWltaWNvcy5jb250ZW9fYWN0aXZhY2lvbmVzLmNsb3JvfSBkb3Npczwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWJsdWUtNjAwIGRhcms6dGV4dC1ibHVlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICBCcy4ge2RhdGFRdWltaWNvcy5jb3N0b3NfZXN0aW1hZG9zX2JzLmNsb3JvLnRvRml4ZWQoMil9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gcC01IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdGV4dC1zbGF0ZS00MDBcIj5TdWxmYXRvIGRlIEFsdW1pbmlvPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYmxhY2sgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlIG10LTJcIj5cbiAgICAgICAgICAgICAgICAgIHtkYXRhUXVpbWljb3MudG90YWxlc19kb3NpZmljYWRvc19rZ1snc3VsZmF0byBkZSBhbHVtaW5pbyddfSBrZ1xuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgdGV4dC14cyBmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+e2RhdGFRdWltaWNvcy5jb250ZW9fYWN0aXZhY2lvbmVzWydzdWxmYXRvIGRlIGFsdW1pbmlvJ119IGRvc2lzPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtYmx1ZS02MDAgZGFyazp0ZXh0LWJsdWUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIEJzLiB7ZGF0YVF1aW1pY29zLmNvc3Rvc19lc3RpbWFkb3NfYnNbJ3N1bGZhdG8gZGUgYWx1bWluaW8nXS50b0ZpeGVkKDIpfVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIHAtNSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRleHQtc2xhdGUtNDAwXCI+U3VsZmF0byBkZSBDb2JyZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZSBtdC0yXCI+XG4gICAgICAgICAgICAgICAgICB7ZGF0YVF1aW1pY29zLnRvdGFsZXNfZG9zaWZpY2Fkb3Nfa2dbJ3N1bGZhdG8gZGUgY29icmUnXX0ga2dcbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPntkYXRhUXVpbWljb3MuY29udGVvX2FjdGl2YWNpb25lc1snc3VsZmF0byBkZSBjb2JyZSddfSBkb3Npczwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWJsdWUtNjAwIGRhcms6dGV4dC1ibHVlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICBCcy4ge2RhdGFRdWltaWNvcy5jb3N0b3NfZXN0aW1hZG9zX2JzWydzdWxmYXRvIGRlIGNvYnJlJ10udG9GaXhlZCgyKX1cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWVtZXJhbGQtNjAwIHRvLXRlYWwtNzAwIHAtNSByb3VuZGVkLTJ4bCB0ZXh0LXdoaXRlIHNoYWRvdy1tZFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWVtZXJhbGQtMTAwXCI+Q29zdG8gVG90YWwgZGUgSW5zdW1vczwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJsYWNrIG10LTJcIj5Ccy4ge2RhdGFRdWltaWNvcy5jb3N0b190b3RhbF9icy50b0ZpeGVkKDIpfTwvcD5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgdGV4dC1lbWVyYWxkLTEwMFwiPlxuICAgICAgICAgICAgICAgICAgVG90YWwgZGUge2RhdGFRdWltaWNvcy50b3RhbF9yZWdpc3Ryb3NfZG9zaWZpY2FjaW9ufSBkb3NpZmljYWNpb25lcyBlbiBlbCBwZXLDrW9kby5cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBHcsOhZmljbyBjb21wYXJhdGl2byBkZSBxdcOtbWljb3MgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIHAtNiByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlIG1iLTFcIj5cbiAgICAgICAgICAgICAgICBDb21wYXJhdGl2YSBkZSBDb25zdW1vIHBvciBJbnN1bW8gUXXDrW1pY29cbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBtYi00XCI+R3JhbW9zIGRvc2lmaWNhZG9zIHNlZ8O6biByZWdpc3Ryb3MgZGVsIHNpc3RlbWE8L3A+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC02NFwiPlxuICAgICAgICAgICAgICAgIDxSZXNwb25zaXZlQ29udGFpbmVyIHdpZHRoPVwiMTAwJVwiIGhlaWdodD1cIjEwMCVcIj5cbiAgICAgICAgICAgICAgICAgIDxCYXJDaGFydFxuICAgICAgICAgICAgICAgICAgICBkYXRhPXtbXG4gICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogJ0Nsb3JvJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGdyYW1vczogZGF0YVF1aW1pY29zLnRvdGFsZXNfZG9zaWZpY2Fkb3NfZy5jbG9ybyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvc3RvQnM6IGRhdGFRdWltaWNvcy5jb3N0b3NfZXN0aW1hZG9zX2JzLmNsb3JvLFxuICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogJ1N1bGZhdG8gQWx1bWluaW8nLFxuICAgICAgICAgICAgICAgICAgICAgICAgZ3JhbW9zOiBkYXRhUXVpbWljb3MudG90YWxlc19kb3NpZmljYWRvc19nWydzdWxmYXRvIGRlIGFsdW1pbmlvJ10sXG4gICAgICAgICAgICAgICAgICAgICAgICBjb3N0b0JzOiBkYXRhUXVpbWljb3MuY29zdG9zX2VzdGltYWRvc19ic1snc3VsZmF0byBkZSBhbHVtaW5pbyddLFxuICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogJ1N1bGZhdG8gQ29icmUnLFxuICAgICAgICAgICAgICAgICAgICAgICAgZ3JhbW9zOiBkYXRhUXVpbWljb3MudG90YWxlc19kb3NpZmljYWRvc19nWydzdWxmYXRvIGRlIGNvYnJlJ10sXG4gICAgICAgICAgICAgICAgICAgICAgICBjb3N0b0JzOiBkYXRhUXVpbWljb3MuY29zdG9zX2VzdGltYWRvc19ic1snc3VsZmF0byBkZSBjb2JyZSddLFxuICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIF19XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxDYXJ0ZXNpYW5HcmlkIHN0cm9rZURhc2hhcnJheT1cIjMgM1wiIG9wYWNpdHk9ezAuMn0gLz5cbiAgICAgICAgICAgICAgICAgICAgPFhBeGlzIGRhdGFLZXk9XCJuYW1lXCIgdGljaz17eyBmb250U2l6ZTogMTEgfX0gLz5cbiAgICAgICAgICAgICAgICAgICAgPFlBeGlzIHRpY2s9e3sgZm9udFNpemU6IDEwIH19IC8+XG4gICAgICAgICAgICAgICAgICAgIDxUb29sdGlwXG4gICAgICAgICAgICAgICAgICAgICAgY29udGVudFN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICcjMUUyOTNCJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogJzhweCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6ICdub25lJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAnI2ZmZicsXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogJzExcHgnLFxuICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDxMZWdlbmQgLz5cbiAgICAgICAgICAgICAgICAgICAgPEJhciBkYXRhS2V5PVwiZ3JhbW9zXCIgZmlsbD1cIiMwMjg0QzdcIiBuYW1lPVwiR3JhbW9zIERvc2lmaWNhZG9zXCIgcmFkaXVzPXtbNiwgNiwgMCwgMF19IC8+XG4gICAgICAgICAgICAgICAgICAgIDxCYXIgZGF0YUtleT1cImNvc3RvQnNcIiBmaWxsPVwiIzEwQjk4MVwiIG5hbWU9XCJDb3N0byBlbiBCb2xpdmlhbm9zIChCcy4pXCIgcmFkaXVzPXtbNiwgNiwgMCwgMF19IC8+XG4gICAgICAgICAgICAgICAgICA8L0JhckNoYXJ0PlxuICAgICAgICAgICAgICAgIDwvUmVzcG9uc2l2ZUNvbnRhaW5lcj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7Lyog4pSA4pSAIFNFQ0NJw5NOIDM6IFJFUE9SVEUgREUgQUZMVUVOQ0lBIERFIEJBw5FJU1RBUyAoUkYtMTYgLyBIVS0wMTYpIOKUgOKUgCAqL31cbiAgICAgICAgeyh0aXBvUmVwb3J0ZSA9PT0gJ2FmbHVlbmNpYScgfHwgdGlwb1JlcG9ydGUgPT09ICdjb21wbGV0bycpICYmIGRhdGFBZmx1ZW5jaWEgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLVsjMjQzMDNGXSBwLTUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIHNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0ZXh0LXNsYXRlLTQwMFwiPlRvdGFsIEJhw7Fpc3Rhczwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJsYWNrIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZSBtdC0yXCI+XG4gICAgICAgICAgICAgICAgICB7ZGF0YUFmbHVlbmNpYS5yZXN1bWVuLnRvdGFsX2JhbmlzdGFzfVxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+ZW4ge2RhdGFBZmx1ZW5jaWEucmFuZ28uZGlhc30gZMOtYXM8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gcC01IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdGV4dC1zbGF0ZS00MDBcIj5SZWNhdWRhY2nDs24gVGFxdWlsbGE8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ibGFjayB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCBtdC0yXCI+XG4gICAgICAgICAgICAgICAgICBCcy4ge2RhdGFBZmx1ZW5jaWEucmVzdW1lbi50b3RhbF9yZWNhdWRhZG9fYnMudG9GaXhlZCgyKX1cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPkluZ3Jlc28gcG9yIHZlbnRhIGRlIGJvbGV0b3M8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gcC01IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdGV4dC1zbGF0ZS00MDBcIj5Qcm9tZWRpbyBEaWFyaW88L3NwYW4+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ibGFjayB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGUgbXQtMlwiPlxuICAgICAgICAgICAgICAgICAge2RhdGFBZmx1ZW5jaWEucmVzdW1lbi5wcm9tZWRpb19kaWFyaW9fYmFuaXN0YXN9XG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5wZXJzb25hcyBwb3Igam9ybmFkYTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLVsjMjQzMDNGXSBwLTUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIHNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0ZXh0LXNsYXRlLTQwMFwiPkhvcmFyaW8gUGljbzwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtaW5kaWdvLTYwMCBkYXJrOnRleHQtaW5kaWdvLTQwMCBtdC0yXCI+XG4gICAgICAgICAgICAgICAgICB7ZGF0YUFmbHVlbmNpYS5yZXN1bWVuLmhvcmFfcGljb31cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgICAgICAge2RhdGFBZmx1ZW5jaWEucmVzdW1lbi5wZXJzb25hc19ob3JhX3BpY299IHBlcnNvbmFzIHJlZ2lzdHJhZGFzXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogR3LDoWZpY2EgZGUgZGlzdHJpYnVjacOzbiBob3JhcmlhIGRlIGFmbHVlbmNpYSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gcC02IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGUgbWItMVwiPlxuICAgICAgICAgICAgICAgIEN1cnZhIGRlIEFmbHVlbmNpYSBwb3IgSG9yYXJpbyBkZWwgRMOtYVxuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG1iLTRcIj5cbiAgICAgICAgICAgICAgICBQZXJtaXRlIGNvcnJlbGFjaW9uYXIgZWwgZmx1am8gZGUgcGVyc29uYXMgY29uIGluY3JlbWVudG9zIGRlIHR1cmJpZGV6IHkgZGVtYW5kYSBkZSBkZXNpbmZlY3RhbnRlXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTY0XCI+XG4gICAgICAgICAgICAgICAgPFJlc3BvbnNpdmVDb250YWluZXIgd2lkdGg9XCIxMDAlXCIgaGVpZ2h0PVwiMTAwJVwiPlxuICAgICAgICAgICAgICAgICAgPEJhckNoYXJ0IGRhdGE9e2RhdGFBZmx1ZW5jaWEuZGlzdHJpYnVjaW9uX3Bvcl9ob3JhfT5cbiAgICAgICAgICAgICAgICAgICAgPENhcnRlc2lhbkdyaWQgc3Ryb2tlRGFzaGFycmF5PVwiMyAzXCIgb3BhY2l0eT17MC4yfSAvPlxuICAgICAgICAgICAgICAgICAgICA8WEF4aXMgZGF0YUtleT1cImhvcmFcIiB0aWNrPXt7IGZvbnRTaXplOiAxMCB9fSAvPlxuICAgICAgICAgICAgICAgICAgICA8WUF4aXMgdGljaz17eyBmb250U2l6ZTogMTAgfX0gLz5cbiAgICAgICAgICAgICAgICAgICAgPFRvb2x0aXBcbiAgICAgICAgICAgICAgICAgICAgICBjb250ZW50U3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogJyMxRTI5M0InLFxuICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnOHB4JyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlcjogJ25vbmUnLFxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICcjZmZmJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiAnMTFweCcsXG4gICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPEJhciBkYXRhS2V5PVwicGVyc29uYXNcIiBmaWxsPVwiIzNCODJGNlwiIG5hbWU9XCJCYcOxaXN0YXMgaW5ncmVzYWRvc1wiIHJhZGl1cz17WzYsIDYsIDAsIDBdfSAvPlxuICAgICAgICAgICAgICAgICAgPC9CYXJDaGFydD5cbiAgICAgICAgICAgICAgICA8L1Jlc3BvbnNpdmVDb250YWluZXI+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl19