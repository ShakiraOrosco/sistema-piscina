import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Authentication/TwoFactor.jsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { useLocation, useNavigate, Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=41a64c35";
import api from "/src/services/api.js";
import { useAuth } from "/src/context/AuthContext.jsx";
var _jsxFileName = "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Authentication/TwoFactor.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=41a64c35";
var _s = $RefreshSig$();
export default function TwoFactor() {
	_s();
	const { updateSession, showError } = useAuth();
	const location = useLocation();
	const navigate = useNavigate();
	const challenge = location.state?.challenge;
	if (!challenge) {
		return /* @__PURE__ */ _jsxDEV(Navigate, {
			to: "/auth/login",
			replace: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 13,
			columnNumber: 12
		}, this);
	}
	const submitTwoFactor = async (event) => {
		event.preventDefault();
		try {
			const form = new FormData(event.currentTarget);
			const { data } = await api.post("/auth/verify-2fa", {
				desafio: challenge.desafio,
				codigo: form.get("codigo")
			});
			const authenticatedSession = {
				...data,
				usuario: challenge.usuario
			};
			updateSession(authenticatedSession);
			navigate(data.must_change_password ? "/auth/change-password" : "/dashboard");
		} catch (requestError) {
			showError(requestError);
		}
	};
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "login-shell single",
		children: /* @__PURE__ */ _jsxDEV("section", {
			className: "login-card",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "brand login-brand",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "brand-mark",
					children: "PA"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 37,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Playa Azul" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("small", { children: "Control center" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 40,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 38,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 36,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("form", {
				className: "form",
				onSubmit: submitTwoFactor,
				children: [
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "eyebrow",
							children: "VERIFICACIÓN DE SEGURIDAD"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 45,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", { children: "Confirma tu acceso" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "muted",
							children: [
								"Enviamos un código de 6 dígitos a ",
								challenge?.correo_mascarado || "tu correo",
								"."
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 47,
							columnNumber: 13
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("label", { children: ["Código de verificación", /* @__PURE__ */ _jsxDEV("input", {
						name: "codigo",
						inputMode: "numeric",
						pattern: "[0-9]{6}",
						maxLength: "6",
						autoComplete: "one-time-code",
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						className: "primary",
						type: "submit",
						children: ["Verificar código ", /* @__PURE__ */ _jsxDEV("span", { children: "→" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 53,
							columnNumber: 70
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 53,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						className: "secondary",
						type: "button",
						onClick: () => navigate("/auth/login"),
						children: "Volver al inicio"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 35,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 34,
		columnNumber: 5
	}, this);
}
_s(TwoFactor, "YC/86VJISCrVxHk+IIK3sgG4wo8=", false, function() {
	return [
		useAuth,
		useLocation,
		useNavigate
	];
});
_c = TwoFactor;
var _c;
$RefreshReg$(_c, "TwoFactor");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Authentication/TwoFactor.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Authentication/TwoFactor.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Authentication/TwoFactor.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Authentication/TwoFactor.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhLGFBQWEsZ0JBQWdCO0FBQ25ELE9BQU8sU0FBUztBQUNoQixTQUFTLGVBQWU7Ozs7QUFFeEIsZUFBZSxTQUFTLFlBQVk7O0NBQ2xDLE1BQU0sRUFBRSxlQUFlLGNBQWMsUUFBUTtDQUM3QyxNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLFdBQVcsWUFBWTtDQUU3QixNQUFNLFlBQVksU0FBUyxPQUFPO0NBRWxDLElBQUksQ0FBQyxXQUFXO0VBQ2QsT0FBTyx3QkFBQyxVQUFEO0dBQVUsSUFBRztHQUFjO0VBQVM7Ozs7O0NBQzdDO0NBRUEsTUFBTSxrQkFBa0IsT0FBTyxVQUFVO0VBQ3ZDLE1BQU0sZUFBZTtFQUNyQixJQUFJO0dBQ0YsTUFBTSxPQUFPLElBQUksU0FBUyxNQUFNLGFBQWE7R0FDN0MsTUFBTSxFQUFFLFNBQVMsTUFBTSxJQUFJLEtBQUssb0JBQW9CO0lBQ2xELFNBQVMsVUFBVTtJQUNuQixRQUFRLEtBQUssSUFBSSxRQUFRO0dBQzNCLENBQUM7R0FFRCxNQUFNLHVCQUF1QjtJQUFFLEdBQUc7SUFBTSxTQUFTLFVBQVU7R0FBUTtHQUNuRSxjQUFjLG9CQUFvQjtHQUNsQyxTQUFTLEtBQUssdUJBQXVCLDBCQUEwQixZQUFZO0VBQzdFLFNBQVMsY0FBYztHQUNyQixVQUFVLFlBQVk7RUFDeEI7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsUUFBRDtFQUFNLFdBQVU7WUFDZCx3QkFBQyxXQUFEO0dBQVMsV0FBVTthQUFuQixDQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFhO0lBQVE7Ozs7Y0FDckMsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFVBQUQsWUFBUSxhQUFrQjs7OztjQUMxQix3QkFBQyxTQUFELFlBQU8saUJBQXFCOzs7O1lBQ3pCOzs7O1lBQ0Y7Ozs7O2FBQ0wsd0JBQUMsUUFBRDtJQUFNLFdBQVU7SUFBTyxVQUFVO2NBQWpDO0tBQ0Usd0JBQUMsT0FBRDtNQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFVO01BQStCOzs7OztNQUN6RCx3QkFBQyxNQUFELFlBQUkscUJBQXNCOzs7OztNQUMxQix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBYjtRQUFxQjtRQUFtQyxXQUFXLG9CQUFvQjtRQUFZO09BQUk7Ozs7OztLQUNwRzs7Ozs7S0FDTCx3QkFBQyxTQUFELGFBQU8sMEJBRUwsd0JBQUMsU0FBRDtNQUFPLE1BQUs7TUFBUyxXQUFVO01BQVUsU0FBUTtNQUFXLFdBQVU7TUFBSSxjQUFhO01BQWdCO0tBQVU7Ozs7YUFDNUc7Ozs7O0tBQ1Asd0JBQUMsVUFBRDtNQUFRLFdBQVU7TUFBVSxNQUFLO2dCQUFqQyxDQUEwQyxxQkFBaUIsd0JBQUMsUUFBRCxZQUFNLElBQU87Ozs7Y0FBUzs7Ozs7O0tBQ2pGLHdCQUFDLFVBQUQ7TUFBUSxXQUFVO01BQVksTUFBSztNQUFTLGVBQWUsU0FBUyxhQUFhO2dCQUFHO0tBQXdCOzs7OztJQUN4Rzs7Ozs7V0FDQzs7Ozs7O0NBQ0w7Ozs7O0FBRVYiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiVHdvRmFjdG9yLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VMb2NhdGlvbiwgdXNlTmF2aWdhdGUsIE5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCBhcGkgZnJvbSAnLi4vLi4vc2VydmljZXMvYXBpJ1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uL2NvbnRleHQvQXV0aENvbnRleHQnXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFR3b0ZhY3RvcigpIHtcbiAgY29uc3QgeyB1cGRhdGVTZXNzaW9uLCBzaG93RXJyb3IgfSA9IHVzZUF1dGgoKVxuICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKClcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXG4gIFxuICBjb25zdCBjaGFsbGVuZ2UgPSBsb2NhdGlvbi5zdGF0ZT8uY2hhbGxlbmdlXG5cbiAgaWYgKCFjaGFsbGVuZ2UpIHtcbiAgICByZXR1cm4gPE5hdmlnYXRlIHRvPVwiL2F1dGgvbG9naW5cIiByZXBsYWNlIC8+XG4gIH1cblxuICBjb25zdCBzdWJtaXRUd29GYWN0b3IgPSBhc3luYyAoZXZlbnQpID0+IHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGZvcm0gPSBuZXcgRm9ybURhdGEoZXZlbnQuY3VycmVudFRhcmdldClcbiAgICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXBpLnBvc3QoJy9hdXRoL3ZlcmlmeS0yZmEnLCB7XG4gICAgICAgIGRlc2FmaW86IGNoYWxsZW5nZS5kZXNhZmlvLFxuICAgICAgICBjb2RpZ286IGZvcm0uZ2V0KCdjb2RpZ28nKSxcbiAgICAgIH0pXG4gICAgICBcbiAgICAgIGNvbnN0IGF1dGhlbnRpY2F0ZWRTZXNzaW9uID0geyAuLi5kYXRhLCB1c3VhcmlvOiBjaGFsbGVuZ2UudXN1YXJpbyB9XG4gICAgICB1cGRhdGVTZXNzaW9uKGF1dGhlbnRpY2F0ZWRTZXNzaW9uKVxuICAgICAgbmF2aWdhdGUoZGF0YS5tdXN0X2NoYW5nZV9wYXNzd29yZCA/ICcvYXV0aC9jaGFuZ2UtcGFzc3dvcmQnIDogJy9kYXNoYm9hcmQnKVxuICAgIH0gY2F0Y2ggKHJlcXVlc3RFcnJvcikge1xuICAgICAgc2hvd0Vycm9yKHJlcXVlc3RFcnJvcilcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxtYWluIGNsYXNzTmFtZT1cImxvZ2luLXNoZWxsIHNpbmdsZVwiPlxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwibG9naW4tY2FyZFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJyYW5kIGxvZ2luLWJyYW5kXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYnJhbmQtbWFya1wiPlBBPC9zcGFuPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8c3Ryb25nPlBsYXlhIEF6dWw8L3N0cm9uZz5cbiAgICAgICAgICAgIDxzbWFsbD5Db250cm9sIGNlbnRlcjwvc21hbGw+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJmb3JtXCIgb25TdWJtaXQ9e3N1Ym1pdFR3b0ZhY3Rvcn0+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImV5ZWJyb3dcIj5WRVJJRklDQUNJw5NOIERFIFNFR1VSSURBRDwvc3Bhbj5cbiAgICAgICAgICAgIDxoMj5Db25maXJtYSB0dSBhY2Nlc288L2gyPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXV0ZWRcIj5FbnZpYW1vcyB1biBjw7NkaWdvIGRlIDYgZMOtZ2l0b3MgYSB7Y2hhbGxlbmdlPy5jb3JyZW9fbWFzY2FyYWRvIHx8ICd0dSBjb3JyZW8nfS48L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGxhYmVsPlxuICAgICAgICAgICAgQ8OzZGlnbyBkZSB2ZXJpZmljYWNpw7NuXG4gICAgICAgICAgICA8aW5wdXQgbmFtZT1cImNvZGlnb1wiIGlucHV0TW9kZT1cIm51bWVyaWNcIiBwYXR0ZXJuPVwiWzAtOV17Nn1cIiBtYXhMZW5ndGg9XCI2XCIgYXV0b0NvbXBsZXRlPVwib25lLXRpbWUtY29kZVwiIHJlcXVpcmVkIC8+XG4gICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInByaW1hcnlcIiB0eXBlPVwic3VibWl0XCI+VmVyaWZpY2FyIGPDs2RpZ28gPHNwYW4+4oaSPC9zcGFuPjwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwic2Vjb25kYXJ5XCIgdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvYXV0aC9sb2dpbicpfT5Wb2x2ZXIgYWwgaW5pY2lvPC9idXR0b24+XG4gICAgICAgIDwvZm9ybT5cbiAgICAgIDwvc2VjdGlvbj5cbiAgICA8L21haW4+XG4gIClcbn1cbiJdfQ==