import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/context/AuthContext.jsx");const createContext = __vite__cjsImport0_react["createContext"]; const useContext = __vite__cjsImport0_react["useContext"]; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=41a64c35";
var _jsxFileName = "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/context/AuthContext.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=41a64c35";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const AuthContext = createContext();
_c = AuthContext;
export function useAuth() {
	_s();
	return useContext(AuthContext);
}
_s(useAuth, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
export function AuthProvider({ children }) {
	_s2();
	const [session, setSession] = useState(() => {
		try {
			return JSON.parse(localStorage.getItem("piscina_session"));
		} catch {
			return null;
		}
	});
	const [error, setError] = useState("");
	const [message, setMessage] = useState("");
	const showMessage = useCallback((text) => {
		setMessage(text);
		setError("");
		window.setTimeout(() => setMessage(""), 4e3);
	}, []);
	const showError = useCallback((errorMsgOrObj) => {
		const text = typeof errorMsgOrObj === "string" ? errorMsgOrObj : errorMsgOrObj?.response?.data?.detail || "No se pudo completar la operación";
		setError(text);
		setMessage("");
		window.setTimeout(() => setError(""), 5e3);
	}, []);
	const authConfig = () => ({ headers: { Authorization: `Bearer ${session?.access_token}` } });
	const logout = useCallback(() => {
		setSession(null);
		localStorage.removeItem("piscina_session");
		setMessage("");
	}, []);
	const updateSession = useCallback((newSession) => {
		setSession(newSession);
		if (newSession) {
			localStorage.setItem("piscina_session", JSON.stringify(newSession));
		} else {
			localStorage.removeItem("piscina_session");
		}
	}, []);
	const value = {
		session,
		error,
		setError,
		message,
		showMessage,
		showError,
		logout,
		updateSession,
		authConfig
	};
	// Auto-logout after 5 minutes of inactivity
	const resetTimer = useCallback(() => {
		if (session) {
			window.localStorage.setItem("piscina_last_activity", Date.now().toString());
		}
	}, [session]);
	useEffect(() => {
		if (!session) return;
		// Reinicia el timestamp al abrir/recargar la sesión para evitar
		// que un valor viejo en localStorage dispare el logout inmediatamente.
		window.localStorage.setItem("piscina_last_activity", Date.now().toString());
		const events = [
			"mousedown",
			"keydown",
			"scroll",
			"touchstart"
		];
		events.forEach((event) => document.addEventListener(event, resetTimer));
		const interval = setInterval(() => {
			const lastActivity = parseInt(window.localStorage.getItem("piscina_last_activity") || Date.now().toString());
			if (Date.now() - lastActivity > 5 * 60 * 1e3) {
				logout();
				showError("Tu sesión ha expirado por inactividad (5 minutos).");
			}
		}, 1e4);
		return () => {
			events.forEach((event) => document.removeEventListener(event, resetTimer));
			clearInterval(interval);
		};
	}, [
		session,
		logout,
		showError,
		resetTimer
	]);
	return /* @__PURE__ */ _jsxDEV(AuthContext.Provider, {
		value,
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 97,
		columnNumber: 5
	}, this);
}
_s2(AuthProvider, "Wa5Vz4OMizcbNgzZvUOO48ySR6c=");
_c2 = AuthProvider;
var _c, _c2;
$RefreshReg$(_c, "AuthContext");
$RefreshReg$(_c2, "AuthProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/context/AuthContext.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/context/AuthContext.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/context/AuthContext.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/context/AuthContext.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlLFlBQVksVUFBVSxXQUFXLG1CQUFtQjs7OztBQUU1RSxNQUFNLGNBQWMsY0FBYzs7QUFFbEMsT0FBTyxTQUFTLFVBQVU7O0NBQ3hCLE9BQU8sV0FBVyxXQUFXO0FBQy9COztBQUVBLE9BQU8sU0FBUyxhQUFhLEVBQUUsWUFBWTs7Q0FDekMsTUFBTSxDQUFDLFNBQVMsY0FBYyxlQUFlO0VBQzNDLElBQUk7R0FDRixPQUFPLEtBQUssTUFBTSxhQUFhLFFBQVEsaUJBQWlCLENBQUM7RUFDM0QsUUFBUTtHQUNOLE9BQU87RUFDVDtDQUNGLENBQUM7Q0FFRCxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsRUFBRTtDQUV6QyxNQUFNLGNBQWMsYUFBYSxTQUFTO0VBQ3hDLFdBQVcsSUFBSTtFQUNmLFNBQVMsRUFBRTtFQUNYLE9BQU8saUJBQWlCLFdBQVcsRUFBRSxHQUFHLEdBQUk7Q0FDOUMsR0FBRyxDQUFDLENBQUM7Q0FFTCxNQUFNLFlBQVksYUFBYSxrQkFBa0I7RUFDL0MsTUFBTSxPQUFPLE9BQU8sa0JBQWtCLFdBQ2xDLGdCQUNBLGVBQWUsVUFBVSxNQUFNLFVBQVU7RUFDN0MsU0FBUyxJQUFJO0VBQ2IsV0FBVyxFQUFFO0VBQ2IsT0FBTyxpQkFBaUIsU0FBUyxFQUFFLEdBQUcsR0FBSTtDQUM1QyxHQUFHLENBQUMsQ0FBQztDQUVMLE1BQU0sb0JBQW9CLEVBQUUsU0FBUyxFQUFFLGVBQWUsVUFBVSxTQUFTLGVBQWUsRUFBRTtDQUUxRixNQUFNLFNBQVMsa0JBQWtCO0VBQy9CLFdBQVcsSUFBSTtFQUNmLGFBQWEsV0FBVyxpQkFBaUI7RUFDekMsV0FBVyxFQUFFO0NBQ2YsR0FBRyxDQUFDLENBQUM7Q0FFTCxNQUFNLGdCQUFnQixhQUFhLGVBQWU7RUFDaEQsV0FBVyxVQUFVO0VBQ3JCLElBQUksWUFBWTtHQUNkLGFBQWEsUUFBUSxtQkFBbUIsS0FBSyxVQUFVLFVBQVUsQ0FBQztFQUNwRSxPQUFPO0dBQ0wsYUFBYSxXQUFXLGlCQUFpQjtFQUMzQztDQUNGLEdBQUcsQ0FBQyxDQUFDO0NBRUwsTUFBTSxRQUFRO0VBQ1o7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Y7O0NBR0EsTUFBTSxhQUFhLGtCQUFrQjtFQUNuQyxJQUFJLFNBQVM7R0FDWCxPQUFPLGFBQWEsUUFBUSx5QkFBeUIsS0FBSyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUM7RUFDNUU7Q0FDRixHQUFHLENBQUMsT0FBTyxDQUFDO0NBRVosZ0JBQWdCO0VBQ2QsSUFBSSxDQUFDLFNBQVM7OztFQUlkLE9BQU8sYUFBYSxRQUFRLHlCQUF5QixLQUFLLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQztFQUUxRSxNQUFNLFNBQVM7R0FBQztHQUFhO0dBQVc7R0FBVTtFQUFZO0VBQzlELE9BQU8sU0FBUSxVQUFTLFNBQVMsaUJBQWlCLE9BQU8sVUFBVSxDQUFDO0VBRXBFLE1BQU0sV0FBVyxrQkFBa0I7R0FDakMsTUFBTSxlQUFlLFNBQVMsT0FBTyxhQUFhLFFBQVEsdUJBQXVCLEtBQUssS0FBSyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUM7R0FDM0csSUFBSSxLQUFLLElBQUksSUFBSSxlQUFlLElBQUksS0FBSyxLQUFNO0lBQzdDLE9BQU87SUFDUCxVQUFVLG9EQUFvRDtHQUNoRTtFQUNGLEdBQUcsR0FBSztFQUVSLGFBQWE7R0FDWCxPQUFPLFNBQVEsVUFBUyxTQUFTLG9CQUFvQixPQUFPLFVBQVUsQ0FBQztHQUN2RSxjQUFjLFFBQVE7RUFDeEI7Q0FDRixHQUFHO0VBQUM7RUFBUztFQUFRO0VBQVc7Q0FBVSxDQUFDO0NBRTNDLE9BQ0Usd0JBQUMsWUFBWSxVQUFiO0VBQTZCO0VBQzFCO0NBQ21COzs7OztBQUUxQiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBdXRoQ29udGV4dC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlQ29udGV4dCwgdXNlQ29udGV4dCwgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlQ2FsbGJhY2sgfSBmcm9tICdyZWFjdCdcblxuY29uc3QgQXV0aENvbnRleHQgPSBjcmVhdGVDb250ZXh0KClcblxuZXhwb3J0IGZ1bmN0aW9uIHVzZUF1dGgoKSB7XG4gIHJldHVybiB1c2VDb250ZXh0KEF1dGhDb250ZXh0KVxufVxuXG5leHBvcnQgZnVuY3Rpb24gQXV0aFByb3ZpZGVyKHsgY2hpbGRyZW4gfSkge1xuICBjb25zdCBbc2Vzc2lvbiwgc2V0U2Vzc2lvbl0gPSB1c2VTdGF0ZSgoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdwaXNjaW5hX3Nlc3Npb24nKSlcbiAgICB9IGNhdGNoIHtcbiAgICAgIHJldHVybiBudWxsXG4gICAgfVxuICB9KVxuICBcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUoJycpXG5cbiAgY29uc3Qgc2hvd01lc3NhZ2UgPSB1c2VDYWxsYmFjaygodGV4dCkgPT4ge1xuICAgIHNldE1lc3NhZ2UodGV4dClcbiAgICBzZXRFcnJvcignJylcbiAgICB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiBzZXRNZXNzYWdlKCcnKSwgNDAwMClcbiAgfSwgW10pXG5cbiAgY29uc3Qgc2hvd0Vycm9yID0gdXNlQ2FsbGJhY2soKGVycm9yTXNnT3JPYmopID0+IHtcbiAgICBjb25zdCB0ZXh0ID0gdHlwZW9mIGVycm9yTXNnT3JPYmogPT09ICdzdHJpbmcnIFxuICAgICAgPyBlcnJvck1zZ09yT2JqIFxuICAgICAgOiBlcnJvck1zZ09yT2JqPy5yZXNwb25zZT8uZGF0YT8uZGV0YWlsIHx8ICdObyBzZSBwdWRvIGNvbXBsZXRhciBsYSBvcGVyYWNpw7NuJ1xuICAgIHNldEVycm9yKHRleHQpXG4gICAgc2V0TWVzc2FnZSgnJylcbiAgICB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiBzZXRFcnJvcignJyksIDUwMDApXG4gIH0sIFtdKVxuXG4gIGNvbnN0IGF1dGhDb25maWcgPSAoKSA9PiAoeyBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtzZXNzaW9uPy5hY2Nlc3NfdG9rZW59YCB9IH0pXG5cbiAgY29uc3QgbG9nb3V0ID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIHNldFNlc3Npb24obnVsbClcbiAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgncGlzY2luYV9zZXNzaW9uJylcbiAgICBzZXRNZXNzYWdlKCcnKVxuICB9LCBbXSlcblxuICBjb25zdCB1cGRhdGVTZXNzaW9uID0gdXNlQ2FsbGJhY2soKG5ld1Nlc3Npb24pID0+IHtcbiAgICBzZXRTZXNzaW9uKG5ld1Nlc3Npb24pXG4gICAgaWYgKG5ld1Nlc3Npb24pIHtcbiAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdwaXNjaW5hX3Nlc3Npb24nLCBKU09OLnN0cmluZ2lmeShuZXdTZXNzaW9uKSlcbiAgICB9IGVsc2Uge1xuICAgICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oJ3Bpc2NpbmFfc2Vzc2lvbicpXG4gICAgfVxuICB9LCBbXSlcblxuICBjb25zdCB2YWx1ZSA9IHtcbiAgICBzZXNzaW9uLFxuICAgIGVycm9yLFxuICAgIHNldEVycm9yLFxuICAgIG1lc3NhZ2UsXG4gICAgc2hvd01lc3NhZ2UsXG4gICAgc2hvd0Vycm9yLFxuICAgIGxvZ291dCxcbiAgICB1cGRhdGVTZXNzaW9uLFxuICAgIGF1dGhDb25maWdcbiAgfVxuXG4gIC8vIEF1dG8tbG9nb3V0IGFmdGVyIDUgbWludXRlcyBvZiBpbmFjdGl2aXR5XG4gIGNvbnN0IHJlc2V0VGltZXIgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgaWYgKHNlc3Npb24pIHtcbiAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSgncGlzY2luYV9sYXN0X2FjdGl2aXR5JywgRGF0ZS5ub3coKS50b1N0cmluZygpKVxuICAgIH1cbiAgfSwgW3Nlc3Npb25dKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFzZXNzaW9uKSByZXR1cm5cblxuICAgIC8vIFJlaW5pY2lhIGVsIHRpbWVzdGFtcCBhbCBhYnJpci9yZWNhcmdhciBsYSBzZXNpw7NuIHBhcmEgZXZpdGFyXG4gICAgLy8gcXVlIHVuIHZhbG9yIHZpZWpvIGVuIGxvY2FsU3RvcmFnZSBkaXNwYXJlIGVsIGxvZ291dCBpbm1lZGlhdGFtZW50ZS5cbiAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3Bpc2NpbmFfbGFzdF9hY3Rpdml0eScsIERhdGUubm93KCkudG9TdHJpbmcoKSlcblxuICAgIGNvbnN0IGV2ZW50cyA9IFsnbW91c2Vkb3duJywgJ2tleWRvd24nLCAnc2Nyb2xsJywgJ3RvdWNoc3RhcnQnXVxuICAgIGV2ZW50cy5mb3JFYWNoKGV2ZW50ID0+IGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoZXZlbnQsIHJlc2V0VGltZXIpKVxuXG4gICAgY29uc3QgaW50ZXJ2YWwgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgICBjb25zdCBsYXN0QWN0aXZpdHkgPSBwYXJzZUludCh3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3Bpc2NpbmFfbGFzdF9hY3Rpdml0eScpIHx8IERhdGUubm93KCkudG9TdHJpbmcoKSlcbiAgICAgIGlmIChEYXRlLm5vdygpIC0gbGFzdEFjdGl2aXR5ID4gNSAqIDYwICogMTAwMCkge1xuICAgICAgICBsb2dvdXQoKVxuICAgICAgICBzaG93RXJyb3IoJ1R1IHNlc2nDs24gaGEgZXhwaXJhZG8gcG9yIGluYWN0aXZpZGFkICg1IG1pbnV0b3MpLicpXG4gICAgICB9XG4gICAgfSwgMTAwMDApIC8vIENoZWNrIGV2ZXJ5IDEwIHNlY29uZHNcblxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBldmVudHMuZm9yRWFjaChldmVudCA9PiBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKGV2ZW50LCByZXNldFRpbWVyKSlcbiAgICAgIGNsZWFySW50ZXJ2YWwoaW50ZXJ2YWwpXG4gICAgfVxuICB9LCBbc2Vzc2lvbiwgbG9nb3V0LCBzaG93RXJyb3IsIHJlc2V0VGltZXJdKVxuXG4gIHJldHVybiAoXG4gICAgPEF1dGhDb250ZXh0LlByb3ZpZGVyIHZhbHVlPXt2YWx1ZX0+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9BdXRoQ29udGV4dC5Qcm92aWRlcj5cbiAgKVxufVxuIl19