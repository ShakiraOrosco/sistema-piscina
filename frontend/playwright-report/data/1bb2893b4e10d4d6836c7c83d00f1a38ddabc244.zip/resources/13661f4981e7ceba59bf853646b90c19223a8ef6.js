import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");const _jsxDEV = __vite__cjsImport16_react_jsxDevRuntime["jsxDEV"];import { Routes, Route, Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=41a64c35";
import { useAuth } from "/src/context/AuthContext.jsx";
import DefaultLayout from "/src/layout/DefaultLayout.jsx";
import AuthLayout from "/src/layout/AuthLayout.jsx";
import SignIn from "/src/pages/Authentication/SignIn.jsx";
import TwoFactor from "/src/pages/Authentication/TwoFactor.jsx";
import ChangePassword from "/src/pages/Authentication/ChangePassword.jsx";
import Dashboard from "/src/pages/Dashboard/index.jsx";
import Profile from "/src/pages/Profile/index.jsx";
import UsersPage from "/src/pages/Users/index.jsx";
import CajaPage from "/src/pages/Caja/index.jsx";
import InventarioPage from "/src/pages/Inventario/index.jsx";
import AuditoriaPage from "/src/pages/Auditoria/index.jsx";
import ReportesPage from "/src/pages/Reportes/index.jsx";
import NotFound from "/src/pages/NotFound.jsx";
import "/src/App.css";
var _jsxFileName = "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/App.jsx";
import __vite__cjsImport16_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=41a64c35";
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$();
function IndexRedirect() {
	_s();
	const { session } = useAuth();
	if (session?.usuario?.sigla_rol === "CAJ") {
		return /* @__PURE__ */ _jsxDEV(Navigate, {
			to: "/caja",
			replace: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 12
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV(Navigate, {
		to: "/dashboard",
		replace: true
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 23,
		columnNumber: 10
	}, this);
}
_s(IndexRedirect, "PfssbkmwXv8OKztt4QwYrctCukQ=", false, function() {
	return [useAuth];
});
_c = IndexRedirect;
function ProtectedDashboard() {
	_s2();
	const { session } = useAuth();
	if (session?.usuario?.sigla_rol === "CAJ") {
		return /* @__PURE__ */ _jsxDEV(Navigate, {
			to: "/caja",
			replace: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 29,
			columnNumber: 12
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV(Dashboard, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 31,
		columnNumber: 10
	}, this);
}
_s2(ProtectedDashboard, "PfssbkmwXv8OKztt4QwYrctCukQ=", false, function() {
	return [useAuth];
});
_c2 = ProtectedDashboard;
function ProtectedCaja() {
	_s3();
	const { session } = useAuth();
	if (session?.usuario?.sigla_rol === "OPE") {
		return /* @__PURE__ */ _jsxDEV(Navigate, {
			to: "/dashboard",
			replace: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 37,
			columnNumber: 12
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV(CajaPage, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 39,
		columnNumber: 10
	}, this);
}
_s3(ProtectedCaja, "PfssbkmwXv8OKztt4QwYrctCukQ=", false, function() {
	return [useAuth];
});
_c3 = ProtectedCaja;
function ProtectedInventario() {
	_s4();
	const { session } = useAuth();
	if (session?.usuario?.sigla_rol === "CAJ") {
		return /* @__PURE__ */ _jsxDEV(Navigate, {
			to: "/caja",
			replace: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 45,
			columnNumber: 12
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV(InventarioPage, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 47,
		columnNumber: 10
	}, this);
}
_s4(ProtectedInventario, "PfssbkmwXv8OKztt4QwYrctCukQ=", false, function() {
	return [useAuth];
});
_c4 = ProtectedInventario;
function ProtectedReportes() {
	_s5();
	const { session } = useAuth();
	if (session?.usuario?.sigla_rol === "CAJ") {
		return /* @__PURE__ */ _jsxDEV(Navigate, {
			to: "/caja",
			replace: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 53,
			columnNumber: 12
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV(ReportesPage, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 55,
		columnNumber: 10
	}, this);
}
_s5(ProtectedReportes, "PfssbkmwXv8OKztt4QwYrctCukQ=", false, function() {
	return [useAuth];
});
_c5 = ProtectedReportes;
function App() {
	return /* @__PURE__ */ _jsxDEV(Routes, { children: [
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/auth",
			element: /* @__PURE__ */ _jsxDEV(AuthLayout, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 36
			}, this),
			children: [
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "login",
					element: /* @__PURE__ */ _jsxDEV(SignIn, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 38
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "verify-2fa",
					element: /* @__PURE__ */ _jsxDEV(TwoFactor, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 43
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "change-password",
					element: /* @__PURE__ */ _jsxDEV(ChangePassword, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 64,
						columnNumber: 48
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 61,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			element: /* @__PURE__ */ _jsxDEV(DefaultLayout, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 67,
				columnNumber: 23
			}, this),
			children: [
				/* @__PURE__ */ _jsxDEV(Route, {
					index: true,
					element: /* @__PURE__ */ _jsxDEV(IndexRedirect, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 31
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 68,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "/dashboard",
					element: /* @__PURE__ */ _jsxDEV(ProtectedDashboard, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 43
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 69,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "/profile",
					element: /* @__PURE__ */ _jsxDEV(Profile, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 41
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 70,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "/users",
					element: /* @__PURE__ */ _jsxDEV(UsersPage, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 39
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "/caja",
					element: /* @__PURE__ */ _jsxDEV(ProtectedCaja, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 38
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 72,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "/inventario",
					element: /* @__PURE__ */ _jsxDEV(ProtectedInventario, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 73,
						columnNumber: 44
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "/reportes",
					element: /* @__PURE__ */ _jsxDEV(ProtectedReportes, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 74,
						columnNumber: 42
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 74,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "/auditoria",
					element: /* @__PURE__ */ _jsxDEV(AuditoriaPage, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 75,
						columnNumber: 43
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 75,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 67,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "*",
			element: /* @__PURE__ */ _jsxDEV(NotFound, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 32
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 78,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 60,
		columnNumber: 5
	}, this);
}
_c6 = App;
export default App;
var _c, _c2, _c3, _c4, _c5, _c6;
$RefreshReg$(_c, "IndexRedirect");
$RefreshReg$(_c2, "ProtectedDashboard");
$RefreshReg$(_c3, "ProtectedCaja");
$RefreshReg$(_c4, "ProtectedInventario");
$RefreshReg$(_c5, "ProtectedReportes");
$RefreshReg$(_c6, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/App.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxRQUFRLE9BQU8sZ0JBQWdCO0FBQ3hDLFNBQVMsZUFBZTtBQUN4QixPQUFPLG1CQUFtQjtBQUMxQixPQUFPLGdCQUFnQjtBQUN2QixPQUFPLFlBQVk7QUFDbkIsT0FBTyxlQUFlO0FBQ3RCLE9BQU8sb0JBQW9CO0FBQzNCLE9BQU8sZUFBZTtBQUN0QixPQUFPLGFBQWE7QUFDcEIsT0FBTyxlQUFlO0FBQ3RCLE9BQU8sY0FBYztBQUNyQixPQUFPLG9CQUFvQjtBQUMzQixPQUFPLG1CQUFtQjtBQUMxQixPQUFPLGtCQUFrQjtBQUN6QixPQUFPLGNBQWM7QUFDckIsT0FBTzs7OztBQUVQLFNBQVMsZ0JBQWdCOztDQUN2QixNQUFNLEVBQUUsWUFBWSxRQUFRO0NBQzVCLElBQUksU0FBUyxTQUFTLGNBQWMsT0FBTztFQUN6QyxPQUFPLHdCQUFDLFVBQUQ7R0FBVSxJQUFHO0dBQVE7RUFBUzs7Ozs7Q0FDdkM7Q0FDQSxPQUFPLHdCQUFDLFVBQUQ7RUFBVSxJQUFHO0VBQWE7Q0FBUzs7Ozs7QUFDNUM7Ozs7O0FBRUEsU0FBUyxxQkFBcUI7O0NBQzVCLE1BQU0sRUFBRSxZQUFZLFFBQVE7Q0FDNUIsSUFBSSxTQUFTLFNBQVMsY0FBYyxPQUFPO0VBQ3pDLE9BQU8sd0JBQUMsVUFBRDtHQUFVLElBQUc7R0FBUTtFQUFTOzs7OztDQUN2QztDQUNBLE9BQU8sd0JBQUMsV0FBRCxDQUFZOzs7OztBQUNyQjs7Ozs7QUFFQSxTQUFTLGdCQUFnQjs7Q0FDdkIsTUFBTSxFQUFFLFlBQVksUUFBUTtDQUM1QixJQUFJLFNBQVMsU0FBUyxjQUFjLE9BQU87RUFDekMsT0FBTyx3QkFBQyxVQUFEO0dBQVUsSUFBRztHQUFhO0VBQVM7Ozs7O0NBQzVDO0NBQ0EsT0FBTyx3QkFBQyxVQUFELENBQVc7Ozs7O0FBQ3BCOzs7OztBQUVBLFNBQVMsc0JBQXNCOztDQUM3QixNQUFNLEVBQUUsWUFBWSxRQUFRO0NBQzVCLElBQUksU0FBUyxTQUFTLGNBQWMsT0FBTztFQUN6QyxPQUFPLHdCQUFDLFVBQUQ7R0FBVSxJQUFHO0dBQVE7RUFBUzs7Ozs7Q0FDdkM7Q0FDQSxPQUFPLHdCQUFDLGdCQUFELENBQWlCOzs7OztBQUMxQjs7Ozs7QUFFQSxTQUFTLG9CQUFvQjs7Q0FDM0IsTUFBTSxFQUFFLFlBQVksUUFBUTtDQUM1QixJQUFJLFNBQVMsU0FBUyxjQUFjLE9BQU87RUFDekMsT0FBTyx3QkFBQyxVQUFEO0dBQVUsSUFBRztHQUFRO0VBQVM7Ozs7O0NBQ3ZDO0NBQ0EsT0FBTyx3QkFBQyxjQUFELENBQWU7Ozs7O0FBQ3hCOzs7OztBQUVBLFNBQVMsTUFBTTtDQUNiLE9BQ0Usd0JBQUMsUUFBRDtFQUNFLHdCQUFDLE9BQUQ7R0FBTyxNQUFLO0dBQVEsU0FBUyx3QkFBQyxZQUFELENBQWE7Ozs7O2FBQTFDO0lBQ0Usd0JBQUMsT0FBRDtLQUFPLE1BQUs7S0FBUSxTQUFTLHdCQUFDLFFBQUQsQ0FBUzs7Ozs7SUFBSTs7Ozs7SUFDMUMsd0JBQUMsT0FBRDtLQUFPLE1BQUs7S0FBYSxTQUFTLHdCQUFDLFdBQUQsQ0FBWTs7Ozs7SUFBSTs7Ozs7SUFDbEQsd0JBQUMsT0FBRDtLQUFPLE1BQUs7S0FBa0IsU0FBUyx3QkFBQyxnQkFBRCxDQUFpQjs7Ozs7SUFBSTs7Ozs7R0FDdkQ7Ozs7OztFQUVQLHdCQUFDLE9BQUQ7R0FBTyxTQUFTLHdCQUFDLGVBQUQsQ0FBZ0I7Ozs7O2FBQWhDO0lBQ0Usd0JBQUMsT0FBRDtLQUFPO0tBQU0sU0FBUyx3QkFBQyxlQUFELENBQWdCOzs7OztJQUFJOzs7OztJQUMxQyx3QkFBQyxPQUFEO0tBQU8sTUFBSztLQUFhLFNBQVMsd0JBQUMsb0JBQUQsQ0FBcUI7Ozs7O0lBQUk7Ozs7O0lBQzNELHdCQUFDLE9BQUQ7S0FBTyxNQUFLO0tBQVcsU0FBUyx3QkFBQyxTQUFELENBQVU7Ozs7O0lBQUk7Ozs7O0lBQzlDLHdCQUFDLE9BQUQ7S0FBTyxNQUFLO0tBQVMsU0FBUyx3QkFBQyxXQUFELENBQVk7Ozs7O0lBQUk7Ozs7O0lBQzlDLHdCQUFDLE9BQUQ7S0FBTyxNQUFLO0tBQVEsU0FBUyx3QkFBQyxlQUFELENBQWdCOzs7OztJQUFJOzs7OztJQUNqRCx3QkFBQyxPQUFEO0tBQU8sTUFBSztLQUFjLFNBQVMsd0JBQUMscUJBQUQsQ0FBc0I7Ozs7O0lBQUk7Ozs7O0lBQzdELHdCQUFDLE9BQUQ7S0FBTyxNQUFLO0tBQVksU0FBUyx3QkFBQyxtQkFBRCxDQUFvQjs7Ozs7SUFBSTs7Ozs7SUFDekQsd0JBQUMsT0FBRDtLQUFPLE1BQUs7S0FBYSxTQUFTLHdCQUFDLGVBQUQsQ0FBZ0I7Ozs7O0lBQUk7Ozs7O0dBQ2pEOzs7Ozs7RUFFUCx3QkFBQyxPQUFEO0dBQU8sTUFBSztHQUFJLFNBQVMsd0JBQUMsVUFBRCxDQUFXOzs7OztFQUFJOzs7OztDQUNsQzs7Ozs7QUFFWjs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUm91dGVzLCBSb3V0ZSwgTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4vY29udGV4dC9BdXRoQ29udGV4dCdcbmltcG9ydCBEZWZhdWx0TGF5b3V0IGZyb20gJy4vbGF5b3V0L0RlZmF1bHRMYXlvdXQnXG5pbXBvcnQgQXV0aExheW91dCBmcm9tICcuL2xheW91dC9BdXRoTGF5b3V0J1xuaW1wb3J0IFNpZ25JbiBmcm9tICcuL3BhZ2VzL0F1dGhlbnRpY2F0aW9uL1NpZ25JbidcbmltcG9ydCBUd29GYWN0b3IgZnJvbSAnLi9wYWdlcy9BdXRoZW50aWNhdGlvbi9Ud29GYWN0b3InXG5pbXBvcnQgQ2hhbmdlUGFzc3dvcmQgZnJvbSAnLi9wYWdlcy9BdXRoZW50aWNhdGlvbi9DaGFuZ2VQYXNzd29yZCdcbmltcG9ydCBEYXNoYm9hcmQgZnJvbSAnLi9wYWdlcy9EYXNoYm9hcmQnXG5pbXBvcnQgUHJvZmlsZSBmcm9tICcuL3BhZ2VzL1Byb2ZpbGUnXG5pbXBvcnQgVXNlcnNQYWdlIGZyb20gJy4vcGFnZXMvVXNlcnMnXG5pbXBvcnQgQ2FqYVBhZ2UgZnJvbSAnLi9wYWdlcy9DYWphJ1xuaW1wb3J0IEludmVudGFyaW9QYWdlIGZyb20gJy4vcGFnZXMvSW52ZW50YXJpbydcbmltcG9ydCBBdWRpdG9yaWFQYWdlIGZyb20gJy4vcGFnZXMvQXVkaXRvcmlhJ1xuaW1wb3J0IFJlcG9ydGVzUGFnZSBmcm9tICcuL3BhZ2VzL1JlcG9ydGVzJ1xuaW1wb3J0IE5vdEZvdW5kIGZyb20gJy4vcGFnZXMvTm90Rm91bmQnXG5pbXBvcnQgJy4vQXBwLmNzcydcblxuZnVuY3Rpb24gSW5kZXhSZWRpcmVjdCgpIHtcbiAgY29uc3QgeyBzZXNzaW9uIH0gPSB1c2VBdXRoKClcbiAgaWYgKHNlc3Npb24/LnVzdWFyaW8/LnNpZ2xhX3JvbCA9PT0gJ0NBSicpIHtcbiAgICByZXR1cm4gPE5hdmlnYXRlIHRvPVwiL2NhamFcIiByZXBsYWNlIC8+XG4gIH1cbiAgcmV0dXJuIDxOYXZpZ2F0ZSB0bz1cIi9kYXNoYm9hcmRcIiByZXBsYWNlIC8+XG59XG5cbmZ1bmN0aW9uIFByb3RlY3RlZERhc2hib2FyZCgpIHtcbiAgY29uc3QgeyBzZXNzaW9uIH0gPSB1c2VBdXRoKClcbiAgaWYgKHNlc3Npb24/LnVzdWFyaW8/LnNpZ2xhX3JvbCA9PT0gJ0NBSicpIHtcbiAgICByZXR1cm4gPE5hdmlnYXRlIHRvPVwiL2NhamFcIiByZXBsYWNlIC8+XG4gIH1cbiAgcmV0dXJuIDxEYXNoYm9hcmQgLz5cbn1cblxuZnVuY3Rpb24gUHJvdGVjdGVkQ2FqYSgpIHtcbiAgY29uc3QgeyBzZXNzaW9uIH0gPSB1c2VBdXRoKClcbiAgaWYgKHNlc3Npb24/LnVzdWFyaW8/LnNpZ2xhX3JvbCA9PT0gJ09QRScpIHtcbiAgICByZXR1cm4gPE5hdmlnYXRlIHRvPVwiL2Rhc2hib2FyZFwiIHJlcGxhY2UgLz5cbiAgfVxuICByZXR1cm4gPENhamFQYWdlIC8+XG59XG5cbmZ1bmN0aW9uIFByb3RlY3RlZEludmVudGFyaW8oKSB7XG4gIGNvbnN0IHsgc2Vzc2lvbiB9ID0gdXNlQXV0aCgpXG4gIGlmIChzZXNzaW9uPy51c3VhcmlvPy5zaWdsYV9yb2wgPT09ICdDQUonKSB7XG4gICAgcmV0dXJuIDxOYXZpZ2F0ZSB0bz1cIi9jYWphXCIgcmVwbGFjZSAvPlxuICB9XG4gIHJldHVybiA8SW52ZW50YXJpb1BhZ2UgLz5cbn1cblxuZnVuY3Rpb24gUHJvdGVjdGVkUmVwb3J0ZXMoKSB7XG4gIGNvbnN0IHsgc2Vzc2lvbiB9ID0gdXNlQXV0aCgpXG4gIGlmIChzZXNzaW9uPy51c3VhcmlvPy5zaWdsYV9yb2wgPT09ICdDQUonKSB7XG4gICAgcmV0dXJuIDxOYXZpZ2F0ZSB0bz1cIi9jYWphXCIgcmVwbGFjZSAvPlxuICB9XG4gIHJldHVybiA8UmVwb3J0ZXNQYWdlIC8+XG59XG5cbmZ1bmN0aW9uIEFwcCgpIHtcbiAgcmV0dXJuIChcbiAgICA8Um91dGVzPlxuICAgICAgPFJvdXRlIHBhdGg9XCIvYXV0aFwiIGVsZW1lbnQ9ezxBdXRoTGF5b3V0IC8+fT5cbiAgICAgICAgPFJvdXRlIHBhdGg9XCJsb2dpblwiIGVsZW1lbnQ9ezxTaWduSW4gLz59IC8+XG4gICAgICAgIDxSb3V0ZSBwYXRoPVwidmVyaWZ5LTJmYVwiIGVsZW1lbnQ9ezxUd29GYWN0b3IgLz59IC8+XG4gICAgICAgIDxSb3V0ZSBwYXRoPVwiY2hhbmdlLXBhc3N3b3JkXCIgZWxlbWVudD17PENoYW5nZVBhc3N3b3JkIC8+fSAvPlxuICAgICAgPC9Sb3V0ZT5cblxuICAgICAgPFJvdXRlIGVsZW1lbnQ9ezxEZWZhdWx0TGF5b3V0IC8+fT5cbiAgICAgICAgPFJvdXRlIGluZGV4IGVsZW1lbnQ9ezxJbmRleFJlZGlyZWN0IC8+fSAvPlxuICAgICAgICA8Um91dGUgcGF0aD1cIi9kYXNoYm9hcmRcIiBlbGVtZW50PXs8UHJvdGVjdGVkRGFzaGJvYXJkIC8+fSAvPlxuICAgICAgICA8Um91dGUgcGF0aD1cIi9wcm9maWxlXCIgZWxlbWVudD17PFByb2ZpbGUgLz59IC8+XG4gICAgICAgIDxSb3V0ZSBwYXRoPVwiL3VzZXJzXCIgZWxlbWVudD17PFVzZXJzUGFnZSAvPn0gLz5cbiAgICAgICAgPFJvdXRlIHBhdGg9XCIvY2FqYVwiIGVsZW1lbnQ9ezxQcm90ZWN0ZWRDYWphIC8+fSAvPlxuICAgICAgICA8Um91dGUgcGF0aD1cIi9pbnZlbnRhcmlvXCIgZWxlbWVudD17PFByb3RlY3RlZEludmVudGFyaW8gLz59IC8+XG4gICAgICAgIDxSb3V0ZSBwYXRoPVwiL3JlcG9ydGVzXCIgZWxlbWVudD17PFByb3RlY3RlZFJlcG9ydGVzIC8+fSAvPlxuICAgICAgICA8Um91dGUgcGF0aD1cIi9hdWRpdG9yaWFcIiBlbGVtZW50PXs8QXVkaXRvcmlhUGFnZSAvPn0gLz5cbiAgICAgIDwvUm91dGU+XG5cbiAgICAgIDxSb3V0ZSBwYXRoPVwiKlwiIGVsZW1lbnQ9ezxOb3RGb3VuZCAvPn0gLz5cbiAgICA8L1JvdXRlcz5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBBcHBcbiJdfQ==