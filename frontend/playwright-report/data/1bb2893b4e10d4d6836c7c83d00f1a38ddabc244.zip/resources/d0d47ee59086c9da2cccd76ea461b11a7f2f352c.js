import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Authentication/SignIn.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=41a64c35";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=41a64c35";
import api from "/src/services/api.js";
import { useAuth } from "/src/context/AuthContext.jsx";
var _jsxFileName = "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Authentication/SignIn.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=41a64c35";
var _s = $RefreshSig$();
export default function SignIn() {
	_s();
	const { updateSession, showError, showMessage } = useAuth();
	const navigate = useNavigate();
	const [showForgotModal, setShowForgotModal] = useState(false);
	const [forgotEmail, setForgotEmail] = useState("");
	const [forgotLoading, setForgotLoading] = useState(false);
	const submitLogin = async (event) => {
		event.preventDefault();
		const form = new FormData(event.currentTarget);
		try {
			const { data } = await api.post("/auth/login", Object.fromEntries(form));
			if (data.requiere_2fa) {
				navigate("/auth/verify-2fa", { state: { challenge: data } });
				return;
			}
			updateSession(data);
			navigate(data.must_change_password ? "/auth/change-password" : "/dashboard");
		} catch (requestError) {
			showError(requestError);
		}
	};
	const handleForgotPassword = async (e) => {
		e.preventDefault();
		if (!forgotEmail) return;
		setForgotLoading(true);
		try {
			const { data } = await api.post("/auth/forgot-password", { correo: forgotEmail });
			showMessage(data.mensaje);
			setShowForgotModal(false);
			setForgotEmail("");
		} catch (requestError) {
			showError(requestError);
		} finally {
			setForgotLoading(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "login-shell",
		children: [/* @__PURE__ */ _jsxDEV("section", {
			className: "login-art",
			children: [
				/* @__PURE__ */ _jsxDEV("span", {
					className: "eyebrow",
					children: "PLAYA AZUL / OPERACIONES"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 50,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h1", { children: "El agua, bajo control." }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 51,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", { children: "Monitoreo inteligente y operación clara para una piscina siempre lista." }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { className: "pool-lines" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 53,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 49,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("section", {
			className: "login-card",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "brand login-brand",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "brand-mark",
						children: "PA"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Playa Azul" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("small", { children: "Control center" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 58,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("form", {
					className: "form",
					onSubmit: submitLogin,
					children: [
						/* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "eyebrow",
								children: "BIENVENIDO DE VUELTA"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 65,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("h2", { children: "Inicia sesión" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 66,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "muted",
								children: "Accede a tu centro de operaciones."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 67,
								columnNumber: 13
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("label", { children: ["Correo", /* @__PURE__ */ _jsxDEV("input", {
							name: "correo",
							type: "email",
							autoComplete: "email",
							required: true
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 71,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 69,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("label", {
							className: "relative",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-between items-center mb-1",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "Contraseña" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 75,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setShowForgotModal(true),
									className: "text-xs text-blue-600 hover:text-blue-700 font-semibold focus:outline-none",
									children: "¿Olvidaste tu contraseña?"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 76,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 74,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								name: "password",
								type: "password",
								autoComplete: "current-password",
								required: true
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 84,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 73,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							className: "primary",
							type: "submit",
							children: ["Entrar al panel ", /* @__PURE__ */ _jsxDEV("span", { children: "→" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 86,
								columnNumber: 69
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 86,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 9
				}, this),
				showForgotModal && /* @__PURE__ */ _jsxDEV("div", {
					className: "fixed inset-0 z-[99999] flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 relative",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between pb-3 border-b border-slate-100 mb-4",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-lg font-bold text-slate-800",
								children: "Recuperar Contraseña"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 95,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-500 mt-0.5",
								children: "Ingresa tu correo para enviarte una contraseña temporal"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 96,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 94,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setShowForgotModal(false),
								className: "w-8 h-8 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center transition-all",
								children: "✕"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 98,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 93,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("form", {
							onSubmit: handleForgotPassword,
							className: "space-y-4",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1",
								children: "Correo Registrado"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 109,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "email",
								required: true,
								value: forgotEmail,
								onChange: (e) => setForgotEmail(e.target.value),
								placeholder: "ejemplo@piscina.com",
								className: "w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 112,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 108,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3 pt-2",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setShowForgotModal(false),
									className: "w-1/3 py-2.5 rounded-xl border border-slate-200 text-slate-600 font-bold text-sm hover:bg-slate-100 transition-all",
									children: "Cancelar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 123,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "submit",
									disabled: forgotLoading || !forgotEmail,
									className: "w-2/3 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold text-sm shadow-md shadow-blue-500/20 transition-all",
									children: forgotLoading ? "Enviando..." : "Enviar Contraseña"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 130,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 122,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 107,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 92,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 91,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 55,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 48,
		columnNumber: 5
	}, this);
}
_s(SignIn, "LUAuZn8ioBvTj3AQ8vpm5L+MzSg=", false, function() {
	return [useAuth, useNavigate];
});
_c = SignIn;
var _c;
$RefreshReg$(_c, "SignIn");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Authentication/SignIn.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Authentication/SignIn.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Authentication/SignIn.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Authentication/SignIn.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxtQkFBbUI7QUFDNUIsT0FBTyxTQUFTO0FBQ2hCLFNBQVMsZUFBZTs7OztBQUV4QixlQUFlLFNBQVMsU0FBUzs7Q0FDL0IsTUFBTSxFQUFFLGVBQWUsV0FBVyxnQkFBZ0IsUUFBUTtDQUMxRCxNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLEtBQUs7Q0FDNUQsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsRUFBRTtDQUNqRCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxLQUFLO0NBRXhELE1BQU0sY0FBYyxPQUFPLFVBQVU7RUFDbkMsTUFBTSxlQUFlO0VBQ3JCLE1BQU0sT0FBTyxJQUFJLFNBQVMsTUFBTSxhQUFhO0VBQzdDLElBQUk7R0FDRixNQUFNLEVBQUUsU0FBUyxNQUFNLElBQUksS0FBSyxlQUFlLE9BQU8sWUFBWSxJQUFJLENBQUM7R0FFdkUsSUFBSSxLQUFLLGNBQWM7SUFDckIsU0FBUyxvQkFBb0IsRUFBRSxPQUFPLEVBQUUsV0FBVyxLQUFLLEVBQUUsQ0FBQztJQUMzRDtHQUNGO0dBRUEsY0FBYyxJQUFJO0dBQ2xCLFNBQVMsS0FBSyx1QkFBdUIsMEJBQTBCLFlBQVk7RUFDN0UsU0FBUyxjQUFjO0dBQ3JCLFVBQVUsWUFBWTtFQUN4QjtDQUNGO0NBRUEsTUFBTSx1QkFBdUIsT0FBTyxNQUFNO0VBQ3hDLEVBQUUsZUFBZTtFQUNqQixJQUFJLENBQUMsYUFBYTtFQUNsQixpQkFBaUIsSUFBSTtFQUNyQixJQUFJO0dBQ0YsTUFBTSxFQUFFLFNBQVMsTUFBTSxJQUFJLEtBQUsseUJBQXlCLEVBQUUsUUFBUSxZQUFZLENBQUM7R0FDaEYsWUFBWSxLQUFLLE9BQU87R0FDeEIsbUJBQW1CLEtBQUs7R0FDeEIsZUFBZSxFQUFFO0VBQ25CLFNBQVMsY0FBYztHQUNyQixVQUFVLFlBQVk7RUFDeEIsVUFBVTtHQUNSLGlCQUFpQixLQUFLO0VBQ3hCO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLFFBQUQ7RUFBTSxXQUFVO1lBQWhCLENBQ0Usd0JBQUMsV0FBRDtHQUFTLFdBQVU7YUFBbkI7SUFDRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFVO0lBQThCOzs7OztJQUN4RCx3QkFBQyxNQUFELFlBQUkseUJBQTBCOzs7OztJQUM5Qix3QkFBQyxLQUFELFlBQUcsMEVBQTBFOzs7OztJQUM3RSx3QkFBQyxPQUFELEVBQUssV0FBVSxhQUFjOzs7OztHQUN0Qjs7Ozs7WUFDVCx3QkFBQyxXQUFEO0dBQVMsV0FBVTthQUFuQjtJQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBYTtLQUFROzs7O2VBQ3JDLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxVQUFELFlBQVEsYUFBa0I7Ozs7ZUFDMUIsd0JBQUMsU0FBRCxZQUFPLGlCQUFxQjs7OzthQUN6Qjs7OzthQUNGOzs7Ozs7SUFDTCx3QkFBQyxRQUFEO0tBQU0sV0FBVTtLQUFPLFVBQVU7ZUFBakM7TUFDRSx3QkFBQyxPQUFEO09BQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQVU7T0FBMEI7Ozs7O09BQ3BELHdCQUFDLE1BQUQsWUFBSSxnQkFBaUI7Ozs7O09BQ3JCLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFRO09BQXFDOzs7OztNQUN2RDs7Ozs7TUFDTCx3QkFBQyxTQUFELGFBQU8sVUFFTCx3QkFBQyxTQUFEO09BQU8sTUFBSztPQUFTLE1BQUs7T0FBUSxjQUFhO09BQVE7TUFBVTs7OztjQUM1RDs7Ozs7TUFDUCx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBakIsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7OztrQkFDdEIsd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlLG1CQUFtQixJQUFJO1NBQ3RDLFdBQVU7bUJBQ1g7UUFFTzs7OztnQkFDTDs7Ozs7aUJBQ0wsd0JBQUMsU0FBRDtRQUFPLE1BQUs7UUFBVyxNQUFLO1FBQVcsY0FBYTtRQUFtQjtPQUFVOzs7O2VBQzVFOzs7Ozs7TUFDUCx3QkFBQyxVQUFEO09BQVEsV0FBVTtPQUFVLE1BQUs7aUJBQWpDLENBQTBDLG9CQUFnQix3QkFBQyxRQUFELFlBQU0sSUFBTzs7OztlQUFTOzs7Ozs7S0FDNUU7Ozs7OztJQUdMLG1CQUNDLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBbUM7T0FBd0I7Ozs7aUJBQ3pFLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFnQztPQUEwRDs7OztlQUNwRzs7OztpQkFDTCx3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLGVBQWUsbUJBQW1CLEtBQUs7UUFDdkMsV0FBVTtrQkFDWDtPQUVPOzs7O2VBQ0w7Ozs7O2dCQUVMLHdCQUFDLFFBQUQ7T0FBTSxVQUFVO09BQXNCLFdBQVU7aUJBQWhELENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUF1RTtPQUVqRjs7OztpQkFDUCx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMO1FBQ0EsT0FBTztRQUNQLFdBQVcsTUFBTSxlQUFlLEVBQUUsT0FBTyxLQUFLO1FBQzlDLGFBQVk7UUFDWixXQUFVO09BQ1g7Ozs7ZUFDRTs7OztpQkFFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsZUFBZSxtQkFBbUIsS0FBSztTQUN2QyxXQUFVO21CQUNYO1FBRU87Ozs7a0JBQ1Isd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxVQUFVLGlCQUFpQixDQUFDO1NBQzVCLFdBQVU7bUJBRVQsZ0JBQWdCLGdCQUFnQjtRQUMzQjs7OztnQkFDTDs7Ozs7ZUFDRDs7Ozs7Y0FDSDs7Ozs7O0lBQ0Y7Ozs7O0dBRUE7Ozs7O1VBQ0w7Ozs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlNpZ25Jbi5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCBhcGkgZnJvbSAnLi4vLi4vc2VydmljZXMvYXBpJ1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uL2NvbnRleHQvQXV0aENvbnRleHQnXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFNpZ25JbigpIHtcbiAgY29uc3QgeyB1cGRhdGVTZXNzaW9uLCBzaG93RXJyb3IsIHNob3dNZXNzYWdlIH0gPSB1c2VBdXRoKClcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXG4gIGNvbnN0IFtzaG93Rm9yZ290TW9kYWwsIHNldFNob3dGb3Jnb3RNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW2ZvcmdvdEVtYWlsLCBzZXRGb3Jnb3RFbWFpbF0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW2ZvcmdvdExvYWRpbmcsIHNldEZvcmdvdExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIFxuICBjb25zdCBzdWJtaXRMb2dpbiA9IGFzeW5jIChldmVudCkgPT4ge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcbiAgICBjb25zdCBmb3JtID0gbmV3IEZvcm1EYXRhKGV2ZW50LmN1cnJlbnRUYXJnZXQpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXBpLnBvc3QoJy9hdXRoL2xvZ2luJywgT2JqZWN0LmZyb21FbnRyaWVzKGZvcm0pKVxuICAgICAgXG4gICAgICBpZiAoZGF0YS5yZXF1aWVyZV8yZmEpIHtcbiAgICAgICAgbmF2aWdhdGUoJy9hdXRoL3ZlcmlmeS0yZmEnLCB7IHN0YXRlOiB7IGNoYWxsZW5nZTogZGF0YSB9IH0pXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuICAgICAgXG4gICAgICB1cGRhdGVTZXNzaW9uKGRhdGEpXG4gICAgICBuYXZpZ2F0ZShkYXRhLm11c3RfY2hhbmdlX3Bhc3N3b3JkID8gJy9hdXRoL2NoYW5nZS1wYXNzd29yZCcgOiAnL2Rhc2hib2FyZCcpXG4gICAgfSBjYXRjaCAocmVxdWVzdEVycm9yKSB7XG4gICAgICBzaG93RXJyb3IocmVxdWVzdEVycm9yKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUZvcmdvdFBhc3N3b3JkID0gYXN5bmMgKGUpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBpZiAoIWZvcmdvdEVtYWlsKSByZXR1cm5cbiAgICBzZXRGb3Jnb3RMb2FkaW5nKHRydWUpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXBpLnBvc3QoJy9hdXRoL2ZvcmdvdC1wYXNzd29yZCcsIHsgY29ycmVvOiBmb3Jnb3RFbWFpbCB9KVxuICAgICAgc2hvd01lc3NhZ2UoZGF0YS5tZW5zYWplKVxuICAgICAgc2V0U2hvd0ZvcmdvdE1vZGFsKGZhbHNlKVxuICAgICAgc2V0Rm9yZ290RW1haWwoJycpXG4gICAgfSBjYXRjaCAocmVxdWVzdEVycm9yKSB7XG4gICAgICBzaG93RXJyb3IocmVxdWVzdEVycm9yKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRGb3Jnb3RMb2FkaW5nKGZhbHNlKVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPG1haW4gY2xhc3NOYW1lPVwibG9naW4tc2hlbGxcIj5cbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImxvZ2luLWFydFwiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJleWVicm93XCI+UExBWUEgQVpVTCAvIE9QRVJBQ0lPTkVTPC9zcGFuPlxuICAgICAgICA8aDE+RWwgYWd1YSwgYmFqbyBjb250cm9sLjwvaDE+XG4gICAgICAgIDxwPk1vbml0b3JlbyBpbnRlbGlnZW50ZSB5IG9wZXJhY2nDs24gY2xhcmEgcGFyYSB1bmEgcGlzY2luYSBzaWVtcHJlIGxpc3RhLjwvcD5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwb29sLWxpbmVzXCIgLz5cbiAgICAgIDwvc2VjdGlvbj5cbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImxvZ2luLWNhcmRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJicmFuZCBsb2dpbi1icmFuZFwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJyYW5kLW1hcmtcIj5QQTwvc3Bhbj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPHN0cm9uZz5QbGF5YSBBenVsPC9zdHJvbmc+XG4gICAgICAgICAgICA8c21hbGw+Q29udHJvbCBjZW50ZXI8L3NtYWxsPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwiZm9ybVwiIG9uU3VibWl0PXtzdWJtaXRMb2dpbn0+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImV5ZWJyb3dcIj5CSUVOVkVOSURPIERFIFZVRUxUQTwvc3Bhbj5cbiAgICAgICAgICAgIDxoMj5JbmljaWEgc2VzacOzbjwvaDI+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdXRlZFwiPkFjY2VkZSBhIHR1IGNlbnRybyBkZSBvcGVyYWNpb25lcy48L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGxhYmVsPlxuICAgICAgICAgICAgQ29ycmVvXG4gICAgICAgICAgICA8aW5wdXQgbmFtZT1cImNvcnJlb1wiIHR5cGU9XCJlbWFpbFwiIGF1dG9Db21wbGV0ZT1cImVtYWlsXCIgcmVxdWlyZWQgLz5cbiAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItMVwiPlxuICAgICAgICAgICAgICA8c3Bhbj5Db250cmFzZcOxYTwvc3Bhbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dGb3Jnb3RNb2RhbCh0cnVlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtYmx1ZS02MDAgaG92ZXI6dGV4dC1ibHVlLTcwMCBmb250LXNlbWlib2xkIGZvY3VzOm91dGxpbmUtbm9uZVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICDCv09sdmlkYXN0ZSB0dSBjb250cmFzZcOxYT9cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxpbnB1dCBuYW1lPVwicGFzc3dvcmRcIiB0eXBlPVwicGFzc3dvcmRcIiBhdXRvQ29tcGxldGU9XCJjdXJyZW50LXBhc3N3b3JkXCIgcmVxdWlyZWQgLz5cbiAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwicHJpbWFyeVwiIHR5cGU9XCJzdWJtaXRcIj5FbnRyYXIgYWwgcGFuZWwgPHNwYW4+4oaSPC9zcGFuPjwvYnV0dG9uPlxuICAgICAgICA8L2Zvcm0+XG5cbiAgICAgICAgey8qIE1vZGFsIGRlIE9sdmlkw6kgbWkgQ29udHJhc2XDsWEgKi99XG4gICAgICAgIHtzaG93Rm9yZ290TW9kYWwgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LVs5OTk5OV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctc2xhdGUtOTAwLzYwIGJhY2tkcm9wLWJsdXItc20gcC00XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtM3hsIG1heC13LW1kIHctZnVsbCBwLTYgc2hhZG93LTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTEwMCByZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwYi0zIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgbWItNFwiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDBcIj5SZWN1cGVyYXIgQ29udHJhc2XDsWE8L2gzPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBtdC0wLjVcIj5JbmdyZXNhIHR1IGNvcnJlbyBwYXJhIGVudmlhcnRlIHVuYSBjb250cmFzZcOxYSB0ZW1wb3JhbDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dGb3Jnb3RNb2RhbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS01MDAgaG92ZXI6Ymctc2xhdGUtMjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICDinJVcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUZvcmdvdFBhc3N3b3JkfSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMCBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIENvcnJlbyBSZWdpc3RyYWRvXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3Jnb3RFbWFpbH1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3Jnb3RFbWFpbChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZWplbXBsb0BwaXNjaW5hLmNvbVwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTMgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS01MDAgdGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBwdC0yXCI+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93Rm9yZ290TW9kYWwoZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEvMyBweS0yLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCB0ZXh0LXNsYXRlLTYwMCBmb250LWJvbGQgdGV4dC1zbSBob3ZlcjpiZy1zbGF0ZS0xMDAgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBDYW5jZWxhclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17Zm9yZ290TG9hZGluZyB8fCAhZm9yZ290RW1haWx9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMi8zIHB5LTIuNSByb3VuZGVkLXhsIGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNzAwIGRpc2FibGVkOm9wYWNpdHktNTAgdGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC1zbSBzaGFkb3ctbWQgc2hhZG93LWJsdWUtNTAwLzIwIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge2ZvcmdvdExvYWRpbmcgPyAnRW52aWFuZG8uLi4nIDogJ0VudmlhciBDb250cmFzZcOxYSd9XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L3NlY3Rpb24+XG4gICAgPC9tYWluPlxuICApXG59XG4iXX0=