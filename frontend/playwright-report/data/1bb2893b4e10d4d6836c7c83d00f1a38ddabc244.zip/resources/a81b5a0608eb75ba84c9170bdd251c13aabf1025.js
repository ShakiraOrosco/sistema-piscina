import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Inventario/index.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=41a64c35";
import api from "/src/services/api.js";
import { useAuth } from "/src/context/AuthContext.jsx";
var _jsxFileName = "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Inventario/index.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=41a64c35";
var _s = $RefreshSig$();
export default function InventarioPage() {
	_s();
	const { session } = useAuth();
	const [quimicos, setQuimicos] = useState([]);
	const [movimientos, setMovimientos] = useState([]);
	const [loading, setLoading] = useState(true);
	const [loadingMovimientos, setLoadingMovimientos] = useState(false);
	const [showMovimientoModal, setShowMovimientoModal] = useState(false);
	const [showQuimicoModal, setShowQuimicoModal] = useState(false);
	// Filtros de fecha para el historial
	const [fechaDesde, setFechaDesde] = useState("");
	const [fechaHasta, setFechaHasta] = useState("");
	// Paginación: 20 registros por página
	const [currentPage, setCurrentPage] = useState(1);
	const ITEMS_PER_PAGE = 20;
	useEffect(() => {
		setCurrentPage(1);
	}, [
		fechaDesde,
		fechaHasta,
		movimientos.length
	]);
	// Form movimiento
	const [tipoMovimiento, setTipoMovimiento] = useState("compra");
	const [selectedQuimico, setSelectedQuimico] = useState("");
	const [cantidadMovimiento, setCantidadMovimiento] = useState("");
	const [observacionesMovimiento, setObservacionesMovimiento] = useState("");
	const [savingMovimiento, setSavingMovimiento] = useState(false);
	// Form nuevo químico
	const [nombreQuimico, setNombreQuimico] = useState("");
	const [siglaQuimico, setSiglaQuimico] = useState("");
	const [unidadMedida, setUnidadMedida] = useState("g");
	const [stockInicial, setStockInicial] = useState("0");
	const [stockMinimo, setStockMinimo] = useState("1000");
	const [savingQuimico, setSavingQuimico] = useState(false);
	const [notification, setNotification] = useState(null);
	// Carga solo los movimientos (para filtrado sin recargar tarjetas de químicos)
	const fetchMovimientos = useCallback(async (desde = fechaDesde, hasta = fechaHasta) => {
		setLoadingMovimientos(true);
		try {
			const params = {};
			if (desde) params.fecha_desde = desde;
			if (hasta) params.fecha_hasta = hasta;
			const { data } = await api.get("/inventario/movimientos", { params });
			setMovimientos(data);
		} catch {
			setNotification({
				type: "error",
				msg: "Error al filtrar los movimientos del inventario"
			});
		} finally {
			setLoadingMovimientos(false);
		}
	}, [fechaDesde, fechaHasta]);
	// Carga químicos y movimientos iniciales
	const fetchData = useCallback(async () => {
		setLoading(true);
		try {
			const params = {};
			if (fechaDesde) params.fecha_desde = fechaDesde;
			if (fechaHasta) params.fecha_hasta = fechaHasta;
			const [{ data: qData }, { data: mData }] = await Promise.all([api.get("/inventario/quimicos"), api.get("/inventario/movimientos", { params })]);
			setQuimicos(qData);
			setMovimientos(mData);
		} catch {
			setNotification({
				type: "error",
				msg: "Error al cargar los datos del inventario"
			});
		} finally {
			setLoading(false);
		}
	}, [fechaDesde, fechaHasta]);
	useEffect(() => {
		fetchData();
	}, [fetchData]);
	// Filtrado de fechas
	const handleFiltrarFechas = (e) => {
		if (e) e.preventDefault();
		fetchMovimientos(fechaDesde, fechaHasta);
	};
	const handleLimpiarFiltroFechas = () => {
		setFechaDesde("");
		setFechaHasta("");
		fetchMovimientos("", "");
	};
	// Químico actualmente seleccionado en el modal
	const selectedQuimicoInfo = quimicos.find((q) => q.sigla === selectedQuimico);
	// Registrar Movimiento (Compra, Dosificación o Merma)
	const handleRegistrarMovimiento = async (e) => {
		e.preventDefault();
		if (!selectedQuimico || !cantidadMovimiento || parseFloat(cantidadMovimiento) <= 0) {
			setNotification({
				type: "error",
				msg: "Seleccione un químico e ingrese una cantidad válida"
			});
			return;
		}
		const cantidadNum = parseFloat(cantidadMovimiento);
		// Validación preventiva en frontend de stock suficiente para salidas
		if ((tipoMovimiento === "dosificacion" || tipoMovimiento === "merma") && selectedQuimicoInfo && cantidadNum > parseFloat(selectedQuimicoInfo.stock_actual)) {
			setNotification({
				type: "error",
				msg: `Stock insuficiente: el stock actual de ${selectedQuimicoInfo.nombre} es ${parseFloat(selectedQuimicoInfo.stock_actual).toFixed(1)} ${selectedQuimicoInfo.unidad_medida}`
			});
			return;
		}
		setSavingMovimiento(true);
		try {
			const { data } = await api.post("/inventario/movimientos", {
				sigla_quimico: selectedQuimico,
				tipo_movimiento: tipoMovimiento,
				cantidad: cantidadNum,
				observaciones: observacionesMovimiento.trim() || null,
				id_usuario: session?.usuario?.id_usuario || null
			});
			setNotification({
				type: "success",
				msg: `✓ ${data.mensaje}`
			});
			setShowMovimientoModal(false);
			setSelectedQuimico("");
			setCantidadMovimiento("");
			setObservacionesMovimiento("");
			setTipoMovimiento("compra");
			fetchData();
		} catch (err) {
			const msg = err.response?.data?.detail || "Error al registrar el movimiento";
			setNotification({
				type: "error",
				msg: `✗ ${msg}`
			});
		} finally {
			setSavingMovimiento(false);
			setTimeout(() => setNotification(null), 4e3);
		}
	};
	const handleCrearQuimico = async (e) => {
		e.preventDefault();
		if (!nombreQuimico || !siglaQuimico || !unidadMedida) {
			setNotification({
				type: "error",
				msg: "Complete todos los campos requeridos"
			});
			return;
		}
		setSavingQuimico(true);
		try {
			const { data } = await api.post("/inventario/quimicos", {
				nombre: nombreQuimico,
				sigla: siglaQuimico,
				unidad_medida: unidadMedida,
				stock_actual: parseFloat(stockInicial) || 0,
				stock_minimo: parseFloat(stockMinimo) || 0
			});
			setNotification({
				type: "success",
				msg: `✓ ${data.mensaje}`
			});
			setShowQuimicoModal(false);
			setNombreQuimico("");
			setSiglaQuimico("");
			setUnidadMedida("g");
			setStockInicial("0");
			setStockMinimo("1000");
			fetchData();
		} catch (err) {
			const msg = err.response?.data?.detail || "Error al registrar el químico";
			setNotification({
				type: "error",
				msg: `✗ ${msg}`
			});
		} finally {
			setSavingQuimico(false);
			setTimeout(() => setNotification(null), 4e3);
		}
	};
	const totalPages = Math.ceil(movimientos.length / ITEMS_PER_PAGE) || 1;
	const validCurrentPage = Math.min(Math.max(currentPage, 1), totalPages);
	const startIndex = (validCurrentPage - 1) * ITEMS_PER_PAGE;
	const endIndex = Math.min(startIndex + ITEMS_PER_PAGE, movimientos.length);
	const paginatedMovimientos = movimientos.slice(startIndex, endIndex);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-50 pb-12 dark:bg-[#1A222C]",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-[#24303F] border-b border-slate-200 dark:border-[#313D4A] px-6 py-6 shadow-sm",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs font-bold tracking-widest uppercase text-blue-500 mb-1",
							children: "Módulo Operativo"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 192,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("h1", {
							className: "text-2xl font-bold text-slate-800 dark:text-white",
							children: "Inventario de Químicos e Insumos"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 193,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-sm text-slate-500 dark:text-slate-400 mt-0.5",
							children: "Control de existencias y registro de movimientos"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 194,
							columnNumber: 13
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 191,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setShowMovimientoModal(true),
							className: "flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-xl font-bold text-sm shadow-md shadow-blue-500/20 active:scale-95 transition-all",
							children: [/* @__PURE__ */ _jsxDEV("svg", {
								className: "w-5 h-5",
								fill: "none",
								stroke: "currentColor",
								viewBox: "0 0 24 24",
								children: /* @__PURE__ */ _jsxDEV("path", {
									strokeLinecap: "round",
									strokeLinejoin: "round",
									strokeWidth: "2.5",
									d: "M12 4v16m8-8H4"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 203,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 202,
								columnNumber: 15
							}, this), "Registrar Movimiento"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 198,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 197,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 190,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 189,
				columnNumber: 7
			}, this),
			notification && /* @__PURE__ */ _jsxDEV("div", {
				className: `max-w-6xl mx-auto px-4 py-3 mt-4 rounded-xl font-semibold text-sm flex items-center gap-3 shadow-md ${notification.type === "success" ? "bg-emerald-50 border border-emerald-200 text-emerald-700" : "bg-red-50 border border-red-200 text-red-700"}`,
				children: notification.msg
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 213,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "max-w-6xl mx-auto px-6 mt-6 grid grid-cols-1 md:grid-cols-3 gap-5",
				children: quimicos.map((q) => {
					const bajoStock = parseFloat(q.stock_actual) <= parseFloat(q.stock_minimo);
					return /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-[#24303F] p-6 rounded-2xl border border-slate-200 dark:border-[#313D4A] shadow-sm relative overflow-hidden",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-start justify-between",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400",
								children: q.sigla
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 226,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("h3", {
								className: "text-lg font-bold text-slate-800 dark:text-white mt-0.5",
								children: q.nombre
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 227,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 225,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: `px-2.5 py-1 rounded-full text-xs font-bold ${bajoStock ? "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400" : "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400"}`,
								children: bajoStock ? "Stock Bajo" : "Normal"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 229,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 224,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-4 flex items-baseline justify-between",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-3xl font-black text-slate-800 dark:text-white",
								children: parseFloat(q.stock_actual).toFixed(1)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 236,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "ml-1 text-sm font-semibold text-slate-400",
								children: q.unidad_medida
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 237,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 235,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-right text-xs text-slate-400 font-medium",
								children: [
									"Mínimo: ",
									parseFloat(q.stock_minimo).toFixed(1),
									" ",
									q.unidad_medida
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 239,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 234,
							columnNumber: 15
						}, this)]
					}, q.id_quimico, true, {
						fileName: _jsxFileName,
						lineNumber: 223,
						columnNumber: 13
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 219,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "max-w-6xl mx-auto px-6 mt-8",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-[#24303F] rounded-2xl border border-slate-200 dark:border-[#313D4A] shadow-sm overflow-hidden",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-wrap items-center justify-between gap-4 px-6 py-5 border-b border-slate-100 dark:border-[#313D4A]",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
								className: "font-bold text-lg text-slate-800 dark:text-white",
								children: "Historial de Movimientos de Inventario"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 253,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-400",
								children: "Entradas por compra, dosificaciones y mermas"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 254,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 252,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("form", {
								onSubmit: handleFiltrarFechas,
								className: "flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2 bg-slate-50 dark:bg-[#1A222C] px-3 py-1.5 rounded-xl border border-slate-200 dark:border-[#313D4A]",
										children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-xs font-semibold text-slate-500 dark:text-slate-400",
											children: "Desde:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 260,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "date",
											value: fechaDesde,
											onChange: (e) => setFechaDesde(e.target.value),
											className: "bg-transparent text-xs text-slate-700 dark:text-slate-200 outline-none"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 261,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 259,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2 bg-slate-50 dark:bg-[#1A222C] px-3 py-1.5 rounded-xl border border-slate-200 dark:border-[#313D4A]",
										children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-xs font-semibold text-slate-500 dark:text-slate-400",
											children: "Hasta:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 270,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "date",
											value: fechaHasta,
											onChange: (e) => setFechaHasta(e.target.value),
											className: "bg-transparent text-xs text-slate-700 dark:text-slate-200 outline-none"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 271,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 269,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "submit",
										className: "flex items-center gap-1.5 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm active:scale-95",
										children: [/* @__PURE__ */ _jsxDEV("svg", {
											className: "w-3.5 h-3.5",
											fill: "none",
											stroke: "currentColor",
											viewBox: "0 0 24 24",
											children: /* @__PURE__ */ _jsxDEV("path", {
												strokeLinecap: "round",
												strokeLinejoin: "round",
												strokeWidth: "2.5",
												d: "M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 284,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 283,
											columnNumber: 17
										}, this), "Filtrar"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 279,
										columnNumber: 15
									}, this),
									(fechaDesde || fechaHasta) && /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: handleLimpiarFiltroFechas,
										className: "flex items-center gap-1 px-3 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl text-xs font-bold transition-all",
										children: "✕ Limpiar"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 290,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-semibold text-slate-400 ml-1",
										children: [movimientos.length, " movimiento(s)"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 299,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 258,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 251,
							columnNumber: 11
						}, this),
						(fechaDesde || fechaHasta) && /* @__PURE__ */ _jsxDEV("div", {
							className: "bg-blue-50/50 dark:bg-blue-950/20 px-6 py-2 border-b border-blue-100 dark:border-blue-900/30 text-xs text-blue-700 dark:text-blue-300 flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: [
								"Filtro activo: ",
								fechaDesde ? `desde ${fechaDesde}` : "",
								" ",
								fechaHasta ? `hasta ${fechaHasta}` : ""
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 307,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: handleLimpiarFiltroFechas,
								className: "underline hover:text-blue-900 dark:hover:text-white",
								children: "Ver todo el historial"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 310,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 306,
							columnNumber: 13
						}, this),
						loading || loadingMovimientos ? /* @__PURE__ */ _jsxDEV("div", {
							className: "text-center py-12 text-slate-400 font-medium",
							children: "Cargando movimientos..."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 320,
							columnNumber: 13
						}, this) : movimientos.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
							className: "text-center py-12 text-slate-400 font-medium",
							children: fechaDesde || fechaHasta ? "No se encontraron movimientos registrados en el rango de fechas seleccionado" : "No hay movimientos registrados de insumos"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 322,
							columnNumber: 13
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "overflow-x-auto",
							children: /* @__PURE__ */ _jsxDEV("table", {
								className: "w-full text-left",
								children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
									className: "bg-slate-50 dark:bg-[#1A222C] border-b border-slate-100 dark:border-[#313D4A]",
									children: [
										/* @__PURE__ */ _jsxDEV("th", {
											className: "px-5 py-3.5 text-xs font-bold uppercase tracking-wider text-slate-400",
											children: "Fecha y Hora"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 332,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "px-5 py-3.5 text-xs font-bold uppercase tracking-wider text-slate-400",
											children: "Químico"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 333,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "px-5 py-3.5 text-xs font-bold uppercase tracking-wider text-slate-400 text-center",
											children: "Tipo / Origen"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 334,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "px-5 py-3.5 text-xs font-bold uppercase tracking-wider text-slate-400 text-right",
											children: "Cantidad"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 335,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "px-5 py-3.5 text-xs font-bold uppercase tracking-wider text-slate-400 text-right",
											children: "Stock Resultante"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 336,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "px-5 py-3.5 text-xs font-bold uppercase tracking-wider text-slate-400",
											children: "Observaciones"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 337,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 331,
									columnNumber: 19
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 330,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("tbody", {
									className: "divide-y divide-slate-100 dark:divide-[#313D4A]",
									children: paginatedMovimientos.map((m, i) => {
										const isEntrada = m.sigla_tipo_movimiento === "ENT";
										const isMerma = m.sigla_origen === "MER" || m.origen_movimiento && m.origen_movimiento.toLowerCase().includes("merma");
										const isDosificacion = m.sigla_origen === "DOS" || m.origen_movimiento && m.origen_movimiento.toLowerCase().includes("dosific");
										let badgeColor = "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300";
										let cantidadSign = "-";
										let cantidadColor = "text-slate-800 dark:text-white";
										if (isEntrada) {
											badgeColor = "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400";
											cantidadSign = "+";
											cantidadColor = "text-emerald-600 dark:text-emerald-400";
										} else if (isMerma) {
											badgeColor = "bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400";
											cantidadSign = "-";
											cantidadColor = "text-rose-600 dark:text-rose-400";
										} else if (isDosificacion) {
											badgeColor = "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400";
											cantidadSign = "-";
											cantidadColor = "text-amber-600 dark:text-amber-400";
										}
										return /* @__PURE__ */ _jsxDEV("tr", {
											className: i % 2 === 0 ? "bg-white dark:bg-[#24303F]" : "bg-slate-50/50 dark:bg-[#1A222C]/50",
											children: [
												/* @__PURE__ */ _jsxDEV("td", {
													className: "px-5 py-4 text-xs font-semibold text-slate-600 dark:text-slate-300 whitespace-nowrap",
													children: m.fecha_hora ? new Date(m.fecha_hora).toLocaleString() : "—"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 370,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "px-5 py-4 text-sm font-bold text-slate-800 dark:text-white",
													children: m.nombre_quimico || m.sigla_quimico
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 373,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "px-5 py-4 text-center",
													children: /* @__PURE__ */ _jsxDEV("span", {
														className: `px-2.5 py-1 rounded-full text-xs font-bold ${badgeColor}`,
														children: [
															m.tipo_movimiento || m.sigla_tipo_movimiento,
															" (",
															m.origen_movimiento || m.sigla_origen,
															")"
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 377,
														columnNumber: 27
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 376,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: `px-5 py-4 text-right font-black text-sm ${cantidadColor}`,
													children: [
														cantidadSign,
														parseFloat(m.cantidad).toFixed(1),
														" ",
														m.unidad_medida
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 381,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "px-5 py-4 text-right text-xs font-bold text-slate-500 dark:text-slate-400",
													children: [
														parseFloat(m.stock_resultante).toFixed(1),
														" ",
														m.unidad_medida
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 384,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "px-5 py-4 text-xs text-slate-500 dark:text-slate-400 italic",
													children: m.observaciones || "—"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 387,
													columnNumber: 25
												}, this)
											]
										}, m.id_movimiento, true, {
											fileName: _jsxFileName,
											lineNumber: 369,
											columnNumber: 23
										}, this);
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 340,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 329,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 328,
							columnNumber: 13
						}, this),
						movimientos.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-wrap items-center justify-between gap-4 px-6 py-4 border-t border-slate-100 dark:border-[#313D4A] bg-slate-50/50 dark:bg-[#1A222C]/50",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "text-xs text-slate-500 dark:text-slate-400 font-medium",
								children: [
									"Mostrando ",
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-slate-700 dark:text-slate-200",
										children: startIndex + 1
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 402,
										columnNumber: 27
									}, this),
									" a",
									" ",
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-slate-700 dark:text-slate-200",
										children: endIndex
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 403,
										columnNumber: 17
									}, this),
									" de",
									" ",
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-slate-700 dark:text-slate-200",
										children: movimientos.length
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 404,
										columnNumber: 17
									}, this),
									" registros"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 401,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setCurrentPage((prev) => Math.max(prev - 1, 1)),
										disabled: validCurrentPage <= 1,
										className: "flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#24303F] text-slate-700 dark:text-slate-200 text-xs font-bold transition-all disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-50 dark:hover:bg-slate-800 shadow-sm",
										title: "Página anterior",
										children: [/* @__PURE__ */ _jsxDEV("svg", {
											className: "w-4 h-4",
											fill: "none",
											stroke: "currentColor",
											viewBox: "0 0 24 24",
											children: /* @__PURE__ */ _jsxDEV("path", {
												strokeLinecap: "round",
												strokeLinejoin: "round",
												strokeWidth: "2.5",
												d: "M15 19l-7-7 7-7"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 416,
												columnNumber: 21
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 415,
											columnNumber: 19
										}, this), "Anterior"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 408,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-1 px-2",
										children: /* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs font-bold text-slate-700 dark:text-slate-300",
											children: [
												"Página ",
												validCurrentPage,
												" de ",
												totalPages
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 422,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 421,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setCurrentPage((prev) => Math.min(prev + 1, totalPages)),
										disabled: validCurrentPage >= totalPages,
										className: "flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#24303F] text-slate-700 dark:text-slate-200 text-xs font-bold transition-all disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-50 dark:hover:bg-slate-800 shadow-sm",
										title: "Página siguiente",
										children: ["Siguiente", /* @__PURE__ */ _jsxDEV("svg", {
											className: "w-4 h-4",
											fill: "none",
											stroke: "currentColor",
											viewBox: "0 0 24 24",
											children: /* @__PURE__ */ _jsxDEV("path", {
												strokeLinecap: "round",
												strokeLinejoin: "round",
												strokeWidth: "2.5",
												d: "M9 5l7 7-7 7"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 436,
												columnNumber: 21
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 435,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 427,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 407,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 400,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 250,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 249,
				columnNumber: 7
			}, this),
			showMovimientoModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-[9999] flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-[#24303F] rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 dark:border-[#313D4A] relative",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between pb-4 border-b border-slate-100 dark:border-[#313D4A] mb-4",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-lg font-bold text-slate-800 dark:text-white",
							children: "Registrar Movimiento"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 451,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400 mt-0.5",
							children: "Entrada o salida de químicos e insumos"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 452,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 450,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setShowMovimientoModal(false),
							className: "w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-700 flex items-center justify-center transition-colors",
							children: "✕"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 454,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 449,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleRegistrarMovimiento,
						className: "space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1",
									children: "Tipo de Movimiento"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 465,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("select", {
									value: tipoMovimiento,
									onChange: (e) => setTipoMovimiento(e.target.value),
									required: true,
									className: "w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-[#313D4A] bg-transparent dark:bg-[#1A222C] text-sm text-slate-800 dark:text-white font-medium focus:ring-2 focus:ring-blue-500 focus:outline-none",
									children: [
										/* @__PURE__ */ _jsxDEV("option", {
											value: "compra",
											className: "dark:bg-[#1A222C]",
											children: "Compra (+ Entrada)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 474,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "dosificacion",
											className: "dark:bg-[#1A222C]",
											children: "Dosificación (- Salida por aplicación)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 475,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "merma",
											className: "dark:bg-[#1A222C]",
											children: "Merma (- Salida por pérdida)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 476,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 468,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-slate-500 dark:text-slate-400 mt-1",
									children: [
										tipoMovimiento === "compra" && "Aumenta el stock del químico al registrar un nuevo ingreso.",
										tipoMovimiento === "dosificacion" && "Descuenta insumo aplicado al tratamiento de la piscina.",
										tipoMovimiento === "merma" && "Descuenta insumo por derrame, rotura, vencimiento o merma física."
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 478,
									columnNumber: 17
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 464,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1",
									children: "Químico Insumo"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 487,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("select", {
									value: selectedQuimico,
									onChange: (e) => setSelectedQuimico(e.target.value),
									required: true,
									className: "w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-[#313D4A] bg-transparent dark:bg-[#1A222C] text-sm text-slate-800 dark:text-white font-medium focus:ring-2 focus:ring-blue-500 focus:outline-none",
									children: [/* @__PURE__ */ _jsxDEV("option", {
										value: "",
										className: "dark:bg-[#1A222C]",
										children: "-- Seleccione químico --"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 496,
										columnNumber: 19
									}, this), quimicos.map((q) => /* @__PURE__ */ _jsxDEV("option", {
										value: q.sigla,
										className: "dark:bg-[#1A222C]",
										children: [
											q.nombre,
											" (",
											q.unidad_medida,
											") — Stock: ",
											parseFloat(q.stock_actual).toFixed(1),
											" ",
											q.unidad_medida
										]
									}, q.sigla, true, {
										fileName: _jsxFileName,
										lineNumber: 498,
										columnNumber: 21
									}, this))]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 490,
									columnNumber: 17
								}, this),
								selectedQuimicoInfo && /* @__PURE__ */ _jsxDEV("div", {
									className: "mt-1.5 flex items-center justify-between text-xs px-1",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400",
										children: "Stock disponible:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 505,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: `font-bold ${parseFloat(selectedQuimicoInfo.stock_actual) <= parseFloat(selectedQuimicoInfo.stock_minimo) ? "text-red-500" : "text-emerald-500"}`,
										children: [
											parseFloat(selectedQuimicoInfo.stock_actual).toFixed(1),
											" ",
											selectedQuimicoInfo.unidad_medida
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 506,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 504,
									columnNumber: 19
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 486,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1",
								children: [
									tipoMovimiento === "compra" ? "Cantidad Comprada" : tipoMovimiento === "dosificacion" ? "Cantidad a Dosificar" : "Cantidad de Merma",
									" ",
									selectedQuimicoInfo ? `(${selectedQuimicoInfo.unidad_medida})` : ""
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 515,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "number",
								step: "0.01",
								min: "0.01",
								required: true,
								placeholder: "Ej: 50.0",
								value: cantidadMovimiento,
								onChange: (e) => setCantidadMovimiento(e.target.value),
								className: "w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-[#313D4A] bg-transparent dark:bg-[#1A222C] text-sm text-slate-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 523,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 514,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1",
								children: "Observaciones / Detalle"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 537,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								placeholder: tipoMovimiento === "compra" ? "Ej: Factura 4501 - Distribuidora Acqua" : tipoMovimiento === "dosificacion" ? "Ej: Tratamiento preventivo nocturno" : "Ej: Envase dañado en bodega",
								value: observacionesMovimiento,
								onChange: (e) => setObservacionesMovimiento(e.target.value),
								className: "w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-[#313D4A] bg-transparent dark:bg-[#1A222C] text-sm text-slate-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 540,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 536,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3 pt-3",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setShowMovimientoModal(false),
									className: "w-1/3 py-3 rounded-xl border border-slate-200 dark:border-[#313D4A] text-slate-600 dark:text-slate-300 font-bold text-sm hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors",
									children: "Cancelar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 557,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "submit",
									disabled: savingMovimiento,
									className: `w-2/3 py-3 rounded-xl text-white font-bold text-sm shadow-md transition-all active:scale-95 ${tipoMovimiento === "compra" ? "bg-blue-600 hover:bg-blue-700 shadow-blue-500/20" : tipoMovimiento === "dosificacion" ? "bg-amber-600 hover:bg-amber-700 shadow-amber-500/20" : "bg-rose-600 hover:bg-rose-700 shadow-rose-500/20"}`,
									children: savingMovimiento ? "Guardando..." : tipoMovimiento === "compra" ? "Registrar Entrada" : tipoMovimiento === "dosificacion" ? "Registrar Dosificación" : "Registrar Merma"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 564,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 556,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 462,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 448,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 447,
				columnNumber: 9
			}, this),
			showQuimicoModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-[9999] flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-[#24303F] rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 dark:border-[#313D4A] relative",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between pb-4 border-b border-slate-100 dark:border-[#313D4A] mb-4",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-lg font-bold text-slate-800 dark:text-white",
							children: "Registrar Nuevo Químico"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 594,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setShowQuimicoModal(false),
							className: "w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-700 flex items-center justify-center transition-colors",
							children: "✕"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 595,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 593,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleCrearQuimico,
						className: "space-y-3",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1",
								children: "Nombre del Químico"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 605,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								required: true,
								placeholder: "Ej: Algicida Concentrado",
								value: nombreQuimico,
								onChange: (e) => setNombreQuimico(e.target.value),
								className: "w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-[#313D4A] bg-transparent dark:bg-[#1A222C] text-sm text-slate-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 606,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 604,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1",
									children: "Sigla (Cód.)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 618,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									required: true,
									placeholder: "Ej: ALG",
									value: siglaQuimico,
									onChange: (e) => setSiglaQuimico(e.target.value.toUpperCase()),
									className: "w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-[#313D4A] bg-transparent dark:bg-[#1A222C] text-sm text-slate-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 619,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 617,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1",
									children: "Unidad Medida"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 629,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									required: true,
									placeholder: "Ej: L, kg, gal",
									value: unidadMedida,
									onChange: (e) => setUnidadMedida(e.target.value),
									className: "w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-[#313D4A] bg-transparent dark:bg-[#1A222C] text-sm text-slate-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 630,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 628,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 616,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1",
									children: "Stock Inicial"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 643,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "number",
									step: "0.1",
									min: "0",
									value: stockInicial,
									onChange: (e) => setStockInicial(e.target.value),
									className: "w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-[#313D4A] bg-transparent dark:bg-[#1A222C] text-sm text-slate-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 644,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 642,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1",
									children: "Stock Mínimo Alerta"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 654,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "number",
									step: "0.1",
									min: "0",
									value: stockMinimo,
									onChange: (e) => setStockMinimo(e.target.value),
									className: "w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-[#313D4A] bg-transparent dark:bg-[#1A222C] text-sm text-slate-800 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 655,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 653,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 641,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3 pt-3",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setShowQuimicoModal(false),
									className: "w-1/3 py-2.5 rounded-xl border border-slate-200 dark:border-[#313D4A] text-slate-600 dark:text-slate-300 font-bold text-sm hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors",
									children: "Cancelar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 667,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "submit",
									disabled: savingQuimico,
									className: "w-2/3 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-md transition-all active:scale-95",
									children: savingQuimico ? "Guardando..." : "Crear Químico"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 674,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 666,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 603,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 592,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 591,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 187,
		columnNumber: 5
	}, this);
}
_s(InventarioPage, "7YM2gYRzqW6eV4tW1uIdX6GyL5g=", false, function() {
	return [useAuth];
});
_c = InventarioPage;
var _c;
$RefreshReg$(_c, "InventarioPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Inventario/index.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Inventario/index.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Inventario/index.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Inventario/index.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFdBQVcsbUJBQW1CO0FBQ2pELE9BQU8sU0FBUztBQUNoQixTQUFTLGVBQWU7Ozs7QUFFeEIsZUFBZSxTQUFTLGlCQUFpQjs7Q0FDdkMsTUFBTSxFQUFFLFlBQVksUUFBUTtDQUM1QixNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsQ0FBQyxDQUFDO0NBQzNDLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLENBQUMsQ0FBQztDQUNqRCxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsSUFBSTtDQUMzQyxNQUFNLENBQUMsb0JBQW9CLHlCQUF5QixTQUFTLEtBQUs7Q0FDbEUsTUFBTSxDQUFDLHFCQUFxQiwwQkFBMEIsU0FBUyxLQUFLO0NBQ3BFLE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsS0FBSzs7Q0FHOUQsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsRUFBRTtDQUMvQyxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxFQUFFOztDQUcvQyxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxDQUFDO0NBQ2hELE1BQU0saUJBQWlCO0NBRXZCLGdCQUFnQjtFQUNkLGVBQWUsQ0FBQztDQUNsQixHQUFHO0VBQUM7RUFBWTtFQUFZLFlBQVk7Q0FBTSxDQUFDOztDQUcvQyxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLFFBQVE7Q0FDN0QsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxFQUFFO0NBQ3pELE1BQU0sQ0FBQyxvQkFBb0IseUJBQXlCLFNBQVMsRUFBRTtDQUMvRCxNQUFNLENBQUMseUJBQXlCLDhCQUE4QixTQUFTLEVBQUU7Q0FDekUsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBUyxLQUFLOztDQUc5RCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxFQUFFO0NBQ3JELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLEVBQUU7Q0FDbkQsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsR0FBRztDQUNwRCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxHQUFHO0NBQ3BELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLE1BQU07Q0FDckQsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsS0FBSztDQUV4RCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxJQUFJOztDQUdyRCxNQUFNLG1CQUFtQixZQUFZLE9BQU8sUUFBUSxZQUFZLFFBQVEsZUFBZTtFQUNyRixzQkFBc0IsSUFBSTtFQUMxQixJQUFJO0dBQ0YsTUFBTSxTQUFTLENBQUM7R0FDaEIsSUFBSSxPQUFPLE9BQU8sY0FBYztHQUNoQyxJQUFJLE9BQU8sT0FBTyxjQUFjO0dBQ2hDLE1BQU0sRUFBRSxTQUFTLE1BQU0sSUFBSSxJQUFJLDJCQUEyQixFQUFFLE9BQU8sQ0FBQztHQUNwRSxlQUFlLElBQUk7RUFDckIsUUFBUTtHQUNOLGdCQUFnQjtJQUFFLE1BQU07SUFBUyxLQUFLO0dBQWtELENBQUM7RUFDM0YsVUFBVTtHQUNSLHNCQUFzQixLQUFLO0VBQzdCO0NBQ0YsR0FBRyxDQUFDLFlBQVksVUFBVSxDQUFDOztDQUczQixNQUFNLFlBQVksWUFBWSxZQUFZO0VBQ3hDLFdBQVcsSUFBSTtFQUNmLElBQUk7R0FDRixNQUFNLFNBQVMsQ0FBQztHQUNoQixJQUFJLFlBQVksT0FBTyxjQUFjO0dBQ3JDLElBQUksWUFBWSxPQUFPLGNBQWM7R0FFckMsTUFBTSxDQUFDLEVBQUUsTUFBTSxTQUFTLEVBQUUsTUFBTSxXQUFXLE1BQU0sUUFBUSxJQUFJLENBQzNELElBQUksSUFBSSxzQkFBc0IsR0FDOUIsSUFBSSxJQUFJLDJCQUEyQixFQUFFLE9BQU8sQ0FBQyxDQUMvQyxDQUFDO0dBQ0QsWUFBWSxLQUFLO0dBQ2pCLGVBQWUsS0FBSztFQUN0QixRQUFRO0dBQ04sZ0JBQWdCO0lBQUUsTUFBTTtJQUFTLEtBQUs7R0FBMkMsQ0FBQztFQUNwRixVQUFVO0dBQ1IsV0FBVyxLQUFLO0VBQ2xCO0NBQ0YsR0FBRyxDQUFDLFlBQVksVUFBVSxDQUFDO0NBRTNCLGdCQUFnQjtFQUNkLFVBQVU7Q0FDWixHQUFHLENBQUMsU0FBUyxDQUFDOztDQUdkLE1BQU0sdUJBQXVCLE1BQU07RUFDakMsSUFBSSxHQUFHLEVBQUUsZUFBZTtFQUN4QixpQkFBaUIsWUFBWSxVQUFVO0NBQ3pDO0NBRUEsTUFBTSxrQ0FBa0M7RUFDdEMsY0FBYyxFQUFFO0VBQ2hCLGNBQWMsRUFBRTtFQUNoQixpQkFBaUIsSUFBSSxFQUFFO0NBQ3pCOztDQUdBLE1BQU0sc0JBQXNCLFNBQVMsTUFBTSxNQUFNLEVBQUUsVUFBVSxlQUFlOztDQUc1RSxNQUFNLDRCQUE0QixPQUFPLE1BQU07RUFDN0MsRUFBRSxlQUFlO0VBQ2pCLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxzQkFBc0IsV0FBVyxrQkFBa0IsS0FBSyxHQUFHO0dBQ2xGLGdCQUFnQjtJQUFFLE1BQU07SUFBUyxLQUFLO0dBQXNELENBQUM7R0FDN0Y7RUFDRjtFQUVBLE1BQU0sY0FBYyxXQUFXLGtCQUFrQjs7RUFHakQsS0FDRyxtQkFBbUIsa0JBQWtCLG1CQUFtQixZQUN6RCx1QkFDQSxjQUFjLFdBQVcsb0JBQW9CLFlBQVksR0FDekQ7R0FDQSxnQkFBZ0I7SUFDZCxNQUFNO0lBQ04sS0FBSywwQ0FBMEMsb0JBQW9CLE9BQU8sTUFBTSxXQUFXLG9CQUFvQixZQUFZLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxHQUFHLG9CQUFvQjtHQUNqSyxDQUFDO0dBQ0Q7RUFDRjtFQUVBLG9CQUFvQixJQUFJO0VBQ3hCLElBQUk7R0FDRixNQUFNLEVBQUUsU0FBUyxNQUFNLElBQUksS0FBSywyQkFBMkI7SUFDekQsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixVQUFVO0lBQ1YsZUFBZSx3QkFBd0IsS0FBSyxLQUFLO0lBQ2pELFlBQVksU0FBUyxTQUFTLGNBQWM7R0FDOUMsQ0FBQztHQUNELGdCQUFnQjtJQUFFLE1BQU07SUFBVyxLQUFLLEtBQUssS0FBSztHQUFVLENBQUM7R0FDN0QsdUJBQXVCLEtBQUs7R0FDNUIsbUJBQW1CLEVBQUU7R0FDckIsc0JBQXNCLEVBQUU7R0FDeEIsMkJBQTJCLEVBQUU7R0FDN0Isa0JBQWtCLFFBQVE7R0FDMUIsVUFBVTtFQUNaLFNBQVMsS0FBSztHQUNaLE1BQU0sTUFBTSxJQUFJLFVBQVUsTUFBTSxVQUFVO0dBQzFDLGdCQUFnQjtJQUFFLE1BQU07SUFBUyxLQUFLLEtBQUs7R0FBTSxDQUFDO0VBQ3BELFVBQVU7R0FDUixvQkFBb0IsS0FBSztHQUN6QixpQkFBaUIsZ0JBQWdCLElBQUksR0FBRyxHQUFJO0VBQzlDO0NBQ0Y7Q0FFQSxNQUFNLHFCQUFxQixPQUFPLE1BQU07RUFDdEMsRUFBRSxlQUFlO0VBQ2pCLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxnQkFBZ0IsQ0FBQyxjQUFjO0dBQ3BELGdCQUFnQjtJQUFFLE1BQU07SUFBUyxLQUFLO0dBQXVDLENBQUM7R0FDOUU7RUFDRjtFQUVBLGlCQUFpQixJQUFJO0VBQ3JCLElBQUk7R0FDRixNQUFNLEVBQUUsU0FBUyxNQUFNLElBQUksS0FBSyx3QkFBd0I7SUFDdEQsUUFBUTtJQUNSLE9BQU87SUFDUCxlQUFlO0lBQ2YsY0FBYyxXQUFXLFlBQVksS0FBSztJQUMxQyxjQUFjLFdBQVcsV0FBVyxLQUFLO0dBQzNDLENBQUM7R0FDRCxnQkFBZ0I7SUFBRSxNQUFNO0lBQVcsS0FBSyxLQUFLLEtBQUs7R0FBVSxDQUFDO0dBQzdELG9CQUFvQixLQUFLO0dBQ3pCLGlCQUFpQixFQUFFO0dBQ25CLGdCQUFnQixFQUFFO0dBQ2xCLGdCQUFnQixHQUFHO0dBQ25CLGdCQUFnQixHQUFHO0dBQ25CLGVBQWUsTUFBTTtHQUNyQixVQUFVO0VBQ1osU0FBUyxLQUFLO0dBQ1osTUFBTSxNQUFNLElBQUksVUFBVSxNQUFNLFVBQVU7R0FDMUMsZ0JBQWdCO0lBQUUsTUFBTTtJQUFTLEtBQUssS0FBSztHQUFNLENBQUM7RUFDcEQsVUFBVTtHQUNSLGlCQUFpQixLQUFLO0dBQ3RCLGlCQUFpQixnQkFBZ0IsSUFBSSxHQUFHLEdBQUk7RUFDOUM7Q0FDRjtDQUVBLE1BQU0sYUFBYSxLQUFLLEtBQUssWUFBWSxTQUFTLGNBQWMsS0FBSztDQUNyRSxNQUFNLG1CQUFtQixLQUFLLElBQUksS0FBSyxJQUFJLGFBQWEsQ0FBQyxHQUFHLFVBQVU7Q0FDdEUsTUFBTSxjQUFjLG1CQUFtQixLQUFLO0NBQzVDLE1BQU0sV0FBVyxLQUFLLElBQUksYUFBYSxnQkFBZ0IsWUFBWSxNQUFNO0NBQ3pFLE1BQU0sdUJBQXVCLFlBQVksTUFBTSxZQUFZLFFBQVE7Q0FFbkUsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUNFLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFpRTtNQUFtQjs7Ozs7TUFDakcsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQW9EO01BQW9DOzs7OztNQUN0Ryx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBb0Q7TUFBbUQ7Ozs7O0tBQ2pIOzs7O2VBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsVUFBRDtPQUNFLGVBQWUsdUJBQXVCLElBQUk7T0FDMUMsV0FBVTtpQkFGWixDQUlFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO1FBQVUsTUFBSztRQUFPLFFBQU87UUFBZSxTQUFRO2tCQUNqRSx3QkFBQyxRQUFEO1NBQU0sZUFBYztTQUFRLGdCQUFlO1NBQVEsYUFBWTtTQUFNLEdBQUU7UUFBa0I7Ozs7O09BQ3RGOzs7O2lCQUFDLHNCQUVBOzs7Ozs7S0FDTDs7OzthQUNGOzs7Ozs7R0FDRjs7Ozs7R0FHSixnQkFDQyx3QkFBQyxPQUFEO0lBQUssV0FBVyx1R0FBdUcsYUFBYSxTQUFTLFlBQVksNkRBQTZEO2NBQ25OLGFBQWE7R0FDWDs7Ozs7R0FJUCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNaLFNBQVMsS0FBSyxNQUFNO0tBQ25CLE1BQU0sWUFBWSxXQUFXLEVBQUUsWUFBWSxLQUFLLFdBQVcsRUFBRSxZQUFZO0tBQ3pFLE9BQ0Usd0JBQUMsT0FBRDtNQUF3QixXQUFVO2dCQUFsQyxDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFpRixFQUFFO09BQVk7Ozs7aUJBQy9HLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUEyRCxFQUFFO09BQVc7Ozs7ZUFDbkY7Ozs7aUJBQ0wsd0JBQUMsUUFBRDtRQUFNLFdBQVcsOENBQThDLFlBQVksaUVBQWlFO2tCQUN6SSxZQUFZLGVBQWU7T0FDeEI7Ozs7ZUFDSDs7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQXNELFdBQVcsRUFBRSxZQUFZLENBQUMsQ0FBQyxRQUFRLENBQUM7T0FBUTs7OztpQkFDbEgsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQTZDLEVBQUU7T0FBb0I7Ozs7ZUFDaEY7Ozs7aUJBQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FBK0Q7U0FDcEQsV0FBVyxFQUFFLFlBQVksQ0FBQyxDQUFDLFFBQVEsQ0FBQztTQUFFO1NBQUUsRUFBRTtRQUNoRDs7Ozs7ZUFDRjs7Ozs7Y0FDRjtRQXBCSyxFQUFFOzs7O1lBb0JQO0lBRVQsQ0FBQztHQUNFOzs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFtRDtPQUEwQzs7OztpQkFDM0csd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQXlCO09BQStDOzs7O2VBQ2xGOzs7O2lCQUdMLHdCQUFDLFFBQUQ7UUFBTSxVQUFVO1FBQXFCLFdBQVU7a0JBQS9DO1NBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBMkQ7VUFBYTs7OztvQkFDekYsd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxPQUFPO1dBQ1AsV0FBVyxNQUFNLGNBQWMsRUFBRSxPQUFPLEtBQUs7V0FDN0MsV0FBVTtVQUNYOzs7O2tCQUNFOzs7Ozs7U0FFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUEyRDtVQUFhOzs7O29CQUN6Rix3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLE9BQU87V0FDUCxXQUFXLE1BQU0sY0FBYyxFQUFFLE9BQU8sS0FBSztXQUM3QyxXQUFVO1VBQ1g7Ozs7a0JBQ0U7Ozs7OztTQUVMLHdCQUFDLFVBQUQ7VUFDRSxNQUFLO1VBQ0wsV0FBVTtvQkFGWixDQUlFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO1dBQWMsTUFBSztXQUFPLFFBQU87V0FBZSxTQUFRO3FCQUNyRSx3QkFBQyxRQUFEO1lBQU0sZUFBYztZQUFRLGdCQUFlO1lBQVEsYUFBWTtZQUFNLEdBQUU7V0FBMko7Ozs7O1VBQy9OOzs7O29CQUFDLFNBRUE7Ozs7OztVQUVOLGNBQWMsZUFDZCx3QkFBQyxVQUFEO1VBQ0UsTUFBSztVQUNMLFNBQVM7VUFDVCxXQUFVO29CQUNYO1NBRU87Ozs7O1NBR1Ysd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQ0csWUFBWSxRQUFPLGdCQUNoQjs7Ozs7O1FBQ0Y7Ozs7O2VBQ0g7Ozs7OztPQUVILGNBQWMsZUFDZCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTTtRQUNZLGFBQWEsU0FBUyxlQUFlO1FBQUc7UUFBRSxhQUFhLFNBQVMsZUFBZTtPQUMzRjs7OztpQkFDTix3QkFBQyxVQUFEO1FBQ0UsU0FBUztRQUNULFdBQVU7a0JBQ1g7T0FFTzs7OztlQUNMOzs7Ozs7TUFHTixXQUFXLHFCQUNWLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUErQztNQUE0Qjs7OztpQkFDeEYsWUFBWSxXQUFXLElBQ3pCLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaLGNBQWMsYUFDWCxpRkFDQTtNQUNEOzs7O2lCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFqQixDQUNFLHdCQUFDLFNBQUQsWUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBZDtVQUNFLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUF3RTtVQUFnQjs7Ozs7VUFDdEcsd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQXdFO1VBQVc7Ozs7O1VBQ2pHLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFvRjtVQUFpQjs7Ozs7VUFDbkgsd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQW1GO1VBQVk7Ozs7O1VBQzdHLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFtRjtVQUFvQjs7Ozs7VUFDckgsd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQXdFO1VBQWlCOzs7OztTQUNyRzs7Ozs7aUJBQ0M7Ozs7a0JBQ1Asd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQ2QscUJBQXFCLEtBQUssR0FBRyxNQUFNO1VBQ2xDLE1BQU0sWUFBWSxFQUFFLDBCQUEwQjtVQUM5QyxNQUFNLFVBQ0osRUFBRSxpQkFBaUIsU0FDbEIsRUFBRSxxQkFBcUIsRUFBRSxrQkFBa0IsWUFBWSxDQUFDLENBQUMsU0FBUyxPQUFPO1VBQzVFLE1BQU0saUJBQ0osRUFBRSxpQkFBaUIsU0FDbEIsRUFBRSxxQkFBcUIsRUFBRSxrQkFBa0IsWUFBWSxDQUFDLENBQUMsU0FBUyxTQUFTO1VBRTlFLElBQUksYUFBYTtVQUNqQixJQUFJLGVBQWU7VUFDbkIsSUFBSSxnQkFBZ0I7VUFFcEIsSUFBSSxXQUFXO1dBQ2IsYUFBYTtXQUNiLGVBQWU7V0FDZixnQkFBZ0I7VUFDbEIsT0FBTyxJQUFJLFNBQVM7V0FDbEIsYUFBYTtXQUNiLGVBQWU7V0FDZixnQkFBZ0I7VUFDbEIsT0FBTyxJQUFJLGdCQUFnQjtXQUN6QixhQUFhO1dBQ2IsZUFBZTtXQUNmLGdCQUFnQjtVQUNsQjtVQUVBLE9BQ0Usd0JBQUMsTUFBRDtXQUEwQixXQUFXLElBQUksTUFBTSxJQUFJLCtCQUErQjtxQkFBbEY7WUFDRSx3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFDWCxFQUFFLGFBQWEsSUFBSSxLQUFLLEVBQUUsVUFBVSxDQUFDLENBQUMsZUFBZSxJQUFJO1lBQ3hEOzs7OztZQUNKLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUNYLEVBQUUsa0JBQWtCLEVBQUU7WUFDckI7Ozs7O1lBQ0osd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQ1osd0JBQUMsUUFBRDtjQUFNLFdBQVcsOENBQThDO3dCQUEvRDtlQUNHLEVBQUUsbUJBQW1CLEVBQUU7ZUFBc0I7ZUFBRyxFQUFFLHFCQUFxQixFQUFFO2VBQWE7Y0FDbkY7Ozs7OztZQUNKOzs7OztZQUNKLHdCQUFDLE1BQUQ7YUFBSSxXQUFXLDJDQUEyQzt1QkFBMUQ7Y0FDRztjQUFjLFdBQVcsRUFBRSxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUM7Y0FBRTtjQUFFLEVBQUU7YUFDbkQ7Ozs7OztZQUNKLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUFkO2NBQ0csV0FBVyxFQUFFLGdCQUFnQixDQUFDLENBQUMsUUFBUSxDQUFDO2NBQUU7Y0FBRSxFQUFFO2FBQzdDOzs7Ozs7WUFDSix3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFDWCxFQUFFLGlCQUFpQjtZQUNsQjs7Ozs7V0FDRjthQXJCSyxFQUFFOzs7O2lCQXFCUDtTQUVSLENBQUM7UUFDSTs7OztnQkFDRjs7Ozs7O01BQ0o7Ozs7O01BSU4sWUFBWSxTQUFTLEtBQ3BCLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FBd0U7U0FDNUQsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWdELGFBQWE7U0FBUTs7Ozs7U0FBQztTQUFHO1NBQ25HLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFnRDtTQUFlOzs7OztTQUFDO1NBQUk7U0FDcEYsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWdELFlBQVk7U0FBYTs7Ozs7U0FBQztRQUN2Rjs7Ozs7aUJBRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxVQUFEO1VBQ0UsTUFBSztVQUNMLGVBQWUsZ0JBQWdCLFNBQVMsS0FBSyxJQUFJLE9BQU8sR0FBRyxDQUFDLENBQUM7VUFDN0QsVUFBVSxvQkFBb0I7VUFDOUIsV0FBVTtVQUNWLE9BQU07b0JBTFIsQ0FPRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtXQUFVLE1BQUs7V0FBTyxRQUFPO1dBQWUsU0FBUTtxQkFDakUsd0JBQUMsUUFBRDtZQUFNLGVBQWM7WUFBUSxnQkFBZTtZQUFRLGFBQVk7WUFBTSxHQUFFO1dBQW1COzs7OztVQUN2Rjs7OztvQkFBQyxVQUVBOzs7Ozs7U0FFUix3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDYix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEI7WUFBdUU7WUFDN0Q7WUFBaUI7WUFBSztXQUMxQjs7Ozs7O1NBQ0g7Ozs7O1NBRUwsd0JBQUMsVUFBRDtVQUNFLE1BQUs7VUFDTCxlQUFlLGdCQUFnQixTQUFTLEtBQUssSUFBSSxPQUFPLEdBQUcsVUFBVSxDQUFDO1VBQ3RFLFVBQVUsb0JBQW9CO1VBQzlCLFdBQVU7VUFDVixPQUFNO29CQUxSLENBTUMsYUFFQyx3QkFBQyxPQUFEO1dBQUssV0FBVTtXQUFVLE1BQUs7V0FBTyxRQUFPO1dBQWUsU0FBUTtxQkFDakUsd0JBQUMsUUFBRDtZQUFNLGVBQWM7WUFBUSxnQkFBZTtZQUFRLGFBQVk7WUFBTSxHQUFFO1dBQWdCOzs7OztVQUNwRjs7OztrQkFDQzs7Ozs7O1FBQ0w7Ozs7O2VBQ0Y7Ozs7OztLQUVKOzs7Ozs7R0FDRjs7Ozs7R0FHSix1QkFDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBbUQ7TUFBd0I7Ozs7Z0JBQ3pGLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFnQztNQUF5Qzs7OztjQUNuRjs7OztnQkFDTCx3QkFBQyxVQUFEO09BQ0UsZUFBZSx1QkFBdUIsS0FBSztPQUMzQyxXQUFVO2lCQUNYO01BRU87Ozs7Y0FDTDs7Ozs7ZUFFTCx3QkFBQyxRQUFEO01BQU0sVUFBVTtNQUEyQixXQUFVO2dCQUFyRDtPQUVFLHdCQUFDLE9BQUQ7UUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBdUU7UUFFakY7Ozs7O1FBQ1Asd0JBQUMsVUFBRDtTQUNFLE9BQU87U0FDUCxXQUFXLE1BQU0sa0JBQWtCLEVBQUUsT0FBTyxLQUFLO1NBQ2pEO1NBQ0EsV0FBVTttQkFKWjtVQU1FLHdCQUFDLFVBQUQ7V0FBUSxPQUFNO1dBQVMsV0FBVTtxQkFBb0I7VUFBMEI7Ozs7O1VBQy9FLHdCQUFDLFVBQUQ7V0FBUSxPQUFNO1dBQWUsV0FBVTtxQkFBb0I7VUFBOEM7Ozs7O1VBQ3pHLHdCQUFDLFVBQUQ7V0FBUSxPQUFNO1dBQVEsV0FBVTtxQkFBb0I7VUFBb0M7Ozs7O1NBQ2xGOzs7Ozs7UUFDUix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBYjtVQUNHLG1CQUFtQixZQUFZO1VBQy9CLG1CQUFtQixrQkFBa0I7VUFDckMsbUJBQW1CLFdBQVc7U0FDOUI7Ozs7OztPQUNBOzs7OztPQUdMLHdCQUFDLE9BQUQ7UUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBdUU7UUFFakY7Ozs7O1FBQ1Asd0JBQUMsVUFBRDtTQUNFLE9BQU87U0FDUCxXQUFXLE1BQU0sbUJBQW1CLEVBQUUsT0FBTyxLQUFLO1NBQ2xEO1NBQ0EsV0FBVTttQkFKWixDQU1FLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO1VBQUcsV0FBVTtvQkFBb0I7U0FBZ0M7Ozs7bUJBQzlFLFNBQVMsS0FBSyxNQUNiLHdCQUFDLFVBQUQ7VUFBc0IsT0FBTyxFQUFFO1VBQU8sV0FBVTtvQkFBaEQ7V0FDRyxFQUFFO1dBQU87V0FBRyxFQUFFO1dBQWM7V0FBWSxXQUFXLEVBQUUsWUFBWSxDQUFDLENBQUMsUUFBUSxDQUFDO1dBQUU7V0FBRSxFQUFFO1VBQzdFO1lBRkssRUFBRTs7OztnQkFFUCxDQUNULENBQ0s7Ozs7OztRQUNQLHVCQUNDLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWlCO1NBQXVCOzs7O21CQUN4RCx3QkFBQyxRQUFEO1VBQU0sV0FBVyxhQUFhLFdBQVcsb0JBQW9CLFlBQVksS0FBSyxXQUFXLG9CQUFvQixZQUFZLElBQUksaUJBQWlCO29CQUE5STtXQUNHLFdBQVcsb0JBQW9CLFlBQVksQ0FBQyxDQUFDLFFBQVEsQ0FBQztXQUFFO1dBQUUsb0JBQW9CO1VBQzNFOzs7OztpQkFDSDs7Ozs7O09BRUo7Ozs7O09BR0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFqQjtTQUNHLG1CQUFtQixXQUNoQixzQkFDQSxtQkFBbUIsaUJBQ25CLHlCQUNBO1NBQXFCO1NBQ3hCLHNCQUFzQixJQUFJLG9CQUFvQixjQUFjLEtBQUs7UUFDN0Q7Ozs7O2lCQUNQLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsTUFBSztRQUNMLEtBQUk7UUFDSjtRQUNBLGFBQVk7UUFDWixPQUFPO1FBQ1AsV0FBVyxNQUFNLHNCQUFzQixFQUFFLE9BQU8sS0FBSztRQUNyRCxXQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7T0FHTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQXVFO09BRWpGOzs7O2lCQUNQLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsYUFDRSxtQkFBbUIsV0FDZiwyQ0FDQSxtQkFBbUIsaUJBQ25CLHdDQUNBO1FBRU4sT0FBTztRQUNQLFdBQVcsTUFBTSwyQkFBMkIsRUFBRSxPQUFPLEtBQUs7UUFDMUQsV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWUsdUJBQXVCLEtBQUs7U0FDM0MsV0FBVTttQkFDWDtRQUVPOzs7O2tCQUNSLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsVUFBVTtTQUNWLFdBQVcsK0ZBQ1QsbUJBQW1CLFdBQ2YscURBQ0EsbUJBQW1CLGlCQUNuQix3REFDQTttQkFHTCxtQkFDRyxpQkFDQSxtQkFBbUIsV0FDbkIsc0JBQ0EsbUJBQW1CLGlCQUNuQiwyQkFDQTtRQUNFOzs7O2dCQUNMOzs7Ozs7TUFDRDs7Ozs7YUFDSDs7Ozs7O0dBQ0Y7Ozs7O0dBSU4sb0JBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBbUQ7TUFBMkI7Ozs7Z0JBQzVGLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLG9CQUFvQixLQUFLO09BQ3hDLFdBQVU7aUJBQ1g7TUFFTzs7OztjQUNMOzs7OztlQUVMLHdCQUFDLFFBQUQ7TUFBTSxVQUFVO01BQW9CLFdBQVU7Z0JBQTlDO09BQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUF1RTtPQUF5Qjs7OztpQkFDakgsd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTDtRQUNBLGFBQVk7UUFDWixPQUFPO1FBQ1AsV0FBVyxNQUFNLGlCQUFpQixFQUFFLE9BQU8sS0FBSztRQUNoRCxXQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7T0FFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBdUU7UUFBbUI7Ozs7a0JBQzNHLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0w7U0FDQSxhQUFZO1NBQ1osT0FBTztTQUNQLFdBQVcsTUFBTSxnQkFBZ0IsRUFBRSxPQUFPLE1BQU0sWUFBWSxDQUFDO1NBQzdELFdBQVU7UUFDWDs7OztnQkFDRTs7OztrQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQXVFO1FBQW9COzs7O2tCQUM1Ryx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMO1NBQ0EsYUFBWTtTQUNaLE9BQU87U0FDUCxXQUFXLE1BQU0sZ0JBQWdCLEVBQUUsT0FBTyxLQUFLO1NBQy9DLFdBQVU7UUFDWDs7OztnQkFDRTs7OztnQkFDRjs7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQXVFO1FBQW9COzs7O2tCQUM1Ryx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLE1BQUs7U0FDTCxLQUFJO1NBQ0osT0FBTztTQUNQLFdBQVcsTUFBTSxnQkFBZ0IsRUFBRSxPQUFPLEtBQUs7U0FDL0MsV0FBVTtRQUNYOzs7O2dCQUNFOzs7O2tCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBdUU7UUFBMEI7Ozs7a0JBQ2xILHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsTUFBSztTQUNMLEtBQUk7U0FDSixPQUFPO1NBQ1AsV0FBVyxNQUFNLGVBQWUsRUFBRSxPQUFPLEtBQUs7U0FDOUMsV0FBVTtRQUNYOzs7O2dCQUNFOzs7O2dCQUNGOzs7Ozs7T0FFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsZUFBZSxvQkFBb0IsS0FBSztTQUN4QyxXQUFVO21CQUNYO1FBRU87Ozs7a0JBQ1Isd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxVQUFVO1NBQ1YsV0FBVTttQkFFVCxnQkFBZ0IsaUJBQWlCO1FBQzVCOzs7O2dCQUNMOzs7Ozs7TUFDRDs7Ozs7YUFDSDs7Ozs7O0dBQ0Y7Ozs7O0VBRUo7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VDYWxsYmFjayB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IGFwaSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9hcGknXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vY29udGV4dC9BdXRoQ29udGV4dCdcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSW52ZW50YXJpb1BhZ2UoKSB7XG4gIGNvbnN0IHsgc2Vzc2lvbiB9ID0gdXNlQXV0aCgpXG4gIGNvbnN0IFtxdWltaWNvcywgc2V0UXVpbWljb3NdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFttb3ZpbWllbnRvcywgc2V0TW92aW1pZW50b3NdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpXG4gIGNvbnN0IFtsb2FkaW5nTW92aW1pZW50b3MsIHNldExvYWRpbmdNb3ZpbWllbnRvc10gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW3Nob3dNb3ZpbWllbnRvTW9kYWwsIHNldFNob3dNb3ZpbWllbnRvTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtzaG93UXVpbWljb01vZGFsLCBzZXRTaG93UXVpbWljb01vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKVxuXG4gIC8vIEZpbHRyb3MgZGUgZmVjaGEgcGFyYSBlbCBoaXN0b3JpYWxcbiAgY29uc3QgW2ZlY2hhRGVzZGUsIHNldEZlY2hhRGVzZGVdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtmZWNoYUhhc3RhLCBzZXRGZWNoYUhhc3RhXSA9IHVzZVN0YXRlKCcnKVxuXG4gIC8vIFBhZ2luYWNpw7NuOiAyMCByZWdpc3Ryb3MgcG9yIHDDoWdpbmFcbiAgY29uc3QgW2N1cnJlbnRQYWdlLCBzZXRDdXJyZW50UGFnZV0gPSB1c2VTdGF0ZSgxKVxuICBjb25zdCBJVEVNU19QRVJfUEFHRSA9IDIwXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBzZXRDdXJyZW50UGFnZSgxKVxuICB9LCBbZmVjaGFEZXNkZSwgZmVjaGFIYXN0YSwgbW92aW1pZW50b3MubGVuZ3RoXSlcblxuICAvLyBGb3JtIG1vdmltaWVudG9cbiAgY29uc3QgW3RpcG9Nb3ZpbWllbnRvLCBzZXRUaXBvTW92aW1pZW50b10gPSB1c2VTdGF0ZSgnY29tcHJhJykgLy8gJ2NvbXByYScsICdkb3NpZmljYWNpb24nLCAnbWVybWEnXG4gIGNvbnN0IFtzZWxlY3RlZFF1aW1pY28sIHNldFNlbGVjdGVkUXVpbWljb10gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW2NhbnRpZGFkTW92aW1pZW50bywgc2V0Q2FudGlkYWRNb3ZpbWllbnRvXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbb2JzZXJ2YWNpb25lc01vdmltaWVudG8sIHNldE9ic2VydmFjaW9uZXNNb3ZpbWllbnRvXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbc2F2aW5nTW92aW1pZW50bywgc2V0U2F2aW5nTW92aW1pZW50b10gPSB1c2VTdGF0ZShmYWxzZSlcblxuICAvLyBGb3JtIG51ZXZvIHF1w61taWNvXG4gIGNvbnN0IFtub21icmVRdWltaWNvLCBzZXROb21icmVRdWltaWNvXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbc2lnbGFRdWltaWNvLCBzZXRTaWdsYVF1aW1pY29dID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFt1bmlkYWRNZWRpZGEsIHNldFVuaWRhZE1lZGlkYV0gPSB1c2VTdGF0ZSgnZycpXG4gIGNvbnN0IFtzdG9ja0luaWNpYWwsIHNldFN0b2NrSW5pY2lhbF0gPSB1c2VTdGF0ZSgnMCcpXG4gIGNvbnN0IFtzdG9ja01pbmltbywgc2V0U3RvY2tNaW5pbW9dID0gdXNlU3RhdGUoJzEwMDAnKVxuICBjb25zdCBbc2F2aW5nUXVpbWljbywgc2V0U2F2aW5nUXVpbWljb10gPSB1c2VTdGF0ZShmYWxzZSlcblxuICBjb25zdCBbbm90aWZpY2F0aW9uLCBzZXROb3RpZmljYXRpb25dID0gdXNlU3RhdGUobnVsbClcblxuICAvLyBDYXJnYSBzb2xvIGxvcyBtb3ZpbWllbnRvcyAocGFyYSBmaWx0cmFkbyBzaW4gcmVjYXJnYXIgdGFyamV0YXMgZGUgcXXDrW1pY29zKVxuICBjb25zdCBmZXRjaE1vdmltaWVudG9zID0gdXNlQ2FsbGJhY2soYXN5bmMgKGRlc2RlID0gZmVjaGFEZXNkZSwgaGFzdGEgPSBmZWNoYUhhc3RhKSA9PiB7XG4gICAgc2V0TG9hZGluZ01vdmltaWVudG9zKHRydWUpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHt9XG4gICAgICBpZiAoZGVzZGUpIHBhcmFtcy5mZWNoYV9kZXNkZSA9IGRlc2RlXG4gICAgICBpZiAoaGFzdGEpIHBhcmFtcy5mZWNoYV9oYXN0YSA9IGhhc3RhXG4gICAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IGFwaS5nZXQoJy9pbnZlbnRhcmlvL21vdmltaWVudG9zJywgeyBwYXJhbXMgfSlcbiAgICAgIHNldE1vdmltaWVudG9zKGRhdGEpXG4gICAgfSBjYXRjaCB7XG4gICAgICBzZXROb3RpZmljYXRpb24oeyB0eXBlOiAnZXJyb3InLCBtc2c6ICdFcnJvciBhbCBmaWx0cmFyIGxvcyBtb3ZpbWllbnRvcyBkZWwgaW52ZW50YXJpbycgfSlcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0TG9hZGluZ01vdmltaWVudG9zKGZhbHNlKVxuICAgIH1cbiAgfSwgW2ZlY2hhRGVzZGUsIGZlY2hhSGFzdGFdKVxuXG4gIC8vIENhcmdhIHF1w61taWNvcyB5IG1vdmltaWVudG9zIGluaWNpYWxlc1xuICBjb25zdCBmZXRjaERhdGEgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgc2V0TG9hZGluZyh0cnVlKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCBwYXJhbXMgPSB7fVxuICAgICAgaWYgKGZlY2hhRGVzZGUpIHBhcmFtcy5mZWNoYV9kZXNkZSA9IGZlY2hhRGVzZGVcbiAgICAgIGlmIChmZWNoYUhhc3RhKSBwYXJhbXMuZmVjaGFfaGFzdGEgPSBmZWNoYUhhc3RhXG5cbiAgICAgIGNvbnN0IFt7IGRhdGE6IHFEYXRhIH0sIHsgZGF0YTogbURhdGEgfV0gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgICAgIGFwaS5nZXQoJy9pbnZlbnRhcmlvL3F1aW1pY29zJyksXG4gICAgICAgIGFwaS5nZXQoJy9pbnZlbnRhcmlvL21vdmltaWVudG9zJywgeyBwYXJhbXMgfSksXG4gICAgICBdKVxuICAgICAgc2V0UXVpbWljb3MocURhdGEpXG4gICAgICBzZXRNb3ZpbWllbnRvcyhtRGF0YSlcbiAgICB9IGNhdGNoIHtcbiAgICAgIHNldE5vdGlmaWNhdGlvbih7IHR5cGU6ICdlcnJvcicsIG1zZzogJ0Vycm9yIGFsIGNhcmdhciBsb3MgZGF0b3MgZGVsIGludmVudGFyaW8nIH0pXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpXG4gICAgfVxuICB9LCBbZmVjaGFEZXNkZSwgZmVjaGFIYXN0YV0pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBmZXRjaERhdGEoKVxuICB9LCBbZmV0Y2hEYXRhXSlcblxuICAvLyBGaWx0cmFkbyBkZSBmZWNoYXNcbiAgY29uc3QgaGFuZGxlRmlsdHJhckZlY2hhcyA9IChlKSA9PiB7XG4gICAgaWYgKGUpIGUucHJldmVudERlZmF1bHQoKVxuICAgIGZldGNoTW92aW1pZW50b3MoZmVjaGFEZXNkZSwgZmVjaGFIYXN0YSlcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUxpbXBpYXJGaWx0cm9GZWNoYXMgPSAoKSA9PiB7XG4gICAgc2V0RmVjaGFEZXNkZSgnJylcbiAgICBzZXRGZWNoYUhhc3RhKCcnKVxuICAgIGZldGNoTW92aW1pZW50b3MoJycsICcnKVxuICB9XG5cbiAgLy8gUXXDrW1pY28gYWN0dWFsbWVudGUgc2VsZWNjaW9uYWRvIGVuIGVsIG1vZGFsXG4gIGNvbnN0IHNlbGVjdGVkUXVpbWljb0luZm8gPSBxdWltaWNvcy5maW5kKChxKSA9PiBxLnNpZ2xhID09PSBzZWxlY3RlZFF1aW1pY28pXG5cbiAgLy8gUmVnaXN0cmFyIE1vdmltaWVudG8gKENvbXByYSwgRG9zaWZpY2FjacOzbiBvIE1lcm1hKVxuICBjb25zdCBoYW5kbGVSZWdpc3RyYXJNb3ZpbWllbnRvID0gYXN5bmMgKGUpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBpZiAoIXNlbGVjdGVkUXVpbWljbyB8fCAhY2FudGlkYWRNb3ZpbWllbnRvIHx8IHBhcnNlRmxvYXQoY2FudGlkYWRNb3ZpbWllbnRvKSA8PSAwKSB7XG4gICAgICBzZXROb3RpZmljYXRpb24oeyB0eXBlOiAnZXJyb3InLCBtc2c6ICdTZWxlY2Npb25lIHVuIHF1w61taWNvIGUgaW5ncmVzZSB1bmEgY2FudGlkYWQgdsOhbGlkYScgfSlcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIGNvbnN0IGNhbnRpZGFkTnVtID0gcGFyc2VGbG9hdChjYW50aWRhZE1vdmltaWVudG8pXG5cbiAgICAvLyBWYWxpZGFjacOzbiBwcmV2ZW50aXZhIGVuIGZyb250ZW5kIGRlIHN0b2NrIHN1ZmljaWVudGUgcGFyYSBzYWxpZGFzXG4gICAgaWYgKFxuICAgICAgKHRpcG9Nb3ZpbWllbnRvID09PSAnZG9zaWZpY2FjaW9uJyB8fCB0aXBvTW92aW1pZW50byA9PT0gJ21lcm1hJykgJiZcbiAgICAgIHNlbGVjdGVkUXVpbWljb0luZm8gJiZcbiAgICAgIGNhbnRpZGFkTnVtID4gcGFyc2VGbG9hdChzZWxlY3RlZFF1aW1pY29JbmZvLnN0b2NrX2FjdHVhbClcbiAgICApIHtcbiAgICAgIHNldE5vdGlmaWNhdGlvbih7XG4gICAgICAgIHR5cGU6ICdlcnJvcicsXG4gICAgICAgIG1zZzogYFN0b2NrIGluc3VmaWNpZW50ZTogZWwgc3RvY2sgYWN0dWFsIGRlICR7c2VsZWN0ZWRRdWltaWNvSW5mby5ub21icmV9IGVzICR7cGFyc2VGbG9hdChzZWxlY3RlZFF1aW1pY29JbmZvLnN0b2NrX2FjdHVhbCkudG9GaXhlZCgxKX0gJHtzZWxlY3RlZFF1aW1pY29JbmZvLnVuaWRhZF9tZWRpZGF9YCxcbiAgICAgIH0pXG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBzZXRTYXZpbmdNb3ZpbWllbnRvKHRydWUpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXBpLnBvc3QoJy9pbnZlbnRhcmlvL21vdmltaWVudG9zJywge1xuICAgICAgICBzaWdsYV9xdWltaWNvOiBzZWxlY3RlZFF1aW1pY28sXG4gICAgICAgIHRpcG9fbW92aW1pZW50bzogdGlwb01vdmltaWVudG8sXG4gICAgICAgIGNhbnRpZGFkOiBjYW50aWRhZE51bSxcbiAgICAgICAgb2JzZXJ2YWNpb25lczogb2JzZXJ2YWNpb25lc01vdmltaWVudG8udHJpbSgpIHx8IG51bGwsXG4gICAgICAgIGlkX3VzdWFyaW86IHNlc3Npb24/LnVzdWFyaW8/LmlkX3VzdWFyaW8gfHwgbnVsbCxcbiAgICAgIH0pXG4gICAgICBzZXROb3RpZmljYXRpb24oeyB0eXBlOiAnc3VjY2VzcycsIG1zZzogYOKckyAke2RhdGEubWVuc2FqZX1gIH0pXG4gICAgICBzZXRTaG93TW92aW1pZW50b01vZGFsKGZhbHNlKVxuICAgICAgc2V0U2VsZWN0ZWRRdWltaWNvKCcnKVxuICAgICAgc2V0Q2FudGlkYWRNb3ZpbWllbnRvKCcnKVxuICAgICAgc2V0T2JzZXJ2YWNpb25lc01vdmltaWVudG8oJycpXG4gICAgICBzZXRUaXBvTW92aW1pZW50bygnY29tcHJhJylcbiAgICAgIGZldGNoRGF0YSgpXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zdCBtc2cgPSBlcnIucmVzcG9uc2U/LmRhdGE/LmRldGFpbCB8fCAnRXJyb3IgYWwgcmVnaXN0cmFyIGVsIG1vdmltaWVudG8nXG4gICAgICBzZXROb3RpZmljYXRpb24oeyB0eXBlOiAnZXJyb3InLCBtc2c6IGDinJcgJHttc2d9YCB9KVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRTYXZpbmdNb3ZpbWllbnRvKGZhbHNlKVxuICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXROb3RpZmljYXRpb24obnVsbCksIDQwMDApXG4gICAgfVxuICB9XG5cbiAgY29uc3QgaGFuZGxlQ3JlYXJRdWltaWNvID0gYXN5bmMgKGUpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBpZiAoIW5vbWJyZVF1aW1pY28gfHwgIXNpZ2xhUXVpbWljbyB8fCAhdW5pZGFkTWVkaWRhKSB7XG4gICAgICBzZXROb3RpZmljYXRpb24oeyB0eXBlOiAnZXJyb3InLCBtc2c6ICdDb21wbGV0ZSB0b2RvcyBsb3MgY2FtcG9zIHJlcXVlcmlkb3MnIH0pXG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBzZXRTYXZpbmdRdWltaWNvKHRydWUpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXBpLnBvc3QoJy9pbnZlbnRhcmlvL3F1aW1pY29zJywge1xuICAgICAgICBub21icmU6IG5vbWJyZVF1aW1pY28sXG4gICAgICAgIHNpZ2xhOiBzaWdsYVF1aW1pY28sXG4gICAgICAgIHVuaWRhZF9tZWRpZGE6IHVuaWRhZE1lZGlkYSxcbiAgICAgICAgc3RvY2tfYWN0dWFsOiBwYXJzZUZsb2F0KHN0b2NrSW5pY2lhbCkgfHwgMCxcbiAgICAgICAgc3RvY2tfbWluaW1vOiBwYXJzZUZsb2F0KHN0b2NrTWluaW1vKSB8fCAwLFxuICAgICAgfSlcbiAgICAgIHNldE5vdGlmaWNhdGlvbih7IHR5cGU6ICdzdWNjZXNzJywgbXNnOiBg4pyTICR7ZGF0YS5tZW5zYWplfWAgfSlcbiAgICAgIHNldFNob3dRdWltaWNvTW9kYWwoZmFsc2UpXG4gICAgICBzZXROb21icmVRdWltaWNvKCcnKVxuICAgICAgc2V0U2lnbGFRdWltaWNvKCcnKVxuICAgICAgc2V0VW5pZGFkTWVkaWRhKCdnJylcbiAgICAgIHNldFN0b2NrSW5pY2lhbCgnMCcpXG4gICAgICBzZXRTdG9ja01pbmltbygnMTAwMCcpXG4gICAgICBmZXRjaERhdGEoKVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc3QgbXNnID0gZXJyLnJlc3BvbnNlPy5kYXRhPy5kZXRhaWwgfHwgJ0Vycm9yIGFsIHJlZ2lzdHJhciBlbCBxdcOtbWljbydcbiAgICAgIHNldE5vdGlmaWNhdGlvbih7IHR5cGU6ICdlcnJvcicsIG1zZzogYOKclyAke21zZ31gIH0pXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFNhdmluZ1F1aW1pY28oZmFsc2UpXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldE5vdGlmaWNhdGlvbihudWxsKSwgNDAwMClcbiAgICB9XG4gIH1cblxuICBjb25zdCB0b3RhbFBhZ2VzID0gTWF0aC5jZWlsKG1vdmltaWVudG9zLmxlbmd0aCAvIElURU1TX1BFUl9QQUdFKSB8fCAxXG4gIGNvbnN0IHZhbGlkQ3VycmVudFBhZ2UgPSBNYXRoLm1pbihNYXRoLm1heChjdXJyZW50UGFnZSwgMSksIHRvdGFsUGFnZXMpXG4gIGNvbnN0IHN0YXJ0SW5kZXggPSAodmFsaWRDdXJyZW50UGFnZSAtIDEpICogSVRFTVNfUEVSX1BBR0VcbiAgY29uc3QgZW5kSW5kZXggPSBNYXRoLm1pbihzdGFydEluZGV4ICsgSVRFTVNfUEVSX1BBR0UsIG1vdmltaWVudG9zLmxlbmd0aClcbiAgY29uc3QgcGFnaW5hdGVkTW92aW1pZW50b3MgPSBtb3ZpbWllbnRvcy5zbGljZShzdGFydEluZGV4LCBlbmRJbmRleClcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLXNsYXRlLTUwIHBiLTEyIGRhcms6YmctWyMxQTIyMkNdXCI+XG4gICAgICB7Lyog4pSA4pSAIEhlYWRlciDilIDilIAgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIHB4LTYgcHktNiBzaGFkb3ctc21cIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy02eGwgbXgtYXV0byBmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRyYWNraW5nLXdpZGVzdCB1cHBlcmNhc2UgdGV4dC1ibHVlLTUwMCBtYi0xXCI+TcOzZHVsbyBPcGVyYXRpdm88L3A+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZVwiPkludmVudGFyaW8gZGUgUXXDrW1pY29zIGUgSW5zdW1vczwvaDE+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgbXQtMC41XCI+Q29udHJvbCBkZSBleGlzdGVuY2lhcyB5IHJlZ2lzdHJvIGRlIG1vdmltaWVudG9zPC9wPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TW92aW1pZW50b01vZGFsKHRydWUpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBiZy1ibHVlLTYwMCBob3ZlcjpiZy1ibHVlLTcwMCB0ZXh0LXdoaXRlIHB4LTUgcHktMi41IHJvdW5kZWQteGwgZm9udC1ib2xkIHRleHQtc20gc2hhZG93LW1kIHNoYWRvdy1ibHVlLTUwMC8yMCBhY3RpdmU6c2NhbGUtOTUgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNSBoLTVcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyLjVcIiBkPVwiTTEyIDR2MTZtOC04SDRcIiAvPlxuICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgUmVnaXN0cmFyIE1vdmltaWVudG9cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7Lyog4pSA4pSAIE5vdGlmaWNhY2nDs24g4pSA4pSAICovfVxuICAgICAge25vdGlmaWNhdGlvbiAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgbWF4LXctNnhsIG14LWF1dG8gcHgtNCBweS0zIG10LTQgcm91bmRlZC14bCBmb250LXNlbWlib2xkIHRleHQtc20gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgc2hhZG93LW1kICR7bm90aWZpY2F0aW9uLnR5cGUgPT09ICdzdWNjZXNzJyA/ICdiZy1lbWVyYWxkLTUwIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDAgdGV4dC1lbWVyYWxkLTcwMCcgOiAnYmctcmVkLTUwIGJvcmRlciBib3JkZXItcmVkLTIwMCB0ZXh0LXJlZC03MDAnfWB9PlxuICAgICAgICAgIHtub3RpZmljYXRpb24ubXNnfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiDilIDilIAgVGFyamV0YXMgZGUgU3RvY2sgZGUgUXXDrW1pY29zIOKUgOKUgCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctNnhsIG14LWF1dG8gcHgtNiBtdC02IGdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTVcIj5cbiAgICAgICAge3F1aW1pY29zLm1hcCgocSkgPT4ge1xuICAgICAgICAgIGNvbnN0IGJham9TdG9jayA9IHBhcnNlRmxvYXQocS5zdG9ja19hY3R1YWwpIDw9IHBhcnNlRmxvYXQocS5zdG9ja19taW5pbW8pXG4gICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxkaXYga2V5PXtxLmlkX3F1aW1pY299IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIHAtNiByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gc2hhZG93LXNtIHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+e3Euc2lnbGF9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZSBtdC0wLjVcIj57cS5ub21icmV9PC9oMz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yLjUgcHktMSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LWJvbGQgJHtiYWpvU3RvY2sgPyAnYmctcmVkLTEwMCB0ZXh0LXJlZC03MDAgZGFyazpiZy1yZWQtOTAwLzMwIGRhcms6dGV4dC1yZWQtNDAwJyA6ICdiZy1lbWVyYWxkLTEwMCB0ZXh0LWVtZXJhbGQtNzAwIGRhcms6YmctZW1lcmFsZC05MDAvMzAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwJ31gfT5cbiAgICAgICAgICAgICAgICAgIHtiYWpvU3RvY2sgPyAnU3RvY2sgQmFqbycgOiAnTm9ybWFsJ31cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBmbGV4IGl0ZW1zLWJhc2VsaW5lIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJsYWNrIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZVwiPntwYXJzZUZsb2F0KHEuc3RvY2tfYWN0dWFsKS50b0ZpeGVkKDEpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTEgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNDAwXCI+e3EudW5pZGFkX21lZGlkYX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0IHRleHQteHMgdGV4dC1zbGF0ZS00MDAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgIE3DrW5pbW86IHtwYXJzZUZsb2F0KHEuc3RvY2tfbWluaW1vKS50b0ZpeGVkKDEpfSB7cS51bmlkYWRfbWVkaWRhfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIClcbiAgICAgICAgfSl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIOKUgOKUgCBIaXN0b3JpYWwgZGUgTW92aW1pZW50b3MgZGUgSW52ZW50YXJpbyDilIDilIAgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTZ4bCBteC1hdXRvIHB4LTYgbXQtOFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBzaGFkb3ctc20gb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IHB4LTYgcHktNSBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXVwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWxnIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZVwiPkhpc3RvcmlhbCBkZSBNb3ZpbWllbnRvcyBkZSBJbnZlbnRhcmlvPC9oMj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPkVudHJhZGFzIHBvciBjb21wcmEsIGRvc2lmaWNhY2lvbmVzIHkgbWVybWFzPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiDilIDilIAgQmFycmEgZGUgRmlsdHJhZG8gcG9yIEZlY2hhcyDilIDilIAgKi99XG4gICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlRmlsdHJhckZlY2hhc30gY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYmctc2xhdGUtNTAgZGFyazpiZy1bIzFBMjIyQ10gcHgtMyBweS0xLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV1cIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5EZXNkZTo8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2ZlY2hhRGVzZGV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZlY2hhRGVzZGUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctdHJhbnNwYXJlbnQgdGV4dC14cyB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIG91dGxpbmUtbm9uZVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBiZy1zbGF0ZS01MCBkYXJrOmJnLVsjMUEyMjJDXSBweC0zIHB5LTEuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXVwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPkhhc3RhOjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17ZmVjaGFIYXN0YX1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RmVjaGFIYXN0YShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy10cmFuc3BhcmVudCB0ZXh0LXhzIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgb3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTIgYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS03MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsIHNoYWRvdy1zbSBhY3RpdmU6c2NhbGUtOTVcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxuICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMi41XCIgZD1cIk0zIDRhMSAxIDAgMDExLTFoMTZhMSAxIDAgMDExIDF2Mi41ODZhMSAxIDAgMDEtLjI5My43MDdsLTYuNDE0IDYuNDE0YTEgMSAwIDAwLS4yOTMuNzA3VjE3bC00IDR2LTYuNTg2YTEgMSAwIDAwLS4yOTMtLjcwN0wzLjI5MyA3LjI5M0ExIDEgMCAwMTMgNi41ODZWNHpcIiAvPlxuICAgICAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgICAgIEZpbHRyYXJcbiAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgeyhmZWNoYURlc2RlIHx8IGZlY2hhSGFzdGEpICYmIChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUxpbXBpYXJGaWx0cm9GZWNoYXN9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBweC0zIHB5LTIgYmctc2xhdGUtMTAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmJnLXNsYXRlLTgwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIOKclSBMaW1waWFyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNDAwIG1sLTFcIj5cbiAgICAgICAgICAgICAgICB7bW92aW1pZW50b3MubGVuZ3RofSBtb3ZpbWllbnRvKHMpXG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsoZmVjaGFEZXNkZSB8fCBmZWNoYUhhc3RhKSAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJsdWUtNTAvNTAgZGFyazpiZy1ibHVlLTk1MC8yMCBweC02IHB5LTIgYm9yZGVyLWIgYm9yZGVyLWJsdWUtMTAwIGRhcms6Ym9yZGVyLWJsdWUtOTAwLzMwIHRleHQteHMgdGV4dC1ibHVlLTcwMCBkYXJrOnRleHQtYmx1ZS0zMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgIEZpbHRybyBhY3Rpdm86IHtmZWNoYURlc2RlID8gYGRlc2RlICR7ZmVjaGFEZXNkZX1gIDogJyd9IHtmZWNoYUhhc3RhID8gYGhhc3RhICR7ZmVjaGFIYXN0YX1gIDogJyd9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUxpbXBpYXJGaWx0cm9GZWNoYXN9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidW5kZXJsaW5lIGhvdmVyOnRleHQtYmx1ZS05MDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIFZlciB0b2RvIGVsIGhpc3RvcmlhbFxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7bG9hZGluZyB8fCBsb2FkaW5nTW92aW1pZW50b3MgPyAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTEyIHRleHQtc2xhdGUtNDAwIGZvbnQtbWVkaXVtXCI+Q2FyZ2FuZG8gbW92aW1pZW50b3MuLi48L2Rpdj5cbiAgICAgICAgICApIDogbW92aW1pZW50b3MubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMiB0ZXh0LXNsYXRlLTQwMCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICB7ZmVjaGFEZXNkZSB8fCBmZWNoYUhhc3RhXG4gICAgICAgICAgICAgICAgPyAnTm8gc2UgZW5jb250cmFyb24gbW92aW1pZW50b3MgcmVnaXN0cmFkb3MgZW4gZWwgcmFuZ28gZGUgZmVjaGFzIHNlbGVjY2lvbmFkbydcbiAgICAgICAgICAgICAgICA6ICdObyBoYXkgbW92aW1pZW50b3MgcmVnaXN0cmFkb3MgZGUgaW5zdW1vcyd9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnRcIj5cbiAgICAgICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYmctc2xhdGUtNTAgZGFyazpiZy1bIzFBMjIyQ10gYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV1cIj5cbiAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTUgcHktMy41IHRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMFwiPkZlY2hhIHkgSG9yYTwvdGg+XG4gICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC01IHB5LTMuNSB0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDBcIj5RdcOtbWljbzwvdGg+XG4gICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC01IHB5LTMuNSB0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgdGV4dC1jZW50ZXJcIj5UaXBvIC8gT3JpZ2VuPC90aD5cbiAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTUgcHktMy41IHRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMCB0ZXh0LXJpZ2h0XCI+Q2FudGlkYWQ8L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNSBweS0zLjUgdGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwIHRleHQtcmlnaHRcIj5TdG9jayBSZXN1bHRhbnRlPC90aD5cbiAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTUgcHktMy41IHRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMFwiPk9ic2VydmFjaW9uZXM8L3RoPlxuICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtMTAwIGRhcms6ZGl2aWRlLVsjMzEzRDRBXVwiPlxuICAgICAgICAgICAgICAgICAge3BhZ2luYXRlZE1vdmltaWVudG9zLm1hcCgobSwgaSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0VudHJhZGEgPSBtLnNpZ2xhX3RpcG9fbW92aW1pZW50byA9PT0gJ0VOVCdcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNNZXJtYSA9XG4gICAgICAgICAgICAgICAgICAgICAgbS5zaWdsYV9vcmlnZW4gPT09ICdNRVInIHx8XG4gICAgICAgICAgICAgICAgICAgICAgKG0ub3JpZ2VuX21vdmltaWVudG8gJiYgbS5vcmlnZW5fbW92aW1pZW50by50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKCdtZXJtYScpKVxuICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0Rvc2lmaWNhY2lvbiA9XG4gICAgICAgICAgICAgICAgICAgICAgbS5zaWdsYV9vcmlnZW4gPT09ICdET1MnIHx8XG4gICAgICAgICAgICAgICAgICAgICAgKG0ub3JpZ2VuX21vdmltaWVudG8gJiYgbS5vcmlnZW5fbW92aW1pZW50by50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKCdkb3NpZmljJykpXG5cbiAgICAgICAgICAgICAgICAgICAgbGV0IGJhZGdlQ29sb3IgPSAnYmctc2xhdGUtMTAwIHRleHQtc2xhdGUtNzAwIGRhcms6Ymctc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0zMDAnXG4gICAgICAgICAgICAgICAgICAgIGxldCBjYW50aWRhZFNpZ24gPSAnLSdcbiAgICAgICAgICAgICAgICAgICAgbGV0IGNhbnRpZGFkQ29sb3IgPSAndGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlJ1xuXG4gICAgICAgICAgICAgICAgICAgIGlmIChpc0VudHJhZGEpIHtcbiAgICAgICAgICAgICAgICAgICAgICBiYWRnZUNvbG9yID0gJ2JnLWVtZXJhbGQtMTAwIHRleHQtZW1lcmFsZC03MDAgZGFyazpiZy1lbWVyYWxkLTkwMC8zMCBkYXJrOnRleHQtZW1lcmFsZC00MDAnXG4gICAgICAgICAgICAgICAgICAgICAgY2FudGlkYWRTaWduID0gJysnXG4gICAgICAgICAgICAgICAgICAgICAgY2FudGlkYWRDb2xvciA9ICd0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChpc01lcm1hKSB7XG4gICAgICAgICAgICAgICAgICAgICAgYmFkZ2VDb2xvciA9ICdiZy1yb3NlLTEwMCB0ZXh0LXJvc2UtNzAwIGRhcms6Ymctcm9zZS05MDAvMzAgZGFyazp0ZXh0LXJvc2UtNDAwJ1xuICAgICAgICAgICAgICAgICAgICAgIGNhbnRpZGFkU2lnbiA9ICctJ1xuICAgICAgICAgICAgICAgICAgICAgIGNhbnRpZGFkQ29sb3IgPSAndGV4dC1yb3NlLTYwMCBkYXJrOnRleHQtcm9zZS00MDAnXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoaXNEb3NpZmljYWNpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgICBiYWRnZUNvbG9yID0gJ2JnLWFtYmVyLTEwMCB0ZXh0LWFtYmVyLTcwMCBkYXJrOmJnLWFtYmVyLTkwMC8zMCBkYXJrOnRleHQtYW1iZXItNDAwJ1xuICAgICAgICAgICAgICAgICAgICAgIGNhbnRpZGFkU2lnbiA9ICctJ1xuICAgICAgICAgICAgICAgICAgICAgIGNhbnRpZGFkQ29sb3IgPSAndGV4dC1hbWJlci02MDAgZGFyazp0ZXh0LWFtYmVyLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17bS5pZF9tb3ZpbWllbnRvfSBjbGFzc05hbWU9e2kgJSAyID09PSAwID8gJ2JnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdJyA6ICdiZy1zbGF0ZS01MC81MCBkYXJrOmJnLVsjMUEyMjJDXS81MCd9PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTUgcHktNCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7bS5mZWNoYV9ob3JhID8gbmV3IERhdGUobS5mZWNoYV9ob3JhKS50b0xvY2FsZVN0cmluZygpIDogJ+KAlCd9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTUgcHktNCB0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge20ubm9tYnJlX3F1aW1pY28gfHwgbS5zaWdsYV9xdWltaWNvfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC01IHB5LTQgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcHgtMi41IHB5LTEgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1ib2xkICR7YmFkZ2VDb2xvcn1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bS50aXBvX21vdmltaWVudG8gfHwgbS5zaWdsYV90aXBvX21vdmltaWVudG99ICh7bS5vcmlnZW5fbW92aW1pZW50byB8fCBtLnNpZ2xhX29yaWdlbn0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPXtgcHgtNSBweS00IHRleHQtcmlnaHQgZm9udC1ibGFjayB0ZXh0LXNtICR7Y2FudGlkYWRDb2xvcn1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2NhbnRpZGFkU2lnbn17cGFyc2VGbG9hdChtLmNhbnRpZGFkKS50b0ZpeGVkKDEpfSB7bS51bmlkYWRfbWVkaWRhfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC01IHB5LTQgdGV4dC1yaWdodCB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtwYXJzZUZsb2F0KG0uc3RvY2tfcmVzdWx0YW50ZSkudG9GaXhlZCgxKX0ge20udW5pZGFkX21lZGlkYX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNSBweS00IHRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBpdGFsaWNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge20ub2JzZXJ2YWNpb25lcyB8fCAn4oCUJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7Lyog4pSA4pSAIFBhZ2luYWNpw7NuIGRlIDIwIHJlZ2lzdHJvcyDilIDilIAgKi99XG4gICAgICAgICAge21vdmltaWVudG9zLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IHB4LTYgcHktNCBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBiZy1zbGF0ZS01MC81MCBkYXJrOmJnLVsjMUEyMjJDXS81MFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgIE1vc3RyYW5kbyA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPntzdGFydEluZGV4ICsgMX08L3NwYW4+IGF7JyAnfVxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+e2VuZEluZGV4fTwvc3Bhbj4gZGV7JyAnfVxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+e21vdmltaWVudG9zLmxlbmd0aH08L3NwYW4+IHJlZ2lzdHJvc1xuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDdXJyZW50UGFnZSgocHJldikgPT4gTWF0aC5tYXgocHJldiAtIDEsIDEpKX1cbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXt2YWxpZEN1cnJlbnRQYWdlIDw9IDF9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMS41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgdGV4dC14cyBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgZGlzYWJsZWQ6b3BhY2l0eS00MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgaG92ZXI6Ymctc2xhdGUtNTAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgc2hhZG93LXNtXCJcbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUMOhZ2luYSBhbnRlcmlvclwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjIuNVwiIGQ9XCJNMTUgMTlsLTctNyA3LTdcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICAgICAgICBBbnRlcmlvclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBweC0yXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgIFDDoWdpbmEge3ZhbGlkQ3VycmVudFBhZ2V9IGRlIHt0b3RhbFBhZ2VzfVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDdXJyZW50UGFnZSgocHJldikgPT4gTWF0aC5taW4ocHJldiArIDEsIHRvdGFsUGFnZXMpKX1cbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXt2YWxpZEN1cnJlbnRQYWdlID49IHRvdGFsUGFnZXN9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMS41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgdGV4dC14cyBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgZGlzYWJsZWQ6b3BhY2l0eS00MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgaG92ZXI6Ymctc2xhdGUtNTAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgc2hhZG93LXNtXCJcbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUMOhZ2luYSBzaWd1aWVudGVcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIFNpZ3VpZW50ZVxuICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjIuNVwiIGQ9XCJNOSA1bDcgNy03IDdcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIOKUgOKUgCBNT0RBTCBSRUdJU1RSQVIgTU9WSU1JRU5UTyDilIDilIAgKi99XG4gICAgICB7c2hvd01vdmltaWVudG9Nb2RhbCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LVs5OTk5XSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1zbGF0ZS05MDAvNjAgYmFja2Ryb3AtYmx1ci1zbSBwLTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIHJvdW5kZWQtM3hsIG1heC13LW1kIHctZnVsbCBwLTYgc2hhZG93LTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gcmVsYXRpdmVcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gbWItNFwiPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGVcIj5SZWdpc3RyYXIgTW92aW1pZW50bzwvaDM+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBtdC0wLjVcIj5FbnRyYWRhIG8gc2FsaWRhIGRlIHF1w61taWNvcyBlIGluc3Vtb3M8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd01vdmltaWVudG9Nb2RhbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWZ1bGwgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNTAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICDinJVcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVJlZ2lzdHJhck1vdmltaWVudG99IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICB7LyogU2VsZWN0IHRpcG8gZGUgbW92aW1pZW50byAqL31cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgIFRpcG8gZGUgTW92aW1pZW50b1xuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3RpcG9Nb3ZpbWllbnRvfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUaXBvTW92aW1pZW50byhlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBiZy10cmFuc3BhcmVudCBkYXJrOmJnLVsjMUEyMjJDXSB0ZXh0LXNtIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZSBmb250LW1lZGl1bSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjb21wcmFcIiBjbGFzc05hbWU9XCJkYXJrOmJnLVsjMUEyMjJDXVwiPkNvbXByYSAoKyBFbnRyYWRhKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImRvc2lmaWNhY2lvblwiIGNsYXNzTmFtZT1cImRhcms6YmctWyMxQTIyMkNdXCI+RG9zaWZpY2FjacOzbiAoLSBTYWxpZGEgcG9yIGFwbGljYWNpw7NuKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIm1lcm1hXCIgY2xhc3NOYW1lPVwiZGFyazpiZy1bIzFBMjIyQ11cIj5NZXJtYSAoLSBTYWxpZGEgcG9yIHDDqXJkaWRhKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAge3RpcG9Nb3ZpbWllbnRvID09PSAnY29tcHJhJyAmJiAnQXVtZW50YSBlbCBzdG9jayBkZWwgcXXDrW1pY28gYWwgcmVnaXN0cmFyIHVuIG51ZXZvIGluZ3Jlc28uJ31cbiAgICAgICAgICAgICAgICAgIHt0aXBvTW92aW1pZW50byA9PT0gJ2Rvc2lmaWNhY2lvbicgJiYgJ0Rlc2N1ZW50YSBpbnN1bW8gYXBsaWNhZG8gYWwgdHJhdGFtaWVudG8gZGUgbGEgcGlzY2luYS4nfVxuICAgICAgICAgICAgICAgICAge3RpcG9Nb3ZpbWllbnRvID09PSAnbWVybWEnICYmICdEZXNjdWVudGEgaW5zdW1vIHBvciBkZXJyYW1lLCByb3R1cmEsIHZlbmNpbWllbnRvIG8gbWVybWEgZsOtc2ljYS4nfVxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIFNlbGVjdCBxdcOtbWljbyAqL31cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgIFF1w61taWNvIEluc3Vtb1xuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkUXVpbWljb31cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWRRdWltaWNvKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0zIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIGJnLXRyYW5zcGFyZW50IGRhcms6YmctWyMxQTIyMkNdIHRleHQtc20gdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOm91dGxpbmUtbm9uZVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiIGNsYXNzTmFtZT1cImRhcms6YmctWyMxQTIyMkNdXCI+LS0gU2VsZWNjaW9uZSBxdcOtbWljbyAtLTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAge3F1aW1pY29zLm1hcCgocSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17cS5zaWdsYX0gdmFsdWU9e3Euc2lnbGF9IGNsYXNzTmFtZT1cImRhcms6YmctWyMxQTIyMkNdXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3Eubm9tYnJlfSAoe3EudW5pZGFkX21lZGlkYX0pIOKAlCBTdG9jazoge3BhcnNlRmxvYXQocS5zdG9ja19hY3R1YWwpLnRvRml4ZWQoMSl9IHtxLnVuaWRhZF9tZWRpZGF9XG4gICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAge3NlbGVjdGVkUXVpbWljb0luZm8gJiYgKFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xLjUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQteHMgcHgtMVwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPlN0b2NrIGRpc3BvbmlibGU6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2Bmb250LWJvbGQgJHtwYXJzZUZsb2F0KHNlbGVjdGVkUXVpbWljb0luZm8uc3RvY2tfYWN0dWFsKSA8PSBwYXJzZUZsb2F0KHNlbGVjdGVkUXVpbWljb0luZm8uc3RvY2tfbWluaW1vKSA/ICd0ZXh0LXJlZC01MDAnIDogJ3RleHQtZW1lcmFsZC01MDAnfWB9PlxuICAgICAgICAgICAgICAgICAgICAgIHtwYXJzZUZsb2F0KHNlbGVjdGVkUXVpbWljb0luZm8uc3RvY2tfYWN0dWFsKS50b0ZpeGVkKDEpfSB7c2VsZWN0ZWRRdWltaWNvSW5mby51bmlkYWRfbWVkaWRhfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogQ2FudGlkYWQgKi99XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMCBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICB7dGlwb01vdmltaWVudG8gPT09ICdjb21wcmEnXG4gICAgICAgICAgICAgICAgICAgID8gJ0NhbnRpZGFkIENvbXByYWRhJ1xuICAgICAgICAgICAgICAgICAgICA6IHRpcG9Nb3ZpbWllbnRvID09PSAnZG9zaWZpY2FjaW9uJ1xuICAgICAgICAgICAgICAgICAgICA/ICdDYW50aWRhZCBhIERvc2lmaWNhcidcbiAgICAgICAgICAgICAgICAgICAgOiAnQ2FudGlkYWQgZGUgTWVybWEnfXsnICd9XG4gICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRRdWltaWNvSW5mbyA/IGAoJHtzZWxlY3RlZFF1aW1pY29JbmZvLnVuaWRhZF9tZWRpZGF9KWAgOiAnJ31cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgICAgICBzdGVwPVwiMC4wMVwiXG4gICAgICAgICAgICAgICAgICBtaW49XCIwLjAxXCJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqOiA1MC4wXCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtjYW50aWRhZE1vdmltaWVudG99XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENhbnRpZGFkTW92aW1pZW50byhlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0zIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIGJnLXRyYW5zcGFyZW50IGRhcms6YmctWyMxQTIyMkNdIHRleHQtc20gdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOm91dGxpbmUtbm9uZVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIE9ic2VydmFjaW9uZXMgKi99XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMCBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICBPYnNlcnZhY2lvbmVzIC8gRGV0YWxsZVxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17XG4gICAgICAgICAgICAgICAgICAgIHRpcG9Nb3ZpbWllbnRvID09PSAnY29tcHJhJ1xuICAgICAgICAgICAgICAgICAgICAgID8gJ0VqOiBGYWN0dXJhIDQ1MDEgLSBEaXN0cmlidWlkb3JhIEFjcXVhJ1xuICAgICAgICAgICAgICAgICAgICAgIDogdGlwb01vdmltaWVudG8gPT09ICdkb3NpZmljYWNpb24nXG4gICAgICAgICAgICAgICAgICAgICAgPyAnRWo6IFRyYXRhbWllbnRvIHByZXZlbnRpdm8gbm9jdHVybm8nXG4gICAgICAgICAgICAgICAgICAgICAgOiAnRWo6IEVudmFzZSBkYcOxYWRvIGVuIGJvZGVnYSdcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtvYnNlcnZhY2lvbmVzTW92aW1pZW50b31cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0T2JzZXJ2YWNpb25lc01vdmltaWVudG8oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBiZy10cmFuc3BhcmVudCBkYXJrOmJnLVsjMUEyMjJDXSB0ZXh0LXNtIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBCb3RvbmVzIGRlIGFjY2nDs24gKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcHQtM1wiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd01vdmltaWVudG9Nb2RhbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEvMyBweS0zIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgZm9udC1ib2xkIHRleHQtc20gaG92ZXI6Ymctc2xhdGUtNTAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIENhbmNlbGFyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17c2F2aW5nTW92aW1pZW50b31cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctMi8zIHB5LTMgcm91bmRlZC14bCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCB0ZXh0LXNtIHNoYWRvdy1tZCB0cmFuc2l0aW9uLWFsbCBhY3RpdmU6c2NhbGUtOTUgJHtcbiAgICAgICAgICAgICAgICAgICAgdGlwb01vdmltaWVudG8gPT09ICdjb21wcmEnXG4gICAgICAgICAgICAgICAgICAgICAgPyAnYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS03MDAgc2hhZG93LWJsdWUtNTAwLzIwJ1xuICAgICAgICAgICAgICAgICAgICAgIDogdGlwb01vdmltaWVudG8gPT09ICdkb3NpZmljYWNpb24nXG4gICAgICAgICAgICAgICAgICAgICAgPyAnYmctYW1iZXItNjAwIGhvdmVyOmJnLWFtYmVyLTcwMCBzaGFkb3ctYW1iZXItNTAwLzIwJ1xuICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXJvc2UtNjAwIGhvdmVyOmJnLXJvc2UtNzAwIHNoYWRvdy1yb3NlLTUwMC8yMCdcbiAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHtzYXZpbmdNb3ZpbWllbnRvXG4gICAgICAgICAgICAgICAgICAgID8gJ0d1YXJkYW5kby4uLidcbiAgICAgICAgICAgICAgICAgICAgOiB0aXBvTW92aW1pZW50byA9PT0gJ2NvbXByYSdcbiAgICAgICAgICAgICAgICAgICAgPyAnUmVnaXN0cmFyIEVudHJhZGEnXG4gICAgICAgICAgICAgICAgICAgIDogdGlwb01vdmltaWVudG8gPT09ICdkb3NpZmljYWNpb24nXG4gICAgICAgICAgICAgICAgICAgID8gJ1JlZ2lzdHJhciBEb3NpZmljYWNpw7NuJ1xuICAgICAgICAgICAgICAgICAgICA6ICdSZWdpc3RyYXIgTWVybWEnfVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7Lyog4pSA4pSAIE1PREFMIE5VRVZPIFFVw41NSUNPIOKUgOKUgCAqL31cbiAgICAgIHtzaG93UXVpbWljb01vZGFsICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotWzk5OTldIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLXNsYXRlLTkwMC82MCBiYWNrZHJvcC1ibHVyLXNtIHAtNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gcm91bmRlZC0zeGwgbWF4LXctbWQgdy1mdWxsIHAtNiBzaGFkb3ctMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSByZWxhdGl2ZVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItNCBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBtYi00XCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGVcIj5SZWdpc3RyYXIgTnVldm8gUXXDrW1pY288L2gzPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1F1aW1pY29Nb2RhbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWZ1bGwgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNTAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICDinJVcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUNyZWFyUXVpbWljb30gY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMCBtYi0xXCI+Tm9tYnJlIGRlbCBRdcOtbWljbzwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFajogQWxnaWNpZGEgQ29uY2VudHJhZG9cIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e25vbWJyZVF1aW1pY299XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5vbWJyZVF1aW1pY28oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMi41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIGJnLXRyYW5zcGFyZW50IGRhcms6YmctWyMxQTIyMkNdIHRleHQtc20gdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOm91dGxpbmUtbm9uZVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgbWItMVwiPlNpZ2xhIChDw7NkLik8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFajogQUxHXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NpZ2xhUXVpbWljb31cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTaWdsYVF1aW1pY28oZS50YXJnZXQudmFsdWUudG9VcHBlckNhc2UoKSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBiZy10cmFuc3BhcmVudCBkYXJrOmJnLVsjMUEyMjJDXSB0ZXh0LXNtIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMCBtYi0xXCI+VW5pZGFkIE1lZGlkYTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqOiBMLCBrZywgZ2FsXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VuaWRhZE1lZGlkYX1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRVbmlkYWRNZWRpZGEoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0yLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gYmctdHJhbnNwYXJlbnQgZGFyazpiZy1bIzFBMjIyQ10gdGV4dC1zbSB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6b3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwIG1iLTFcIj5TdG9jayBJbmljaWFsPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMVwiXG4gICAgICAgICAgICAgICAgICAgIG1pbj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c3RvY2tJbmljaWFsfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFN0b2NrSW5pY2lhbChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBiZy10cmFuc3BhcmVudCBkYXJrOmJnLVsjMUEyMjJDXSB0ZXh0LXNtIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMCBtYi0xXCI+U3RvY2sgTcOtbmltbyBBbGVydGE8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgICBzdGVwPVwiMC4xXCJcbiAgICAgICAgICAgICAgICAgICAgbWluPVwiMFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzdG9ja01pbmltb31cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTdG9ja01pbmltbyhlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBiZy10cmFuc3BhcmVudCBkYXJrOmJnLVsjMUEyMjJDXSB0ZXh0LXNtIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBwdC0zXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93UXVpbWljb01vZGFsKGZhbHNlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMS8zIHB5LTIuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGZvbnQtYm9sZCB0ZXh0LXNtIGhvdmVyOmJnLXNsYXRlLTUwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBDYW5jZWxhclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3NhdmluZ1F1aW1pY299XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTIvMyBweS0yLjUgcm91bmRlZC14bCBiZy1ibHVlLTYwMCBob3ZlcjpiZy1ibHVlLTcwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCB0ZXh0LXNtIHNoYWRvdy1tZCB0cmFuc2l0aW9uLWFsbCBhY3RpdmU6c2NhbGUtOTVcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHtzYXZpbmdRdWltaWNvID8gJ0d1YXJkYW5kby4uLicgOiAnQ3JlYXIgUXXDrW1pY28nfVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApXG59XG4iXX0=