import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Header/index.jsx");const useState = __vite__cjsImport0_react["useState"]; const useRef = __vite__cjsImport0_react["useRef"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=41a64c35";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=41a64c35";
import { useAuth } from "/src/context/AuthContext.jsx";
var _jsxFileName = "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/components/Header/index.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=41a64c35";
var _s = $RefreshSig$();
export default function Header() {
	_s();
	const { session, logout } = useAuth();
	const [dropdownOpen, setDropdownOpen] = useState(false);
	const dropdownRef = useRef(null);
	// Close dropdown when clicking outside
	useEffect(() => {
		const clickHandler = ({ target }) => {
			if (!dropdownRef.current) return;
			if (!dropdownOpen || dropdownRef.current.contains(target)) return;
			setDropdownOpen(false);
		};
		document.addEventListener("click", clickHandler);
		return () => document.removeEventListener("click", clickHandler);
	});
	return /* @__PURE__ */ _jsxDEV("header", {
		className: "sticky top-0 z-999 flex w-full bg-white dark:bg-[#24303F] border-b border-slate-200 dark:border-[#313D4A]",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-grow items-center justify-end py-4 px-4 shadow-sm md:px-6 2xl:px-11",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "relative",
				ref: dropdownRef,
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3 group cursor-pointer",
					onClick: () => setDropdownOpen(!dropdownOpen),
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "h-10 w-10 rounded-full flex items-center justify-center bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300 font-bold overflow-hidden",
							children: session?.usuario?.nombre?.slice(0, 1).toUpperCase()
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 29,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "hidden text-right lg:block",
							children: /* @__PURE__ */ _jsxDEV("span", {
								className: "block text-sm font-semibold text-slate-800 dark:text-white",
								children: [
									session?.usuario?.nombre,
									" ",
									session?.usuario?.primer_apellido
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 33,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 32,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("svg", {
							className: `hidden lg:block w-4 h-4 text-slate-500 dark:text-slate-400 transition-transform ${dropdownOpen ? "rotate-180" : ""}`,
							fill: "none",
							stroke: "currentColor",
							viewBox: "0 0 24 24",
							xmlns: "http://www.w3.org/2000/svg",
							children: /* @__PURE__ */ _jsxDEV("path", {
								strokeLinecap: "round",
								strokeLinejoin: "round",
								strokeWidth: "2",
								d: "M19 9l-7 7-7-7"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 44,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 37,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 11
				}, this), dropdownOpen && /* @__PURE__ */ _jsxDEV("div", {
					className: "absolute right-0 mt-4 flex w-62.5 flex-col rounded-xl border border-slate-200 dark:border-[#313D4A] bg-white dark:bg-[#24303F] shadow-lg z-99999 w-[260px]",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "px-6 py-5 border-b border-slate-200 dark:border-[#313D4A]",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "block text-sm font-semibold text-slate-800 dark:text-white",
								children: [
									session?.usuario?.nombre,
									" ",
									session?.usuario?.primer_apellido
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 52,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "block text-sm font-medium text-slate-500 dark:text-slate-400 mt-0.5",
								children: session?.usuario?.correo
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 55,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 51,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("ul", {
							className: "flex flex-col gap-1 px-4 py-4 border-b border-slate-200 dark:border-[#313D4A]",
							children: /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
								to: "/profile",
								onClick: () => setDropdownOpen(false),
								className: "flex items-center gap-3.5 text-sm font-medium duration-300 ease-in-out hover:text-blue-600 dark:hover:text-white text-slate-600 dark:text-slate-300 px-2 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-[#313D4A]",
								children: [/* @__PURE__ */ _jsxDEV("svg", {
									className: "w-5 h-5",
									fill: "none",
									stroke: "currentColor",
									viewBox: "0 0 24 24",
									xmlns: "http://www.w3.org/2000/svg",
									children: /* @__PURE__ */ _jsxDEV("path", {
										strokeLinecap: "round",
										strokeLinejoin: "round",
										strokeWidth: "2",
										d: "M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 68,
										columnNumber: 25
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 67,
									columnNumber: 23
								}, this), "Mi Perfil"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 62,
								columnNumber: 21
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 61,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 60,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "px-4 py-4",
							children: /* @__PURE__ */ _jsxDEV("button", {
								onClick: logout,
								className: "w-full flex items-center gap-3.5 text-sm font-medium duration-300 ease-in-out hover:text-red-600 text-slate-600 dark:text-slate-300 px-2 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-[#313D4A]",
								children: [/* @__PURE__ */ _jsxDEV("svg", {
									className: "w-5 h-5",
									fill: "none",
									stroke: "currentColor",
									viewBox: "0 0 24 24",
									xmlns: "http://www.w3.org/2000/svg",
									children: /* @__PURE__ */ _jsxDEV("path", {
										strokeLinecap: "round",
										strokeLinejoin: "round",
										strokeWidth: "2",
										d: "M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 81,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 80,
									columnNumber: 21
								}, this), "Cerrar sesión"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 76,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 75,
							columnNumber: 17
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 50,
					columnNumber: 15
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 22,
		columnNumber: 5
	}, this);
}
_s(Header, "50M/2Tw+8NLog/KYDGHRjlVQnv4=", false, function() {
	return [useAuth];
});
_c = Header;
var _c;
$RefreshReg$(_c, "Header");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Header/index.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/components/Header/index.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/components/Header/index.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/components/Header/index.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFFBQVEsaUJBQWlCO0FBQzVDLFNBQVMsWUFBWTtBQUNyQixTQUFTLGVBQWU7Ozs7QUFFeEIsZUFBZSxTQUFTLFNBQVM7O0NBQy9CLE1BQU0sRUFBRSxTQUFTLFdBQVcsUUFBUTtDQUNwQyxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxLQUFLO0NBQ3RELE1BQU0sY0FBYyxPQUFPLElBQUk7O0NBRy9CLGdCQUFnQjtFQUNkLE1BQU0sZ0JBQWdCLEVBQUUsYUFBYTtHQUNuQyxJQUFJLENBQUMsWUFBWSxTQUFTO0dBQzFCLElBQUksQ0FBQyxnQkFBZ0IsWUFBWSxRQUFRLFNBQVMsTUFBTSxHQUFHO0dBQzNELGdCQUFnQixLQUFLO0VBQ3ZCO0VBQ0EsU0FBUyxpQkFBaUIsU0FBUyxZQUFZO0VBQy9DLGFBQWEsU0FBUyxvQkFBb0IsU0FBUyxZQUFZO0NBQ2pFLENBQUM7Q0FFRCxPQUNFLHdCQUFDLFVBQUQ7RUFBUSxXQUFVO1lBQ2hCLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ2Isd0JBQUMsT0FBRDtJQUFLLFdBQVU7SUFBVyxLQUFLO2NBQS9CLENBQ0Usd0JBQUMsT0FBRDtLQUNFLFdBQVU7S0FDVixlQUFlLGdCQUFnQixDQUFDLFlBQVk7ZUFGOUM7TUFJRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFDYixTQUFTLFNBQVMsUUFBUSxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsWUFBWTtNQUMvQzs7Ozs7TUFDTix3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFDZCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEI7U0FDRyxTQUFTLFNBQVM7U0FBTztTQUFFLFNBQVMsU0FBUztRQUMxQzs7Ozs7O01BQ0Y7Ozs7O01BQ04sd0JBQUMsT0FBRDtPQUNFLFdBQVcsbUZBQW1GLGVBQWUsZUFBZTtPQUM1SCxNQUFLO09BQ0wsUUFBTztPQUNQLFNBQVE7T0FDUixPQUFNO2lCQUVOLHdCQUFDLFFBQUQ7UUFBTSxlQUFjO1FBQVEsZ0JBQWU7UUFBUSxhQUFZO1FBQUksR0FBRTtPQUF1Qjs7Ozs7TUFDekY7Ozs7O0tBQ0Y7Ozs7O2NBR0YsZ0JBQ0Msd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCO1NBQ0csU0FBUyxTQUFTO1NBQU87U0FBRSxTQUFTLFNBQVM7UUFDMUM7Ozs7O2lCQUNOLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLFNBQVMsU0FBUztPQUNmOzs7O2VBQ0g7Ozs7OztNQUVMLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUNaLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO1FBQ0UsSUFBRztRQUNILGVBQWUsZ0JBQWdCLEtBQUs7UUFDcEMsV0FBVTtrQkFIWixDQUtFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO1NBQVUsTUFBSztTQUFPLFFBQU87U0FBZSxTQUFRO1NBQVksT0FBTTttQkFDbkYsd0JBQUMsUUFBRDtVQUFNLGVBQWM7VUFBUSxnQkFBZTtVQUFRLGFBQVk7VUFBSSxHQUFFO1NBQTRFOzs7OztRQUM5STs7OztrQkFBQyxXQUVGOzs7OztnQkFDSjs7Ozs7TUFDRjs7Ozs7TUFFSix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxVQUFEO1FBQ0UsU0FBUztRQUNULFdBQVU7a0JBRlosQ0FJRSx3QkFBQyxPQUFEO1NBQUssV0FBVTtTQUFVLE1BQUs7U0FBTyxRQUFPO1NBQWUsU0FBUTtTQUFZLE9BQU07bUJBQ25GLHdCQUFDLFFBQUQ7VUFBTSxlQUFjO1VBQVEsZ0JBQWU7VUFBUSxhQUFZO1VBQUksR0FBRTtTQUFrRzs7Ozs7UUFDcEs7Ozs7a0JBQUMsZUFFQTs7Ozs7O01BQ0w7Ozs7O0tBQ0Y7Ozs7O1lBRUo7Ozs7OztFQUNGOzs7OztDQUNDOzs7OztBQUVaIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlUmVmLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uL2NvbnRleHQvQXV0aENvbnRleHQnXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhlYWRlcigpIHtcbiAgY29uc3QgeyBzZXNzaW9uLCBsb2dvdXQgfSA9IHVzZUF1dGgoKVxuICBjb25zdCBbZHJvcGRvd25PcGVuLCBzZXREcm9wZG93bk9wZW5dID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IGRyb3Bkb3duUmVmID0gdXNlUmVmKG51bGwpXG5cbiAgLy8gQ2xvc2UgZHJvcGRvd24gd2hlbiBjbGlja2luZyBvdXRzaWRlXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgY2xpY2tIYW5kbGVyID0gKHsgdGFyZ2V0IH0pID0+IHtcbiAgICAgIGlmICghZHJvcGRvd25SZWYuY3VycmVudCkgcmV0dXJuXG4gICAgICBpZiAoIWRyb3Bkb3duT3BlbiB8fCBkcm9wZG93blJlZi5jdXJyZW50LmNvbnRhaW5zKHRhcmdldCkpIHJldHVyblxuICAgICAgc2V0RHJvcGRvd25PcGVuKGZhbHNlKVxuICAgIH1cbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGNsaWNrSGFuZGxlcilcbiAgICByZXR1cm4gKCkgPT4gZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignY2xpY2snLCBjbGlja0hhbmRsZXIpXG4gIH0pXG5cbiAgcmV0dXJuIChcbiAgICA8aGVhZGVyIGNsYXNzTmFtZT1cInN0aWNreSB0b3AtMCB6LTk5OSBmbGV4IHctZnVsbCBiZy13aGl0ZSBkYXJrOmJnLVsjMjQzMDNGXSBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtZ3JvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1lbmQgcHktNCBweC00IHNoYWRvdy1zbSBtZDpweC02IDJ4bDpweC0xMVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCIgcmVmPXtkcm9wZG93blJlZn0+XG4gICAgICAgICAgPGRpdiBcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIGdyb3VwIGN1cnNvci1wb2ludGVyXCIgXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXREcm9wZG93bk9wZW4oIWRyb3Bkb3duT3Blbil9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaC0xMCB3LTEwIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1ibHVlLTEwMCBkYXJrOmJnLWJsdWUtOTAwIHRleHQtYmx1ZS02MDAgZGFyazp0ZXh0LWJsdWUtMzAwIGZvbnQtYm9sZCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAge3Nlc3Npb24/LnVzdWFyaW8/Lm5vbWJyZT8uc2xpY2UoMCwgMSkudG9VcHBlckNhc2UoKX1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiB0ZXh0LXJpZ2h0IGxnOmJsb2NrXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICB7c2Vzc2lvbj8udXN1YXJpbz8ubm9tYnJlfSB7c2Vzc2lvbj8udXN1YXJpbz8ucHJpbWVyX2FwZWxsaWRvfVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8c3ZnIFxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BoaWRkZW4gbGc6YmxvY2sgdy00IGgtNCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIHRyYW5zaXRpb24tdHJhbnNmb3JtICR7ZHJvcGRvd25PcGVuID8gJ3JvdGF0ZS0xODAnIDogJyd9YH0gXG4gICAgICAgICAgICAgIGZpbGw9XCJub25lXCIgXG4gICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIFxuICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgXG4gICAgICAgICAgICAgIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk0xOSA5bC03IDctNy03XCI+PC9wYXRoPlxuICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBEcm9wZG93biBNZW51ICovfVxuICAgICAgICAgICAge2Ryb3Bkb3duT3BlbiAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtMCBtdC00IGZsZXggdy02Mi41IGZsZXgtY29sIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIGJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIHNoYWRvdy1sZyB6LTk5OTk5IHctWzI2MHB4XVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS01IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgIHtzZXNzaW9uPy51c3VhcmlvPy5ub21icmV9IHtzZXNzaW9uPy51c3VhcmlvPy5wcmltZXJfYXBlbGxpZG99XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgIHtzZXNzaW9uPy51c3VhcmlvPy5jb3JyZW99XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMSBweC00IHB5LTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV1cIj5cbiAgICAgICAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgICAgICAgICB0bz1cIi9wcm9maWxlXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXREcm9wZG93bk9wZW4oZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zLjUgdGV4dC1zbSBmb250LW1lZGl1bSBkdXJhdGlvbi0zMDAgZWFzZS1pbi1vdXQgaG92ZXI6dGV4dC1ibHVlLTYwMCBkYXJrOmhvdmVyOnRleHQtd2hpdGUgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBweC0yIHB5LTIgcm91bmRlZC1sZyBob3ZlcjpiZy1zbGF0ZS01MCBkYXJrOmhvdmVyOmJnLVsjMzEzRDRBXVwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNSBoLTVcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk0xNiA3YTQgNCAwIDExLTggMCA0IDQgMCAwMTggMHpNMTIgMTRhNyA3IDAgMDAtNyA3aDE0YTcgNyAwIDAwLTctN3pcIj48L3BhdGg+XG4gICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICAgICAgICAgICAgTWkgUGVyZmlsXG4gICAgICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTQgcHktNFwiPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtsb2dvdXR9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMy41IHRleHQtc20gZm9udC1tZWRpdW0gZHVyYXRpb24tMzAwIGVhc2UtaW4tb3V0IGhvdmVyOnRleHQtcmVkLTYwMCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIHB4LTIgcHktMiByb3VuZGVkLWxnIGhvdmVyOmJnLXNsYXRlLTUwIGRhcms6aG92ZXI6YmctWyMzMTNENEFdXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTUgaC01XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiPlxuICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTE3IDE2bDQtNG0wIDBsLTQtNG00IDRIN202IDR2MWEzIDMgMCAwMS0zIDNINmEzIDMgMCAwMS0zLTNWN2EzIDMgMCAwMTMtM2g0YTMgMyAwIDAxMyAzdjFcIj48L3BhdGg+XG4gICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgICAgICAgICBDZXJyYXIgc2VzacOzblxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2hlYWRlcj5cbiAgICApXG4gIH1cbiJdfQ==