import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Sidebar/index.jsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport2_react_jsxDevRuntime["Fragment"];import { NavLink } from "/node_modules/.vite/deps/react-router-dom.js?v=41a64c35";
import { useAuth } from "/src/context/AuthContext.jsx";
var _jsxFileName = "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/components/Sidebar/index.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=41a64c35";
var _s = $RefreshSig$();
export default function Sidebar() {
	_s();
	const { session } = useAuth();
	return /* @__PURE__ */ _jsxDEV("aside", {
		className: "absolute left-0 top-0 z-9999 flex h-screen w-[290px] flex-col overflow-y-hidden bg-white dark:bg-[#24303F] border-r border-slate-200 dark:border-[#313D4A] duration-300 ease-linear lg:static lg:translate-x-0",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center justify-start gap-2 px-6 py-5.5 lg:py-6.5 mt-2 mb-2",
			children: /* @__PURE__ */ _jsxDEV(NavLink, {
				to: "/",
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex h-10 w-10 items-center justify-center rounded-lg bg-blue-600 text-white font-bold text-xl",
					children: /* @__PURE__ */ _jsxDEV("svg", {
						width: "20",
						height: "20",
						viewBox: "0 0 24 24",
						fill: "none",
						xmlns: "http://www.w3.org/2000/svg",
						children: [
							/* @__PURE__ */ _jsxDEV("path", {
								d: "M4 12V20C4 20.5523 4.44772 21 5 21H19C19.5523 21 20 20.5523 20 20V12",
								stroke: "currentColor",
								strokeWidth: "2.5",
								strokeLinecap: "round"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 14,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("path", {
								d: "M12 15L12 3",
								stroke: "currentColor",
								strokeWidth: "2.5",
								strokeLinecap: "round"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 15,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("path", {
								d: "M8 7L12 3L16 7",
								stroke: "currentColor",
								strokeWidth: "2.5",
								strokeLinecap: "round",
								strokeLinejoin: "round"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 16,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 12,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("strong", {
					className: "text-2xl font-bold text-slate-800 dark:text-white",
					children: "Playa Azul"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 19,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 10,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "no-scrollbar flex flex-col overflow-y-auto duration-300 ease-linear",
			children: /* @__PURE__ */ _jsxDEV("nav", {
				className: "mt-5 py-4 px-4 lg:mt-2 lg:px-6",
				children: /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "mb-4 ml-4 text-[11px] font-semibold tracking-wider text-slate-400 uppercase",
					children: "MENÚ"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("ul", {
					className: "mb-6 flex flex-col gap-1.5",
					children: [
						session?.usuario?.sigla_rol !== "CAJ" && /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(NavLink, {
							to: "/dashboard",
							className: ({ isActive }) => `group relative flex items-center gap-3 rounded-md px-4 py-2.5 font-medium duration-300 ease-in-out ${isActive ? "bg-blue-50 dark:bg-[#313D4A] text-blue-600 dark:text-white" : "text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-[#313D4A] hover:text-slate-700 dark:hover:text-white"}`,
							children: [/* @__PURE__ */ _jsxDEV("svg", {
								className: "w-5 h-5",
								fill: "none",
								stroke: "currentColor",
								viewBox: "0 0 24 24",
								xmlns: "http://www.w3.org/2000/svg",
								children: /* @__PURE__ */ _jsxDEV("path", {
									strokeLinecap: "round",
									strokeLinejoin: "round",
									strokeWidth: "2",
									d: "M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 44,
									columnNumber: 23
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 43,
								columnNumber: 21
							}, this), "Dashboard"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 33,
							columnNumber: 19
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 32,
							columnNumber: 17
						}, this),
						session?.usuario?.sigla_rol !== "CAJ" && /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(NavLink, {
							to: "/reportes",
							className: ({ isActive }) => `group relative flex items-center gap-3 rounded-md px-4 py-2.5 font-medium duration-300 ease-in-out ${isActive ? "bg-blue-50 dark:bg-[#313D4A] text-blue-600 dark:text-white" : "text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-[#313D4A] hover:text-slate-700 dark:hover:text-white"}`,
							children: [/* @__PURE__ */ _jsxDEV("svg", {
								className: "w-5 h-5",
								fill: "none",
								stroke: "currentColor",
								viewBox: "0 0 24 24",
								xmlns: "http://www.w3.org/2000/svg",
								children: /* @__PURE__ */ _jsxDEV("path", {
									strokeLinecap: "round",
									strokeLinejoin: "round",
									strokeWidth: "2",
									d: "M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 64,
									columnNumber: 23
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 63,
								columnNumber: 21
							}, this), "Reportes"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 53,
							columnNumber: 19
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 52,
							columnNumber: 17
						}, this),
						session?.usuario?.sigla_rol !== "OPE" && /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(NavLink, {
							to: "/caja",
							className: ({ isActive }) => `group relative flex items-center gap-3 rounded-md px-4 py-2.5 font-medium duration-300 ease-in-out ${isActive ? "bg-blue-50 dark:bg-[#313D4A] text-blue-600 dark:text-white" : "text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-[#313D4A] hover:text-slate-700 dark:hover:text-white"}`,
							children: [/* @__PURE__ */ _jsxDEV("svg", {
								className: "w-5 h-5",
								fill: "none",
								stroke: "currentColor",
								viewBox: "0 0 24 24",
								xmlns: "http://www.w3.org/2000/svg",
								children: /* @__PURE__ */ _jsxDEV("path", {
									strokeLinecap: "round",
									strokeLinejoin: "round",
									strokeWidth: "2",
									d: "M15 5v2m0 4v2m0 4v2M5 5a2 2 0 00-2 2v3a2 2 0 110 4v3a2 2 0 002 2h14a2 2 0 002-2v-3a2 2 0 110-4V7a2 2 0 00-2-2H5z"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 84,
									columnNumber: 23
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 83,
								columnNumber: 21
							}, this), "Caja"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 73,
							columnNumber: 19
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 72,
							columnNumber: 17
						}, this),
						session?.usuario?.sigla_rol !== "CAJ" && /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(NavLink, {
							to: "/inventario",
							className: ({ isActive }) => `group relative flex items-center gap-3 rounded-md px-4 py-2.5 font-medium duration-300 ease-in-out ${isActive ? "bg-blue-50 dark:bg-[#313D4A] text-blue-600 dark:text-white" : "text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-[#313D4A] hover:text-slate-700 dark:hover:text-white"}`,
							children: [/* @__PURE__ */ _jsxDEV("svg", {
								className: "w-5 h-5",
								fill: "none",
								stroke: "currentColor",
								viewBox: "0 0 24 24",
								xmlns: "http://www.w3.org/2000/svg",
								children: /* @__PURE__ */ _jsxDEV("path", {
									strokeLinecap: "round",
									strokeLinejoin: "round",
									strokeWidth: "2",
									d: "M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 104,
									columnNumber: 23
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 103,
								columnNumber: 21
							}, this), "Inventario"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 93,
							columnNumber: 19
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 92,
							columnNumber: 17
						}, this),
						session?.usuario?.sigla_rol === "ADM" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(NavLink, {
							to: "/users",
							className: ({ isActive }) => `group relative flex items-center gap-3 rounded-md px-4 py-2.5 font-medium duration-300 ease-in-out ${isActive ? "bg-blue-50 dark:bg-[#313D4A] text-blue-600 dark:text-white" : "text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-[#313D4A] hover:text-slate-700 dark:hover:text-white"}`,
							children: [/* @__PURE__ */ _jsxDEV("svg", {
								className: "w-5 h-5",
								fill: "none",
								stroke: "currentColor",
								viewBox: "0 0 24 24",
								xmlns: "http://www.w3.org/2000/svg",
								children: /* @__PURE__ */ _jsxDEV("path", {
									strokeLinecap: "round",
									strokeLinejoin: "round",
									strokeWidth: "2",
									d: "M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 125,
									columnNumber: 25
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 124,
								columnNumber: 23
							}, this), "Usuarios"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 114,
							columnNumber: 21
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 113,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(NavLink, {
							to: "/auditoria",
							className: ({ isActive }) => `group relative flex items-center gap-3 rounded-md px-4 py-2.5 font-medium duration-300 ease-in-out ${isActive ? "bg-blue-50 dark:bg-[#313D4A] text-blue-600 dark:text-white" : "text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-[#313D4A] hover:text-slate-700 dark:hover:text-white"}`,
							children: [/* @__PURE__ */ _jsxDEV("svg", {
								className: "w-5 h-5",
								fill: "none",
								stroke: "currentColor",
								viewBox: "0 0 24 24",
								xmlns: "http://www.w3.org/2000/svg",
								children: /* @__PURE__ */ _jsxDEV("path", {
									strokeLinecap: "round",
									strokeLinejoin: "round",
									strokeWidth: "2",
									d: "M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 143,
									columnNumber: 25
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 142,
								columnNumber: 23
							}, this), "Auditoría"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 132,
							columnNumber: 21
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 131,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 112,
							columnNumber: 17
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 8,
		columnNumber: 5
	}, this);
}
_s(Sidebar, "PfssbkmwXv8OKztt4QwYrctCukQ=", false, function() {
	return [useAuth];
});
_c = Sidebar;
var _c;
$RefreshReg$(_c, "Sidebar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Sidebar/index.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/components/Sidebar/index.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/components/Sidebar/index.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/components/Sidebar/index.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsZUFBZTs7OztBQUV4QixlQUFlLFNBQVMsVUFBVTs7Q0FDaEMsTUFBTSxFQUFFLFlBQVksUUFBUTtDQUU1QixPQUNFLHdCQUFDLFNBQUQ7RUFBTyxXQUFVO1lBQWpCLENBRUUsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDYix3QkFBQyxTQUFEO0lBQVMsSUFBRztJQUFJLFdBQVU7Y0FBMUIsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLE9BQUQ7TUFBSyxPQUFNO01BQUssUUFBTztNQUFLLFNBQVE7TUFBWSxNQUFLO01BQU8sT0FBTTtnQkFBbEU7T0FDRSx3QkFBQyxRQUFEO1FBQU0sR0FBRTtRQUF1RSxRQUFPO1FBQWUsYUFBWTtRQUFNLGVBQWM7T0FBUTs7Ozs7T0FDN0ksd0JBQUMsUUFBRDtRQUFNLEdBQUU7UUFBYyxRQUFPO1FBQWUsYUFBWTtRQUFNLGVBQWM7T0FBUTs7Ozs7T0FDcEYsd0JBQUMsUUFBRDtRQUFNLEdBQUU7UUFBaUIsUUFBTztRQUFlLGFBQVk7UUFBTSxlQUFjO1FBQVEsZ0JBQWU7T0FBUTs7Ozs7TUFDM0c7Ozs7OztJQUNGOzs7O2NBQ0wsd0JBQUMsVUFBRDtLQUFRLFdBQVU7ZUFBb0Q7SUFBa0I7Ozs7WUFDakY7Ozs7OztFQUNOOzs7O1lBRUwsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDYix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUE4RTtJQUV4Rjs7OztjQUVKLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWQ7TUFDRyxTQUFTLFNBQVMsY0FBYyxTQUMvQix3QkFBQyxNQUFELFlBQ0Usd0JBQUMsU0FBRDtPQUNFLElBQUc7T0FDSCxZQUFZLEVBQUUsZUFDWixzR0FDRSxXQUNJLCtEQUNBO2lCQU5WLENBVUUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7UUFBVSxNQUFLO1FBQU8sUUFBTztRQUFlLFNBQVE7UUFBWSxPQUFNO2tCQUNuRix3QkFBQyxRQUFEO1NBQU0sZUFBYztTQUFRLGdCQUFlO1NBQVEsYUFBWTtTQUFJLEdBQUU7UUFBNlE7Ozs7O09BQy9VOzs7O2lCQUFDLFdBRUM7Ozs7O2VBQ1A7Ozs7O01BR0wsU0FBUyxTQUFTLGNBQWMsU0FDL0Isd0JBQUMsTUFBRCxZQUNFLHdCQUFDLFNBQUQ7T0FDRSxJQUFHO09BQ0gsWUFBWSxFQUFFLGVBQ1osc0dBQ0UsV0FDSSwrREFDQTtpQkFOVixDQVVFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO1FBQVUsTUFBSztRQUFPLFFBQU87UUFBZSxTQUFRO1FBQVksT0FBTTtrQkFDbkYsd0JBQUMsUUFBRDtTQUFNLGVBQWM7U0FBUSxnQkFBZTtTQUFRLGFBQVk7U0FBSSxHQUFFO1FBQTZNOzs7OztPQUMvUTs7OztpQkFBQyxVQUVDOzs7OztlQUNQOzs7OztNQUdMLFNBQVMsU0FBUyxjQUFjLFNBQy9CLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxTQUFEO09BQ0UsSUFBRztPQUNILFlBQVksRUFBRSxlQUNaLHNHQUNFLFdBQ0ksK0RBQ0E7aUJBTlYsQ0FVRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtRQUFVLE1BQUs7UUFBTyxRQUFPO1FBQWUsU0FBUTtRQUFZLE9BQU07a0JBQ25GLHdCQUFDLFFBQUQ7U0FBTSxlQUFjO1NBQVEsZ0JBQWU7U0FBUSxhQUFZO1NBQUksR0FBRTtRQUF5SDs7Ozs7T0FDM0w7Ozs7aUJBQUMsTUFFQzs7Ozs7ZUFDUDs7Ozs7TUFHTCxTQUFTLFNBQVMsY0FBYyxTQUMvQix3QkFBQyxNQUFELFlBQ0Usd0JBQUMsU0FBRDtPQUNFLElBQUc7T0FDSCxZQUFZLEVBQUUsZUFDWixzR0FDRSxXQUNJLCtEQUNBO2lCQU5WLENBVUUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7UUFBVSxNQUFLO1FBQU8sUUFBTztRQUFlLFNBQVE7UUFBWSxPQUFNO2tCQUNuRix3QkFBQyxRQUFEO1NBQU0sZUFBYztTQUFRLGdCQUFlO1NBQVEsYUFBWTtTQUFJLEdBQUU7UUFBK0o7Ozs7O09BQ2pPOzs7O2lCQUFDLFlBRUM7Ozs7O2VBQ1A7Ozs7O01BR0wsU0FBUyxTQUFTLGNBQWMsU0FDL0IsZ0RBQ0Usd0JBQUMsTUFBRCxZQUNFLHdCQUFDLFNBQUQ7T0FDRSxJQUFHO09BQ0gsWUFBWSxFQUFFLGVBQ1osc0dBQ0UsV0FDSSwrREFDQTtpQkFOVixDQVVFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO1FBQVUsTUFBSztRQUFPLFFBQU87UUFBZSxTQUFRO1FBQVksT0FBTTtrQkFDbkYsd0JBQUMsUUFBRDtTQUFNLGVBQWM7U0FBUSxnQkFBZTtTQUFRLGFBQVk7U0FBSSxHQUFFO1FBQXNIOzs7OztPQUN4TDs7OztpQkFBQyxVQUVDOzs7OztlQUNQOzs7O2dCQUVKLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxTQUFEO09BQ0UsSUFBRztPQUNILFlBQVksRUFBRSxlQUNaLHNHQUNFLFdBQ0ksK0RBQ0E7aUJBTlYsQ0FVRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtRQUFVLE1BQUs7UUFBTyxRQUFPO1FBQWUsU0FBUTtRQUFZLE9BQU07a0JBQ25GLHdCQUFDLFFBQUQ7U0FBTSxlQUFjO1NBQVEsZ0JBQWU7U0FBUSxhQUFZO1NBQUksR0FBRTtRQUF3Szs7Ozs7T0FDMU87Ozs7aUJBQUMsV0FFQzs7Ozs7ZUFDUDs7OztjQUNKOzs7OztLQUVGOzs7OztZQUNEOzs7OztHQUNGOzs7OztFQUNGOzs7O1VBQ0E7Ozs7OztBQUVYIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOYXZMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi8uLi9jb250ZXh0L0F1dGhDb250ZXh0J1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTaWRlYmFyKCkge1xuICBjb25zdCB7IHNlc3Npb24gfSA9IHVzZUF1dGgoKVxuXG4gIHJldHVybiAoXG4gICAgPGFzaWRlIGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtMCB0b3AtMCB6LTk5OTkgZmxleCBoLXNjcmVlbiB3LVsyOTBweF0gZmxleC1jb2wgb3ZlcmZsb3cteS1oaWRkZW4gYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gZHVyYXRpb24tMzAwIGVhc2UtbGluZWFyIGxnOnN0YXRpYyBsZzp0cmFuc2xhdGUteC0wXCI+XG4gICAgICB7LyogU0lERUJBUiBIRUFERVIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktc3RhcnQgZ2FwLTIgcHgtNiBweS01LjUgbGc6cHktNi41IG10LTIgbWItMlwiPlxuICAgICAgICA8TmF2TGluayB0bz1cIi9cIiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLTEwIHctMTAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtbGcgYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC14bFwiPlxuICAgICAgICAgICAgPHN2ZyB3aWR0aD1cIjIwXCIgaGVpZ2h0PVwiMjBcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cIm5vbmVcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+XG4gICAgICAgICAgICAgIDxwYXRoIGQ9XCJNNCAxMlYyMEM0IDIwLjU1MjMgNC40NDc3MiAyMSA1IDIxSDE5QzE5LjU1MjMgMjEgMjAgMjAuNTUyMyAyMCAyMFYxMlwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMi41XCIgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIvPlxuICAgICAgICAgICAgICA8cGF0aCBkPVwiTTEyIDE1TDEyIDNcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjIuNVwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiLz5cbiAgICAgICAgICAgICAgPHBhdGggZD1cIk04IDdMMTIgM0wxNiA3XCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIyLjVcIiBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIvPlxuICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlXCI+UGxheWEgQXp1bDwvc3Ryb25nPlxuICAgICAgICA8L05hdkxpbms+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJuby1zY3JvbGxiYXIgZmxleCBmbGV4LWNvbCBvdmVyZmxvdy15LWF1dG8gZHVyYXRpb24tMzAwIGVhc2UtbGluZWFyXCI+XG4gICAgICAgIDxuYXYgY2xhc3NOYW1lPVwibXQtNSBweS00IHB4LTQgbGc6bXQtMiBsZzpweC02XCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IG1sLTQgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2VcIj5cbiAgICAgICAgICAgICAgTUVOw5pcbiAgICAgICAgICAgIDwvaDM+XG5cbiAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJtYi02IGZsZXggZmxleC1jb2wgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICB7c2Vzc2lvbj8udXN1YXJpbz8uc2lnbGFfcm9sICE9PSAnQ0FKJyAmJiAoXG4gICAgICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgICAgICAgPE5hdkxpbmtcbiAgICAgICAgICAgICAgICAgICAgdG89XCIvZGFzaGJvYXJkXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXsoeyBpc0FjdGl2ZSB9KSA9PlxuICAgICAgICAgICAgICAgICAgICAgIGBncm91cCByZWxhdGl2ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyByb3VuZGVkLW1kIHB4LTQgcHktMi41IGZvbnQtbWVkaXVtIGR1cmF0aW9uLTMwMCBlYXNlLWluLW91dCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgaXNBY3RpdmUgXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWJsdWUtNTAgZGFyazpiZy1bIzMxM0Q0QV0gdGV4dC1ibHVlLTYwMCBkYXJrOnRleHQtd2hpdGUnIFxuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGhvdmVyOmJnLXNsYXRlLTUwIGRhcms6aG92ZXI6YmctWyMzMTNENEFdIGhvdmVyOnRleHQtc2xhdGUtNzAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgICB9YFxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy01IGgtNVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk00IDZhMiAyIDAgMDEyLTJoMmEyIDIgMCAwMTIgMnYyYTIgMiAwIDAxLTIgMkg2YTIgMiAwIDAxLTItMlY2ek0xNCA2YTIgMiAwIDAxMi0yaDJhMiAyIDAgMDEyIDJ2MmEyIDIgMCAwMS0yIDJoLTJhMiAyIDAgMDEtMi0yVjZ6TTQgMTZhMiAyIDAgMDEyLTJoMmEyIDIgMCAwMTIgMnYyYTIgMiAwIDAxLTIgMkg2YTIgMiAwIDAxLTItMnYtMnpNMTQgMTZhMiAyIDAgMDEyLTJoMmEyIDIgMCAwMTIgMnYyYTIgMiAwIDAxLTIgMmgtMmEyIDIgMCAwMS0yLTJ2LTJ6XCI+PC9wYXRoPlxuICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgICAgICAgRGFzaGJvYXJkXG4gICAgICAgICAgICAgICAgICA8L05hdkxpbms+XG4gICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7c2Vzc2lvbj8udXN1YXJpbz8uc2lnbGFfcm9sICE9PSAnQ0FKJyAmJiAoXG4gICAgICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgICAgICAgPE5hdkxpbmtcbiAgICAgICAgICAgICAgICAgICAgdG89XCIvcmVwb3J0ZXNcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9eyh7IGlzQWN0aXZlIH0pID0+XG4gICAgICAgICAgICAgICAgICAgICAgYGdyb3VwIHJlbGF0aXZlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHJvdW5kZWQtbWQgcHgtNCBweS0yLjUgZm9udC1tZWRpdW0gZHVyYXRpb24tMzAwIGVhc2UtaW4tb3V0ICR7XG4gICAgICAgICAgICAgICAgICAgICAgICBpc0FjdGl2ZSBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctYmx1ZS01MCBkYXJrOmJnLVsjMzEzRDRBXSB0ZXh0LWJsdWUtNjAwIGRhcms6dGV4dC13aGl0ZScgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgaG92ZXI6Ymctc2xhdGUtNTAgZGFyazpob3ZlcjpiZy1bIzMxM0Q0QV0gaG92ZXI6dGV4dC1zbGF0ZS03MDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgICAgIH1gXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTUgaC01XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiPlxuICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTkgMTl2LTZhMiAyIDAgMDAtMi0ySDVhMiAyIDAgMDAtMiAydjZhMiAyIDAgMDAyIDJoMmEyIDIgMCAwMDItMnptMCAwVjlhMiAyIDAgMDEyLTJoMmEyIDIgMCAwMTIgMnYxMG0tNiAwYTIgMiAwIDAwMiAyaDJhMiAyIDAgMDAyLTJtMCAwVjVhMiAyIDAgMDEyLTJoMmEyIDIgMCAwMTIgMnYxNGEyIDIgMCAwMS0yIDJoLTJhMiAyIDAgMDEtMi0yelwiPjwvcGF0aD5cbiAgICAgICAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICAgICAgICAgIFJlcG9ydGVzXG4gICAgICAgICAgICAgICAgICA8L05hdkxpbms+XG4gICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7c2Vzc2lvbj8udXN1YXJpbz8uc2lnbGFfcm9sICE9PSAnT1BFJyAmJiAoXG4gICAgICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgICAgICAgPE5hdkxpbmtcbiAgICAgICAgICAgICAgICAgICAgdG89XCIvY2FqYVwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17KHsgaXNBY3RpdmUgfSkgPT5cbiAgICAgICAgICAgICAgICAgICAgICBgZ3JvdXAgcmVsYXRpdmUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcm91bmRlZC1tZCBweC00IHB5LTIuNSBmb250LW1lZGl1bSBkdXJhdGlvbi0zMDAgZWFzZS1pbi1vdXQgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzQWN0aXZlIFxuICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ibHVlLTUwIGRhcms6YmctWyMzMTNENEFdIHRleHQtYmx1ZS02MDAgZGFyazp0ZXh0LXdoaXRlJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBob3ZlcjpiZy1zbGF0ZS01MCBkYXJrOmhvdmVyOmJnLVsjMzEzRDRBXSBob3Zlcjp0ZXh0LXNsYXRlLTcwMCBkYXJrOmhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgICAgICAgfWBcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNSBoLTVcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMTUgNXYybTAgNHYybTAgNHYyTTUgNWEyIDIgMCAwMC0yIDJ2M2EyIDIgMCAxMTAgNHYzYTIgMiAwIDAwMiAyaDE0YTIgMiAwIDAwMi0ydi0zYTIgMiAwIDExMC00VjdhMiAyIDAgMDAtMi0ySDV6XCI+PC9wYXRoPlxuICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgICAgICAgQ2FqYVxuICAgICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxuICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAge3Nlc3Npb24/LnVzdWFyaW8/LnNpZ2xhX3JvbCAhPT0gJ0NBSicgJiYgKFxuICAgICAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgICAgICAgIDxOYXZMaW5rXG4gICAgICAgICAgICAgICAgICAgIHRvPVwiL2ludmVudGFyaW9cIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9eyh7IGlzQWN0aXZlIH0pID0+XG4gICAgICAgICAgICAgICAgICAgICAgYGdyb3VwIHJlbGF0aXZlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHJvdW5kZWQtbWQgcHgtNCBweS0yLjUgZm9udC1tZWRpdW0gZHVyYXRpb24tMzAwIGVhc2UtaW4tb3V0ICR7XG4gICAgICAgICAgICAgICAgICAgICAgICBpc0FjdGl2ZSBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctYmx1ZS01MCBkYXJrOmJnLVsjMzEzRDRBXSB0ZXh0LWJsdWUtNjAwIGRhcms6dGV4dC13aGl0ZScgXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgaG92ZXI6Ymctc2xhdGUtNTAgZGFyazpob3ZlcjpiZy1bIzMxM0Q0QV0gaG92ZXI6dGV4dC1zbGF0ZS03MDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgICAgIH1gXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTUgaC01XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiPlxuICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTE5IDExSDVtMTQgMGEyIDIgMCAwMTIgMnY2YTIgMiAwIDAxLTIgMkg1YTIgMiAwIDAxLTItMnYtNmEyIDIgMCAwMTItMm0xNCAwVjlhMiAyIDAgMDAtMi0yTTUgMTFWOWEyIDIgMCAwMTItMm0wIDBWNWEyIDIgMCAwMTItMmg2YTIgMiAwIDAxMiAydjJNNyA3aDEwXCI+PC9wYXRoPlxuICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgICAgICAgSW52ZW50YXJpb1xuICAgICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxuICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAge3Nlc3Npb24/LnVzdWFyaW8/LnNpZ2xhX3JvbCA9PT0gJ0FETScgJiYgKFxuICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICA8bGk+XG4gICAgICAgICAgICAgICAgICAgIDxOYXZMaW5rXG4gICAgICAgICAgICAgICAgICAgICAgdG89XCIvdXNlcnNcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17KHsgaXNBY3RpdmUgfSkgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgIGBncm91cCByZWxhdGl2ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyByb3VuZGVkLW1kIHB4LTQgcHktMi41IGZvbnQtbWVkaXVtIGR1cmF0aW9uLTMwMCBlYXNlLWluLW91dCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICBpc0FjdGl2ZSBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ibHVlLTUwIGRhcms6YmctWyMzMTNENEFdIHRleHQtYmx1ZS02MDAgZGFyazp0ZXh0LXdoaXRlJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGhvdmVyOmJnLXNsYXRlLTUwIGRhcms6aG92ZXI6YmctWyMzMTNENEFdIGhvdmVyOnRleHQtc2xhdGUtNzAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gXG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTUgaC01XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMTIgNC4zNTRhNCA0IDAgMTEwIDUuMjkyTTE1IDIxSDN2LTFhNiA2IDAgMDExMiAwdjF6bTAgMGg2di0xYTYgNiAwIDAwLTktNS4xOTdNMTMgN2E0IDQgMCAxMS04IDAgNCA0IDAgMDE4IDB6XCI+PC9wYXRoPlxuICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgICAgICAgICAgIFVzdWFyaW9zXG4gICAgICAgICAgICAgICAgICAgIDwvTmF2TGluaz5cbiAgICAgICAgICAgICAgICAgIDwvbGk+XG5cbiAgICAgICAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgICAgICAgICAgPE5hdkxpbmtcbiAgICAgICAgICAgICAgICAgICAgICB0bz1cIi9hdWRpdG9yaWFcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17KHsgaXNBY3RpdmUgfSkgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgIGBncm91cCByZWxhdGl2ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyByb3VuZGVkLW1kIHB4LTQgcHktMi41IGZvbnQtbWVkaXVtIGR1cmF0aW9uLTMwMCBlYXNlLWluLW91dCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICBpc0FjdGl2ZSBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ibHVlLTUwIGRhcms6YmctWyMzMTNENEFdIHRleHQtYmx1ZS02MDAgZGFyazp0ZXh0LXdoaXRlJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGhvdmVyOmJnLXNsYXRlLTUwIGRhcms6aG92ZXI6YmctWyMzMTNENEFdIGhvdmVyOnRleHQtc2xhdGUtNzAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gXG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTUgaC01XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNOSA1SDdhMiAyIDAgMDAtMiAydjEyYTIgMiAwIDAwMiAyaDEwYTIgMiAwIDAwMi0yVjdhMiAyIDAgMDAtMi0yaC0yTTkgNWEyIDIgMCAwMDIgMmgyYTIgMiAwIDAwMi0yTTkgNWEyIDIgMCAwMTItMmgyYTIgMiAwIDAxMiAybS0zIDdoM20tMyA0aDNtLTYtNGguMDFNOSAxNmguMDFcIj48L3BhdGg+XG4gICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICAgICAgICAgICAgQXVkaXRvcsOtYVxuICAgICAgICAgICAgICAgICAgICA8L05hdkxpbms+XG4gICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9uYXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2FzaWRlPlxuICApXG59XG4iXX0=