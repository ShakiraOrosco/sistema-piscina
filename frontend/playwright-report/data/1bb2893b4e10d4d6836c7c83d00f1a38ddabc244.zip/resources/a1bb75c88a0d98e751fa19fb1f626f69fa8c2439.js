import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/layout/AuthLayout.jsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport2_react_jsxDevRuntime["Fragment"];import { Outlet } from "/node_modules/.vite/deps/react-router-dom.js?v=41a64c35";
import { useAuth } from "/src/context/AuthContext.jsx";
var _jsxFileName = "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/layout/AuthLayout.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=41a64c35";
var _s = $RefreshSig$();
export default function AuthLayout() {
	_s();
	const { error } = useAuth();
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [error && /* @__PURE__ */ _jsxDEV("div", {
		className: "notice error",
		children: error
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 9,
		columnNumber: 17
	}, this), /* @__PURE__ */ _jsxDEV(Outlet, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 10,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 8,
		columnNumber: 5
	}, this);
}
_s(AuthLayout, "d2Wua+zVjEFVcbW4fUEg9Eu8vZ0=", false, function() {
	return [useAuth];
});
_c = AuthLayout;
var _c;
$RefreshReg$(_c, "AuthLayout");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/layout/AuthLayout.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/layout/AuthLayout.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/layout/AuthLayout.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/layout/AuthLayout.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsZUFBZTs7OztBQUV4QixlQUFlLFNBQVMsYUFBYTs7Q0FDbkMsTUFBTSxFQUFFLFVBQVUsUUFBUTtDQUUxQixPQUNFLGdEQUNHLFNBQVMsd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZ0I7Q0FBVzs7OztXQUNwRCx3QkFBQyxRQUFELENBQVM7Ozs7U0FDVDs7Ozs7QUFFTiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBdXRoTGF5b3V0LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBPdXRsZXQgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uL2NvbnRleHQvQXV0aENvbnRleHQnXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEF1dGhMYXlvdXQoKSB7XG4gIGNvbnN0IHsgZXJyb3IgfSA9IHVzZUF1dGgoKVxuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIHtlcnJvciAmJiA8ZGl2IGNsYXNzTmFtZT1cIm5vdGljZSBlcnJvclwiPntlcnJvcn08L2Rpdj59XG4gICAgICA8T3V0bGV0IC8+XG4gICAgPC8+XG4gIClcbn1cbiJdfQ==