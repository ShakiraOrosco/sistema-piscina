import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ReportesModal/index.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=41a64c35";
import api from "/src/services/api.js";
import { useAuth } from "/src/context/AuthContext.jsx";
var _jsxFileName = "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/components/ReportesModal/index.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=41a64c35";
var _s = $RefreshSig$();
export default function ReportesModal({ isOpen, onClose }) {
	_s();
	const { session } = useAuth();
	const [tipoReporte, setTipoReporte] = useState("calidad_agua");
	const [tipoRango, setTipoRango] = useState("semana");
	const [fechaInicio, setFechaInicio] = useState("");
	const [fechaFin, setFechaFin] = useState("");
	const [loading, setLoading] = useState(false);
	const [exportingPdf, setExportingPdf] = useState(false);
	const [reporteData, setReporteData] = useState(null);
	const [errorMsg, setErrorMsg] = useState(null);
	const [successMsg, setSuccessMsg] = useState(null);
	useEffect(() => {
		const hoyStr = new Date().toISOString().split("T")[0];
		const hace7dias = new Date(Date.now() - 6 * 24 * 60 * 60 * 1e3).toISOString().split("T")[0];
		setFechaInicio(hace7dias);
		setFechaFin(hoyStr);
	}, []);
	const fetchResumen = useCallback(async () => {
		if (!isOpen) return;
		setLoading(true);
		setErrorMsg(null);
		setSuccessMsg(null);
		const params = {
			tipo_rango: tipoRango,
			fecha_inicio: tipoRango === "personalizado" ? fechaInicio : undefined,
			fecha_fin: tipoRango === "personalizado" ? fechaFin : undefined
		};
		try {
			let endpoint = "/reportes/calidad-agua";
			if (tipoReporte === "dosificacion") endpoint = "/reportes/quimicos-dosificacion";
			if (tipoReporte === "afluencia") endpoint = "/reportes/afluencia";
			const { data } = await api.get(endpoint, { params });
			setReporteData(data);
		} catch (err) {
			console.error("Error al consultar datos de reporte:", err);
			setErrorMsg(err.response?.data?.detail || "No se pudieron obtener los datos para el reporte.");
		} finally {
			setLoading(false);
		}
	}, [
		isOpen,
		tipoReporte,
		tipoRango,
		fechaInicio,
		fechaFin
	]);
	useEffect(() => {
		if (isOpen) {
			fetchResumen();
		}
	}, [isOpen, fetchResumen]);
	const handleDescargarPdf = async () => {
		setExportingPdf(true);
		setErrorMsg(null);
		setSuccessMsg(null);
		try {
			const nombreUsuario = session?.usuario ? `${session.usuario.nombre || ""} ${session.usuario.primer_apellido || ""}`.trim() : "Administrador";
			const response = await api.get("/reportes/pdf", {
				params: {
					tipo_reporte: tipoReporte,
					tipo_rango: tipoRango,
					fecha_inicio: tipoRango === "personalizado" ? fechaInicio : undefined,
					fecha_fin: tipoRango === "personalizado" ? fechaFin : undefined,
					usuario_generador: nombreUsuario || "Administrador"
				},
				responseType: "blob"
			});
			const blob = new Blob([response.data], { type: "application/pdf" });
			const url = window.URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			const hoyStr = new Date().toISOString().split("T")[0];
			a.download = `reporte_playa_azul_${tipoReporte}_${hoyStr}.pdf`;
			document.body.appendChild(a);
			a.click();
			window.URL.revokeObjectURL(url);
			a.remove();
			setSuccessMsg("Reporte en PDF generado y descargado correctamente.");
		} catch (err) {
			console.error("Error al exportar PDF:", err);
			setErrorMsg("No se pudo generar el archivo PDF. Intente nuevamente.");
		} finally {
			setExportingPdf(false);
		}
	};
	if (!isOpen) return null;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-99999 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "relative w-full max-w-3xl rounded-2xl bg-white dark:bg-[#24303F] border border-slate-200 dark:border-[#313D4A] shadow-2xl overflow-hidden my-8",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between border-b border-slate-100 dark:border-[#313D4A] px-6 py-5 bg-slate-50 dark:bg-[#1A222C]",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex h-10 w-10 items-center justify-center rounded-xl bg-blue-600 text-white font-bold text-lg shadow-md shadow-blue-500/20",
							children: "📊"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 108,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-lg font-bold text-slate-800 dark:text-white",
							children: "Generar y Exportar Reporte Oficial"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 112,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-500 dark:text-slate-400",
							children: "Piscina Playa Azul · Cumplimiento Normativo Ley Municipal 020 & RD 742/2013"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 115,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 111,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 107,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 hover:text-slate-700 dark:hover:text-white transition-all",
						children: /* @__PURE__ */ _jsxDEV("svg", {
							className: "w-5 h-5",
							fill: "none",
							stroke: "currentColor",
							viewBox: "0 0 24 24",
							children: /* @__PURE__ */ _jsxDEV("path", {
								strokeLinecap: "round",
								strokeLinejoin: "round",
								strokeWidth: "2",
								d: "M6 18L18 6M6 6l12 12"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 126,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 125,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 121,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 106,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "p-6 space-y-5 max-h-[75vh] overflow-y-auto",
					children: [
						errorMsg && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 dark:bg-rose-950/30 dark:border-rose-900/50 dark:text-rose-400 text-xs font-semibold flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "⚠️" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 136,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: errorMsg }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 137,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 135,
							columnNumber: 13
						}, this),
						successMsg && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 dark:bg-emerald-950/30 dark:border-emerald-900/50 dark:text-emerald-400 text-xs font-semibold flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "✅" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 143,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: successMsg }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 144,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 142,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2",
							children: "1. Seleccione el Tipo de Reporte"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 150,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 sm:grid-cols-3 gap-2.5",
							children: [
								{
									id: "calidad_agua",
									label: "💧 Calidad del Agua",
									desc: "pH, Turbidez, Temp. y Cumplimiento"
								},
								{
									id: "dosificacion",
									label: "🧪 Químicos y Costos",
									desc: "Cloro, Cobre, Aluminio y Gastos (Bs)"
								},
								{
									id: "afluencia",
									label: "👥 Afluencia de Bañistas",
									desc: "Taquilla, Horarios Pico y Aforo"
								}
							].map((r) => /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setTipoReporte(r.id),
								className: `p-3 rounded-xl border text-left transition-all ${tipoReporte === r.id ? "border-blue-500 bg-blue-50/50 dark:bg-blue-900/20 ring-2 ring-blue-500/20" : "border-slate-200 dark:border-[#313D4A] hover:bg-slate-50 dark:hover:bg-slate-800"}`,
								children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs font-bold text-slate-800 dark:text-white",
									children: r.label
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 169,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5",
									children: r.desc
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 170,
									columnNumber: 19
								}, this)]
							}, r.id, true, {
								fileName: _jsxFileName,
								lineNumber: 159,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 153,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 149,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2",
								children: "2. Período a Evaluar"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 178,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									{
										id: "hoy",
										label: "Hoy"
									},
									{
										id: "semana",
										label: "Últimos 7 Días"
									},
									{
										id: "mes",
										label: "Últimos 30 Días"
									},
									{
										id: "personalizado",
										label: "Rango Personalizado"
									}
								].map((rg) => /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setTipoRango(rg.id),
									className: `px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${tipoRango === rg.id ? "bg-blue-600 text-white shadow-sm" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200"}`,
									children: rg.label
								}, rg.id, false, {
									fileName: _jsxFileName,
									lineNumber: 188,
									columnNumber: 17
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 181,
								columnNumber: 13
							}, this),
							tipoRango === "personalizado" && /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-3 grid grid-cols-2 gap-3 p-3 rounded-xl bg-slate-50 dark:bg-[#1A222C] border border-slate-200 dark:border-[#313D4A]",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[11px] text-slate-400 block mb-1",
									children: "Fecha de Inicio:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 206,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "date",
									value: fechaInicio,
									onChange: (e) => setFechaInicio(e.target.value),
									className: "w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-[#313D4A] bg-white dark:bg-[#24303F] text-xs text-slate-800 dark:text-white"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 207,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 205,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[11px] text-slate-400 block mb-1",
									children: "Fecha de Fin:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 215,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "date",
									value: fechaFin,
									onChange: (e) => setFechaFin(e.target.value),
									className: "w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-[#313D4A] bg-white dark:bg-[#24303F] text-xs text-slate-800 dark:text-white"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 216,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 214,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 204,
								columnNumber: 15
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 177,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "rounded-xl border border-slate-200 dark:border-[#313D4A] p-4 bg-slate-50 dark:bg-[#1A222C]",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between mb-2",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold text-slate-700 dark:text-slate-200",
										children: "Resumen Preliminar del Período"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 230,
										columnNumber: 15
									}, this), loading && /* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs text-blue-500 animate-pulse font-medium",
										children: "Cargando métricas..."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 233,
										columnNumber: 27
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 229,
									columnNumber: 13
								}, this),
								tipoReporte === "calidad_agua" && reporteData?.estadisticas && /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-3 gap-3 text-center",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-white dark:bg-[#24303F] p-2.5 rounded-lg border border-slate-200 dark:border-[#313D4A]",
											children: [
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] text-slate-400 uppercase font-semibold",
													children: "pH Promedio"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 239,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-lg font-black text-blue-600 dark:text-blue-400",
													children: reporteData.estadisticas.ph.promedio ?? "—"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 240,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] text-emerald-600 font-bold",
													children: [reporteData.estadisticas.ph.pct_cumplimiento, "% norma"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 243,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 238,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-white dark:bg-[#24303F] p-2.5 rounded-lg border border-slate-200 dark:border-[#313D4A]",
											children: [
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] text-slate-400 uppercase font-semibold",
													children: "Turbidez Media"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 248,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-lg font-black text-amber-600 dark:text-amber-400",
													children: [
														reporteData.estadisticas.turbidez.promedio ?? "—",
														" ",
														/* @__PURE__ */ _jsxDEV("span", {
															className: "text-xs font-normal",
															children: "NTU"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 250,
															columnNumber: 73
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 249,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] text-emerald-600 font-bold",
													children: [reporteData.estadisticas.turbidez.pct_cumplimiento, "% < 5 NTU"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 252,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 247,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-white dark:bg-[#24303F] p-2.5 rounded-lg border border-slate-200 dark:border-[#313D4A]",
											children: [
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] text-slate-400 uppercase font-semibold",
													children: "Índice Global"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 257,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-lg font-black text-emerald-600 dark:text-emerald-400",
													children: [reporteData.indice_global_cumplimiento, "%"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 258,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] text-slate-400 font-medium",
													children: [reporteData.total_mediciones, " muestras"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 261,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 256,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 237,
									columnNumber: 15
								}, this),
								tipoReporte === "dosificacion" && reporteData?.totales_dosificados_kg && /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-3 gap-3 text-center",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-white dark:bg-[#24303F] p-2.5 rounded-lg border border-slate-200 dark:border-[#313D4A]",
											children: [
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] text-slate-400 uppercase font-semibold",
													children: "Cloro"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 271,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-base font-bold text-slate-800 dark:text-white",
													children: [reporteData.totales_dosificados_kg.cloro, " kg"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 272,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] text-blue-500",
													children: ["Bs. ", reporteData.costos_estimados_bs.cloro.toFixed(2)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 275,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 270,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-white dark:bg-[#24303F] p-2.5 rounded-lg border border-slate-200 dark:border-[#313D4A]",
											children: [
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] text-slate-400 uppercase font-semibold",
													children: "Sulfato Aluminio"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 278,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-base font-bold text-slate-800 dark:text-white",
													children: [reporteData.totales_dosificados_kg["sulfato de aluminio"], " kg"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 279,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] text-blue-500",
													children: ["Bs. ", reporteData.costos_estimados_bs["sulfato de aluminio"].toFixed(2)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 282,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 277,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-white dark:bg-[#24303F] p-2.5 rounded-lg border border-slate-200 dark:border-[#313D4A]",
											children: [
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] text-slate-400 uppercase font-semibold",
													children: "Costo Total"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 285,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-base font-black text-emerald-600 dark:text-emerald-400",
													children: ["Bs. ", reporteData.costo_total_bs.toFixed(2)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 286,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] text-slate-400",
													children: "Inversión en insumos"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 289,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 284,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 269,
									columnNumber: 15
								}, this),
								tipoReporte === "afluencia" && reporteData?.resumen && /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-3 gap-3 text-center",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-white dark:bg-[#24303F] p-2.5 rounded-lg border border-slate-200 dark:border-[#313D4A]",
											children: [/* @__PURE__ */ _jsxDEV("p", {
												className: "text-[10px] text-slate-400 uppercase font-semibold",
												children: "Total Bañistas"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 297,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-base font-bold text-slate-800 dark:text-white",
												children: [reporteData.resumen.total_banistas, " personas"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 298,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 296,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-white dark:bg-[#24303F] p-2.5 rounded-lg border border-slate-200 dark:border-[#313D4A]",
											children: [/* @__PURE__ */ _jsxDEV("p", {
												className: "text-[10px] text-slate-400 uppercase font-semibold",
												children: "Recaudación"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 303,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-base font-black text-emerald-600 dark:text-emerald-400",
												children: ["Bs. ", reporteData.resumen.total_recaudado_bs.toFixed(2)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 304,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 302,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-white dark:bg-[#24303F] p-2.5 rounded-lg border border-slate-200 dark:border-[#313D4A]",
											children: [/* @__PURE__ */ _jsxDEV("p", {
												className: "text-[10px] text-slate-400 uppercase font-semibold",
												children: "Horario Pico"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 309,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-xs font-bold text-indigo-600 dark:text-indigo-400",
												children: reporteData.resumen.hora_pico
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 310,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 308,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 295,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 228,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 132,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between border-t border-slate-100 dark:border-[#313D4A] px-6 py-4 bg-slate-50 dark:bg-[#1A222C]",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: onClose,
						className: "px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-all",
						children: "Cerrar"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 321,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: handleDescargarPdf,
						disabled: exportingPdf || loading,
						className: "flex items-center gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-5 py-2.5 rounded-xl font-bold text-xs transition-all shadow-md hover:shadow-lg disabled:opacity-50",
						children: exportingPdf ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("svg", {
							className: "w-4 h-4 animate-spin",
							fill: "none",
							stroke: "currentColor",
							viewBox: "0 0 24 24",
							children: [/* @__PURE__ */ _jsxDEV("circle", {
								className: "opacity-25",
								cx: "12",
								cy: "12",
								r: "10",
								stroke: "currentColor",
								strokeWidth: "4"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 338,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("path", {
								className: "opacity-75",
								fill: "currentColor",
								d: "M4 12a8 8 0 018-8v8H4z"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 339,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 337,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Generando Documento..." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 341,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 336,
							columnNumber: 15
						}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("svg", {
							className: "w-4 h-4",
							fill: "none",
							stroke: "currentColor",
							viewBox: "0 0 24 24",
							children: /* @__PURE__ */ _jsxDEV("path", {
								strokeLinecap: "round",
								strokeLinejoin: "round",
								strokeWidth: "2",
								d: "M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 346,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 345,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Descargar Reporte PDF Oficial" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 348,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 344,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 329,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 320,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 104,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 103,
		columnNumber: 5
	}, this);
}
_s(ReportesModal, "WLvNPSBLC/du5cfluZaKPFNQUsI=", false, function() {
	return [useAuth];
});
_c = ReportesModal;
var _c;
$RefreshReg$(_c, "ReportesModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ReportesModal/index.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/components/ReportesModal/index.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/components/ReportesModal/index.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/components/ReportesModal/index.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFdBQVcsbUJBQW1CO0FBQ2pELE9BQU8sU0FBUztBQUNoQixTQUFTLGVBQWU7Ozs7QUFFeEIsZUFBZSxTQUFTLGNBQWMsRUFBRSxRQUFRLFdBQVc7O0NBQ3pELE1BQU0sRUFBRSxZQUFZLFFBQVE7Q0FFNUIsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsY0FBYztDQUM3RCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxRQUFRO0NBQ25ELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEVBQUU7Q0FDakQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEVBQUU7Q0FFM0MsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLEtBQUs7Q0FDNUMsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsS0FBSztDQUN0RCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxJQUFJO0NBQ25ELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxJQUFJO0NBQzdDLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLElBQUk7Q0FFakQsZ0JBQWdCO0VBQ2QsTUFBTSxTQUFTLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztFQUNuRCxNQUFNLFlBQVksSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLElBQUksS0FBSyxLQUFLLEtBQUssR0FBSSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztFQUMxRixlQUFlLFNBQVM7RUFDeEIsWUFBWSxNQUFNO0NBQ3BCLEdBQUcsQ0FBQyxDQUFDO0NBRUwsTUFBTSxlQUFlLFlBQVksWUFBWTtFQUMzQyxJQUFJLENBQUMsUUFBUTtFQUNiLFdBQVcsSUFBSTtFQUNmLFlBQVksSUFBSTtFQUNoQixjQUFjLElBQUk7RUFFbEIsTUFBTSxTQUFTO0dBQ2IsWUFBWTtHQUNaLGNBQWMsY0FBYyxrQkFBa0IsY0FBYztHQUM1RCxXQUFXLGNBQWMsa0JBQWtCLFdBQVc7RUFDeEQ7RUFFQSxJQUFJO0dBQ0YsSUFBSSxXQUFXO0dBQ2YsSUFBSSxnQkFBZ0IsZ0JBQWdCLFdBQVc7R0FDL0MsSUFBSSxnQkFBZ0IsYUFBYSxXQUFXO0dBRTVDLE1BQU0sRUFBRSxTQUFTLE1BQU0sSUFBSSxJQUFJLFVBQVUsRUFBRSxPQUFPLENBQUM7R0FDbkQsZUFBZSxJQUFJO0VBQ3JCLFNBQVMsS0FBSztHQUNaLFFBQVEsTUFBTSx3Q0FBd0MsR0FBRztHQUN6RCxZQUFZLElBQUksVUFBVSxNQUFNLFVBQVUsbURBQW1EO0VBQy9GLFVBQVU7R0FDUixXQUFXLEtBQUs7RUFDbEI7Q0FDRixHQUFHO0VBQUM7RUFBUTtFQUFhO0VBQVc7RUFBYTtDQUFRLENBQUM7Q0FFMUQsZ0JBQWdCO0VBQ2QsSUFBSSxRQUFRO0dBQ1YsYUFBYTtFQUNmO0NBQ0YsR0FBRyxDQUFDLFFBQVEsWUFBWSxDQUFDO0NBRXpCLE1BQU0scUJBQXFCLFlBQVk7RUFDckMsZ0JBQWdCLElBQUk7RUFDcEIsWUFBWSxJQUFJO0VBQ2hCLGNBQWMsSUFBSTtFQUVsQixJQUFJO0dBQ0YsTUFBTSxnQkFBZ0IsU0FBUyxVQUMzQixHQUFHLFFBQVEsUUFBUSxVQUFVLEdBQUcsR0FBRyxRQUFRLFFBQVEsbUJBQW1CLEtBQUssS0FBSyxJQUNoRjtHQUVKLE1BQU0sV0FBVyxNQUFNLElBQUksSUFBSSxpQkFBaUI7SUFDOUMsUUFBUTtLQUNOLGNBQWM7S0FDZCxZQUFZO0tBQ1osY0FBYyxjQUFjLGtCQUFrQixjQUFjO0tBQzVELFdBQVcsY0FBYyxrQkFBa0IsV0FBVztLQUN0RCxtQkFBbUIsaUJBQWlCO0lBQ3RDO0lBQ0EsY0FBYztHQUNoQixDQUFDO0dBRUQsTUFBTSxPQUFPLElBQUksS0FBSyxDQUFDLFNBQVMsSUFBSSxHQUFHLEVBQUUsTUFBTSxrQkFBa0IsQ0FBQztHQUNsRSxNQUFNLE1BQU0sT0FBTyxJQUFJLGdCQUFnQixJQUFJO0dBQzNDLE1BQU0sSUFBSSxTQUFTLGNBQWMsR0FBRztHQUNwQyxFQUFFLE9BQU87R0FDVCxNQUFNLFNBQVMsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0dBQ25ELEVBQUUsV0FBVyxzQkFBc0IsWUFBWSxHQUFHLE9BQU87R0FDekQsU0FBUyxLQUFLLFlBQVksQ0FBQztHQUMzQixFQUFFLE1BQU07R0FDUixPQUFPLElBQUksZ0JBQWdCLEdBQUc7R0FDOUIsRUFBRSxPQUFPO0dBRVQsY0FBYyxxREFBcUQ7RUFDckUsU0FBUyxLQUFLO0dBQ1osUUFBUSxNQUFNLDBCQUEwQixHQUFHO0dBQzNDLFlBQVksd0RBQXdEO0VBQ3RFLFVBQVU7R0FDUixnQkFBZ0IsS0FBSztFQUN2QjtDQUNGO0NBRUEsSUFBSSxDQUFDLFFBQVEsT0FBTztDQUVwQixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ2Isd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUVFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUE4SDtNQUV4STs7OztnQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQW1EO01BRTdEOzs7O2dCQUNKLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUE2QztNQUV2RDs7OztjQUNBOzs7O2NBQ0Y7Ozs7O2VBRUwsd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxXQUFVO2dCQUVWLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO09BQVUsTUFBSztPQUFPLFFBQU87T0FBZSxTQUFRO2lCQUNqRSx3QkFBQyxRQUFEO1FBQU0sZUFBYztRQUFRLGdCQUFlO1FBQVEsYUFBWTtRQUFJLEdBQUU7T0FBd0I7Ozs7O01BQzFGOzs7OztLQUNDOzs7O2FBQ0w7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFFRyxZQUNDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLEtBQVE7Ozs7aUJBQ2Qsd0JBQUMsUUFBRCxZQUFPLFNBQWU7Ozs7ZUFDbkI7Ozs7OztNQUdOLGNBQ0Msd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sSUFBTzs7OztpQkFDYix3QkFBQyxRQUFELFlBQU8sV0FBaUI7Ozs7ZUFDckI7Ozs7OztNQUlQLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBdUU7TUFFakY7Ozs7Z0JBQ1Asd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1o7UUFDQztTQUFFLElBQUk7U0FBZ0IsT0FBTztTQUF1QixNQUFNO1FBQXFDO1FBQy9GO1NBQUUsSUFBSTtTQUFnQixPQUFPO1NBQXdCLE1BQU07UUFBdUM7UUFDbEc7U0FBRSxJQUFJO1NBQWEsT0FBTztTQUE0QixNQUFNO1FBQWtDO09BQ2hHLENBQUMsQ0FBQyxLQUFLLE1BQ0wsd0JBQUMsVUFBRDtRQUVFLE1BQUs7UUFDTCxlQUFlLGVBQWUsRUFBRSxFQUFFO1FBQ2xDLFdBQVcsa0RBQ1QsZ0JBQWdCLEVBQUUsS0FDZCw4RUFDQTtrQkFQUixDQVVFLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFvRCxFQUFFO1FBQVM7Ozs7a0JBQzVFLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUF5RCxFQUFFO1FBQVE7Ozs7Z0JBQzFFO1VBWEQsRUFBRTs7OztjQVdELENBQ1Q7TUFDRTs7OztjQUNGOzs7OztNQUdMLHdCQUFDLE9BQUQ7T0FDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBdUU7T0FFakY7Ozs7O09BQ1Asd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1o7U0FDQztVQUFFLElBQUk7VUFBTyxPQUFPO1NBQU07U0FDMUI7VUFBRSxJQUFJO1VBQVUsT0FBTztTQUFpQjtTQUN4QztVQUFFLElBQUk7VUFBTyxPQUFPO1NBQWtCO1NBQ3RDO1VBQUUsSUFBSTtVQUFpQixPQUFPO1NBQXNCO1FBQ3RELENBQUMsQ0FBQyxLQUFLLE9BQ0wsd0JBQUMsVUFBRDtTQUVFLE1BQUs7U0FDTCxlQUFlLGFBQWEsR0FBRyxFQUFFO1NBQ2pDLFdBQVcsMkRBQ1QsY0FBYyxHQUFHLEtBQ2IscUNBQ0E7bUJBR0wsR0FBRztRQUNFLEdBVkQsR0FBRzs7OztlQVVGLENBQ1Q7T0FDRTs7Ozs7T0FFSixjQUFjLG1CQUNiLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUF3QztRQUFzQjs7OztrQkFDOUUsd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxPQUFPO1NBQ1AsV0FBVyxNQUFNLGVBQWUsRUFBRSxPQUFPLEtBQUs7U0FDOUMsV0FBVTtRQUNYOzs7O2dCQUNFOzs7O2tCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBd0M7UUFBbUI7Ozs7a0JBQzNFLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsT0FBTztTQUNQLFdBQVcsTUFBTSxZQUFZLEVBQUUsT0FBTyxLQUFLO1NBQzNDLFdBQVU7UUFDWDs7OztnQkFDRTs7OztnQkFDRjs7Ozs7O01BRUo7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUF1RDtTQUVqRTs7OzttQkFDTCxXQUFXLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFrRDtTQUEwQjs7OztpQkFDckc7Ozs7OztRQUVKLGdCQUFnQixrQkFBa0IsYUFBYSxnQkFDOUMsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZjtZQUNFLHdCQUFDLEtBQUQ7YUFBRyxXQUFVO3VCQUFxRDtZQUFjOzs7OztZQUNoRix3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFDVixZQUFZLGFBQWEsR0FBRyxZQUFZO1lBQ3hDOzs7OztZQUNILHdCQUFDLEtBQUQ7YUFBRyxXQUFVO3VCQUFiLENBQ0csWUFBWSxhQUFhLEdBQUcsa0JBQWlCLFNBQzdDOzs7Ozs7V0FDQTs7Ozs7O1VBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRSx3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFBcUQ7WUFBaUI7Ozs7O1lBQ25GLHdCQUFDLEtBQUQ7YUFBRyxXQUFVO3VCQUFiO2NBQ0csWUFBWSxhQUFhLFNBQVMsWUFBWTtjQUFJO2NBQUMsd0JBQUMsUUFBRDtlQUFNLFdBQVU7eUJBQXNCO2NBQVM7Ozs7O2FBQ2xHOzs7Ozs7WUFDSCx3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFBYixDQUNHLFlBQVksYUFBYSxTQUFTLGtCQUFpQixXQUNuRDs7Ozs7O1dBQ0E7Ozs7OztVQUNMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmO1lBQ0Usd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQXFEO1lBQWdCOzs7OztZQUNsRix3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFBYixDQUNHLFlBQVksNEJBQTJCLEdBQ3ZDOzs7Ozs7WUFDSCx3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFBYixDQUNHLFlBQVksa0JBQWlCLFdBQzdCOzs7Ozs7V0FDQTs7Ozs7O1NBQ0Y7Ozs7OztRQUdOLGdCQUFnQixrQkFBa0IsYUFBYSwwQkFDOUMsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZjtZQUNFLHdCQUFDLEtBQUQ7YUFBRyxXQUFVO3VCQUFxRDtZQUFROzs7OztZQUMxRSx3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFBYixDQUNHLFlBQVksdUJBQXVCLE9BQU0sS0FDekM7Ozs7OztZQUNILHdCQUFDLEtBQUQ7YUFBRyxXQUFVO3VCQUFiLENBQXlDLFFBQUssWUFBWSxvQkFBb0IsTUFBTSxRQUFRLENBQUMsQ0FBSzs7Ozs7O1dBQy9GOzs7Ozs7VUFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZjtZQUNFLHdCQUFDLEtBQUQ7YUFBRyxXQUFVO3VCQUFxRDtZQUFtQjs7Ozs7WUFDckYsd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQWIsQ0FDRyxZQUFZLHVCQUF1Qix3QkFBdUIsS0FDMUQ7Ozs7OztZQUNILHdCQUFDLEtBQUQ7YUFBRyxXQUFVO3VCQUFiLENBQXlDLFFBQUssWUFBWSxvQkFBb0Isc0JBQXNCLENBQUMsUUFBUSxDQUFDLENBQUs7Ozs7OztXQUNoSDs7Ozs7O1VBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRSx3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFBcUQ7WUFBYzs7Ozs7WUFDaEYsd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQWIsQ0FBMkUsUUFDcEUsWUFBWSxlQUFlLFFBQVEsQ0FBQyxDQUN4Qzs7Ozs7O1lBQ0gsd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQTZCO1lBQXVCOzs7OztXQUM5RDs7Ozs7O1NBQ0Y7Ozs7OztRQUdOLGdCQUFnQixlQUFlLGFBQWEsV0FDM0Msd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLEtBQUQ7WUFBRyxXQUFVO3NCQUFxRDtXQUFpQjs7OztxQkFDbkYsd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQWIsQ0FDRyxZQUFZLFFBQVEsZ0JBQWUsV0FDbkM7Ozs7O21CQUNBOzs7Ozs7VUFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLEtBQUQ7WUFBRyxXQUFVO3NCQUFxRDtXQUFjOzs7O3FCQUNoRix3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFBYixDQUEyRSxRQUNwRSxZQUFZLFFBQVEsbUJBQW1CLFFBQVEsQ0FBQyxDQUNwRDs7Ozs7bUJBQ0E7Ozs7OztVQUNMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQXFEO1dBQWU7Ozs7cUJBQ2pGLHdCQUFDLEtBQUQ7WUFBRyxXQUFVO3NCQUNWLFlBQVksUUFBUTtXQUNwQjs7OzttQkFDQTs7Ozs7O1NBQ0Y7Ozs7OztPQUVKOzs7Ozs7S0FDRjs7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFVBQUQ7TUFDRSxNQUFLO01BQ0wsU0FBUztNQUNULFdBQVU7Z0JBQ1g7S0FFTzs7OztlQUVSLHdCQUFDLFVBQUQ7TUFDRSxNQUFLO01BQ0wsU0FBUztNQUNULFVBQVUsZ0JBQWdCO01BQzFCLFdBQVU7Z0JBRVQsZUFDQyxnREFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtPQUF1QixNQUFLO09BQU8sUUFBTztPQUFlLFNBQVE7aUJBQWhGLENBQ0Usd0JBQUMsVUFBRDtRQUFRLFdBQVU7UUFBYSxJQUFHO1FBQUssSUFBRztRQUFLLEdBQUU7UUFBSyxRQUFPO1FBQWUsYUFBWTtPQUFZOzs7O2lCQUNwRyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtRQUFhLE1BQUs7UUFBZSxHQUFFO09BQStCOzs7O2VBQy9FOzs7OztnQkFDTCx3QkFBQyxRQUFELFlBQU0seUJBQTRCOzs7O2NBQ2xDOzs7O2lCQUVGLGdEQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO09BQVUsTUFBSztPQUFPLFFBQU87T0FBZSxTQUFRO2lCQUNqRSx3QkFBQyxRQUFEO1FBQU0sZUFBYztRQUFRLGdCQUFlO1FBQVEsYUFBWTtRQUFJLEdBQUU7T0FBbUk7Ozs7O01BQ3JNOzs7O2dCQUNMLHdCQUFDLFFBQUQsWUFBTSxnQ0FBbUM7Ozs7Y0FDekM7Ozs7O0tBRUU7Ozs7YUFDTDs7Ozs7O0dBQ0Y7Ozs7OztDQUNGOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VDYWxsYmFjayB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IGFwaSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9hcGknXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vY29udGV4dC9BdXRoQ29udGV4dCdcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUmVwb3J0ZXNNb2RhbCh7IGlzT3Blbiwgb25DbG9zZSB9KSB7XG4gIGNvbnN0IHsgc2Vzc2lvbiB9ID0gdXNlQXV0aCgpXG5cbiAgY29uc3QgW3RpcG9SZXBvcnRlLCBzZXRUaXBvUmVwb3J0ZV0gPSB1c2VTdGF0ZSgnY2FsaWRhZF9hZ3VhJylcbiAgY29uc3QgW3RpcG9SYW5nbywgc2V0VGlwb1JhbmdvXSA9IHVzZVN0YXRlKCdzZW1hbmEnKVxuICBjb25zdCBbZmVjaGFJbmljaW8sIHNldEZlY2hhSW5pY2lvXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbZmVjaGFGaW4sIHNldEZlY2hhRmluXSA9IHVzZVN0YXRlKCcnKVxuXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbZXhwb3J0aW5nUGRmLCBzZXRFeHBvcnRpbmdQZGZdID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtyZXBvcnRlRGF0YSwgc2V0UmVwb3J0ZURhdGFdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW2Vycm9yTXNnLCBzZXRFcnJvck1zZ10gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbc3VjY2Vzc01zZywgc2V0U3VjY2Vzc01zZ10gPSB1c2VTdGF0ZShudWxsKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgaG95U3RyID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF1cbiAgICBjb25zdCBoYWNlN2RpYXMgPSBuZXcgRGF0ZShEYXRlLm5vdygpIC0gNiAqIDI0ICogNjAgKiA2MCAqIDEwMDApLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXVxuICAgIHNldEZlY2hhSW5pY2lvKGhhY2U3ZGlhcylcbiAgICBzZXRGZWNoYUZpbihob3lTdHIpXG4gIH0sIFtdKVxuXG4gIGNvbnN0IGZldGNoUmVzdW1lbiA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcbiAgICBpZiAoIWlzT3BlbikgcmV0dXJuXG4gICAgc2V0TG9hZGluZyh0cnVlKVxuICAgIHNldEVycm9yTXNnKG51bGwpXG4gICAgc2V0U3VjY2Vzc01zZyhudWxsKVxuXG4gICAgY29uc3QgcGFyYW1zID0ge1xuICAgICAgdGlwb19yYW5nbzogdGlwb1JhbmdvLFxuICAgICAgZmVjaGFfaW5pY2lvOiB0aXBvUmFuZ28gPT09ICdwZXJzb25hbGl6YWRvJyA/IGZlY2hhSW5pY2lvIDogdW5kZWZpbmVkLFxuICAgICAgZmVjaGFfZmluOiB0aXBvUmFuZ28gPT09ICdwZXJzb25hbGl6YWRvJyA/IGZlY2hhRmluIDogdW5kZWZpbmVkLFxuICAgIH1cblxuICAgIHRyeSB7XG4gICAgICBsZXQgZW5kcG9pbnQgPSAnL3JlcG9ydGVzL2NhbGlkYWQtYWd1YSdcbiAgICAgIGlmICh0aXBvUmVwb3J0ZSA9PT0gJ2Rvc2lmaWNhY2lvbicpIGVuZHBvaW50ID0gJy9yZXBvcnRlcy9xdWltaWNvcy1kb3NpZmljYWNpb24nXG4gICAgICBpZiAodGlwb1JlcG9ydGUgPT09ICdhZmx1ZW5jaWEnKSBlbmRwb2ludCA9ICcvcmVwb3J0ZXMvYWZsdWVuY2lhJ1xuXG4gICAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IGFwaS5nZXQoZW5kcG9pbnQsIHsgcGFyYW1zIH0pXG4gICAgICBzZXRSZXBvcnRlRGF0YShkYXRhKVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgYWwgY29uc3VsdGFyIGRhdG9zIGRlIHJlcG9ydGU6JywgZXJyKVxuICAgICAgc2V0RXJyb3JNc2coZXJyLnJlc3BvbnNlPy5kYXRhPy5kZXRhaWwgfHwgJ05vIHNlIHB1ZGllcm9uIG9idGVuZXIgbG9zIGRhdG9zIHBhcmEgZWwgcmVwb3J0ZS4nKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKVxuICAgIH1cbiAgfSwgW2lzT3BlbiwgdGlwb1JlcG9ydGUsIHRpcG9SYW5nbywgZmVjaGFJbmljaW8sIGZlY2hhRmluXSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChpc09wZW4pIHtcbiAgICAgIGZldGNoUmVzdW1lbigpXG4gICAgfVxuICB9LCBbaXNPcGVuLCBmZXRjaFJlc3VtZW5dKVxuXG4gIGNvbnN0IGhhbmRsZURlc2NhcmdhclBkZiA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRFeHBvcnRpbmdQZGYodHJ1ZSlcbiAgICBzZXRFcnJvck1zZyhudWxsKVxuICAgIHNldFN1Y2Nlc3NNc2cobnVsbClcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCBub21icmVVc3VhcmlvID0gc2Vzc2lvbj8udXN1YXJpb1xuICAgICAgICA/IGAke3Nlc3Npb24udXN1YXJpby5ub21icmUgfHwgJyd9ICR7c2Vzc2lvbi51c3VhcmlvLnByaW1lcl9hcGVsbGlkbyB8fCAnJ31gLnRyaW0oKVxuICAgICAgICA6ICdBZG1pbmlzdHJhZG9yJ1xuXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoJy9yZXBvcnRlcy9wZGYnLCB7XG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHRpcG9fcmVwb3J0ZTogdGlwb1JlcG9ydGUsXG4gICAgICAgICAgdGlwb19yYW5nbzogdGlwb1JhbmdvLFxuICAgICAgICAgIGZlY2hhX2luaWNpbzogdGlwb1JhbmdvID09PSAncGVyc29uYWxpemFkbycgPyBmZWNoYUluaWNpbyA6IHVuZGVmaW5lZCxcbiAgICAgICAgICBmZWNoYV9maW46IHRpcG9SYW5nbyA9PT0gJ3BlcnNvbmFsaXphZG8nID8gZmVjaGFGaW4gOiB1bmRlZmluZWQsXG4gICAgICAgICAgdXN1YXJpb19nZW5lcmFkb3I6IG5vbWJyZVVzdWFyaW8gfHwgJ0FkbWluaXN0cmFkb3InLFxuICAgICAgICB9LFxuICAgICAgICByZXNwb25zZVR5cGU6ICdibG9iJyxcbiAgICAgIH0pXG5cbiAgICAgIGNvbnN0IGJsb2IgPSBuZXcgQmxvYihbcmVzcG9uc2UuZGF0YV0sIHsgdHlwZTogJ2FwcGxpY2F0aW9uL3BkZicgfSlcbiAgICAgIGNvbnN0IHVybCA9IHdpbmRvdy5VUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpXG4gICAgICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpXG4gICAgICBhLmhyZWYgPSB1cmxcbiAgICAgIGNvbnN0IGhveVN0ciA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdXG4gICAgICBhLmRvd25sb2FkID0gYHJlcG9ydGVfcGxheWFfYXp1bF8ke3RpcG9SZXBvcnRlfV8ke2hveVN0cn0ucGRmYFxuICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChhKVxuICAgICAgYS5jbGljaygpXG4gICAgICB3aW5kb3cuVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpXG4gICAgICBhLnJlbW92ZSgpXG5cbiAgICAgIHNldFN1Y2Nlc3NNc2coJ1JlcG9ydGUgZW4gUERGIGdlbmVyYWRvIHkgZGVzY2FyZ2FkbyBjb3JyZWN0YW1lbnRlLicpXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBhbCBleHBvcnRhciBQREY6JywgZXJyKVxuICAgICAgc2V0RXJyb3JNc2coJ05vIHNlIHB1ZG8gZ2VuZXJhciBlbCBhcmNoaXZvIFBERi4gSW50ZW50ZSBudWV2YW1lbnRlLicpXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldEV4cG9ydGluZ1BkZihmYWxzZSlcbiAgICB9XG4gIH1cblxuICBpZiAoIWlzT3BlbikgcmV0dXJuIG51bGxcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTk5OTk5IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLWJsYWNrLzYwIGJhY2tkcm9wLWJsdXItc20gcC00IG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgbWF4LXctM3hsIHJvdW5kZWQtMnhsIGJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBzaGFkb3ctMnhsIG92ZXJmbG93LWhpZGRlbiBteS04XCI+XG4gICAgICAgIHsvKiBDYWJlY2VyYSBkZWwgTW9kYWwgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItWyMzMTNENEFdIHB4LTYgcHktNSBiZy1zbGF0ZS01MCBkYXJrOmJnLVsjMUEyMjJDXVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLTEwIHctMTAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQteGwgYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC1sZyBzaGFkb3ctbWQgc2hhZG93LWJsdWUtNTAwLzIwXCI+XG4gICAgICAgICAgICAgIPCfk4pcbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgIEdlbmVyYXIgeSBFeHBvcnRhciBSZXBvcnRlIE9maWNpYWxcbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgUGlzY2luYSBQbGF5YSBBenVsIMK3IEN1bXBsaW1pZW50byBOb3JtYXRpdm8gTGV5IE11bmljaXBhbCAwMjAgJiBSRCA3NDIvMjAxM1xuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGgtOCB3LTggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtbGcgdGV4dC1zbGF0ZS00MDAgaG92ZXI6Ymctc2xhdGUtMjAwIGRhcms6aG92ZXI6Ymctc2xhdGUtNzAwIGhvdmVyOnRleHQtc2xhdGUtNzAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTUgaC01XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTYgMThMMTggNk02IDZsMTIgMTJcIiAvPlxuICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBDb250ZW5pZG8gZGVsIE1vZGFsICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiBzcGFjZS15LTUgbWF4LWgtWzc1dmhdIG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgICAgIHsvKiBNZW5zYWplcyBkZSBFc3RhZG8gKi99XG4gICAgICAgICAge2Vycm9yTXNnICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zLjUgcm91bmRlZC14bCBiZy1yb3NlLTUwIGJvcmRlciBib3JkZXItcm9zZS0yMDAgdGV4dC1yb3NlLTcwMCBkYXJrOmJnLXJvc2UtOTUwLzMwIGRhcms6Ym9yZGVyLXJvc2UtOTAwLzUwIGRhcms6dGV4dC1yb3NlLTQwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPHNwYW4+4pqg77iPPC9zcGFuPlxuICAgICAgICAgICAgICA8c3Bhbj57ZXJyb3JNc2d9PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHtzdWNjZXNzTXNnICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zLjUgcm91bmRlZC14bCBiZy1lbWVyYWxkLTUwIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDAgdGV4dC1lbWVyYWxkLTcwMCBkYXJrOmJnLWVtZXJhbGQtOTUwLzMwIGRhcms6Ym9yZGVyLWVtZXJhbGQtOTAwLzUwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPHNwYW4+4pyFPC9zcGFuPlxuICAgICAgICAgICAgICA8c3Bhbj57c3VjY2Vzc01zZ308L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIFNlbGVjdG9yIGRlIFRpcG8gZGUgUmVwb3J0ZSAqL31cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMCBtYi0yXCI+XG4gICAgICAgICAgICAgIDEuIFNlbGVjY2lvbmUgZWwgVGlwbyBkZSBSZXBvcnRlXG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0zIGdhcC0yLjVcIj5cbiAgICAgICAgICAgICAge1tcbiAgICAgICAgICAgICAgICB7IGlkOiAnY2FsaWRhZF9hZ3VhJywgbGFiZWw6ICfwn5KnIENhbGlkYWQgZGVsIEFndWEnLCBkZXNjOiAncEgsIFR1cmJpZGV6LCBUZW1wLiB5IEN1bXBsaW1pZW50bycgfSxcbiAgICAgICAgICAgICAgICB7IGlkOiAnZG9zaWZpY2FjaW9uJywgbGFiZWw6ICfwn6eqIFF1w61taWNvcyB5IENvc3RvcycsIGRlc2M6ICdDbG9ybywgQ29icmUsIEFsdW1pbmlvIHkgR2FzdG9zIChCcyknIH0sXG4gICAgICAgICAgICAgICAgeyBpZDogJ2FmbHVlbmNpYScsIGxhYmVsOiAn8J+RpSBBZmx1ZW5jaWEgZGUgQmHDsWlzdGFzJywgZGVzYzogJ1RhcXVpbGxhLCBIb3JhcmlvcyBQaWNvIHkgQWZvcm8nIH0sXG4gICAgICAgICAgICAgIF0ubWFwKChyKSA9PiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAga2V5PXtyLmlkfVxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRUaXBvUmVwb3J0ZShyLmlkKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMyByb3VuZGVkLXhsIGJvcmRlciB0ZXh0LWxlZnQgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgdGlwb1JlcG9ydGUgPT09IHIuaWRcbiAgICAgICAgICAgICAgICAgICAgICA/ICdib3JkZXItYmx1ZS01MDAgYmctYmx1ZS01MC81MCBkYXJrOmJnLWJsdWUtOTAwLzIwIHJpbmctMiByaW5nLWJsdWUtNTAwLzIwJ1xuICAgICAgICAgICAgICAgICAgICAgIDogJ2JvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIGhvdmVyOmJnLXNsYXRlLTUwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlXCI+e3IubGFiZWx9PC9wPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBtdC0wLjVcIj57ci5kZXNjfTwvcD5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBTZWxlY3RvciBkZSBSYW5nbyBkZSBGZWNoYXMgKi99XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgbWItMlwiPlxuICAgICAgICAgICAgICAyLiBQZXLDrW9kbyBhIEV2YWx1YXJcbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICB7W1xuICAgICAgICAgICAgICAgIHsgaWQ6ICdob3knLCBsYWJlbDogJ0hveScgfSxcbiAgICAgICAgICAgICAgICB7IGlkOiAnc2VtYW5hJywgbGFiZWw6ICfDmmx0aW1vcyA3IETDrWFzJyB9LFxuICAgICAgICAgICAgICAgIHsgaWQ6ICdtZXMnLCBsYWJlbDogJ8OabHRpbW9zIDMwIETDrWFzJyB9LFxuICAgICAgICAgICAgICAgIHsgaWQ6ICdwZXJzb25hbGl6YWRvJywgbGFiZWw6ICdSYW5nbyBQZXJzb25hbGl6YWRvJyB9LFxuICAgICAgICAgICAgICBdLm1hcCgocmcpID0+IChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBrZXk9e3JnLmlkfVxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRUaXBvUmFuZ28ocmcuaWQpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMyBweS0xLjUgcm91bmRlZC1sZyB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICB0aXBvUmFuZ28gPT09IHJnLmlkXG4gICAgICAgICAgICAgICAgICAgICAgPyAnYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBzaGFkb3ctc20nXG4gICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgaG92ZXI6Ymctc2xhdGUtMjAwJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAge3JnLmxhYmVsfVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7dGlwb1JhbmdvID09PSAncGVyc29uYWxpemFkbycgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgZ3JpZCBncmlkLWNvbHMtMiBnYXAtMyBwLTMgcm91bmRlZC14bCBiZy1zbGF0ZS01MCBkYXJrOmJnLVsjMUEyMjJDXSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV1cIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgYmxvY2sgbWItMVwiPkZlY2hhIGRlIEluaWNpbzo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZmVjaGFJbmljaW99XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RmVjaGFJbmljaW8oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0xLjUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gdGV4dC14cyB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgYmxvY2sgbWItMVwiPkZlY2hhIGRlIEZpbjo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZmVjaGFGaW59XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RmVjaGFGaW4oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0xLjUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gdGV4dC14cyB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFZpc3RhIFByZXZpYSBkZSBSZXN1bWVuIEVzdGFkw61zdGljbyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIHAtNCBiZy1zbGF0ZS01MCBkYXJrOmJnLVsjMUEyMjJDXVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+XG4gICAgICAgICAgICAgICAgUmVzdW1lbiBQcmVsaW1pbmFyIGRlbCBQZXLDrW9kb1xuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIHtsb2FkaW5nICYmIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ibHVlLTUwMCBhbmltYXRlLXB1bHNlIGZvbnQtbWVkaXVtXCI+Q2FyZ2FuZG8gbcOpdHJpY2FzLi4uPC9zcGFuPn1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7dGlwb1JlcG9ydGUgPT09ICdjYWxpZGFkX2FndWEnICYmIHJlcG9ydGVEYXRhPy5lc3RhZGlzdGljYXMgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTMgZ2FwLTMgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIHAtMi41IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdXCI+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgZm9udC1zZW1pYm9sZFwiPnBIIFByb21lZGlvPC9wPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJsYWNrIHRleHQtYmx1ZS02MDAgZGFyazp0ZXh0LWJsdWUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIHtyZXBvcnRlRGF0YS5lc3RhZGlzdGljYXMucGgucHJvbWVkaW8gPz8gJ+KAlCd9XG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWVtZXJhbGQtNjAwIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICB7cmVwb3J0ZURhdGEuZXN0YWRpc3RpY2FzLnBoLnBjdF9jdW1wbGltaWVudG99JSBub3JtYVxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gcC0yLjUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV1cIj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSBmb250LXNlbWlib2xkXCI+VHVyYmlkZXogTWVkaWE8L3A+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYmxhY2sgdGV4dC1hbWJlci02MDAgZGFyazp0ZXh0LWFtYmVyLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICB7cmVwb3J0ZURhdGEuZXN0YWRpc3RpY2FzLnR1cmJpZGV6LnByb21lZGlvID8/ICfigJQnfSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbm9ybWFsXCI+TlRVPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1lbWVyYWxkLTYwMCBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAge3JlcG9ydGVEYXRhLmVzdGFkaXN0aWNhcy50dXJiaWRlei5wY3RfY3VtcGxpbWllbnRvfSUgJmx0OyA1IE5UVVxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gcC0yLjUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV1cIj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSBmb250LXNlbWlib2xkXCI+w41uZGljZSBHbG9iYWw8L3A+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYmxhY2sgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAge3JlcG9ydGVEYXRhLmluZGljZV9nbG9iYWxfY3VtcGxpbWllbnRvfSVcbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgIHtyZXBvcnRlRGF0YS50b3RhbF9tZWRpY2lvbmVzfSBtdWVzdHJhc1xuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHt0aXBvUmVwb3J0ZSA9PT0gJ2Rvc2lmaWNhY2lvbicgJiYgcmVwb3J0ZURhdGE/LnRvdGFsZXNfZG9zaWZpY2Fkb3Nfa2cgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTMgZ2FwLTMgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIHAtMi41IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdXCI+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgZm9udC1zZW1pYm9sZFwiPkNsb3JvPC9wPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAge3JlcG9ydGVEYXRhLnRvdGFsZXNfZG9zaWZpY2Fkb3Nfa2cuY2xvcm99IGtnXG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWJsdWUtNTAwXCI+QnMuIHtyZXBvcnRlRGF0YS5jb3N0b3NfZXN0aW1hZG9zX2JzLmNsb3JvLnRvRml4ZWQoMil9PC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gcC0yLjUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV1cIj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSBmb250LXNlbWlib2xkXCI+U3VsZmF0byBBbHVtaW5pbzwvcD5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgIHtyZXBvcnRlRGF0YS50b3RhbGVzX2Rvc2lmaWNhZG9zX2tnWydzdWxmYXRvIGRlIGFsdW1pbmlvJ119IGtnXG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWJsdWUtNTAwXCI+QnMuIHtyZXBvcnRlRGF0YS5jb3N0b3NfZXN0aW1hZG9zX2JzWydzdWxmYXRvIGRlIGFsdW1pbmlvJ10udG9GaXhlZCgyKX08L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLVsjMjQzMDNGXSBwLTIuNSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXVwiPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIGZvbnQtc2VtaWJvbGRcIj5Db3N0byBUb3RhbDwvcD5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJsYWNrIHRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIEJzLiB7cmVwb3J0ZURhdGEuY29zdG9fdG90YWxfYnMudG9GaXhlZCgyKX1cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwXCI+SW52ZXJzacOzbiBlbiBpbnN1bW9zPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHt0aXBvUmVwb3J0ZSA9PT0gJ2FmbHVlbmNpYScgJiYgcmVwb3J0ZURhdGE/LnJlc3VtZW4gJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTMgZ2FwLTMgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIHAtMi41IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdXCI+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgZm9udC1zZW1pYm9sZFwiPlRvdGFsIEJhw7Fpc3RhczwvcD5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgIHtyZXBvcnRlRGF0YS5yZXN1bWVuLnRvdGFsX2JhbmlzdGFzfSBwZXJzb25hc1xuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gcC0yLjUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV1cIj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSBmb250LXNlbWlib2xkXCI+UmVjYXVkYWNpw7NuPC9wPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYmxhY2sgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgQnMuIHtyZXBvcnRlRGF0YS5yZXN1bWVuLnRvdGFsX3JlY2F1ZGFkb19icy50b0ZpeGVkKDIpfVxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gcC0yLjUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV1cIj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSBmb250LXNlbWlib2xkXCI+SG9yYXJpbyBQaWNvPC9wPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1pbmRpZ28tNjAwIGRhcms6dGV4dC1pbmRpZ28tNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIHtyZXBvcnRlRGF0YS5yZXN1bWVuLmhvcmFfcGljb31cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogUGllIGRlbCBNb2RhbCBjb24gQm90b25lcyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gcHgtNiBweS00IGJnLXNsYXRlLTUwIGRhcms6YmctWyMxQTIyMkNdXCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBob3ZlcjpiZy1zbGF0ZS0yMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS03MDAgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIENlcnJhclxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVEZXNjYXJnYXJQZGZ9XG4gICAgICAgICAgICBkaXNhYmxlZD17ZXhwb3J0aW5nUGRmIHx8IGxvYWRpbmd9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS02MDAgdG8taW5kaWdvLTYwMCBob3Zlcjpmcm9tLWJsdWUtNzAwIGhvdmVyOnRvLWluZGlnby03MDAgdGV4dC13aGl0ZSBweC01IHB5LTIuNSByb3VuZGVkLXhsIGZvbnQtYm9sZCB0ZXh0LXhzIHRyYW5zaXRpb24tYWxsIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAge2V4cG9ydGluZ1BkZiA/IChcbiAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNCBoLTQgYW5pbWF0ZS1zcGluXCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgICAgICAgICAgICAgICA8Y2lyY2xlIGNsYXNzTmFtZT1cIm9wYWNpdHktMjVcIiBjeD1cIjEyXCIgY3k9XCIxMlwiIHI9XCIxMFwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiNFwiPjwvY2lyY2xlPlxuICAgICAgICAgICAgICAgICAgPHBhdGggY2xhc3NOYW1lPVwib3BhY2l0eS03NVwiIGZpbGw9XCJjdXJyZW50Q29sb3JcIiBkPVwiTTQgMTJhOCA4IDAgMDE4LTh2OEg0elwiPjwvcGF0aD5cbiAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5HZW5lcmFuZG8gRG9jdW1lbnRvLi4uPC9zcGFuPlxuICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk0xMiAxMHY2bTAgMGwtMy0zbTMgM2wzLTNtMiA4SDdhMiAyIDAgMDEtMi0yVjVhMiAyIDAgMDEyLTJoNS41ODZhMSAxIDAgMDEuNzA3LjI5M2w1LjQxNCA1LjQxNGExIDEgMCAwMS4yOTMuNzA3VjE5YTIgMiAwIDAxLTIgMnpcIiAvPlxuICAgICAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgICAgIDxzcGFuPkRlc2NhcmdhciBSZXBvcnRlIFBERiBPZmljaWFsPC9zcGFuPlxuICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdfQ==