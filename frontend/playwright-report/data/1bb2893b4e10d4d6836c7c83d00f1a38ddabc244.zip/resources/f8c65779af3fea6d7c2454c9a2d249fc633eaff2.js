import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Auditoria/index.jsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=41a64c35";
import api from "/src/services/api.js";
import { useAuth } from "/src/context/AuthContext.jsx";
import { Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=41a64c35";
var _jsxFileName = "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Auditoria/index.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=41a64c35";
var _s = $RefreshSig$();
function getHoyISO() {
	const now = new Date();
	const year = now.getFullYear();
	const month = String(now.getMonth() + 1).padStart(2, "0");
	const day = String(now.getDate()).padStart(2, "0");
	return `${year}-${month}-${day}`;
}
function formatearFechaLegible(fechaStr) {
	if (!fechaStr) return "";
	const partes = fechaStr.split("-");
	if (partes.length !== 3) return fechaStr;
	const [y, m, d] = partes.map(Number);
	const fecha = new Date(y, m - 1, d);
	return fecha.toLocaleDateString("es-ES", {
		weekday: "long",
		year: "numeric",
		month: "long",
		day: "numeric"
	});
}
export default function AuditoriaPage() {
	_s();
	const { session, authConfig, showError } = useAuth();
	const [logs, setLogs] = useState([]);
	const [loading, setLoading] = useState(true);
	const [searchTerm, setSearchTerm] = useState("");
	const [logDetalle, setLogDetalle] = useState(null);
	// Filtro por fecha: por defecto hoy
	const [fechaFiltro, setFechaFiltro] = useState(getHoyISO());
	const esHoy = fechaFiltro === getHoyISO();
	// Paginación: 20 registros por página
	const [currentPage, setCurrentPage] = useState(1);
	const ITEMS_PER_PAGE = 20;
	useEffect(() => {
		setCurrentPage(1);
	}, [fechaFiltro, searchTerm]);
	const fetchLogs = useCallback(async (targetFecha = fechaFiltro) => {
		setLoading(true);
		try {
			const params = {};
			if (targetFecha) {
				params.fecha = targetFecha;
			}
			const { data } = await api.get("/auditoria/logs", {
				...authConfig(),
				params
			});
			setLogs(data);
		} catch (requestError) {
			showError(requestError);
		} finally {
			setLoading(false);
		}
	}, [
		authConfig,
		showError,
		fechaFiltro
	]);
	useEffect(() => {
		if (session?.usuario?.sigla_rol === "ADM") {
			fetchLogs(fechaFiltro);
		}
	}, [
		session,
		fechaFiltro,
		fetchLogs
	]);
	if (session?.usuario?.sigla_rol !== "ADM") {
		return /* @__PURE__ */ _jsxDEV(Navigate, {
			to: "/dashboard",
			replace: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 73,
			columnNumber: 12
		}, this);
	}
	const filteredLogs = logs.filter((log) => {
		// 1. Filtrar por fecha seleccionada
		if (fechaFiltro) {
			if (!log.fecha_hora) return false;
			let match = false;
			const d = new Date(log.fecha_hora);
			if (!isNaN(d.getTime())) {
				const y = d.getFullYear();
				const m = String(d.getMonth() + 1).padStart(2, "0");
				const day = String(d.getDate()).padStart(2, "0");
				if (`${y}-${m}-${day}` === fechaFiltro) {
					match = true;
				}
			}
			if (!match && typeof log.fecha_hora === "string") {
				const rawDate = log.fecha_hora.split("T")[0].split(" ")[0];
				if (rawDate === fechaFiltro) {
					match = true;
				}
			}
			if (!match) return false;
		}
		// 2. Filtrar por término de búsqueda
		const query = searchTerm.toLowerCase().trim();
		if (!query) return true;
		return log.entidad && log.entidad.toLowerCase().includes(query) || log.accion && log.accion.toLowerCase().includes(query) || log.nombre_usuario && log.nombre_usuario.toLowerCase().includes(query) || log.correo_usuario && log.correo_usuario.toLowerCase().includes(query);
	});
	const totalPages = Math.ceil(filteredLogs.length / ITEMS_PER_PAGE) || 1;
	const validCurrentPage = Math.min(Math.max(currentPage, 1), totalPages);
	const startIndex = (validCurrentPage - 1) * ITEMS_PER_PAGE;
	const endIndex = Math.min(startIndex + ITEMS_PER_PAGE, filteredLogs.length);
	const paginatedLogs = filteredLogs.slice(startIndex, endIndex);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-50 pb-12 dark:bg-[#1A222C]",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-[#24303F] border-b border-slate-200 dark:border-[#313D4A] px-6 py-6 shadow-sm",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs font-bold tracking-widest uppercase text-blue-500 mb-1",
							children: "Módulo de Administración"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 125,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("h1", {
							className: "text-2xl font-bold text-slate-800 dark:text-white",
							children: "Auditoría y Bitácora de Eventos"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 126,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-sm text-slate-500 dark:text-slate-400 mt-0.5",
							children: "Seguimiento detallado de cambios y operaciones del sistema"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 127,
							columnNumber: 13
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 124,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => fetchLogs(fechaFiltro),
							className: "flex items-center gap-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 px-4 py-2.5 rounded-xl font-bold text-sm transition-all",
							children: "🔄 Actualizar Logs"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 131,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 130,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 123,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 122,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "max-w-6xl mx-auto px-6 mt-6",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-[#24303F] p-4 rounded-2xl border border-slate-200 dark:border-[#313D4A] shadow-sm flex flex-wrap items-center justify-between gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-wrap items-center gap-3",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("label", {
									htmlFor: "fechaFiltroAuditoria",
									className: "text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV("svg", {
										className: "w-4 h-4 text-blue-500",
										fill: "none",
										stroke: "currentColor",
										viewBox: "0 0 24 24",
										children: /* @__PURE__ */ _jsxDEV("path", {
											strokeLinecap: "round",
											strokeLinejoin: "round",
											strokeWidth: "2",
											d: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 148,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 147,
										columnNumber: 17
									}, this), "Filtrar por fecha:"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 146,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									id: "fechaFiltroAuditoria",
									type: "date",
									value: fechaFiltro,
									onChange: (e) => setFechaFiltro(e.target.value),
									className: "px-3.5 py-2 rounded-xl border border-slate-200 dark:border-[#313D4A] font-bold text-sm text-slate-800 dark:text-white bg-slate-50 dark:bg-[#1A222C] focus:bg-white dark:focus:bg-[#1A222C] focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all cursor-pointer"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 152,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 145,
								columnNumber: 13
							}, this),
							!esHoy && /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setFechaFiltro(getHoyISO()),
								className: "px-3.5 py-2 rounded-xl bg-blue-50 hover:bg-blue-100 dark:bg-blue-900/30 dark:hover:bg-blue-900/50 text-blue-700 dark:text-blue-300 text-xs font-black transition-all border border-blue-200 dark:border-blue-800 active:scale-95 flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV("svg", {
									className: "w-3.5 h-3.5",
									fill: "none",
									stroke: "currentColor",
									viewBox: "0 0 24 24",
									children: /* @__PURE__ */ _jsxDEV("path", {
										strokeLinecap: "round",
										strokeLinejoin: "round",
										strokeWidth: "2.5",
										d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 168,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 167,
									columnNumber: 17
								}, this), "Volver a Hoy"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 162,
								columnNumber: 15
							}, this),
							fechaFiltro && /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setFechaFiltro(""),
								className: "px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 text-xs font-semibold transition-all border border-slate-200 dark:border-slate-700",
								title: "Ver todos los registros sin filtro de fecha",
								children: "Ver todos"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 175,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 144,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: fechaFiltro ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-bold text-slate-600 dark:text-slate-300 capitalize",
							children: formatearFechaLegible(fechaFiltro)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 189,
							columnNumber: 17
						}, this), esHoy ? /* @__PURE__ */ _jsxDEV("span", {
							className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-extrabold bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800",
							children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-emerald-500 animate-pulse" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 194,
								columnNumber: 21
							}, this), "Hoy"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 193,
							columnNumber: 19
						}, this) : /* @__PURE__ */ _jsxDEV("span", {
							className: "inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300 border border-slate-200 dark:border-slate-700",
							children: "Fecha Seleccionada"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 198,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 188,
							columnNumber: 15
						}, this) : /* @__PURE__ */ _jsxDEV("span", {
							className: "inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-purple-50 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400 border border-purple-200 dark:border-purple-800",
							children: "Todos los registros recientes"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 204,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 186,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 143,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 142,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "max-w-6xl mx-auto px-6 mt-6",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-[#24303F] rounded-2xl border border-slate-200 dark:border-[#313D4A] shadow-sm overflow-hidden",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-wrap items-center justify-between gap-4 px-6 py-5 border-b border-slate-100 dark:border-[#313D4A]",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ _jsxDEV("span", { className: "h-2.5 w-2.5 rounded-full bg-blue-500" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 217,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("h2", {
										className: "font-bold text-lg text-slate-800 dark:text-white",
										children: fechaFiltro ? esHoy ? "Registros de Hoy" : `Registros del ${fechaFiltro}` : "Todos los Registros"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 218,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "ml-2 px-2.5 py-0.5 rounded-full text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300",
										children: [
											filteredLogs.length,
											" ",
											filteredLogs.length === 1 ? "evento" : "eventos"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 221,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 216,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								placeholder: "Buscar por usuario, acción o módulo...",
								value: searchTerm,
								onChange: (e) => setSearchTerm(e.target.value),
								className: "px-4 py-2 rounded-xl border border-slate-200 dark:border-[#313D4A] bg-slate-50 dark:bg-[#1A222C] text-sm text-slate-800 dark:text-white w-72 focus:outline-none focus:ring-2 focus:ring-blue-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 226,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 215,
							columnNumber: 11
						}, this),
						loading ? /* @__PURE__ */ _jsxDEV("div", {
							className: "text-center py-16 text-slate-400 font-medium",
							children: "Cargando bitácora de auditoría..."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 236,
							columnNumber: 13
						}, this) : filteredLogs.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
							className: "text-center py-16 text-slate-400 font-medium space-y-3",
							children: [/* @__PURE__ */ _jsxDEV("p", { children: fechaFiltro ? `No se encontraron registros de auditoría para el ${esHoy ? "día de hoy" : fechaFiltro}` : "No se encontraron registros de auditoría" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 239,
								columnNumber: 15
							}, this), !esHoy && /* @__PURE__ */ _jsxDEV("div", { children: /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setFechaFiltro(getHoyISO()),
								className: "inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-xs font-bold hover:underline",
								children: "Volver a registros de hoy"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 246,
								columnNumber: 19
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 245,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 238,
							columnNumber: 13
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "overflow-x-auto",
							children: /* @__PURE__ */ _jsxDEV("table", {
								className: "w-full text-left",
								children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
									className: "bg-slate-50 dark:bg-[#1A222C] border-b border-slate-100 dark:border-[#313D4A]",
									children: [
										/* @__PURE__ */ _jsxDEV("th", {
											className: "px-5 py-3.5 text-xs font-bold uppercase tracking-wider text-slate-400",
											children: "Fecha y Hora"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 261,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "px-5 py-3.5 text-xs font-bold uppercase tracking-wider text-slate-400",
											children: "Usuario Responsable"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 262,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "px-5 py-3.5 text-xs font-bold uppercase tracking-wider text-slate-400",
											children: "IP Dispositivo"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 263,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "px-5 py-3.5 text-xs font-bold uppercase tracking-wider text-slate-400",
											children: "Acción"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 264,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "px-5 py-3.5 text-xs font-bold uppercase tracking-wider text-slate-400",
											children: "Módulo / Entidad"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 265,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "px-5 py-3.5 text-xs font-bold uppercase tracking-wider text-slate-400 text-center",
											children: "Detalles"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 266,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 260,
									columnNumber: 19
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 259,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("tbody", {
									className: "divide-y divide-slate-100 dark:divide-[#313D4A]",
									children: paginatedLogs.map((log, i) => {
										const esInsert = log.accion === "INSERT";
										const esUpdate = log.accion === "UPDATE";
										const esDelete = log.accion === "DELETE";
										const esLoginOK = log.accion === "LOGIN_SUCCESS";
										const esLoginFail = log.accion === "LOGIN_FAILED";
										const usuarioNombre = log.nombre_usuario ? `${log.nombre_usuario} ${log.apellido_usuario || ""}` : log.detalle?.nuevo?.id_usuario ? `Usuario #${log.detalle.nuevo.id_usuario}` : "Sistema / Automático";
										return /* @__PURE__ */ _jsxDEV("tr", {
											className: i % 2 === 0 ? "bg-white dark:bg-[#24303F]" : "bg-slate-50/50 dark:bg-[#1A222C]/50",
											children: [
												/* @__PURE__ */ _jsxDEV("td", {
													className: "px-5 py-4 text-xs font-semibold text-slate-600 dark:text-slate-300 whitespace-nowrap",
													children: log.fecha_hora ? new Date(log.fecha_hora).toLocaleString() : "—"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 285,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "px-5 py-4 text-sm font-bold text-slate-800 dark:text-white",
													children: [usuarioNombre, /* @__PURE__ */ _jsxDEV("span", {
														className: "block text-xs font-medium text-slate-400",
														children: log.correo_usuario || log.detalle?.correo_intentado || (log.sigla_rol ? `Rol: ${log.sigla_rol}` : "Sistema IoT")
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 290,
														columnNumber: 27
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 288,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "px-5 py-4 text-xs font-mono font-semibold text-slate-600 dark:text-slate-400 whitespace-nowrap",
													children: log.ip_origen || "127.0.0.1 (Localhost)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 294,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "px-5 py-4",
													children: /* @__PURE__ */ _jsxDEV("span", {
														className: `px-2.5 py-1 rounded-full text-xs font-black ${esLoginOK ? "bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-400" : esLoginFail ? "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400" : esInsert ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400" : esUpdate ? "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400" : "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400"}`,
														children: log.accion
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 298,
														columnNumber: 27
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 297,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "px-5 py-4 text-sm font-semibold text-slate-700 dark:text-slate-300",
													children: log.modulo || log.entidad
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 308,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "px-5 py-4 text-center",
													children: /* @__PURE__ */ _jsxDEV("button", {
														onClick: () => setLogDetalle(log),
														className: "px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-blue-50 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 hover:text-blue-600 font-bold text-xs transition-all border border-slate-200 dark:border-slate-700",
														children: "Ver Datos"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 312,
														columnNumber: 27
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 311,
													columnNumber: 25
												}, this)
											]
										}, log.id_log, true, {
											fileName: _jsxFileName,
											lineNumber: 284,
											columnNumber: 23
										}, this);
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 269,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 258,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 257,
							columnNumber: 13
						}, this),
						filteredLogs.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-wrap items-center justify-between gap-4 px-6 py-4 border-t border-slate-100 dark:border-[#313D4A] bg-slate-50/50 dark:bg-[#1A222C]/50",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "text-xs text-slate-500 dark:text-slate-400 font-medium",
								children: [
									"Mostrando ",
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-slate-700 dark:text-slate-200",
										children: startIndex + 1
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 331,
										columnNumber: 27
									}, this),
									" a",
									" ",
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-slate-700 dark:text-slate-200",
										children: endIndex
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 332,
										columnNumber: 17
									}, this),
									" de",
									" ",
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-slate-700 dark:text-slate-200",
										children: filteredLogs.length
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 333,
										columnNumber: 17
									}, this),
									" registros"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 330,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setCurrentPage((prev) => Math.max(prev - 1, 1)),
										disabled: validCurrentPage <= 1,
										className: "flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#24303F] text-slate-700 dark:text-slate-200 text-xs font-bold transition-all disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-50 dark:hover:bg-slate-800 shadow-sm",
										title: "Página anterior",
										children: [/* @__PURE__ */ _jsxDEV("svg", {
											className: "w-4 h-4",
											fill: "none",
											stroke: "currentColor",
											viewBox: "0 0 24 24",
											children: /* @__PURE__ */ _jsxDEV("path", {
												strokeLinecap: "round",
												strokeLinejoin: "round",
												strokeWidth: "2.5",
												d: "M15 19l-7-7 7-7"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 345,
												columnNumber: 21
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 344,
											columnNumber: 19
										}, this), "Anterior"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 337,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-1 px-2",
										children: /* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs font-bold text-slate-700 dark:text-slate-300",
											children: [
												"Página ",
												validCurrentPage,
												" de ",
												totalPages
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 351,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 350,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setCurrentPage((prev) => Math.min(prev + 1, totalPages)),
										disabled: validCurrentPage >= totalPages,
										className: "flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#24303F] text-slate-700 dark:text-slate-200 text-xs font-bold transition-all disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-50 dark:hover:bg-slate-800 shadow-sm",
										title: "Página siguiente",
										children: ["Siguiente", /* @__PURE__ */ _jsxDEV("svg", {
											className: "w-4 h-4",
											fill: "none",
											stroke: "currentColor",
											viewBox: "0 0 24 24",
											children: /* @__PURE__ */ _jsxDEV("path", {
												strokeLinecap: "round",
												strokeLinejoin: "round",
												strokeWidth: "2.5",
												d: "M9 5l7 7-7 7"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 365,
												columnNumber: 21
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 364,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 356,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 336,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 329,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 214,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 213,
				columnNumber: 7
			}, this),
			logDetalle && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-[99999] flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-[#24303F] rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 dark:border-[#313D4A] relative",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between pb-4 border-b border-slate-100 dark:border-[#313D4A] mb-4",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-lg font-bold text-slate-800 dark:text-white",
							children: ["Detalle de Auditoría #", logDetalle.id_log]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 380,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400",
							children: [
								"Tabla: ",
								logDetalle.entidad,
								" | Acción: ",
								logDetalle.accion
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 381,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 379,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setLogDetalle(null),
							className: "w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 hover:bg-slate-200 flex items-center justify-center",
							children: "✕"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 383,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 378,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-3",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs font-bold uppercase tracking-wider text-slate-400 mb-1",
							children: "Payload JSON de Cambios"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 388,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("pre", {
							className: "p-4 rounded-xl bg-slate-900 text-emerald-400 text-xs font-mono overflow-x-auto max-h-60",
							children: JSON.stringify(logDetalle.detalle, null, 2)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 389,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 387,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setLogDetalle(null),
							className: "w-full mt-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-bold text-sm transition-all",
							children: "Cerrar"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 394,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 386,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 377,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 376,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 120,
		columnNumber: 5
	}, this);
}
_s(AuditoriaPage, "2UyKxhZqg0KEzmNbx9MT35yuics=", false, function() {
	return [useAuth];
});
_c = AuditoriaPage;
var _c;
$RefreshReg$(_c, "AuditoriaPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/Auditoria/index.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Auditoria/index.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Auditoria/index.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/DiscoD/Ayana/UNIVERSIDAD/1PROYECTO/PROYECTO ESTRUCTURA/ProyectoLSTM/sistema-piscina/frontend/src/pages/Auditoria/index.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFdBQVcsbUJBQW1CO0FBQ2pELE9BQU8sU0FBUztBQUNoQixTQUFTLGVBQWU7QUFDeEIsU0FBUyxnQkFBZ0I7Ozs7QUFFekIsU0FBUyxZQUFZO0NBQ25CLE1BQU0sTUFBTSxJQUFJLEtBQUs7Q0FDckIsTUFBTSxPQUFPLElBQUksWUFBWTtDQUM3QixNQUFNLFFBQVEsT0FBTyxJQUFJLFNBQVMsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUcsR0FBRztDQUN4RCxNQUFNLE1BQU0sT0FBTyxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUc7Q0FDakQsT0FBTyxHQUFHLEtBQUssR0FBRyxNQUFNLEdBQUc7QUFDN0I7QUFFQSxTQUFTLHNCQUFzQixVQUFVO0NBQ3ZDLElBQUksQ0FBQyxVQUFVLE9BQU87Q0FDdEIsTUFBTSxTQUFTLFNBQVMsTUFBTSxHQUFHO0NBQ2pDLElBQUksT0FBTyxXQUFXLEdBQUcsT0FBTztDQUNoQyxNQUFNLENBQUMsR0FBRyxHQUFHLEtBQUssT0FBTyxJQUFJLE1BQU07Q0FDbkMsTUFBTSxRQUFRLElBQUksS0FBSyxHQUFHLElBQUksR0FBRyxDQUFDO0NBQ2xDLE9BQU8sTUFBTSxtQkFBbUIsU0FBUztFQUN2QyxTQUFTO0VBQ1QsTUFBTTtFQUNOLE9BQU87RUFDUCxLQUFLO0NBQ1AsQ0FBQztBQUNIO0FBRUEsZUFBZSxTQUFTLGdCQUFnQjs7Q0FDdEMsTUFBTSxFQUFFLFNBQVMsWUFBWSxjQUFjLFFBQVE7Q0FDbkQsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLENBQUMsQ0FBQztDQUNuQyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsSUFBSTtDQUMzQyxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxFQUFFO0NBQy9DLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLElBQUk7O0NBR2pELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLFVBQVUsQ0FBQztDQUMxRCxNQUFNLFFBQVEsZ0JBQWdCLFVBQVU7O0NBR3hDLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLENBQUM7Q0FDaEQsTUFBTSxpQkFBaUI7Q0FFdkIsZ0JBQWdCO0VBQ2QsZUFBZSxDQUFDO0NBQ2xCLEdBQUcsQ0FBQyxhQUFhLFVBQVUsQ0FBQztDQUU1QixNQUFNLFlBQVksWUFBWSxPQUFPLGNBQWMsZ0JBQWdCO0VBQ2pFLFdBQVcsSUFBSTtFQUNmLElBQUk7R0FDRixNQUFNLFNBQVMsQ0FBQztHQUNoQixJQUFJLGFBQWE7SUFDZixPQUFPLFFBQVE7R0FDakI7R0FDQSxNQUFNLEVBQUUsU0FBUyxNQUFNLElBQUksSUFBSSxtQkFBbUI7SUFDaEQsR0FBRyxXQUFXO0lBQ2Q7R0FDRixDQUFDO0dBQ0QsUUFBUSxJQUFJO0VBQ2QsU0FBUyxjQUFjO0dBQ3JCLFVBQVUsWUFBWTtFQUN4QixVQUFVO0dBQ1IsV0FBVyxLQUFLO0VBQ2xCO0NBQ0YsR0FBRztFQUFDO0VBQVk7RUFBVztDQUFXLENBQUM7Q0FFdkMsZ0JBQWdCO0VBQ2QsSUFBSSxTQUFTLFNBQVMsY0FBYyxPQUFPO0dBQ3pDLFVBQVUsV0FBVztFQUN2QjtDQUNGLEdBQUc7RUFBQztFQUFTO0VBQWE7Q0FBUyxDQUFDO0NBRXBDLElBQUksU0FBUyxTQUFTLGNBQWMsT0FBTztFQUN6QyxPQUFPLHdCQUFDLFVBQUQ7R0FBVSxJQUFHO0dBQWE7RUFBUzs7Ozs7Q0FDNUM7Q0FFQSxNQUFNLGVBQWUsS0FBSyxRQUFRLFFBQVE7O0VBRXhDLElBQUksYUFBYTtHQUNmLElBQUksQ0FBQyxJQUFJLFlBQVksT0FBTztHQUU1QixJQUFJLFFBQVE7R0FDWixNQUFNLElBQUksSUFBSSxLQUFLLElBQUksVUFBVTtHQUNqQyxJQUFJLENBQUMsTUFBTSxFQUFFLFFBQVEsQ0FBQyxHQUFHO0lBQ3ZCLE1BQU0sSUFBSSxFQUFFLFlBQVk7SUFDeEIsTUFBTSxJQUFJLE9BQU8sRUFBRSxTQUFTLElBQUksQ0FBQyxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUc7SUFDbEQsTUFBTSxNQUFNLE9BQU8sRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHO0lBQy9DLElBQUksR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLFVBQVUsYUFBYTtLQUN0QyxRQUFRO0lBQ1Y7R0FDRjtHQUVBLElBQUksQ0FBQyxTQUFTLE9BQU8sSUFBSSxlQUFlLFVBQVU7SUFDaEQsTUFBTSxVQUFVLElBQUksV0FBVyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0lBQ3hELElBQUksWUFBWSxhQUFhO0tBQzNCLFFBQVE7SUFDVjtHQUNGO0dBRUEsSUFBSSxDQUFDLE9BQU8sT0FBTztFQUNyQjs7RUFHQSxNQUFNLFFBQVEsV0FBVyxZQUFZLENBQUMsQ0FBQyxLQUFLO0VBQzVDLElBQUksQ0FBQyxPQUFPLE9BQU87RUFDbkIsT0FDRyxJQUFJLFdBQVcsSUFBSSxRQUFRLFlBQVksQ0FBQyxDQUFDLFNBQVMsS0FBSyxLQUN2RCxJQUFJLFVBQVUsSUFBSSxPQUFPLFlBQVksQ0FBQyxDQUFDLFNBQVMsS0FBSyxLQUNyRCxJQUFJLGtCQUFrQixJQUFJLGVBQWUsWUFBWSxDQUFDLENBQUMsU0FBUyxLQUFLLEtBQ3JFLElBQUksa0JBQWtCLElBQUksZUFBZSxZQUFZLENBQUMsQ0FBQyxTQUFTLEtBQUs7Q0FFMUUsQ0FBQztDQUVELE1BQU0sYUFBYSxLQUFLLEtBQUssYUFBYSxTQUFTLGNBQWMsS0FBSztDQUN0RSxNQUFNLG1CQUFtQixLQUFLLElBQUksS0FBSyxJQUFJLGFBQWEsQ0FBQyxHQUFHLFVBQVU7Q0FDdEUsTUFBTSxjQUFjLG1CQUFtQixLQUFLO0NBQzVDLE1BQU0sV0FBVyxLQUFLLElBQUksYUFBYSxnQkFBZ0IsYUFBYSxNQUFNO0NBQzFFLE1BQU0sZ0JBQWdCLGFBQWEsTUFBTSxZQUFZLFFBQVE7Q0FFN0QsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUNFLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFpRTtNQUEyQjs7Ozs7TUFDekcsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQW9EO01BQW1DOzs7OztNQUNyRyx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBb0Q7TUFBNkQ7Ozs7O0tBQzNIOzs7O2VBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsVUFBRDtPQUNFLGVBQWUsVUFBVSxXQUFXO09BQ3BDLFdBQVU7aUJBQ1g7TUFFTzs7Ozs7S0FDTDs7OzthQUNGOzs7Ozs7R0FDRjs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsU0FBRDtTQUFPLFNBQVE7U0FBdUIsV0FBVTttQkFBaEQsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtVQUF3QixNQUFLO1VBQU8sUUFBTztVQUFlLFNBQVE7b0JBQy9FLHdCQUFDLFFBQUQ7V0FBTSxlQUFjO1dBQVEsZ0JBQWU7V0FBUSxhQUFZO1dBQUksR0FBRTtVQUEwRjs7Ozs7U0FDNUo7Ozs7bUJBQUMsb0JBRUQ7Ozs7O2tCQUNQLHdCQUFDLFNBQUQ7U0FDRSxJQUFHO1NBQ0gsTUFBSztTQUNMLE9BQU87U0FDUCxXQUFXLE1BQU0sZUFBZSxFQUFFLE9BQU8sS0FBSztTQUM5QyxXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7OztPQUVKLENBQUMsU0FDQSx3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLGVBQWUsZUFBZSxVQUFVLENBQUM7UUFDekMsV0FBVTtrQkFIWixDQUtFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO1NBQWMsTUFBSztTQUFPLFFBQU87U0FBZSxTQUFRO21CQUNyRSx3QkFBQyxRQUFEO1VBQU0sZUFBYztVQUFRLGdCQUFlO1VBQVEsYUFBWTtVQUFNLEdBQUU7U0FBK0M7Ozs7O1FBQ25IOzs7O2tCQUFDLGNBRUE7Ozs7OztPQUdULGVBQ0Msd0JBQUMsVUFBRDtRQUNFLE1BQUs7UUFDTCxlQUFlLGVBQWUsRUFBRTtRQUNoQyxXQUFVO1FBQ1YsT0FBTTtrQkFDUDtPQUVPOzs7OztNQUVQOzs7OztlQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaLGNBQ0MsZ0RBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQ2Isc0JBQXNCLFdBQVc7TUFDOUI7Ozs7Z0JBQ0wsUUFDQyx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBaEIsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxvREFBMEQ7Ozs7aUJBQUMsS0FFdkU7Ozs7O2lCQUVOLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFvTDtNQUU5TDs7OztjQUVSOzs7O2lCQUVGLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUE0TDtNQUV0TTs7Ozs7S0FFTDs7OzthQUNGOzs7Ozs7R0FDRjs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsdUNBQTZDOzs7OztTQUM3RCx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWCxjQUFlLFFBQVEscUJBQXFCLGlCQUFpQixnQkFBaUI7U0FDN0U7Ozs7O1NBQ0osd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCO1dBQ0csYUFBYTtXQUFPO1dBQUUsYUFBYSxXQUFXLElBQUksV0FBVztVQUMxRDs7Ozs7O1FBQ0g7Ozs7O2lCQUVMLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsYUFBWTtRQUNaLE9BQU87UUFDUCxXQUFXLE1BQU0sY0FBYyxFQUFFLE9BQU8sS0FBSztRQUM3QyxXQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7O01BRUosVUFDQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBK0M7TUFBc0M7Ozs7aUJBQ2xHLGFBQWEsV0FBVyxJQUMxQix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLEtBQUQsWUFDRyxjQUNHLG9EQUFvRCxRQUFRLGVBQWUsZ0JBQzNFLDJDQUNIOzs7O2lCQUNGLENBQUMsU0FDQSx3QkFBQyxPQUFELFlBQ0Usd0JBQUMsVUFBRDtRQUNFLE1BQUs7UUFDTCxlQUFlLGVBQWUsVUFBVSxDQUFDO1FBQ3pDLFdBQVU7a0JBQ1g7T0FFTzs7OztnQkFDTDs7OztlQUVKOzs7OztpQkFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBakIsQ0FDRSx3QkFBQyxTQUFELFlBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWQ7VUFDRSx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBd0U7VUFBZ0I7Ozs7O1VBQ3RHLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUF3RTtVQUF1Qjs7Ozs7VUFDN0csd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQXdFO1VBQWtCOzs7OztVQUN4Ryx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBd0U7VUFBVTs7Ozs7VUFDaEcsd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQXdFO1VBQW9COzs7OztVQUMxRyx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBb0Y7VUFBWTs7Ozs7U0FDNUc7Ozs7O2lCQUNDOzs7O2tCQUNQLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUNkLGNBQWMsS0FBSyxLQUFLLE1BQU07VUFDN0IsTUFBTSxXQUFXLElBQUksV0FBVztVQUNoQyxNQUFNLFdBQVcsSUFBSSxXQUFXO1VBQ2hDLE1BQU0sV0FBVyxJQUFJLFdBQVc7VUFDaEMsTUFBTSxZQUFZLElBQUksV0FBVztVQUNqQyxNQUFNLGNBQWMsSUFBSSxXQUFXO1VBRW5DLE1BQU0sZ0JBQWdCLElBQUksaUJBQ3RCLEdBQUcsSUFBSSxlQUFlLEdBQUcsSUFBSSxvQkFBb0IsT0FDakQsSUFBSSxTQUFTLE9BQU8sYUFDbEIsWUFBWSxJQUFJLFFBQVEsTUFBTSxlQUM5QjtVQUVOLE9BQ0Usd0JBQUMsTUFBRDtXQUFxQixXQUFXLElBQUksTUFBTSxJQUFJLCtCQUErQjtxQkFBN0U7WUFDRSx3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFDWCxJQUFJLGFBQWEsSUFBSSxLQUFLLElBQUksVUFBVSxDQUFDLENBQUMsZUFBZSxJQUFJO1lBQzVEOzs7OztZQUNKLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUFkLENBQ0csZUFDRCx3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFDYixJQUFJLGtCQUFrQixJQUFJLFNBQVMscUJBQXFCLElBQUksWUFBWSxRQUFRLElBQUksY0FBYzthQUMvRjs7OztxQkFDSjs7Ozs7O1lBQ0osd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQ1gsSUFBSSxhQUFhO1lBQ2hCOzs7OztZQUNKLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUNaLHdCQUFDLFFBQUQ7Y0FBTSxXQUFXLCtDQUNmLFlBQVksNkVBQ1osY0FBYyx5RUFDZCxXQUFXLGlGQUNYLFdBQVcscUVBQ1g7d0JBRUMsSUFBSTthQUNEOzs7OztZQUNKOzs7OztZQUNKLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUNYLElBQUksVUFBVSxJQUFJO1lBQ2pCOzs7OztZQUNKLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUNaLHdCQUFDLFVBQUQ7Y0FDRSxlQUFlLGNBQWMsR0FBRztjQUNoQyxXQUFVO3dCQUNYO2FBRU87Ozs7O1lBQ047Ozs7O1dBQ0Y7YUFuQ0ssSUFBSTs7OztpQkFtQ1Q7U0FFUixDQUFDO1FBQ0k7Ozs7Z0JBQ0Y7Ozs7OztNQUNKOzs7OztNQUlOLGFBQWEsU0FBUyxLQUNyQix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQXdFO1NBQzVELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFnRCxhQUFhO1NBQVE7Ozs7O1NBQUM7U0FBRztTQUNuRyx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBZ0Q7U0FBZTs7Ozs7U0FBQztTQUFJO1NBQ3BGLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFnRCxhQUFhO1NBQWE7Ozs7O1NBQUM7UUFDeEY7Ozs7O2lCQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsVUFBRDtVQUNFLE1BQUs7VUFDTCxlQUFlLGdCQUFnQixTQUFTLEtBQUssSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDO1VBQzdELFVBQVUsb0JBQW9CO1VBQzlCLFdBQVU7VUFDVixPQUFNO29CQUxSLENBT0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7V0FBVSxNQUFLO1dBQU8sUUFBTztXQUFlLFNBQVE7cUJBQ2pFLHdCQUFDLFFBQUQ7WUFBTSxlQUFjO1lBQVEsZ0JBQWU7WUFBUSxhQUFZO1lBQU0sR0FBRTtXQUFtQjs7Ozs7VUFDdkY7Ozs7b0JBQUMsVUFFQTs7Ozs7O1NBRVIsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ2Isd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCO1lBQXVFO1lBQzdEO1lBQWlCO1lBQUs7V0FDMUI7Ozs7OztTQUNIOzs7OztTQUVMLHdCQUFDLFVBQUQ7VUFDRSxNQUFLO1VBQ0wsZUFBZSxnQkFBZ0IsU0FBUyxLQUFLLElBQUksT0FBTyxHQUFHLFVBQVUsQ0FBQztVQUN0RSxVQUFVLG9CQUFvQjtVQUM5QixXQUFVO1VBQ1YsT0FBTTtvQkFMUixDQU1DLGFBRUMsd0JBQUMsT0FBRDtXQUFLLFdBQVU7V0FBVSxNQUFLO1dBQU8sUUFBTztXQUFlLFNBQVE7cUJBQ2pFLHdCQUFDLFFBQUQ7WUFBTSxlQUFjO1lBQVEsZ0JBQWU7WUFBUSxhQUFZO1lBQU0sR0FBRTtXQUFnQjs7Ozs7VUFDcEY7Ozs7a0JBQ0M7Ozs7OztRQUNMOzs7OztlQUNGOzs7Ozs7S0FFSjs7Ozs7O0dBQ0Y7Ozs7O0dBR0osY0FDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZCxDQUFpRSwwQkFBdUIsV0FBVyxNQUFXOzs7OztnQkFDOUcsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWI7UUFBc0M7UUFBUSxXQUFXO1FBQVE7UUFBWSxXQUFXO09BQVU7Ozs7O2NBQy9GOzs7O2dCQUNMLHdCQUFDLFVBQUQ7T0FBUSxlQUFlLGNBQWMsSUFBSTtPQUFHLFdBQVU7aUJBQXlIO01BQVM7Ozs7Y0FDckw7Ozs7O2VBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWlFO01BQTBCOzs7O2dCQUN4Ryx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWixLQUFLLFVBQVUsV0FBVyxTQUFTLE1BQU0sQ0FBQztNQUN4Qzs7OztjQUNGOzs7O2dCQUVMLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGNBQWMsSUFBSTtPQUNqQyxXQUFVO2lCQUNYO01BRU87Ozs7Y0FDTDs7Ozs7YUFDRjs7Ozs7O0dBQ0Y7Ozs7O0VBRUo7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluZGV4LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VDYWxsYmFjayB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IGFwaSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9hcGknXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vY29udGV4dC9BdXRoQ29udGV4dCdcbmltcG9ydCB7IE5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcblxuZnVuY3Rpb24gZ2V0SG95SVNPKCkge1xuICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpXG4gIGNvbnN0IHllYXIgPSBub3cuZ2V0RnVsbFllYXIoKVxuICBjb25zdCBtb250aCA9IFN0cmluZyhub3cuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsICcwJylcbiAgY29uc3QgZGF5ID0gU3RyaW5nKG5vdy5nZXREYXRlKCkpLnBhZFN0YXJ0KDIsICcwJylcbiAgcmV0dXJuIGAke3llYXJ9LSR7bW9udGh9LSR7ZGF5fWBcbn1cblxuZnVuY3Rpb24gZm9ybWF0ZWFyRmVjaGFMZWdpYmxlKGZlY2hhU3RyKSB7XG4gIGlmICghZmVjaGFTdHIpIHJldHVybiAnJ1xuICBjb25zdCBwYXJ0ZXMgPSBmZWNoYVN0ci5zcGxpdCgnLScpXG4gIGlmIChwYXJ0ZXMubGVuZ3RoICE9PSAzKSByZXR1cm4gZmVjaGFTdHJcbiAgY29uc3QgW3ksIG0sIGRdID0gcGFydGVzLm1hcChOdW1iZXIpXG4gIGNvbnN0IGZlY2hhID0gbmV3IERhdGUoeSwgbSAtIDEsIGQpXG4gIHJldHVybiBmZWNoYS50b0xvY2FsZURhdGVTdHJpbmcoJ2VzLUVTJywge1xuICAgIHdlZWtkYXk6ICdsb25nJyxcbiAgICB5ZWFyOiAnbnVtZXJpYycsXG4gICAgbW9udGg6ICdsb25nJyxcbiAgICBkYXk6ICdudW1lcmljJyxcbiAgfSlcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXVkaXRvcmlhUGFnZSgpIHtcbiAgY29uc3QgeyBzZXNzaW9uLCBhdXRoQ29uZmlnLCBzaG93RXJyb3IgfSA9IHVzZUF1dGgoKVxuICBjb25zdCBbbG9ncywgc2V0TG9nc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSlcbiAgY29uc3QgW3NlYXJjaFRlcm0sIHNldFNlYXJjaFRlcm1dID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtsb2dEZXRhbGxlLCBzZXRMb2dEZXRhbGxlXSA9IHVzZVN0YXRlKG51bGwpXG5cbiAgLy8gRmlsdHJvIHBvciBmZWNoYTogcG9yIGRlZmVjdG8gaG95XG4gIGNvbnN0IFtmZWNoYUZpbHRybywgc2V0RmVjaGFGaWx0cm9dID0gdXNlU3RhdGUoZ2V0SG95SVNPKCkpXG4gIGNvbnN0IGVzSG95ID0gZmVjaGFGaWx0cm8gPT09IGdldEhveUlTTygpXG5cbiAgLy8gUGFnaW5hY2nDs246IDIwIHJlZ2lzdHJvcyBwb3IgcMOhZ2luYVxuICBjb25zdCBbY3VycmVudFBhZ2UsIHNldEN1cnJlbnRQYWdlXSA9IHVzZVN0YXRlKDEpXG4gIGNvbnN0IElURU1TX1BFUl9QQUdFID0gMjBcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHNldEN1cnJlbnRQYWdlKDEpXG4gIH0sIFtmZWNoYUZpbHRybywgc2VhcmNoVGVybV0pXG5cbiAgY29uc3QgZmV0Y2hMb2dzID0gdXNlQ2FsbGJhY2soYXN5bmMgKHRhcmdldEZlY2hhID0gZmVjaGFGaWx0cm8pID0+IHtcbiAgICBzZXRMb2FkaW5nKHRydWUpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHt9XG4gICAgICBpZiAodGFyZ2V0RmVjaGEpIHtcbiAgICAgICAgcGFyYW1zLmZlY2hhID0gdGFyZ2V0RmVjaGFcbiAgICAgIH1cbiAgICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXBpLmdldCgnL2F1ZGl0b3JpYS9sb2dzJywge1xuICAgICAgICAuLi5hdXRoQ29uZmlnKCksXG4gICAgICAgIHBhcmFtcyxcbiAgICAgIH0pXG4gICAgICBzZXRMb2dzKGRhdGEpXG4gICAgfSBjYXRjaCAocmVxdWVzdEVycm9yKSB7XG4gICAgICBzaG93RXJyb3IocmVxdWVzdEVycm9yKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKVxuICAgIH1cbiAgfSwgW2F1dGhDb25maWcsIHNob3dFcnJvciwgZmVjaGFGaWx0cm9dKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHNlc3Npb24/LnVzdWFyaW8/LnNpZ2xhX3JvbCA9PT0gJ0FETScpIHtcbiAgICAgIGZldGNoTG9ncyhmZWNoYUZpbHRybylcbiAgICB9XG4gIH0sIFtzZXNzaW9uLCBmZWNoYUZpbHRybywgZmV0Y2hMb2dzXSlcblxuICBpZiAoc2Vzc2lvbj8udXN1YXJpbz8uc2lnbGFfcm9sICE9PSAnQURNJykge1xuICAgIHJldHVybiA8TmF2aWdhdGUgdG89XCIvZGFzaGJvYXJkXCIgcmVwbGFjZSAvPlxuICB9XG5cbiAgY29uc3QgZmlsdGVyZWRMb2dzID0gbG9ncy5maWx0ZXIoKGxvZykgPT4ge1xuICAgIC8vIDEuIEZpbHRyYXIgcG9yIGZlY2hhIHNlbGVjY2lvbmFkYVxuICAgIGlmIChmZWNoYUZpbHRybykge1xuICAgICAgaWYgKCFsb2cuZmVjaGFfaG9yYSkgcmV0dXJuIGZhbHNlXG5cbiAgICAgIGxldCBtYXRjaCA9IGZhbHNlXG4gICAgICBjb25zdCBkID0gbmV3IERhdGUobG9nLmZlY2hhX2hvcmEpXG4gICAgICBpZiAoIWlzTmFOKGQuZ2V0VGltZSgpKSkge1xuICAgICAgICBjb25zdCB5ID0gZC5nZXRGdWxsWWVhcigpXG4gICAgICAgIGNvbnN0IG0gPSBTdHJpbmcoZC5nZXRNb250aCgpICsgMSkucGFkU3RhcnQoMiwgJzAnKVxuICAgICAgICBjb25zdCBkYXkgPSBTdHJpbmcoZC5nZXREYXRlKCkpLnBhZFN0YXJ0KDIsICcwJylcbiAgICAgICAgaWYgKGAke3l9LSR7bX0tJHtkYXl9YCA9PT0gZmVjaGFGaWx0cm8pIHtcbiAgICAgICAgICBtYXRjaCA9IHRydWVcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAoIW1hdGNoICYmIHR5cGVvZiBsb2cuZmVjaGFfaG9yYSA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgY29uc3QgcmF3RGF0ZSA9IGxvZy5mZWNoYV9ob3JhLnNwbGl0KCdUJylbMF0uc3BsaXQoJyAnKVswXVxuICAgICAgICBpZiAocmF3RGF0ZSA9PT0gZmVjaGFGaWx0cm8pIHtcbiAgICAgICAgICBtYXRjaCA9IHRydWVcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAoIW1hdGNoKSByZXR1cm4gZmFsc2VcbiAgICB9XG5cbiAgICAvLyAyLiBGaWx0cmFyIHBvciB0w6lybWlubyBkZSBiw7pzcXVlZGFcbiAgICBjb25zdCBxdWVyeSA9IHNlYXJjaFRlcm0udG9Mb3dlckNhc2UoKS50cmltKClcbiAgICBpZiAoIXF1ZXJ5KSByZXR1cm4gdHJ1ZVxuICAgIHJldHVybiAoXG4gICAgICAobG9nLmVudGlkYWQgJiYgbG9nLmVudGlkYWQudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhxdWVyeSkpIHx8XG4gICAgICAobG9nLmFjY2lvbiAmJiBsb2cuYWNjaW9uLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocXVlcnkpKSB8fFxuICAgICAgKGxvZy5ub21icmVfdXN1YXJpbyAmJiBsb2cubm9tYnJlX3VzdWFyaW8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhxdWVyeSkpIHx8XG4gICAgICAobG9nLmNvcnJlb191c3VhcmlvICYmIGxvZy5jb3JyZW9fdXN1YXJpby50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHF1ZXJ5KSlcbiAgICApXG4gIH0pXG5cbiAgY29uc3QgdG90YWxQYWdlcyA9IE1hdGguY2VpbChmaWx0ZXJlZExvZ3MubGVuZ3RoIC8gSVRFTVNfUEVSX1BBR0UpIHx8IDFcbiAgY29uc3QgdmFsaWRDdXJyZW50UGFnZSA9IE1hdGgubWluKE1hdGgubWF4KGN1cnJlbnRQYWdlLCAxKSwgdG90YWxQYWdlcylcbiAgY29uc3Qgc3RhcnRJbmRleCA9ICh2YWxpZEN1cnJlbnRQYWdlIC0gMSkgKiBJVEVNU19QRVJfUEFHRVxuICBjb25zdCBlbmRJbmRleCA9IE1hdGgubWluKHN0YXJ0SW5kZXggKyBJVEVNU19QRVJfUEFHRSwgZmlsdGVyZWRMb2dzLmxlbmd0aClcbiAgY29uc3QgcGFnaW5hdGVkTG9ncyA9IGZpbHRlcmVkTG9ncy5zbGljZShzdGFydEluZGV4LCBlbmRJbmRleClcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLXNsYXRlLTUwIHBiLTEyIGRhcms6YmctWyMxQTIyMkNdXCI+XG4gICAgICB7Lyog4pSA4pSAIEhlYWRlciDilIDilIAgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIHB4LTYgcHktNiBzaGFkb3ctc21cIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy02eGwgbXgtYXV0byBmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRyYWNraW5nLXdpZGVzdCB1cHBlcmNhc2UgdGV4dC1ibHVlLTUwMCBtYi0xXCI+TcOzZHVsbyBkZSBBZG1pbmlzdHJhY2nDs248L3A+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZVwiPkF1ZGl0b3LDrWEgeSBCaXTDoWNvcmEgZGUgRXZlbnRvczwvaDE+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgbXQtMC41XCI+U2VndWltaWVudG8gZGV0YWxsYWRvIGRlIGNhbWJpb3MgeSBvcGVyYWNpb25lcyBkZWwgc2lzdGVtYTwvcD5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZmV0Y2hMb2dzKGZlY2hhRmlsdHJvKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYmctc2xhdGUtMTAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmJnLXNsYXRlLTgwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIHB4LTQgcHktMi41IHJvdW5kZWQteGwgZm9udC1ib2xkIHRleHQtc20gdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICDwn5SEIEFjdHVhbGl6YXIgTG9nc1xuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiDilIDilIAgQmFycmEgZGUgQ29udHJvbCBkZSBGZWNoYSDilIDilIAgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTZ4bCBteC1hdXRvIHB4LTYgbXQtNlwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIHAtNCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gc2hhZG93LXNtIGZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImZlY2hhRmlsdHJvQXVkaXRvcmlhXCIgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWJsdWUtNTAwXCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk04IDdWM204IDRWM20tOSA4aDEwTTUgMjFoMTRhMiAyIDAgMDAyLTJWN2EyIDIgMCAwMC0yLTJINWEyIDIgMCAwMC0yIDJ2MTJhMiAyIDAgMDAyIDJ6XCIgLz5cbiAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgICBGaWx0cmFyIHBvciBmZWNoYTpcbiAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgaWQ9XCJmZWNoYUZpbHRyb0F1ZGl0b3JpYVwiXG4gICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtmZWNoYUZpbHRyb31cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZlY2hhRmlsdHJvKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXSBmb250LWJvbGQgdGV4dC1zbSB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGUgYmctc2xhdGUtNTAgZGFyazpiZy1bIzFBMjIyQ10gZm9jdXM6Ymctd2hpdGUgZGFyazpmb2N1czpiZy1bIzFBMjIyQ10gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7IWVzSG95ICYmIChcbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEZlY2hhRmlsdHJvKGdldEhveUlTTygpKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMiByb3VuZGVkLXhsIGJnLWJsdWUtNTAgaG92ZXI6YmctYmx1ZS0xMDAgZGFyazpiZy1ibHVlLTkwMC8zMCBkYXJrOmhvdmVyOmJnLWJsdWUtOTAwLzUwIHRleHQtYmx1ZS03MDAgZGFyazp0ZXh0LWJsdWUtMzAwIHRleHQteHMgZm9udC1ibGFjayB0cmFuc2l0aW9uLWFsbCBib3JkZXIgYm9yZGVyLWJsdWUtMjAwIGRhcms6Ym9yZGVyLWJsdWUtODAwIGFjdGl2ZTpzY2FsZS05NSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjIuNVwiIGQ9XCJNMTIgOHY0bDMgM202LTNhOSA5IDAgMTEtMTggMCA5IDkgMCAwMTE4IDB6XCIgLz5cbiAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgICBWb2x2ZXIgYSBIb3lcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7ZmVjaGFGaWx0cm8gJiYgKFxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RmVjaGFGaWx0cm8oJycpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMiByb3VuZGVkLXhsIGJnLXNsYXRlLTEwMCBob3ZlcjpiZy1zbGF0ZS0yMDAgZGFyazpiZy1zbGF0ZS04MDAgZGFyazpob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwXCJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIlZlciB0b2RvcyBsb3MgcmVnaXN0cm9zIHNpbiBmaWx0cm8gZGUgZmVjaGFcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgVmVyIHRvZG9zXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgIHtmZWNoYUZpbHRybyA/IChcbiAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGNhcGl0YWxpemVcIj5cbiAgICAgICAgICAgICAgICAgIHtmb3JtYXRlYXJGZWNoYUxlZ2libGUoZmVjaGFGaWx0cm8pfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICB7ZXNIb3kgPyAoXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1leHRyYWJvbGQgYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtNzAwIGRhcms6YmctZW1lcmFsZC05MDAvMzAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDAgZGFyazpib3JkZXItZW1lcmFsZC04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC01MDAgYW5pbWF0ZS1wdWxzZVwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgSG95XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0zIHB5LTEgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1ib2xkIGJnLXNsYXRlLTEwMCB0ZXh0LXNsYXRlLTYwMCBkYXJrOmJnLXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICBGZWNoYSBTZWxlY2Npb25hZGFcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0zIHB5LTEgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1ib2xkIGJnLXB1cnBsZS01MCB0ZXh0LXB1cnBsZS03MDAgZGFyazpiZy1wdXJwbGUtOTAwLzMwIGRhcms6dGV4dC1wdXJwbGUtNDAwIGJvcmRlciBib3JkZXItcHVycGxlLTIwMCBkYXJrOmJvcmRlci1wdXJwbGUtODAwXCI+XG4gICAgICAgICAgICAgICAgVG9kb3MgbG9zIHJlZ2lzdHJvcyByZWNpZW50ZXNcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIOKUgOKUgCBGaWx0cm8geSBUYWJsYSBkZSBMb2dzIOKUgOKUgCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctNnhsIG14LWF1dG8gcHgtNiBtdC02XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItWyMzMTNENEFdIHNoYWRvdy1zbSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTQgcHgtNiBweS01IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItWyMzMTNENEFdXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImgtMi41IHctMi41IHJvdW5kZWQtZnVsbCBiZy1ibHVlLTUwMFwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWxnIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgIHtmZWNoYUZpbHRybyA/IChlc0hveSA/ICdSZWdpc3Ryb3MgZGUgSG95JyA6IGBSZWdpc3Ryb3MgZGVsICR7ZmVjaGFGaWx0cm99YCkgOiAnVG9kb3MgbG9zIFJlZ2lzdHJvcyd9XG4gICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LWJvbGQgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICB7ZmlsdGVyZWRMb2dzLmxlbmd0aH0ge2ZpbHRlcmVkTG9ncy5sZW5ndGggPT09IDEgPyAnZXZlbnRvJyA6ICdldmVudG9zJ31cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQnVzY2FyIHBvciB1c3VhcmlvLCBhY2Npw7NuIG8gbcOzZHVsby4uLlwiXG4gICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2hUZXJtfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaFRlcm0oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gYmctc2xhdGUtNTAgZGFyazpiZy1bIzFBMjIyQ10gdGV4dC1zbSB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGUgdy03MiBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS01MDBcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHtsb2FkaW5nID8gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xNiB0ZXh0LXNsYXRlLTQwMCBmb250LW1lZGl1bVwiPkNhcmdhbmRvIGJpdMOhY29yYSBkZSBhdWRpdG9yw61hLi4uPC9kaXY+XG4gICAgICAgICAgKSA6IGZpbHRlcmVkTG9ncy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTE2IHRleHQtc2xhdGUtNDAwIGZvbnQtbWVkaXVtIHNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICA8cD5cbiAgICAgICAgICAgICAgICB7ZmVjaGFGaWx0cm9cbiAgICAgICAgICAgICAgICAgID8gYE5vIHNlIGVuY29udHJhcm9uIHJlZ2lzdHJvcyBkZSBhdWRpdG9yw61hIHBhcmEgZWwgJHtlc0hveSA/ICdkw61hIGRlIGhveScgOiBmZWNoYUZpbHRyb31gXG4gICAgICAgICAgICAgICAgICA6ICdObyBzZSBlbmNvbnRyYXJvbiByZWdpc3Ryb3MgZGUgYXVkaXRvcsOtYSd9XG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgeyFlc0hveSAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEZlY2hhRmlsdHJvKGdldEhveUlTTygpKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMy41IHB5LTEuNSByb3VuZGVkLXhsIGJnLWJsdWUtNTAgZGFyazpiZy1ibHVlLTkwMC8zMCB0ZXh0LWJsdWUtNjAwIGRhcms6dGV4dC1ibHVlLTQwMCB0ZXh0LXhzIGZvbnQtYm9sZCBob3Zlcjp1bmRlcmxpbmVcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBWb2x2ZXIgYSByZWdpc3Ryb3MgZGUgaG95XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0b1wiPlxuICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdFwiPlxuICAgICAgICAgICAgICAgIDx0aGVhZD5cbiAgICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MCBkYXJrOmJnLVsjMUEyMjJDXSBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLVsjMzEzRDRBXVwiPlxuICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNSBweS0zLjUgdGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwXCI+RmVjaGEgeSBIb3JhPC90aD5cbiAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTUgcHktMy41IHRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMFwiPlVzdWFyaW8gUmVzcG9uc2FibGU8L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNSBweS0zLjUgdGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwXCI+SVAgRGlzcG9zaXRpdm88L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNSBweS0zLjUgdGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwXCI+QWNjacOzbjwvdGg+XG4gICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC01IHB5LTMuNSB0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDBcIj5Nw7NkdWxvIC8gRW50aWRhZDwvdGg+XG4gICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC01IHB5LTMuNSB0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgdGV4dC1jZW50ZXJcIj5EZXRhbGxlczwvdGg+XG4gICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1zbGF0ZS0xMDAgZGFyazpkaXZpZGUtWyMzMTNENEFdXCI+XG4gICAgICAgICAgICAgICAgICB7cGFnaW5hdGVkTG9ncy5tYXAoKGxvZywgaSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBlc0luc2VydCA9IGxvZy5hY2Npb24gPT09ICdJTlNFUlQnXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGVzVXBkYXRlID0gbG9nLmFjY2lvbiA9PT0gJ1VQREFURSdcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZXNEZWxldGUgPSBsb2cuYWNjaW9uID09PSAnREVMRVRFJ1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBlc0xvZ2luT0sgPSBsb2cuYWNjaW9uID09PSAnTE9HSU5fU1VDQ0VTUydcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZXNMb2dpbkZhaWwgPSBsb2cuYWNjaW9uID09PSAnTE9HSU5fRkFJTEVEJ1xuXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHVzdWFyaW9Ob21icmUgPSBsb2cubm9tYnJlX3VzdWFyaW8gXG4gICAgICAgICAgICAgICAgICAgICAgPyBgJHtsb2cubm9tYnJlX3VzdWFyaW99ICR7bG9nLmFwZWxsaWRvX3VzdWFyaW8gfHwgJyd9YFxuICAgICAgICAgICAgICAgICAgICAgIDogbG9nLmRldGFsbGU/Lm51ZXZvPy5pZF91c3VhcmlvIFxuICAgICAgICAgICAgICAgICAgICAgICAgPyBgVXN1YXJpbyAjJHtsb2cuZGV0YWxsZS5udWV2by5pZF91c3VhcmlvfWBcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ1Npc3RlbWEgLyBBdXRvbcOhdGljbydcblxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2xvZy5pZF9sb2d9IGNsYXNzTmFtZT17aSAlIDIgPT09IDAgPyAnYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0nIDogJ2JnLXNsYXRlLTUwLzUwIGRhcms6YmctWyMxQTIyMkNdLzUwJ30+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNSBweS00IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIHdoaXRlc3BhY2Utbm93cmFwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtsb2cuZmVjaGFfaG9yYSA/IG5ldyBEYXRlKGxvZy5mZWNoYV9ob3JhKS50b0xvY2FsZVN0cmluZygpIDogJ+KAlCd9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTUgcHktNCB0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3VzdWFyaW9Ob21icmV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bG9nLmNvcnJlb191c3VhcmlvIHx8IGxvZy5kZXRhbGxlPy5jb3JyZW9faW50ZW50YWRvIHx8IChsb2cuc2lnbGFfcm9sID8gYFJvbDogJHtsb2cuc2lnbGFfcm9sfWAgOiAnU2lzdGVtYSBJb1QnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC01IHB5LTQgdGV4dC14cyBmb250LW1vbm8gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwIHdoaXRlc3BhY2Utbm93cmFwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtsb2cuaXBfb3JpZ2VuIHx8ICcxMjcuMC4wLjEgKExvY2FsaG9zdCknfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC01IHB5LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcHgtMi41IHB5LTEgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1ibGFjayAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVzTG9naW5PSyA/ICdiZy1pbmRpZ28tMTAwIHRleHQtaW5kaWdvLTcwMCBkYXJrOmJnLWluZGlnby05MDAvMzAgZGFyazp0ZXh0LWluZGlnby00MDAnIDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlc0xvZ2luRmFpbCA/ICdiZy1hbWJlci0xMDAgdGV4dC1hbWJlci04MDAgZGFyazpiZy1hbWJlci05MDAvMzAgZGFyazp0ZXh0LWFtYmVyLTQwMCcgOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVzSW5zZXJ0ID8gJ2JnLWVtZXJhbGQtMTAwIHRleHQtZW1lcmFsZC03MDAgZGFyazpiZy1lbWVyYWxkLTkwMC8zMCBkYXJrOnRleHQtZW1lcmFsZC00MDAnIDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlc1VwZGF0ZSA/ICdiZy1ibHVlLTEwMCB0ZXh0LWJsdWUtNzAwIGRhcms6YmctYmx1ZS05MDAvMzAgZGFyazp0ZXh0LWJsdWUtNDAwJyA6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2JnLXJlZC0xMDAgdGV4dC1yZWQtNzAwIGRhcms6YmctcmVkLTkwMC8zMCBkYXJrOnRleHQtcmVkLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsb2cuYWNjaW9ufVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTUgcHktNCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7bG9nLm1vZHVsbyB8fCBsb2cuZW50aWRhZH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNSBweS00IHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRMb2dEZXRhbGxlKGxvZyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgcm91bmRlZC14bCBiZy1zbGF0ZS0xMDAgaG92ZXI6YmctYmx1ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGhvdmVyOnRleHQtYmx1ZS02MDAgZm9udC1ib2xkIHRleHQteHMgdHJhbnNpdGlvbi1hbGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZlciBEYXRvc1xuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7Lyog4pSA4pSAIFBhZ2luYWNpw7NuIGRlIDIwIHJlZ2lzdHJvcyDilIDilIAgKi99XG4gICAgICAgICAge2ZpbHRlcmVkTG9ncy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNCBweC02IHB5LTQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gYmctc2xhdGUtNTAvNTAgZGFyazpiZy1bIzFBMjIyQ10vNTBcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICBNb3N0cmFuZG8gPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIj57c3RhcnRJbmRleCArIDF9PC9zcGFuPiBheycgJ31cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPntlbmRJbmRleH08L3NwYW4+IGRleycgJ31cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPntmaWx0ZXJlZExvZ3MubGVuZ3RofTwvc3Bhbj4gcmVnaXN0cm9zXG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEN1cnJlbnRQYWdlKChwcmV2KSA9PiBNYXRoLm1heChwcmV2IC0gMSwgMSkpfVxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3ZhbGlkQ3VycmVudFBhZ2UgPD0gMX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCBkaXNhYmxlZDpvcGFjaXR5LTQwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCBob3ZlcjpiZy1zbGF0ZS01MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCBzaGFkb3ctc21cIlxuICAgICAgICAgICAgICAgICAgdGl0bGU9XCJQw6FnaW5hIGFudGVyaW9yXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNCBoLTRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMi41XCIgZD1cIk0xNSAxOWwtNy03IDctN1wiIC8+XG4gICAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgICAgIEFudGVyaW9yXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHB4LTJcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgUMOhZ2luYSB7dmFsaWRDdXJyZW50UGFnZX0gZGUge3RvdGFsUGFnZXN9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEN1cnJlbnRQYWdlKChwcmV2KSA9PiBNYXRoLm1pbihwcmV2ICsgMSwgdG90YWxQYWdlcykpfVxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3ZhbGlkQ3VycmVudFBhZ2UgPj0gdG90YWxQYWdlc31cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgYmctd2hpdGUgZGFyazpiZy1bIzI0MzAzRl0gdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCBkaXNhYmxlZDpvcGFjaXR5LTQwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCBob3ZlcjpiZy1zbGF0ZS01MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCBzaGFkb3ctc21cIlxuICAgICAgICAgICAgICAgICAgdGl0bGU9XCJQw6FnaW5hIHNpZ3VpZW50ZVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgU2lndWllbnRlXG4gICAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNCBoLTRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cbiAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMi41XCIgZD1cIk05IDVsNyA3LTcgN1wiIC8+XG4gICAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7Lyog4pSA4pSAIE1PREFMIFZFUiBERVRBTExFUyBERSBBVURJVE9Sw41BIOKUgOKUgCAqL31cbiAgICAgIHtsb2dEZXRhbGxlICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotWzk5OTk5XSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1zbGF0ZS05MDAvNjAgYmFja2Ryb3AtYmx1ci1zbSBwLTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctWyMyNDMwM0ZdIHJvdW5kZWQtM3hsIG1heC13LWxnIHctZnVsbCBwLTYgc2hhZG93LTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gcmVsYXRpdmVcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1bIzMxM0Q0QV0gbWItNFwiPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtd2hpdGVcIj5EZXRhbGxlIGRlIEF1ZGl0b3LDrWEgI3tsb2dEZXRhbGxlLmlkX2xvZ308L2gzPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5UYWJsYToge2xvZ0RldGFsbGUuZW50aWRhZH0gfCBBY2Npw7NuOiB7bG9nRGV0YWxsZS5hY2Npb259PC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRMb2dEZXRhbGxlKG51bGwpfSBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS01MDAgaG92ZXI6Ymctc2xhdGUtMjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+4pyVPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgbWItMVwiPlBheWxvYWQgSlNPTiBkZSBDYW1iaW9zPC9wPlxuICAgICAgICAgICAgICAgIDxwcmUgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQteGwgYmctc2xhdGUtOTAwIHRleHQtZW1lcmFsZC00MDAgdGV4dC14cyBmb250LW1vbm8gb3ZlcmZsb3cteC1hdXRvIG1heC1oLTYwXCI+XG4gICAgICAgICAgICAgICAgICB7SlNPTi5zdHJpbmdpZnkobG9nRGV0YWxsZS5kZXRhbGxlLCBudWxsLCAyKX1cbiAgICAgICAgICAgICAgICA8L3ByZT5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldExvZ0RldGFsbGUobnVsbCl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG10LTQgcHktMi41IHJvdW5kZWQteGwgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTkwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCB0ZXh0LXNtIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIENlcnJhclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdfQ==